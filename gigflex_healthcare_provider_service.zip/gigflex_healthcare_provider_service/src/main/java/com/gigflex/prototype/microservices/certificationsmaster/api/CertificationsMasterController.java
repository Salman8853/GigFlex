package com.gigflex.prototype.microservices.certificationsmaster.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMasterRequest;
import com.gigflex.prototype.microservices.certificationsmaster.service.CertificationsMasterService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class CertificationsMasterController {
	
	@Autowired
	public CertificationsMasterService cerificationsMasterService;
	
	@GetMapping("/certifications/{search}")
	public String search(@PathVariable("search") String search) {
		return cerificationsMasterService.search(search);
	}
	
	@GetMapping("/getAllCertificationsMaster")
	public String getAllCertificationsMaster() {
		return cerificationsMasterService.findAllCertificationsMaster();
	}
	@GetMapping(path="/getAllCertificationsMasterByPage")
    public String getAllCertificationsMasterByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String cm = cerificationsMasterService.getCertificationsMasterByPage(page, limit);
      
        return cm;
       
    }

	@GetMapping("/getCertificationsMaster/{id}")
	public String getCertificationsMasterById(@PathVariable Long id) {
		return cerificationsMasterService.findCertificationsMasterById(id);
	}

	@GetMapping("/getCertificationsMasterByCertificationCode/{certificationCode}")
	public String getCertificationsMasterByCertificationCode(@PathVariable String certificationCode) {
		return cerificationsMasterService.getCertificationsMasterByCertificationCode(certificationCode);
	}
	
//	@GetMapping("/getCertificationsMasterByWorkerCode/{workerCode}")
//	public String getCertificationsMasterByWorkerCode(@PathVariable String workerCode){
//		return cerificationsMasterService.getCertificationsMasterByWorkerCode(workerCode);
//	}
	
//	@GetMapping("/getCertificationsMasterByWorkerCodeAssigned/{workerCode}")
//	public String getCertificationsMasterByWorkerCodeAssigned(@PathVariable String workerCode){
//		return cerificationsMasterService.getCertificationsMasterByWorkerCodeAssigned(workerCode);
//	}
	
	@GetMapping("/getCertificationsMasterByOrganizationCode/{organization_code}")
	public String getCertificationsMasterByOrganizationCode(@PathVariable String organization_code){
		return cerificationsMasterService.getCertificationsMasterByOrganizationCode(organization_code);
	}
	
//	@GetMapping("/getCertificationsMasterByWorkerCodeByPage/{workerCode}")
//	public String getCertificationsMasterByWorkerCodeByPage(@PathVariable String workerCode,@RequestParam(value = "page", defaultValue = "0") int page,
//            @RequestParam(value = "limit", defaultValue = "30") int limit) {
//
//        String cm = cerificationsMasterService.getCertificationsMasterByWorkerCode(workerCode,page, limit);
//      
//		return cm;
//	}
	
	@GetMapping("/getCertificationsMasterByOrganizationCodeByPage/{organization_code}")
	public String getCertificationsMasterByOrganizationCodeByPage(@PathVariable String organization_code,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String cm = cerificationsMasterService.getCertificationsMasterByOrganizationCode(organization_code,page, limit);
      
		return cm;
	}

	@PostMapping("/saveCertificationsMaster")
	public String saveCertificationsMaster(
			@RequestBody CertificationsMasterRequest certiMasterReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return cerificationsMasterService.saveCertificationsMaster(certiMasterReq, ip);

	}

	@DeleteMapping("/deleteCertificationsMaster/{id}")
	public String deleteCertificationsMasterById(@PathVariable Long id) {
		return cerificationsMasterService.deleteCertificationsMasterById(id);
	}
	
	@DeleteMapping("/deleteCertificationsMasterByCertificationCode/{certificationCode}")
	public String deleteCertificationsMasterByCertificationCode(@PathVariable String certificationCode) {
		return cerificationsMasterService.deleteByCertificationCode(certificationCode);
	}
	
	@DeleteMapping("/softDeleteCertificationsMasterByCertificationCode/{certificationCode}")
	public String softDeleteCertificationsMasterByCertificationCode(@PathVariable String certificationCode) {
		return cerificationsMasterService.softDeleteByCertificationCode(certificationCode);
	}
	
	@DeleteMapping("/softMultipleDeleteByCertificationCode/{certificationCodeList}")
	public String softMultipleDeleteByCertificationCode(@PathVariable List<String> certificationCodeList) {
		if(certificationCodeList != null && certificationCodeList.size()>0){
			return cerificationsMasterService.softMultipleDeleteByCertificationCode(certificationCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
		
	}

	@PutMapping("/updateCertificationsMaster/{id}")
	public String updateCertificationsMaster(@PathVariable Long id,
			 @RequestBody CertificationsMasterRequest certiMasterReq,
			HttpServletRequest request) {

		if (id == null) {
			return "Role Master with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return cerificationsMasterService.updateCertificationsMasterById(id, certiMasterReq, ip);

		}

	}
	

}
