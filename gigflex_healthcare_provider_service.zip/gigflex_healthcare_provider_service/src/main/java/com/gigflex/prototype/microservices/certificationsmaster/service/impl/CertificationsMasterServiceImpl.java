package com.gigflex.prototype.microservices.certificationsmaster.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMasterRequest;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMasterResponse;
import com.gigflex.prototype.microservices.certificationsmaster.repository.CertificationsMasterRepository;
import com.gigflex.prototype.microservices.certificationsmaster.search.CertificationsMasterSpecificationsBuilder;
import com.gigflex.prototype.microservices.certificationsmaster.service.CertificationsMasterService;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.skillmaster.repository.SkillMasterDao;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@Service
public class CertificationsMasterServiceImpl implements
		CertificationsMasterService {

	private static final Logger LOG = LoggerFactory
			.getLogger(CertificationsMasterServiceImpl.class);

	@Autowired
	private CertificationsMasterRepository certificationsMasterRepository;

        @Autowired
	private SkillMasterDao skillMasterDao;

	@Override
	public String updateCertificationsMasterById(Long id,
			CertificationsMasterRequest cermasterreq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && cermasterreq != null) {
				if (cermasterreq.getCertificationName() != null
						&& cermasterreq.getCertificationName().trim().length() > 0 &&
                                       cermasterreq.getOrganizationCode()!=null &&  cermasterreq.getOrganizationCode().trim().length()>0 
                                        && cermasterreq.getSkillCode() != null && cermasterreq.getSkillCode().trim().length() > 0 
                                        && cermasterreq.getCertificationUrl() != null && cermasterreq.getCertificationUrl().trim().length() >0) {

					CertificationsMaster certimasterInDb = certificationsMasterRepository
							.getCertificationsMastersById(id);
					if (certimasterInDb != null && certimasterInDb.getId() > 0) {

						CertificationsMaster certimaster = certimasterInDb;

//						if (!(cermasterreq.getCertificationName()
//								.equals(certimaster.getCertificationName()))) {

                                                SkillMaster skillMaster = skillMasterDao.getSkillMasterBySkillCode(cermasterreq.getSkillCode());
                                     
                                                if(skillMaster == null)
                                                {
                                                    jsonobj.put("responsecode", 400);
                                                    jsonobj.put("timestamp", new Date());
                                                    jsonobj.put("message", "Skill code not exists!");

                                                    return jsonobj.toString();
                                                }
                                                
                                                CertificationsMaster cm = certificationsMasterRepository
                                                                .getCertificationsMasterByCertificationsNameOrgCodeNotID(cermasterreq
                                                                                .getCertificationName().trim(),cermasterreq.getOrganizationCode().trim(),id);
                                                if (cm != null && cm.getId() > 0) {

                                                        jsonobj.put("responsecode", 409);
                                                        jsonobj.put("timestamp", new Date());
                                                        jsonobj.put("message", "Record already exists!");
                                                } else {

                                                        certimaster.setCertificationName(cermasterreq
                                                                        .getCertificationName());
                                                        if (cermasterreq.getIsAssigned() != null) {
                                                                certimaster.setIsAssigned(cermasterreq
                                                                                .getIsAssigned());
                                                        } else {
                                                                certimaster.setIsAssigned(false);
                                                        }
                                                        certimaster.setOrganizationCode(cermasterreq.getOrganizationCode());
                                                        certimaster.setIpAddress(ip);
                                                        certimaster.setCertificationUrl(cermasterreq.getCertificationUrl());
                                                        certimaster.setSkillCode(cermasterreq.getSkillCode()); 
                                                        
                                                        CertificationsMaster certimasterRes = certificationsMasterRepository
                                                                        .save(certimaster);
                                                        if (certimasterRes != null
                                                                        && certimasterRes.getId() > 0) {
                                                                jsonobj.put("responsecode", 200);
                                                                jsonobj.put("message",
                                                                                "CertificationsMaster updation has been done");
                                                                jsonobj.put("timestamp", new Date());
                                                                ObjectMapper mapperObj = new ObjectMapper();
                                                                String Detail = mapperObj
                                                                                .writeValueAsString(certimasterRes);
                                                                jsonobj.put("data", new JSONObject(Detail));

//									kafkaService
//											.sendCertificationsMasterUpdate(certimasterRes);
                                                        } else {
                                                                jsonobj.put("responsecode", 400);
                                                                jsonobj.put("message",
                                                                                "CertificationsMaster updation has been failed.");
                                                                jsonobj.put("timestamp", new Date());
                                                        }
                                                }
//						} else {
//							jsonobj.put("responsecode", 400);
//							jsonobj.put("message",
//									"Old Certification name and New Certification name should be different.");
//							jsonobj.put("timestamp", new Date());
//						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"CertificationsMaster ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message",
							"Certification name ,Organization Code ,Skill Code & CertificationUrl should not be blank");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String findAllCertificationsMaster() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        List<CertificationsMasterResponse> cermasterlst=new ArrayList<CertificationsMasterResponse>();
			List<Object> objlst = certificationsMasterRepository.getAllCertificationsMaster();
                        if(objlst!=null && objlst.size()>0)
                        {
                          for(Object obj:objlst)  
                          {
                              Object[] arr = (Object[]) obj;
                                if (arr.length >= 2) {
                                    CertificationsMasterResponse cmres=new CertificationsMasterResponse();
                                    CertificationsMaster cm=(CertificationsMaster) arr[0];
                                    cmres.setCertificationCode(cm.getCertificationCode());
                                    cmres.setCertificationName(cm.getCertificationName());
                                    cmres.setId(cm.getId());
                                    cmres.setIsAssigned(cm.getIsAssigned());
                                    cmres.setOrganizationCode(cm.getOrganizationCode());
                                    if(arr[1]!=null)
                                    {
                                        cmres.setOrganizationName((String) arr[1]);
                                    }
                                    cmres.setCertificationUrl(cm.getCertificationUrl());
                                    cmres.setSkillCode(cm.getSkillCode());
                                    
                                    SkillMaster skillMaster = skillMasterDao.getSkillMasterBySkillCode(cm.getSkillCode());
                                    if(skillMaster != null)
                                    {
                                        cmres.setSkillName(skillMaster.getSkillName()); 
                                    }
                                    cermasterlst.add(cmres);
                                }
                          }
                            
			
			if (cermasterlst != null && cermasterlst.size() > 0) {
                            jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(cermasterlst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
                        }
                        else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String findCertificationsMasterById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			CertificationsMaster certimasterInDb = certificationsMasterRepository
					.getCertificationsMastersById(id);
			if (certimasterInDb != null && certimasterInDb.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(certimasterInDb);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveCertificationsMaster(
			CertificationsMasterRequest cermasterreq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (cermasterreq != null) {
				if (cermasterreq.getCertificationName() != null
						&& cermasterreq.getCertificationName().trim().length() > 0 &&
                                       cermasterreq.getOrganizationCode()!=null &&  cermasterreq.getOrganizationCode().trim().length()>0
                                        && cermasterreq.getSkillCode() != null && cermasterreq.getSkillCode().trim().length() > 0 
                                        && cermasterreq.getCertificationUrl() != null && cermasterreq.getCertificationUrl().trim().length() >0) {

                                        SkillMaster skillMaster = skillMasterDao.getSkillMasterBySkillCode(cermasterreq.getSkillCode());
                                     
                                        if(skillMaster == null)
                                        {
                                            jsonobj.put("responsecode", 400);
                                            jsonobj.put("timestamp", new Date());
                                            jsonobj.put("message", "Skill code not exists!");
                                            
                                            return jsonobj.toString();
                                            
                                        }
                                    
					CertificationsMaster cm = certificationsMasterRepository
							.getCertificationsMasterByCertificationsNameOrgCode(cermasterreq
									.getCertificationName().trim(),cermasterreq.getOrganizationCode().trim());
					if (cm != null && cm.getId() > 0) {

						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record already exists!");
					} else {

						CertificationsMaster cermasterlst = new CertificationsMaster();
						cermasterlst.setCertificationName(cermasterreq
								.getCertificationName());
						if (cermasterreq.getIsAssigned() != null) {
							cermasterlst.setIsAssigned(cermasterreq
									.getIsAssigned());
						} else {
							cermasterlst.setIsAssigned(false);
						}
                                                cermasterlst.setOrganizationCode(cermasterreq.getOrganizationCode());
						cermasterlst.setIpAddress(ip);
                                                cermasterlst.setCertificationUrl(cermasterreq.getCertificationUrl());
                                                cermasterlst.setSkillCode(cermasterreq.getSkillCode()); 

						CertificationsMaster cermasterRes = certificationsMasterRepository
								.save(cermasterlst);

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());

						if (cermasterRes != null && cermasterRes.getId() > 0) {

//							kafkaService.sendCertificationsMaster(cermasterRes);

							jsonobj.put("message",
									"Certifications Master has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(cermasterRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("message", "Failed");
						}
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Certification name ,Organization Code ,Skill Code & CertificationUrl should not be blank");
				}
			} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Invalid input");
				}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteCertificationsMasterById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<CertificationsMaster> cermasterData = certificationsMasterRepository
					.findById(id);
			if (cermasterData.isPresent() && cermasterData.get() != null) {
				certificationsMasterRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message",
						"Certifications Master has been deleted.");
				jsonobj.put("timestamp", new Date());

//				kafkaService
//						.sendCertificationsMasterDelete(cermasterData.get());

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getCertificationsMasterByCertificationCode(
			String certificationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			CertificationsMaster cermasterlst = certificationsMasterRepository
					.getCertificationsMasterByCertificationCode(certificationCode);
			if (cermasterlst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(cermasterlst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteByCertificationCode(String certificationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			CertificationsMaster certimasterlst = certificationsMasterRepository
					.getCertificationsMasterByCertificationCode(certificationCode);
			Integer deleteByCertificationCode = certificationsMasterRepository
					.deleteCertificationsMasterByCertificationCode(certificationCode);
			if (deleteByCertificationCode != 0 && certimasterlst != null
					&& certimasterlst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "CertificationsMaster has been deleted.");
				jsonobj.put("timestamp", new Date());
				res = jsonobj.toString();

//				kafkaService.sendCertificationsMasterDelete(certimasterlst);

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

//	@Override
//	public String getCertificationsMasterByWorkerCode(String workerCode) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//
//			if (workerCode != null && workerCode.length() > 0) {
//				List<CertificationsMaster> certimasterlst = new ArrayList<CertificationsMaster>();
//				certimasterlst = certificationsMasterRepository
//						.getCertificationsMasterByWorkerCode(workerCode);
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//
//				if (certimasterlst != null && certimasterlst.size() > 0) {
//					ObjectMapper mapperObj = new ObjectMapper();
//					String Detail = mapperObj
//							.writeValueAsString(certimasterlst);
//					jsonobj.put("data", new JSONArray(Detail));
//
//				} else {
//					jsonobj.put("responsecode", 404);
//					jsonobj.put("timestamp", new Date());
//					jsonobj.put("message", "Record Not Found");
//
//				}
//			} else {
//				jsonobj.put("responsecode", 400);
//				jsonobj.put("timestamp", new Date());
//				jsonobj.put("message", "Invalid Input");
//			}
//
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		}
//		return res;
//	}

	@Override
	public String getCertificationsMasterByOrganizationCode(
			String organization_Code) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (organization_Code != null && organization_Code.trim().length() > 0) {
                        List<CertificationsMasterResponse> cermasterlst=new ArrayList<CertificationsMasterResponse>();
			List<Object> objlst = certificationsMasterRepository.getCertificationsMasterByOrganizationCode(organization_Code.trim());
                        if(objlst!=null && objlst.size()>0)
                        {
                          for(Object obj:objlst)  
                          {
                              Object[] arr = (Object[]) obj;
                                if (arr.length >= 2) {
                                    CertificationsMasterResponse cmres=new CertificationsMasterResponse();
                                    CertificationsMaster cm=(CertificationsMaster) arr[0];
                                    cmres.setCertificationCode(cm.getCertificationCode());
                                    cmres.setCertificationName(cm.getCertificationName());
                                    cmres.setId(cm.getId());
                                    cmres.setIsAssigned(cm.getIsAssigned());
                                    cmres.setOrganizationCode(cm.getOrganizationCode());
                                    if(arr[1]!=null)
                                    {
                                        cmres.setOrganizationName((String) arr[1]);
                                    }
                                    cmres.setCertificationUrl(cm.getCertificationUrl());
                                    cmres.setSkillCode(cm.getSkillCode());
                                    
                                    SkillMaster skillMaster = skillMasterDao.getSkillMasterBySkillCode(cm.getSkillCode());
                                    if(skillMaster != null)
                                    {
                                        cmres.setSkillName(skillMaster.getSkillName()); 
                                    }
                                    
                                    
                                    cermasterlst.add(cmres);
                                }
                          }
                            
			
			if (cermasterlst != null && cermasterlst.size() > 0) {
                            jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(cermasterlst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
                        }
                        else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
                        
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Organization code should not be blank");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByCertificationCode(String certificationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			CertificationsMaster certimasterlst = certificationsMasterRepository
					.getCertificationsMasterByCertificationCode(certificationCode);
			if (certimasterlst != null && certimasterlst.getId() > 0) {

				certimasterlst.setIsDeleted(true);
				CertificationsMaster CertiMasterDataRes = certificationsMasterRepository
						.save(certimasterlst);
				if (CertiMasterDataRes != null
						&& CertiMasterDataRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Certification Master deleted successfully.");
//					kafkaService
//							.sendCertificationsMasterUpdate(CertiMasterDataRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteByCertificationCode>>>>>>", ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteByCertificationCode>>>>>>", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByCertificationCode(
			List<String> certificationCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String certificationCode : certificationCodeList) {
				if (certificationCode != null
						&& certificationCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					certificationCode = certificationCode.trim();

					CertificationsMaster certimasterlst = certificationsMasterRepository
							.getCertificationsMasterByCertificationCode(certificationCode);
					if (certimasterlst != null && certimasterlst.getId() > 0) {

						try {

							certimasterlst.setIsDeleted(true);
							CertificationsMaster CertiMasterDataRes = certificationsMasterRepository
									.save(certimasterlst);
							if (CertiMasterDataRes != null
									&& CertiMasterDataRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", certificationCode);
								jsonobj.put("message",
										"Certifications Master deleted successfully.");
//								kafkaService
//										.sendCertificationsMasterUpdate(CertiMasterDataRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", certificationCode);
								jsonobj.put("message", "Failed");
							}
						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", certificationCode);
							jsonobj.put("message",
									GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", certificationCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getCertificationsMasterByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0)
                        {
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<CertificationsMasterResponse> cermasterlst=new ArrayList<CertificationsMasterResponse>();
			List<Object> objlst = certificationsMasterRepository.getAllCertificationsMaster(pageableRequest);
                        
                        if(objlst!=null && objlst.size()>0)
                        {
                        int count=0;
                        List<Object> objlstcnt = certificationsMasterRepository.getAllCertificationsMaster();
                        if(objlstcnt!=null &&objlstcnt.size()>0)
                        {
                            count=objlstcnt.size();
                        }
                          for(Object obj:objlst)  
                          {
                              Object[] arr = (Object[]) obj;
                                if (arr.length >= 2) {
                                    CertificationsMasterResponse cmres=new CertificationsMasterResponse();
                                    CertificationsMaster cm=(CertificationsMaster) arr[0];
                                    cmres.setCertificationCode(cm.getCertificationCode());
                                    cmres.setCertificationName(cm.getCertificationName());
                                    cmres.setId(cm.getId());
                                    cmres.setIsAssigned(cm.getIsAssigned());
                                    cmres.setOrganizationCode(cm.getOrganizationCode());
                                    if(arr[1]!=null)
                                    {
                                        cmres.setOrganizationName((String) arr[1]);
                                    }
                                    cmres.setCertificationUrl(cm.getCertificationUrl());
                                    cmres.setSkillCode(cm.getSkillCode());
                                    
                                    SkillMaster skillMaster = skillMasterDao.getSkillMasterBySkillCode(cm.getSkillCode());
                                    if(skillMaster != null)
                                    {
                                        cmres.setSkillName(skillMaster.getSkillName()); 
                                    }
                                    
                                    
                                    cermasterlst.add(cmres);
                                }
                          }
                            
			
			if (cermasterlst != null && cermasterlst.size() > 0) {
                            jsonobj.put("responsecode", 200);
			jsonobj.put("count", count);
                        jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(cermasterlst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
                        }
                        else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

//	@Override
//	public String getCertificationsMasterByWorkerCode(String workerCode,
//			int page, int limit) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//
//			if (workerCode != null && workerCode.length() > 0) {
//				Pageable pageableRequest = PageRequest.of(page, limit);
//				List<CertificationsMaster> certimasterlst = new ArrayList<CertificationsMaster>();
//				certimasterlst = certificationsMasterRepository
//						.getCertificationsMasterByWorkerCode(workerCode,
//								pageableRequest);
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//
//				if (certimasterlst != null && certimasterlst.size() > 0) {
//					ObjectMapper mapperObj = new ObjectMapper();
//					String Detail = mapperObj
//							.writeValueAsString(certimasterlst);
//					jsonobj.put("data", new JSONArray(Detail));
//
//				} else {
//					jsonobj.put("responsecode", 404);
//					jsonobj.put("timestamp", new Date());
//					jsonobj.put("message", "Record Not Found");
//
//				}
//			} else {
//				jsonobj.put("responsecode", 400);
//				jsonobj.put("timestamp", new Date());
//				jsonobj.put("message", "Invalid Input");
//			}
//
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		}
//		return res;
//	}
//
	@Override
	public String getCertificationsMasterByOrganizationCode(
			String organization_Code, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0)
                        {
			Pageable pageableRequest = PageRequest.of(page, limit);
                        
			if (organization_Code != null && organization_Code.trim().length() > 0) {
                        List<CertificationsMasterResponse> cermasterlst=new ArrayList<CertificationsMasterResponse>();
			List<Object> objlst = certificationsMasterRepository.getCertificationsMasterByOrganizationCode(organization_Code.trim(),pageableRequest);
                        if(objlst!=null && objlst.size()>0)
                        {
                            int count=0;
                            List<Object> objlstcnt = certificationsMasterRepository.getCertificationsMasterByOrganizationCode(organization_Code.trim());
                            if(objlstcnt!=null && objlstcnt.size()>0)
                            {
                                count=objlstcnt.size();
                            }
                          for(Object obj:objlst)  
                          {
                              Object[] arr = (Object[]) obj;
                                if (arr.length >= 2) {
                                    CertificationsMasterResponse cmres=new CertificationsMasterResponse();
                                    CertificationsMaster cm=(CertificationsMaster) arr[0];
                                    cmres.setCertificationCode(cm.getCertificationCode());
                                    cmres.setCertificationName(cm.getCertificationName());
                                    cmres.setId(cm.getId());
                                    cmres.setIsAssigned(cm.getIsAssigned());
                                    cmres.setOrganizationCode(cm.getOrganizationCode());
                                    if(arr[1]!=null)
                                    {
                                        cmres.setOrganizationName((String) arr[1]);
                                    }
                                    cmres.setCertificationUrl(cm.getCertificationUrl());
                                    cmres.setSkillCode(cm.getSkillCode());
                                    
                                    SkillMaster skillMaster = skillMasterDao.getSkillMasterBySkillCode(cm.getSkillCode());
                                    if(skillMaster != null)
                                    {
                                        cmres.setSkillName(skillMaster.getSkillName()); 
                                    }
                                    
                                    cermasterlst.add(cmres);
                                }
                          }
                            
			
			if (cermasterlst != null && cermasterlst.size() > 0) {
                            jsonobj.put("responsecode", 200);
			jsonobj.put("count", count);
                        jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(cermasterlst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
                        }
                        else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
                        
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Organization code should not be blank");
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

//	@Override
//	public String getCertificationsMasterByWorkerCodeAssigned(String workerCode) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//
//			if (workerCode != null && workerCode.length() > 0) {
//				List<CertificationsMaster> certimasterlst = new ArrayList<CertificationsMaster>();
//				certimasterlst = certificationsMasterRepository
//						.getCertificationsMasterByWorkerCodeAssigned(workerCode);
//				jsonobj.put("responsecode", 200);
//				jsonobj.put("message", "Success");
//				jsonobj.put("timestamp", new Date());
//
//				if (certimasterlst != null && certimasterlst.size() > 0) {
//					ObjectMapper mapperObj = new ObjectMapper();
//					String Detail = mapperObj
//							.writeValueAsString(certimasterlst);
//					jsonobj.put("data", new JSONArray(Detail));
//
//				} else {
//					jsonobj.put("responsecode", 404);
//					jsonobj.put("timestamp", new Date());
//					jsonobj.put("message", "Record Not Found");
//
//				}
//			} else {
//				jsonobj.put("responsecode", 400);
//				jsonobj.put("timestamp", new Date());
//				jsonobj.put("message", "Invalid Input");
//			}
//
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		}
//		return res;
//	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				CertificationsMasterSpecificationsBuilder builder = new CertificationsMasterSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<CertificationsMaster> spec = builder.build();
				if (spec != null) {
					List<CertificationsMaster> certimasterlst = certificationsMasterRepository
							.findAll(spec);
					if (certimasterlst != null && certimasterlst.size() > 0) {
						for (CertificationsMaster cert : certimasterlst) {
							if (cert.getIsDeleted() != null
									&& cert.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(cert);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("CertificationsMaster",
										new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}

				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
