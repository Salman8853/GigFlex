/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.config;

import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.worker.dtob.Worker;

/**
 *
 * @author nirbhay.p
 */
@Configuration
public class ProduceConfig {
    @Bean
    public Map<String, Object> producerConfigs() {

         Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        return props;
    }
    
    
    @Bean
    public ProducerFactory<String, Users> producerFactory() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Users> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
    
    @Bean
    public ProducerFactory<String, Worker> producerFactoryWorker() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Worker> kafkaTemplateWorker() {
        return new KafkaTemplate<>(producerFactoryWorker());
    }
    
    
    @Bean
    public ProducerFactory<String, Organization> producerFactoryOrganization() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Organization> kafkaTemplateOrganization() {
        return new KafkaTemplate<>(producerFactoryOrganization());
    }
    
     @Bean
    public ProducerFactory<String, HealthcareNotification> producerFactoryHealthcareNotification() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, HealthcareNotification> kafkaTemplateHealthcareNotification() {
        return new KafkaTemplate<>(producerFactoryHealthcareNotification());
    }
    
}
