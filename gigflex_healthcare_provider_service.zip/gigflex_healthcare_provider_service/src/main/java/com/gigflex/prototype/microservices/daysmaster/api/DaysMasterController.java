package com.gigflex.prototype.microservices.daysmaster.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMasterRequest;
import com.gigflex.prototype.microservices.daysmaster.service.DaysMasterService;
import com.gigflex.prototype.microservices.util.GigflexResponse;



@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class DaysMasterController {
	
	@Autowired
	public DaysMasterService daysMasterService;
	
	@GetMapping("/daysMaster/{search}")
	public String search(@PathVariable("search") String search) {
		return daysMasterService.search(search);
	}
	
	@GetMapping("/getAllDaysMaster")
	public String getAllDaysMaster(){
		return daysMasterService.findAllDaysMaster();
	}
	
	@GetMapping(path="/getAllDaysMasterByPage")
    public String getAllDaysMasterByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String daysMaster = daysMasterService.getAllDaysMasterByPage(page, limit);
      
        return daysMaster;
       
    }
	
	@GetMapping("/getDaysMaster/{id}")
	public String getDaysMasterById(@PathVariable Integer id){
		return daysMasterService.findDaysMasterById(id);
		}
	
	@GetMapping("/getByDaysCode/{daysCode}")
	public String getDaysMasterByCode(@PathVariable String daysCode) {
		return daysMasterService.findByDaysCode(daysCode);
	}
	
	  @PostMapping("/saveDaysMaster")
	    public String saveNewDaysMaster(@RequestBody DaysMasterRequest daysMasterReq,HttpServletRequest request){
			String ip = request.getRemoteAddr();

		  return daysMasterService.saveDaysMaster(daysMasterReq,ip);
	    	
	    }
	  
	   @DeleteMapping("/deleteDaysMaster/{id}")
	    public String deleteDaysMasterById(@PathVariable Integer id){
	    	return daysMasterService.deleteDaysMasterById(id);
	    }
	   
	   @DeleteMapping("/deleteBydaysCode/{daysCode}")
	    public String deleteDaysMasterByCode(@PathVariable String daysCode){
	    	return daysMasterService.deleteDaysMasterByDaysCode(daysCode);
	    }
	   
	   @DeleteMapping("/softDeleteByDaysCode/{daysCode}")
	    public String softDeleteByDaysCode(@PathVariable String daysCode){
	    	return daysMasterService.softDeleteDaysMasterByDaysCode(daysCode);
	    }
	   
	   @DeleteMapping("/softMultipleDeleteByDaysCode/{daysCodeList}")
		public String softMultipleDeleteByUserCode(@PathVariable List<String> daysCodeList) {
			if(daysCodeList != null && daysCodeList.size()>0){
				return daysMasterService.softMultipleDeleteByDaysCode(daysCodeList);
			}else{
				 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
		           return derr.toString();
			}
			
		}
	    
	    @PutMapping("/updateDaysMaster/{id}")
		public String updateDaysMaster(@PathVariable Integer id, @RequestBody DaysMasterRequest daysMasterReq,HttpServletRequest request) {

			if (id == null) {
				return  "Days Master with Id : (" + id + ") Not found.";
			} else {
				String ip = request.getRemoteAddr();

				return daysMasterService.updateDaysMasterById(id, daysMasterReq,ip);
			}
		}

}
