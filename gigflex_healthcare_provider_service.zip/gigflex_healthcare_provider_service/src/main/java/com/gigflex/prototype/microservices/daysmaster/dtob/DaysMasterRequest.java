package com.gigflex.prototype.microservices.daysmaster.dtob;


public class DaysMasterRequest {
	

	 private String daysName;

	public String getDaysName() {
		return daysName;
	}

	public void setDaysName(String daysName) {
		this.daysName = daysName;
	}
	 
	 

}
