/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.department.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.department.dtob.DepartmentMaster;
import com.gigflex.prototype.microservices.department.dtob.DepartmentMasterOrgNameResponse;
import com.gigflex.prototype.microservices.department.dtob.DepartmentMasterRequest;
import com.gigflex.prototype.microservices.department.repository.DepartmentMasterRepository;
import com.gigflex.prototype.microservices.department.search.DepartmentMasterSpecificationsBuilder;
import com.gigflex.prototype.microservices.department.service.DepartmentMasterService;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;

/**
 *
 * @author nirbhay.p
 */

@Service
public class DepartmentMasterServiceImpl implements DepartmentMasterService {
	
	private static final Logger LOG = LoggerFactory
			.getLogger(DepartmentMasterServiceImpl.class);

	@Autowired
	DepartmentMasterRepository departmentMasterRepository;
	

	@Autowired
	OrganizationRepository orgDao;
        
        
        private Boolean ischildparent=false;

	@Override
	public String getAllDepartment() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<DepartmentMaster> deptlst = departmentMasterRepository
					.getAllDepartmentMaster();
			List<DepartmentMaster> deptlstRes = new ArrayList<DepartmentMaster>();
			for (DepartmentMaster dept : deptlst) {
				dept.setParentid();
				dept.setParentName();
				// Long parentid = dept.getParentidLong();
				// DepartmentMaster deptlst1 =
				// departmentMasterRepository.getDepartmentMasterById(parentid);
				// dept.setParentName(deptlst1.getDepartmentName());
				deptlstRes.add(dept);
			}
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (deptlstRes != null && deptlstRes.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(deptlstRes);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllDepartmentByID(long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DepartmentMaster deptlst = departmentMasterRepository
					.getDepartmentMasterById(id);
			if (deptlst != null && deptlst.getId() > 0) {

				DepartmentMaster dept = deptlst;
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (dept != null) {
					dept.setParentid();

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(dept);

					jsonobj.put("data", new JSONObject(Detail));
				}
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveNewDepartment(DepartmentMasterRequest deptReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (deptReq != null) {

				if (deptReq.getDepartmentName() != null
						&& deptReq.getDepartmentName().trim().length() > 0
						&& deptReq.getOrganizationCode() != null
						&& deptReq.getOrganizationCode().trim().length() > 0) {

					Organization org = orgDao.findByOrganizationCode(deptReq
							.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						DepartmentMaster deptMast = departmentMasterRepository
								.getDepartmentMasterByOrgCodeDeptName(
										deptReq.getOrganizationCode(),
										deptReq.getDepartmentName());
						if (deptMast != null && deptMast.getId() > 0) {
							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Record already exist.");
						} else {
                                                    boolean invalidparent=false;
                                                    if(deptReq.getParentid()!=null && deptReq.getParentid()>0)
                                                    {
                                                       DepartmentMaster deptres= departmentMasterRepository.getDepartmentMasterById(deptReq.getParentid());
                                                       if(deptres!=null && deptres.getId()>0)
                                                       {
                                                           invalidparent=false;
                                                       }
                                                       else
                                                               {
                                                                  invalidparent=true; 
                                                               }
                                                    }
                                                    if(invalidparent)
                                                    {
                                                        jsonobj.put("responsecode", 404);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Parent is not valid.");
                                                    }
                                                    else
                                                    {
							DepartmentMaster dept = new DepartmentMaster();
							dept.setDepartmentName(deptReq.getDepartmentName());
							dept.setOrganizationCode(deptReq
									.getOrganizationCode());
							dept.setIpAddress(ip);
							if (deptReq.getParentid() != null
									&& deptReq.getParentid() > 0) {
								Optional<DepartmentMaster> deptlst = departmentMasterRepository
										.findById(deptReq.getParentid());
								if (deptlst != null && deptlst.get() != null) {
									dept.setParent(deptlst.get());
								}
							}
							DepartmentMaster deptRes = departmentMasterRepository
									.save(dept);
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							if (deptRes != null && deptRes.getId() > 0) {
								if (deptRes.getParent() != null
										&& deptRes.getParent().getId() > 0) {
									deptRes.setParentid(deptRes.getParent()
											.getId());
								}
//								kafkaService.sendDepartment(deptRes);
								jsonobj.put("message",
										"Department has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(deptRes);
								jsonobj.put("data", new JSONObject(Detail));
							}

							else {
								jsonobj.put("message", "Failed");
							}
						}}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Department Name and Organization Code should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteDepartmentById(long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<DepartmentMaster> deptData = departmentMasterRepository
					.findById(id);
			if (deptData.isPresent() && deptData.get() != null) {
				departmentMasterRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Department has been deleted.");
				jsonobj.put("timestamp", new Date());

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateDepartment(DepartmentMaster deptMaster, Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && deptMaster != null) {

				if (deptMaster.getDepartmentName() != null
						&& deptMaster.getDepartmentName().trim().length() > 0
						&& deptMaster.getOrganizationCode() != null
						&& deptMaster.getOrganizationCode().trim().length() > 0) {

					Organization org = orgDao.findByOrganizationCode(deptMaster
							.getOrganizationCode());
					if (org != null && org.getId() > 0) {
                                            
                                            if(deptMaster.getParentid()!=null && deptMaster.getParentid()>0 && deptMaster.getParentid()==id)
                                            {
                                                jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "You can not assign your self as parent.");
                                            }
                                            else{
						DepartmentMaster deptlst = departmentMasterRepository
								.getDepartmentMasterById(id);
						if (deptlst != null && deptlst.getId() > 0) {
                                                    
                                                    boolean invalidparent=false;
                                                    if(deptMaster.getParentid()!=null && deptMaster.getParentid()>0)
                                                    {
                                                       DepartmentMaster deptres= departmentMasterRepository.getDepartmentMasterById(deptMaster.getParentid());
                                                       if(deptres!=null && deptres.getId()>0)
                                                       {
                                                           invalidparent=false;
                                                       }
                                                       else
                                                               {
                                                                  invalidparent=true; 
                                                               }
                                                    }
                                                    if(invalidparent)
                                                    {
                                                        jsonobj.put("responsecode", 404);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Parent is not valid.");
                                                    }
                                                    else
                                                    {
                                                    
                                                    
                                                    
                                                    ischildparent=false;
                                                    if(deptlst.getChildDepartment()!=null && deptlst.getChildDepartment().size()>0 && deptMaster.getParentid()>0)
                                                    {
//                                                        List<DepartmentMaster> childlst=new ArrayList<DepartmentMaster>();
//                                                                childlst.addAll( deptlst.getChildDepartment());
//                                                        for(DepartmentMaster dm:childlst)
//                                                        {
//                                                            if(dm.getId()==deptMaster.getParentid())
//                                                            {
//                                                                ischildparent=true;
//                                                                break;
//                                                            }
//                                                        }
                                                       ischildparent= checkParentValid(deptlst,deptMaster.getParentid());
                                                    }
                                                    if(ischildparent)
                                                    {
                                                         jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "You can not assign child department as parent.");
                                                    }
                                                    else
                                                    {
							DepartmentMaster deptMast = departmentMasterRepository
									.getDepartmentMasterByIdOrgCodeDeptName(
											id,
											deptMaster.getOrganizationCode(),
											deptMaster.getDepartmentName());
							if (deptMast != null && deptMast.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {

								DepartmentMaster departmentInDb = deptlst;
								if (deptMaster.getParentid() != null
										&& deptMaster.getParentid() > 0) {
									Optional<DepartmentMaster> departmentInDbParent = departmentMasterRepository
											.findById(deptMaster.getParentid());

									if (departmentInDbParent.isPresent()
											&& departmentInDbParent != null
											&& departmentInDbParent.get() != null
											&& departmentInDbParent.get()
													.getId() > 0) {
										DepartmentMaster dept = departmentInDbParent
												.get();
										departmentInDb.setParent(dept);
									}
								}
								departmentInDb.setDepartmentName(deptMaster
										.getDepartmentName());
								departmentInDb.setOrganizationCode(deptMaster
										.getOrganizationCode());
								departmentInDb.setParentid(deptMaster
										.getParentid());
								DepartmentMaster departmentInRes = departmentMasterRepository
										.save(departmentInDb);
								if (departmentInRes != null
										&& departmentInRes.getId() > 0) {
									jsonobj.put("responsecode", 200);
									jsonobj.put("message",
											"Department updation has been done");
									jsonobj.put("timestamp", new Date());
									departmentInRes.setParentid();
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(departmentInRes);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message",
											"Department updation has been failed.");
									jsonobj.put("timestamp", new Date());
								}
							}
                                                    }}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Department ID is not valid.");
							jsonobj.put("timestamp", new Date());
						}
                                            }
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Organization Code not found.");
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Department Name and Organization Code should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDepartmentMasterByDepartmentCode(String departmentCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DepartmentMaster departmentInDb = departmentMasterRepository
					.getDepartmentMasterByDepartmentCode(departmentCode);
			if (departmentInDb != null && departmentInDb.getId() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(departmentInDb);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteByDepartmentCode(String departmentCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Integer deleteByDepartmentCode = departmentMasterRepository
					.deleteByDepartmentCode(departmentCode);
			if (deleteByDepartmentCode != 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "DepartmentMaster has been deleted.");
				jsonobj.put("timestamp", new Date());
				res = jsonobj.toString();
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getDepartmentByParentId(Long parentId) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (parentId != null && parentId > 0) {
				List<DepartmentMaster> deptlst = departmentMasterRepository
						.getDepartmentByParentId(parentId);
				List<DepartmentMaster> deptlstRes = new ArrayList<DepartmentMaster>();
				for (DepartmentMaster dept : deptlst) {
					dept.setParentid();
					deptlstRes.add(dept);
				}
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				if (deptlstRes != null && deptlstRes.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(deptlstRes);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String softDeleteByDepartmentCode(String departmentCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DepartmentMaster departmentlst = departmentMasterRepository
					.getDepartmentMasterByDepartmentCode(departmentCode);

			if (departmentlst != null && departmentlst.getId() > 0) {
				
			
				
				departmentlst.setIsDeleted(true);
				DepartmentMaster deptRes = departmentMasterRepository
						.save(departmentlst);
				if (deptRes != null && deptRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message","Department Master deleted successfully.");
                                        try
                                        {
                                        if(deptRes.getChildDepartment()!=null && deptRes.getChildDepartment().size()>0)
                                        {
                                       deleteAllChild(deptRes);
//                                            List<DepartmentMaster> childlst=new ArrayList<DepartmentMaster>();
//                                                                childlst.addAll( deptRes.getChildDepartment());
//                                                        for(DepartmentMaster dm:childlst)
//                                                        {
//                                                           dm.setIsDeleted(true);
//                                                           DepartmentMaster dmRes = departmentMasterRepository
//						.save(dm);
//                                                        }
                                        }
                                        }catch(Exception e)
                                        {
                                            e.printStackTrace();
                                        }

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}
				}
			
			res = jsonobj.toString();
		} catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        LOG.error("Error in softDeleteByDepartmentCode>>>>>>", ex);
                }catch(org.springframework.orm.jpa.JpaSystemException ex)
                {
                    GigflexResponse derr = new GigflexResponse(401, new Date(), GigUtil.getRootException(ex));
            res = derr.toString();
            ex.printStackTrace();
		} catch (Exception ex) {
		 ex.printStackTrace();
        LOG.error("Error in softDeleteByDepartmentCode>>>>>>", ex);	
                    GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
		// String res = "";
		// try {
		// JSONObject jsonobj = new JSONObject();
		// DepartmentMaster departmentInDb =
		// departmentMasterRepository.getDepartmentMasterByDepartmentCode(departmentCode);
		//
		//
		// if (departmentInDb != null && departmentInDb.getId() > 0) {
		// departmentInDb.setIsDeleted(true);
		// DepartmentMaster deptRes =
		// departmentMasterRepository.save(departmentInDb);
		// if (deptRes != null && deptRes.getId()>0) {
		// jsonobj.put("responsecode", 200);
		// jsonobj.put("timestamp", new Date());
		// jsonobj.put("message", "Department Master deleted successfully.");
		// // kafkaService.send
		// } else {
		// jsonobj.put("responsecode", 400);
		// jsonobj.put("timestamp", new Date());
		// jsonobj.put("message", "Failed");
		// }
		//
		// } else {
		// jsonobj.put("responsecode", 404);
		// jsonobj.put("timestamp", new Date());
		// jsonobj.put("message", "Record Not Found");
		// }
		// res = jsonobj.toString();
		// } catch (Exception ex) {
		// GigflexResponse derr = new GigflexResponse(500, new Date(),
		// "JSON parsing exception occurred.");
		// res = derr.toString();
		// }
		// return res;
	}

	@Override
	public String softMultipleDeleteByDepartmentCode(
			List<String> departmentCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String departmentCode : departmentCodeList) {
				if (departmentCode != null
						&& departmentCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					departmentCode = departmentCode.trim();

					DepartmentMaster departmentlst = departmentMasterRepository
							.getDepartmentMasterByDepartmentCode(departmentCode);
					if (departmentlst != null && departmentlst.getId() > 0) {

						try{
						
						
						departmentlst.setIsDeleted(true);
						DepartmentMaster deptRes = departmentMasterRepository
								.save(departmentlst);
						if (deptRes != null && deptRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", departmentCode);
							jsonobj.put("message",
									"Department Master deleted successfully.");
                                                        try
                                        {
                                        if(deptRes.getChildDepartment()!=null && deptRes.getChildDepartment().size()>0)
                                        {
                                             deleteAllChild(deptRes);
//                                        List<DepartmentMaster> childlst=new ArrayList<DepartmentMaster>();
//                                                                childlst.addAll( deptRes.getChildDepartment());
//                                                        for(DepartmentMaster dm:childlst)
//                                                        {
//                                                           dm.setIsDeleted(true);
//                                                           DepartmentMaster dmRes = departmentMasterRepository
//						.save(dm);
//                                                        }
                                        }
                                        }catch(Exception e)
                                        {
                                            e.printStackTrace();
                                        }
                                                        
							// kafkaService.send
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", departmentCode);
							jsonobj.put("message", "Failed");
						}
						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", departmentCode);
							jsonobj.put("message",
									GigUtil.getRootException(ex));
						}
						}
					
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllDepartmentByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0)
                        {
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<DepartmentMaster> departmentlst = departmentMasterRepository
					.getAllDepartmentMaster(pageableRequest);
			int count=0;
                        List<DepartmentMaster> deptlst = departmentMasterRepository.getAllDepartmentMaster();
                        if(deptlst!=null && deptlst.size()>0)
                        {
                            count=deptlst.size();
                        }
			List<DepartmentMaster> deptlstRes = new ArrayList<DepartmentMaster>();
			for (DepartmentMaster dept : departmentlst) {
				dept.setParentid();
				dept.setParentName();
				// Long parentid = dept.getParentidLong();
				// DepartmentMaster deptlst1 =
				// departmentMasterRepository.getDepartmentMasterById(parentid);
				// dept.setParentName(deptlst1.getDepartmentName());
				deptlstRes.add(dept);
			}
			
			if (deptlstRes != null && deptlstRes.size() > 0) {
                            jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
                        jsonobj.put("count", count);
			jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(deptlstRes);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDepartmentByParentId(Long parentId, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0)
                        {
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (parentId != null && parentId > 0) {
				List<DepartmentMaster> deptlst = departmentMasterRepository
						.getDepartmentByParentId(parentId, pageableRequest);
                                int count=0;
                                List<DepartmentMaster> deptlstcnt = departmentMasterRepository
						.getDepartmentByParentId(parentId);
                                if(deptlstcnt!=null && deptlstcnt.size()>0)
                                {
                                    count=deptlstcnt.size();
                                }
				List<DepartmentMaster> deptlstRes = new ArrayList<DepartmentMaster>();
				for (DepartmentMaster dept : deptlst) {
					dept.setParentid();
					deptlstRes.add(dept);
				}
				if (deptlstRes != null && deptlstRes.size() > 0) {
                                    jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
                                jsonobj.put("count", count);
				jsonobj.put("timestamp", new Date());
				
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(deptlstRes);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				DepartmentMasterSpecificationsBuilder builder = new DepartmentMasterSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<DepartmentMaster> spec = builder.build();
                                if(spec!=null){
				List<DepartmentMaster> deptlst = departmentMasterRepository
						.findAll(spec);
				if (deptlst != null && deptlst.size() > 0) {
					for (DepartmentMaster dept : deptlst) {
						if (dept.getIsDeleted() != null
								&& dept.getIsDeleted() != true) {

							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(dept);
							JSONObject jsonobjNew = new JSONObject();
							jsonobjNew
									.put("department", new JSONObject(Detail));
							jarr.add(jsonobjNew);

						}

					}
					if (jarr.size() > 0) {

						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", jarr);
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}}
                                else{
                                  jsonobj.put("responsecode", 400);
				  jsonobj.put("message", "Record Not Found!");
				  jsonobj.put("timestamp", new Date());  
                                }
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getDepartmentMasterByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {

				List<Object> objlst = departmentMasterRepository
						.getDepartmentMasterByOrgCode(organizationCode);
				List<DepartmentMasterOrgNameResponse> maplst = new ArrayList<DepartmentMasterOrgNameResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							DepartmentMasterOrgNameResponse wplr = new DepartmentMasterOrgNameResponse();

							DepartmentMaster wpl = (DepartmentMaster) arr[0];
							wpl.setParentid();
							wpl.setParentName();
							wplr.setId(wpl.getId());
							wplr.setDepartmentName(wpl.getDepartmentName());
							wplr.setParentid(wpl.getParentid());
							wplr.setParentName(wpl.getParentName());
							wplr.setOrganizationCode(wpl.getOrganizationCode());
							wplr.setOrganizationName((String) arr[1]);

							maplst.add(wplr);
						}
					}
					if (maplst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDepartmentMasterByOrgCodeByPage(String organizationCode,
			int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0)
                        {
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {

				List<Object> objlst = departmentMasterRepository
						.getDepartmentMasterByOrgCodeByPage(organizationCode,
								pageableRequest);
                                int count=0;
                                List<Object> objlstcnt = departmentMasterRepository
						.getDepartmentMasterByOrgCode(organizationCode);
                                if(objlstcnt!=null && objlstcnt.size()>0)
                                {
                                    count=objlstcnt.size();
                                }
				List<DepartmentMasterOrgNameResponse> maplst = new ArrayList<DepartmentMasterOrgNameResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							DepartmentMasterOrgNameResponse wplr = new DepartmentMasterOrgNameResponse();

							DepartmentMaster wpl = (DepartmentMaster) arr[0];

							wpl.setParentid();
							wpl.setParentName();
							wplr.setId(wpl.getId());
							wplr.setDepartmentName(wpl.getDepartmentName());
							wplr.setParentid(wpl.getParentid());
							wplr.setParentName(wpl.getParentName());
							wplr.setOrganizationCode(wpl.getOrganizationCode());
							wplr.setOrganizationName((String) arr[1]);

							maplst.add(wplr);
						}
					}
					if (maplst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(maplst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
                                                jsonobj.put("count", count);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}
        
        
      
        
        public void deleteAllChild(DepartmentMaster deptlst)
        {
            if(deptlst!=null)
            {
                if (deptlst.getChildDepartment() != null && deptlst.getChildDepartment().size() > 0) {
                    
                    List<DepartmentMaster> childlst = new ArrayList<DepartmentMaster>();
                    childlst.addAll(deptlst.getChildDepartment());
                    for (DepartmentMaster dm : childlst) {
                        if (dm!=null && dm.getId() >0) {
                            if( dm.getChildDepartment() != null && dm.getChildDepartment().size() > 0)
                            {
                                deleteAllChild(dm);
                                dm.setIsDeleted(true);
                                DepartmentMaster dmRes = departmentMasterRepository.save(dm);
                            }
                            else
                            {
                                dm.setIsDeleted(true);
                                DepartmentMaster dmRes = departmentMasterRepository.save(dm);
                            }
                           
                        }
                        
                    }
                }
                else
                {
                     deptlst.setIsDeleted(true);
                                DepartmentMaster dmRes = departmentMasterRepository.save(deptlst);
                }
            }

        }
        
        public Boolean checkParentValid(DepartmentMaster deptlst, Long pid)
        {
            
            if(deptlst!=null)
            {
                if (deptlst.getChildDepartment() != null && deptlst.getChildDepartment().size() > 0) {
                    List<DepartmentMaster> childlst = new ArrayList<DepartmentMaster>();
                    childlst.addAll(deptlst.getChildDepartment());
                    for (DepartmentMaster dm : childlst) {
                        if (dm.getId() == pid) {
                             ischildparent=true;
                            return ischildparent;
                           
                        }
                        else if(ischildparent!=true && dm.getChildDepartment() != null && dm.getChildDepartment().size() > 0)
                        {
                            checkParentValid(dm,pid);
                        }
                    }
                } else {
                    return ischildparent;
                }
            }
            else
            {
                return ischildparent;
            }
            return ischildparent;
        }
}
