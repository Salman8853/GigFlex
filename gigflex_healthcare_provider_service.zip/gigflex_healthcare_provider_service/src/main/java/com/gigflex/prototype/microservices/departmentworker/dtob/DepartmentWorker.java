/**
 * 
 */
package com.gigflex.prototype.microservices.departmentworker.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

/**
 * @author ajit.p
 *
 */
@Entity
@Table(name = "organization_department_worker")
public class DepartmentWorker extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "departmentname", nullable = false)
	private String departmentName;
	
	@Column(name = "department_code", nullable = false)
	private String departmentCode;

	@Column(name = "worker_name", nullable = false)
	private String workerName;
	
	@Column(name = "worker_code", nullable = false)
	private String workerCode;
	
	@Column(name = "isassigned", columnDefinition = "boolean default false", nullable = false)
	private Boolean isAssigned = false;


	public DepartmentWorker() {
		super();
	}

	public DepartmentWorker(Long id) {
		super();
		this.id = id;
	}

	public DepartmentWorker(Long id, String departmentName, String departmentCode, String workerName,
			String workerCode) {
		super();
		this.id = id;
		this.departmentName = departmentName;
		this.departmentCode = departmentCode;
		this.workerName = workerName;
		this.workerCode = workerCode;
	}

	public Boolean getIsAssigned() {
		return isAssigned;
	}

	public void setIsAssigned(Boolean isAssigned) {
		this.isAssigned = isAssigned;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	public String getWorkerName() {
		return workerName;
	}

	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "DepartmentWorker [id=" + id + ", departmentName=" + departmentName + ", departmentCode="
				+ departmentCode + ", workerName=" + workerName + ", workerCode=" + workerCode + "]";
	}
	
	

}
