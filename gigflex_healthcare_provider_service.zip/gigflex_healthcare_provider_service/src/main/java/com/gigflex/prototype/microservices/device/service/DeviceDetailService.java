/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.device.service;

import com.gigflex.prototype.microservices.device.dtob.DeviceDetailReq;

/**
 *
 * @author amit.kumar
 */
public interface DeviceDetailService {
    
    public String saveDeviceDetail(DeviceDetailReq dReq, String ip);
}
