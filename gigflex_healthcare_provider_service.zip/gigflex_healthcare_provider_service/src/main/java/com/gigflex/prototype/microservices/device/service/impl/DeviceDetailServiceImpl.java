/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.device.service.impl;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.device.dtob.DeviceDetail;
import com.gigflex.prototype.microservices.device.dtob.DeviceDetailReq;
import com.gigflex.prototype.microservices.device.repository.DeviceDetailRepository;
import com.gigflex.prototype.microservices.device.service.DeviceDetailService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class DeviceDetailServiceImpl implements DeviceDetailService{

    @Autowired
    DeviceDetailRepository deviceDetailDao;
    
    @Override
    public String saveDeviceDetail(DeviceDetailReq dReq, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (dReq != null) {        
                            
			if ( (dReq.getDeviceId()!= null && dReq.getDeviceId().trim().length() >0 
                                && dReq.getUserCode()!=null &&  dReq.getUserCode().length() > 0  
                                && dReq.getDeviceType()!=null &&  dReq.getDeviceType().length() > 0  
                                )) {                                       
                                          
                            
                               DeviceDetail deviceDetailRes = deviceDetailDao.getDeviceDetailByUserCodeAndDeviceType(dReq.getUserCode(),dReq.getDeviceType());
                               DeviceDetail deviceDetailResponse = null;
                                if(deviceDetailRes == null )
                                {
                                    DeviceDetail deviceDetail = new DeviceDetail();

                                    deviceDetail.setDeviceId(dReq.getDeviceId());
                                    deviceDetail.setUserCode(dReq.getUserCode());
                                    deviceDetail.setDeviceType(dReq.getDeviceType()); 
                                    deviceDetail.setIpAddress(ip);

                                    deviceDetailResponse = deviceDetailDao.save(deviceDetail);
                                }
                                else
                                {
                                    deviceDetailRes.setDeviceId(dReq.getDeviceId());
                                    deviceDetailRes.setDeviceType(dReq.getDeviceType());
                                    deviceDetailRes.setIpAddress(ip);
                                    deviceDetailResponse = deviceDetailDao.save(deviceDetailRes);                                    
                                }
                                
                                if (deviceDetailResponse != null && deviceDetailResponse.getId() > 0) {

                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message",
                                                    "Device Details has been saved successfully.");
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(deviceDetailResponse);
                                    jsonobj.put("data", new JSONObject(Detail));
                                } else {
                                    jsonobj.put("responsecode", 400);
                                    jsonobj.put("timestamp", new Date());                                
                                    jsonobj.put("message", "Failed");
                                }
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Device Id ,User Code and Device Type should not be blank");
                            }
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
    }
    
}
