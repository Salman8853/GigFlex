package com.gigflex.prototype.microservices.documentmapping.dtob;



public class DocumentOrganizationMappingRequest {
	
  
    private String documentCode;
   
 
    private String organizationCode;

  

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

   
    
}
