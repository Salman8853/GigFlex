package com.gigflex.prototype.microservices.documentmapping.dtob;

public class DocumentOrganizationMappingResponse {

    private Long id;

    private String organizationDocumentCode;
    
    private String documentCode;

    private String documentName;
    
    private String organizationCode;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrganizationDocumentCode() {
        return organizationDocumentCode;
    }

    public void setOrganizationDocumentCode(String organizationDocumentCode) {
        this.organizationDocumentCode = organizationDocumentCode;
    }
    
    private String organizationName;

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

}
