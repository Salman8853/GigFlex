package com.gigflex.prototype.microservices.documentmapping.dtob;

public class DocumentOrganizationWorkerMappingRequest {
	
    
   private String workerDocumentCode;
   
   private String organizationDocumentCode;
    

    public String getWorkerDocumentCode() {
        return workerDocumentCode;
    }

    public void setWorkerDocumentCode(String workerDocumentCode) {
        this.workerDocumentCode = workerDocumentCode;
    }

    public String getOrganizationDocumentCode() {
        return organizationDocumentCode;
    }

    public void setOrganizationDocumentCode(String organizationDocumentCode) {
        this.organizationDocumentCode = organizationDocumentCode;
    }

    
}
