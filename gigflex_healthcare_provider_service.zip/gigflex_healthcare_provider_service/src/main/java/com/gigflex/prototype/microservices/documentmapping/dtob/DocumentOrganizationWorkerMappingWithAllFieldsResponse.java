package com.gigflex.prototype.microservices.documentmapping.dtob;

public class DocumentOrganizationWorkerMappingWithAllFieldsResponse {

    private Long organizationDocumentId;

    private String organizationDocumentCode;
    
    private String documentCode;

    private String documentName;
    
    private String organizationCode;
    
    private String organizationName;
     
    private Long workerDocumentId;

    private String workerDocumentCode;
    
    private String workerCode;

    private String workerName;

    private String documentValue;
    
    private Boolean isUploaded;
    
    private Boolean isMapped;
    
    private Boolean canShare;
    
    private Long documentOrganizationWorkerId;

    private String documentOrganizationWorkerCode;

    public Long getOrganizationDocumentId() {
        return organizationDocumentId;
    }

    public void setOrganizationDocumentId(Long organizationDocumentId) {
        this.organizationDocumentId = organizationDocumentId;
    }

    public Long getWorkerDocumentId() {
        return workerDocumentId;
    }

    public void setWorkerDocumentId(Long workerDocumentId) {
        this.workerDocumentId = workerDocumentId;
    }

    public String getWorkerDocumentCode() {
        return workerDocumentCode;
    }

    public void setWorkerDocumentCode(String workerDocumentCode) {
        this.workerDocumentCode = workerDocumentCode;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public String getDocumentValue() {
        return documentValue;
    }

    public void setDocumentValue(String documentValue) {
        this.documentValue = documentValue;
    }

    public Boolean getIsUploaded() {
        return isUploaded;
    }

    public void setIsUploaded(Boolean isUploaded) {
        this.isUploaded = isUploaded;
    }

    public Boolean getIsMapped() {
        return isMapped;
    }

    public void setIsMapped(Boolean isMapped) {
        this.isMapped = isMapped;
    }

    public Boolean getCanShare() {
        return canShare;
    }

    public void setCanShare(Boolean canShare) {
        this.canShare = canShare;
    }

    public Long getDocumentOrganizationWorkerId() {
        return documentOrganizationWorkerId;
    }

    public void setDocumentOrganizationWorkerId(Long documentOrganizationWorkerId) {
        this.documentOrganizationWorkerId = documentOrganizationWorkerId;
    }

    public String getDocumentOrganizationWorkerCode() {
        return documentOrganizationWorkerCode;
    }

    public void setDocumentOrganizationWorkerCode(String documentOrganizationWorkerCode) {
        this.documentOrganizationWorkerCode = documentOrganizationWorkerCode;
    }

    

    public String getOrganizationDocumentCode() {
        return organizationDocumentCode;
    }

    public void setOrganizationDocumentCode(String organizationDocumentCode) {
        this.organizationDocumentCode = organizationDocumentCode;
    }
    
   

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

}
