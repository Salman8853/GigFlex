package com.gigflex.prototype.microservices.documentmapping.dtob;

public class WorkerDocumentsResponse {

    private Long id;

    private String workerDocumentCode;

    private String documentCode;

    private String documentNmae;

    private String workerCode;

    private String workerName;

    private String documentValue;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWorkerDocumentCode() {
        return workerDocumentCode;
    }

    public void setWorkerDocumentCode(String workerDocumentCode) {
        this.workerDocumentCode = workerDocumentCode;
    }

    public String getDocumentNmae() {
        return documentNmae;
    }

    public void setDocumentNmae(String documentNmae) {
        this.documentNmae = documentNmae;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    
    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getDocumentValue() {
        return documentValue;
    }

    public void setDocumentValue(String documentValue) {
        this.documentValue = documentValue;
    }

}
