package com.gigflex.prototype.microservices.documentmapping.repository;


import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationMapping;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface DocumentOrganizationMappingRepository extends JpaRepository<DocumentOrganizationMapping, Long>,JpaSpecificationExecutor<DocumentOrganizationMapping>{
	
	@Query("SELECT d,dd.documentName ,o.organizationName FROM DocumentOrganizationMapping d, Organization o, DocumentTypeDetail dd  WHERE d.isDeleted != TRUE AND dd.isDeleted != TRUE AND o.isDeleted != TRUE AND d.organizationCode=o.organizationCode AND  d.documentCode = dd.documentCode")
	public List<Object> getAllDocumentOrganizationMapping();
        
        
    	@Query("SELECT d,dd.documentName ,o.organizationName FROM DocumentOrganizationMapping d, Organization o, DocumentTypeDetail dd  WHERE d.isDeleted != TRUE AND dd.isDeleted != TRUE AND o.isDeleted != TRUE AND d.organizationCode=o.organizationCode AND  d.documentCode = dd.documentCode")
	public List<Object> getAllDocumentOrganizationMapping(Pageable pageableRequest);
        
        @Query("SELECT d,dd.documentName ,o.organizationName FROM DocumentOrganizationMapping d, Organization o, DocumentTypeDetail dd  WHERE d.isDeleted != TRUE AND dd.isDeleted != TRUE AND o.isDeleted != TRUE AND d.organizationCode=o.organizationCode AND  d.documentCode = dd.documentCode AND d.organizationDocumentCode = :organizationDocumentCode")
	public Object getDocumentOrganizationMappingWithNameByCode(@Param("organizationDocumentCode") String organizationDocumentCode);
	
       @Query("SELECT d,dd.documentName ,o.organizationName FROM DocumentOrganizationMapping d, Organization o, DocumentTypeDetail dd  WHERE d.isDeleted != TRUE AND dd.isDeleted != TRUE AND o.isDeleted != TRUE AND d.organizationCode=o.organizationCode AND  d.documentCode = dd.documentCode AND d.organizationCode = :organizationCode ORDER BY d.id")
	public List<Object> getAllDocumentOrganizationMappingByOrgCode(@Param("organizationCode") String organizationCode);
        
        
	@Query("SELECT d FROM DocumentOrganizationMapping d WHERE d.isDeleted != TRUE AND d.organizationDocumentCode = :organizationDocumentCode")
	public DocumentOrganizationMapping getDocumentOrganizationMappingByCode(@Param("organizationDocumentCode") String organizationDocumentCode);
	
	@Query("SELECT d FROM DocumentOrganizationMapping d WHERE d.isDeleted != TRUE AND d.id = :id")
	public DocumentOrganizationMapping getDocumentOrganizationMappingById(@Param("id") Long id);
	
        @Query("SELECT d FROM DocumentOrganizationMapping d WHERE d.isDeleted != TRUE AND d.documentCode = :documentCode  AND d.organizationCode = :organizationCode")
	public DocumentOrganizationMapping getDocumentOrganizationMappingByDocCodeAndOrgCode(@Param("documentCode") String documentCode,@Param("organizationCode") String organizationCode);
	
        @Query("SELECT d FROM DocumentOrganizationMapping d WHERE d.isDeleted != TRUE AND d.id != :id AND  d.documentCode = :documentCode  AND d.organizationCode = :organizationCode")
	public DocumentOrganizationMapping getDocumentOrganizationMappingByNotIDDocCodeAndOrgCode(@Param("id") Long id,@Param("documentCode") String documentCode,@Param("organizationCode") String organizationCode);
	

}
