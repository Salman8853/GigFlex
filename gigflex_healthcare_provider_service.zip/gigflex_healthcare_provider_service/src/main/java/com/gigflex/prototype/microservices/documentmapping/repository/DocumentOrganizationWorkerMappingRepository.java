package com.gigflex.prototype.microservices.documentmapping.repository;


import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationWorkerMapping;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface DocumentOrganizationWorkerMappingRepository extends JpaRepository<DocumentOrganizationWorkerMapping, Long>,JpaSpecificationExecutor<DocumentOrganizationWorkerMapping>{
	
	@Query("SELECT d,wd,dom,dtd.documentName FROM DocumentOrganizationWorkerMapping d,WorkerDocuments wd, DocumentOrganizationMapping dom, DocumentTypeDetail dtd WHERE dtd.isDeleted != TRUE AND d.isDeleted != TRUE AND wd.isDeleted != TRUE AND dom.isDeleted != TRUE AND d.workerDocumentCode = wd.workerDocumentCode AND d.organizationDocumentCode= dom.organizationDocumentCode AND dtd.documentCode=wd.documentCode")
	public List<Object> getAllDocumentOrganizationWorkerMapping();
	
        @Query("SELECT d,wd,dom,dtd.documentName FROM DocumentOrganizationWorkerMapping d,WorkerDocuments wd, DocumentOrganizationMapping dom, DocumentTypeDetail dtd WHERE dtd.isDeleted != TRUE AND d.isDeleted != TRUE AND wd.isDeleted != TRUE AND dom.isDeleted != TRUE AND d.workerDocumentCode = wd.workerDocumentCode AND d.organizationDocumentCode= dom.organizationDocumentCode AND dtd.documentCode=wd.documentCode AND d.documentOrganizationWorkerCode = :documentOrganizationWorkerCode")
	public Object getDocumentOrganizationWorkerMappingWithNameByCode(@Param("documentOrganizationWorkerCode") String documentOrganizationWorkerCode);
	
       
	@Query("SELECT d FROM DocumentOrganizationWorkerMapping d WHERE d.isDeleted != TRUE AND d.documentOrganizationWorkerCode = :documentOrganizationWorkerCode")
	public DocumentOrganizationWorkerMapping getDocumentOrganizationWorkerMappingByCode(@Param("documentOrganizationWorkerCode") String documentOrganizationWorkerCode);
	
	@Query("SELECT d FROM DocumentOrganizationWorkerMapping d WHERE d.isDeleted != TRUE AND d.id = :id")
	public DocumentOrganizationWorkerMapping getDocumentOrganizationWorkerMappingById(@Param("id") Long id);
	
	
        @Query("SELECT d FROM DocumentOrganizationWorkerMapping d WHERE d.isDeleted != TRUE AND d.workerDocumentCode = :workerDocumentCode AND d.organizationDocumentCode= :organizationDocumentCode")
	public DocumentOrganizationWorkerMapping getDocumentOrganizationWorkerMappingByWorkerDocumentCodeAndOrganizationDocumentCode(@Param("workerDocumentCode") String workerDocumentCode,@Param("organizationDocumentCode") String organizationDocumentCode);
	

}
