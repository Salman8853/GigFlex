/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service;

import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationWorkerMappingRequest;
import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public interface DocumentOrganizationWorkerMappingService {
    public String getDocumentOrganizationWorkerMapping();
    public String getDocumentOrganizationWorkerMappingByCode(String documentOrganizationWorkerCode);
    public String getDocumentOrganizationWorkerMappingWithNameByCode(String documentOrganizationWorkerCode);
    public String saveDocumentOrganizationWorkerMapping(DocumentOrganizationWorkerMappingRequest driDetReq,String ip);
    public String softDeleteDocumentOrganizationWorkerMappingByCode(String documentOrganizationWorkerCode);
    public String softMultipleDeleteDocumentOrganizationWorkerMappingByCode(List<String> documentOrganizationWorkerCodeList);
    public String checkDocumentOrganizationWorkerMappingByOrgCodeAndWorkerCode(String organizationCode,String workerCode);
    public String getAllDocumentOrganizationWorkerMappingByOrganizationCode(String organizationCode);
    public String getAllDocumentOrganizationWorkerMappingByWorkerCode(String workerCode);
}
