/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service;

import com.gigflex.prototype.microservices.documentmapping.dtob.WorkerDocumentsRequest;

/**
 *
 * @author nirbhay.p
 */
public interface WorkerDocumentsService {
    public String getAllWorkerDocuments();
    public String getAllWorkerDocumentsByWorkerCode(String workerCode);
    public String getAllWorkerDocumentsByPage(int page,int limit);
    public String getAllWorkerDocumentsByWorkerCodeByPage(String workerCode,int page,int limit);
    public String getWorkerDocumentsByWorkerDocumentCode(String workerDocumentCode);
    public String getWorkerDocumentsByID(Long id);
    public String saveWorkerDocuments(WorkerDocumentsRequest docReq,String ip);
    public String updateWorkerDocuments(Long id,WorkerDocumentsRequest docReq,String ip);
            
}
