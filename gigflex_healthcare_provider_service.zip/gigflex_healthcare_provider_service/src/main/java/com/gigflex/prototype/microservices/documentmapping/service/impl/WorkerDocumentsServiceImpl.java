/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.documentmapping.dtob.WorkerDocuments;
import com.gigflex.prototype.microservices.documentmapping.dtob.WorkerDocumentsResponse;
import com.gigflex.prototype.microservices.documentmapping.dtob.WorkerDocumentsRequest;
import com.gigflex.prototype.microservices.documentmapping.repository.WorkerDocumentsRepository;
import com.gigflex.prototype.microservices.documentmapping.service.WorkerDocumentsService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */
@Service
public class WorkerDocumentsServiceImpl implements WorkerDocumentsService{

    @Autowired
    WorkerDocumentsRepository workerDocumentsRepository;
    
    @Override
    public String getAllWorkerDocuments() {
        
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 List<WorkerDocumentsResponse> rsplst= new ArrayList<WorkerDocumentsResponse>();
		 List<Object> objlst = workerDocumentsRepository.getAllWorkerDocuments();
		        if (objlst != null && objlst.size() > 0) {
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 WorkerDocumentsResponse resp=new WorkerDocumentsResponse();
                                 WorkerDocuments dom=(WorkerDocuments) arr[0];
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentNmae((String) arr[1]);
                                 resp.setDocumentValue(dom.getDocumentValue());
                                 resp.setId(dom.getId());
                                 resp.setWorkerCode(dom.getWorkerCode());
                                 resp.setWorkerDocumentCode(dom.getWorkerDocumentCode());
                                 resp.setWorkerName((String) arr[2]);
                                 rsplst.add(resp);
                             }
                         }
                     }
		 if (rsplst != null && rsplst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

    }

    @Override
    public String getAllWorkerDocumentsByWorkerCode(String workerCode) {
        
        
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 List<WorkerDocumentsResponse> rsplst= new ArrayList<WorkerDocumentsResponse>();
		 List<Object> objlst = workerDocumentsRepository.getAllWorkerDocumentsByWorkerCode(workerCode);
		        if (objlst != null && objlst.size() > 0) {
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 WorkerDocumentsResponse resp=new WorkerDocumentsResponse();
                                 WorkerDocuments dom=(WorkerDocuments) arr[0];
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentNmae((String) arr[1]);
                                 resp.setDocumentValue(dom.getDocumentValue());
                                 resp.setId(dom.getId());
                                 resp.setWorkerCode(dom.getWorkerCode());
                                 resp.setWorkerDocumentCode(dom.getWorkerDocumentCode());
                                 resp.setWorkerName((String) arr[2]);
                                 rsplst.add(resp);
                             }
                         }
                     }
		 if (rsplst != null && rsplst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

    }

    @Override
    public String getAllWorkerDocumentsByPage(int page, int limit) {
        String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(limit>0)
                        {
                 int count =0;
                 Pageable pageableRequest = PageRequest.of(page, limit);
                 
                 List<WorkerDocumentsResponse> rsplst= new ArrayList<WorkerDocumentsResponse>();
		 List<Object> objlst = workerDocumentsRepository.getAllWorkerDocuments(pageableRequest);
                 if (objlst != null && objlst.size() > 0) {
                     
                 List<Object> objlstcnt = workerDocumentsRepository.getAllWorkerDocuments();
		        if(objlstcnt!=null && objlstcnt.size()>0)
                        {
                            count= objlstcnt.size();
                        }
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 WorkerDocumentsResponse resp=new WorkerDocumentsResponse();
                                 WorkerDocuments dom=(WorkerDocuments) arr[0];
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentNmae((String) arr[1]);
                                 resp.setDocumentValue(dom.getDocumentValue());
                                 resp.setId(dom.getId());
                                 resp.setWorkerCode(dom.getWorkerCode());
                                 resp.setWorkerDocumentCode(dom.getWorkerDocumentCode());
                                 resp.setWorkerName((String) arr[2]);
                                 rsplst.add(resp);
                             }
                         }
                     }
		 if (rsplst != null && rsplst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
                 jsonobj.put("count", count);
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                 } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;
    }

    @Override
    public String getAllWorkerDocumentsByWorkerCodeByPage(String workerCode, int page, int limit) {
        
        String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(limit>0)
                        {
                 int count =0;
                 Pageable pageableRequest = PageRequest.of(page, limit);
                 
                 List<WorkerDocumentsResponse> rsplst= new ArrayList<WorkerDocumentsResponse>();
		 List<Object> objlst = workerDocumentsRepository.getAllWorkerDocumentsByWorkerCode(workerCode,pageableRequest);
                 if (objlst != null && objlst.size() > 0) {
                     
                 List<Object> objlstcnt = workerDocumentsRepository.getAllWorkerDocumentsByWorkerCode(workerCode);
		        if(objlstcnt!=null && objlstcnt.size()>0)
                        {
                            count= objlstcnt.size();
                        }
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 WorkerDocumentsResponse resp=new WorkerDocumentsResponse();
                                 WorkerDocuments dom=(WorkerDocuments) arr[0];
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentNmae((String) arr[1]);
                                 resp.setDocumentValue(dom.getDocumentValue());
                                 resp.setId(dom.getId());
                                 resp.setWorkerCode(dom.getWorkerCode());
                                 resp.setWorkerDocumentCode(dom.getWorkerDocumentCode());
                                 resp.setWorkerName((String) arr[2]);
                                 rsplst.add(resp);
                             }
                         }
                     }
		 if (rsplst != null && rsplst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
                 jsonobj.put("count", count);
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                 } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

    }

    @Override
    public String getWorkerDocumentsByWorkerDocumentCode(String workerDocumentCode) {
       
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 WorkerDocuments wd = workerDocumentsRepository.getWorkerDocumentsByWorkerDocumentCode(workerDocumentCode);
		       
		 if (wd != null && wd.getId() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(wd);
		 jsonobj.put("data", new JSONObject(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

    }

    @Override
    public String getWorkerDocumentsByID(Long id) {
       
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 WorkerDocuments wd = workerDocumentsRepository.getWorkerDocumentsByID(id);
		       
		 if (wd != null && wd.getId() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(wd);
		 jsonobj.put("data", new JSONObject(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;
    }

    @Override
    public String saveWorkerDocuments(WorkerDocumentsRequest docReq, String ip) {
        
        String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 
                   WorkerDocuments dom=  workerDocumentsRepository.getWorkerDocumentsByDocCodeAndWorkerCode(docReq.getDocumentCode(), docReq.getWorkerCode());
                   if(dom!=null && dom.getId()>0)
                   {
                       jsonobj.put("responsecode", 409);
                       jsonobj.put("message", "Record is already exist.");
                       jsonobj.put("timestamp", new Date());
                   }
                   else
                     {
                         WorkerDocuments dm = new WorkerDocuments();
                         dm.setDocumentCode(docReq.getDocumentCode());
                         dm.setDocumentValue(docReq.getDocumentValue());
                         dm.setWorkerCode(docReq.getWorkerCode());
                         dm.setIpAddress(ip);
                         WorkerDocuments dmres = workerDocumentsRepository.save(dm);
                         if (dmres != null && dmres.getId() > 0) {
                             jsonobj.put("responsecode", 200);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message",
                                     "Worker Documents has been added successfully.");
                             ObjectMapper mapperObj = new ObjectMapper();
                             String Detail = mapperObj.writeValueAsString(dmres);
                             jsonobj.put("data", new JSONObject(Detail));
                         } else {
                             jsonobj.put("responsecode", 400);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Failed");
                         }
                     }
                 
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;
    }

    @Override
    public String updateWorkerDocuments(Long id, WorkerDocumentsRequest docReq, String ip) {
       
        
        String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
               
                   WorkerDocuments dom=  workerDocumentsRepository.getWorkerDocumentsByNotIDDocCodeAndWorkerCode(id,docReq.getDocumentCode(), docReq.getWorkerCode());
                   if(dom!=null && dom.getId()>0)
                   {
                       jsonobj.put("responsecode", 409);
                       jsonobj.put("message", "Record is already exist.");
                       jsonobj.put("timestamp", new Date());
                   }
                   else
                     {
                         WorkerDocuments dm= workerDocumentsRepository.getWorkerDocumentsByID(id);
                         if(dm!=null && dm.getId()>0)
                         {
                         dm.setDocumentValue(docReq.getDocumentValue());
                         dm.setIpAddress(ip);
                         WorkerDocuments dmres = workerDocumentsRepository.save(dm);
                         if (dmres != null && dmres.getId() > 0) {
                             jsonobj.put("responsecode", 200);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message",
                                     "Worker Documents has been updated successfully.");
                             ObjectMapper mapperObj = new ObjectMapper();
                             String Detail = mapperObj.writeValueAsString(dmres);
                             jsonobj.put("data", new JSONObject(Detail));
                         } else {
                             jsonobj.put("responsecode", 400);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Failed");
                         }
                         }
                         else {
                             jsonobj.put("responsecode", 404);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Record not found.");
                         }
                     }
                 
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;
    }
    
}
