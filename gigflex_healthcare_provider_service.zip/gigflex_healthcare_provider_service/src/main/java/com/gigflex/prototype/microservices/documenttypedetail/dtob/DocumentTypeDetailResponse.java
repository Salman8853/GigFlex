package com.gigflex.prototype.microservices.documenttypedetail.dtob;

public class DocumentTypeDetailResponse {

	private Long id;

	private String documentCode;

	private String documentName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	
	

}
