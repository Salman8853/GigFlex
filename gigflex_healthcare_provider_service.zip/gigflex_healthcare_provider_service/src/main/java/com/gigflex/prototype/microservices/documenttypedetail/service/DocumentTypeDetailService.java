package com.gigflex.prototype.microservices.documenttypedetail.service;

import java.util.List;

import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetailRequest;

public interface DocumentTypeDetailService {
	
	public String getAllDocumentTypeDetail();
        //public String getAllDocumentTypeDetailByUserTypeCode(String userTypeCode);
	public String getDocumentTypeDetailById(Long id);
	public String getDocumentTypeDetailByDocumentCode(String documentCode);
	public String saveNewDocumentTypeDetail(DocumentTypeDetailRequest docTypeDetReq, String ip);
	public String updateDocumentTypeDetailById(Long id,DocumentTypeDetailRequest docTypeDetReq, String ip);
	public String softDeleteByDocumentCode(String documentCode);
    public String softMultipleDeleteByDocumentCode(List<String> documentCodeList);
    public String getAllDocumentTypeDetailByPgae(int page, int limit);
//    public String getAllDocumentTypeDetailByUserTypeCodeByPgae(String userTypeCode,int page, int limit);
    public String search(String search);
    public String getDocumentTypeDetailByDocumentName(String documentName);
//    public String getAllDocumentTypeDetailByDocumentTypeCodeByPgae(String documentTypeCode,int page, int limit);

}
