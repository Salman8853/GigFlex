/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.employmenttype.repository;

import com.gigflex.prototype.microservices.employmenttype.dtob.EmploymentType;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface EmploymentTypeRepository extends JpaRepository<EmploymentType, Long>, JpaSpecificationExecutor<EmploymentType> {

    @Query("SELECT et FROM EmploymentType et WHERE et.isDeleted != TRUE")
    public List<EmploymentType> getAllEmploymentType();

    @Query("SELECT et FROM EmploymentType et WHERE et.isDeleted != TRUE AND et.employmentTypeName= :employmentTypeName")
    public EmploymentType getEmploymentTypeByName(@Param("employmentTypeName")String employmentTypeName);

    @Query("SELECT et FROM EmploymentType et WHERE et.isDeleted != TRUE AND et.employmentTypeCode= :employmentTypeCode")
    public EmploymentType getEmploymentTypeByCode(@Param("employmentTypeCode")String employmentTypeCode);

    @Query("SELECT et FROM EmploymentType et WHERE et.isDeleted != TRUE AND et.employmentTypeCode!= :employmentTypeCode AND et.employmentTypeName= :employmentTypeName")
    public EmploymentType getEmploymentTypeByNameNotInCode(@Param("employmentTypeName")String employmentTypeName, @Param("employmentTypeCode")String employmentTypeCode);
    
}
