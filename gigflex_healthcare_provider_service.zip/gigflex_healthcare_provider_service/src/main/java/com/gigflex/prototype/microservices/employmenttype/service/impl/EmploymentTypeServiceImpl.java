/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.employmenttype.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.employmenttype.dtob.EmploymentType;
import com.gigflex.prototype.microservices.employmenttype.dtob.EmploymentTypeRequest;
import com.gigflex.prototype.microservices.employmenttype.repository.EmploymentTypeRepository;
import com.gigflex.prototype.microservices.employmenttype.service.EmploymentTypeService;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */
@Service
public class EmploymentTypeServiceImpl implements EmploymentTypeService{

    @Autowired
    private EmploymentTypeRepository employmentTypeRepository;
    
    @Override
    public String getAllEmploymentType() {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<EmploymentType> emptylst = employmentTypeRepository.getAllEmploymentType();

			if (emptylst != null && emptylst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(emptylst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "No data found.");
				jsonobj.put("timestamp", new Date());

			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String saveEmploymentType(EmploymentTypeRequest empreq, String ip) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			EmploymentType empty = employmentTypeRepository.getEmploymentTypeByName(empreq.getEmploymentTypeName().trim());
			if (empty != null && empty.getId() > 0) {
                            jsonobj.put("responsecode", 409);
				jsonobj.put("message", "Name already exist.");
				jsonobj.put("timestamp", new Date());
                        }
                        else
                        {
                            EmploymentType et=new EmploymentType();
                            et.setEmploymentTypeName(empreq.getEmploymentTypeName().trim());
                             EmploymentType emptyRes=employmentTypeRepository.save(et);
                             
                            if (emptyRes != null && emptyRes.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Employment Type has been created.");
				jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(emptyRes);
				jsonobj.put("data", new JSONObject(Detail));
                            }else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Creation has been failed.");
				jsonobj.put("timestamp", new Date());
                            }
                        }
                        
                        
                        res = jsonobj.toString();
		} catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String getEmploymentTypeByCode(String employmentTypeCode) {
        
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			EmploymentType empty = employmentTypeRepository.getEmploymentTypeByCode(employmentTypeCode);

			if (empty != null && empty.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(empty);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "No data found.");
				jsonobj.put("timestamp", new Date());

			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String softDeleteEmploymentTypeByCode(String employmentTypeCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			EmploymentType empty = employmentTypeRepository.getEmploymentTypeByCode(employmentTypeCode);

			if (empty != null && empty.getId() > 0) {
                            empty.setIsDeleted(Boolean.TRUE);
                            EmploymentType emptyRes =employmentTypeRepository.save(empty);
                            if (emptyRes != null && emptyRes.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Employment Type has been deleted.");
				jsonobj.put("timestamp", new Date());
                            }else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Deletion has been failed.");
				jsonobj.put("timestamp", new Date());
                            }
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "No data found.");
				jsonobj.put("timestamp", new Date());

			}
        res = jsonobj.toString();
		} catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String updateEmploymentTypeByCode(EmploymentTypeRequest empreq, String employmentTypeCode, String ip) {
       
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        EmploymentType empty = employmentTypeRepository.getEmploymentTypeByCode(employmentTypeCode);

			if (empty != null && empty.getId() > 0) {
			EmploymentType etp = employmentTypeRepository.getEmploymentTypeByNameNotInCode(empreq.getEmploymentTypeName().trim(),employmentTypeCode);
			if (etp != null && etp.getId() > 0) {
                            jsonobj.put("responsecode", 409);
				jsonobj.put("message", "Name already exist.");
				jsonobj.put("timestamp", new Date());
                        }
                        else
                        {
                            empty.setEmploymentTypeName(empreq.getEmploymentTypeName().trim());
                             EmploymentType emptyRes=employmentTypeRepository.save(empty);
                             
                            if (emptyRes != null && emptyRes.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Employment Type has been updated.");
				jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(emptyRes);
				jsonobj.put("data", new JSONObject(Detail));
                            }else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Updation has been failed.");
				jsonobj.put("timestamp", new Date());
                            }
                        }
                        }
                        else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Employment Type Code not found.");
				jsonobj.put("timestamp", new Date());
                            }
                        res = jsonobj.toString();
		} catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
    
    }
    
}
