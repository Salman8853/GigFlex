/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.healthcarenotification.api;

import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotificationUpdate;
import com.gigflex.prototype.microservices.healthcarenotification.service.HealthcareNotificationService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author amit.kumar
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class HealthcareNotificationController {
    
    @Autowired
    public HealthcareNotificationService notificationService;

    @PutMapping("/updateHealthcareNotification/{notificationCode}")
    public String updateHealthcareNotification(@PathVariable String notificationCode,
                    @RequestBody HealthcareNotificationUpdate notificationReq, HttpServletRequest request) {

            String ip = request.getRemoteAddr();

            return notificationService.updateHealthcareNotificationByNotificationCode(notificationReq, notificationCode, ip);

    }

    @GetMapping("/getAllHealthcareNotificationByUserCodeWithReadByPage/{userCode}")
    public String getAllHealthcareNotificationByUserCodeWithReadByPage(@PathVariable("userCode") String userCode,
                    @RequestParam(value = "page", defaultValue = "0") int page,
                    @RequestParam(value = "limit", defaultValue = "30") int limit) {

            if (userCode != null && userCode.trim().length() > 0) {

                    String notification = notificationService.getAllHealthcareNotificationByUserCodeWithRead(userCode.trim(), page, limit);

                    return notification;
            } else {
                    GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code should not be blank.");
                    return derr.toString();
            }
    }

    @GetMapping("/getAllHealthcareNotificationByUserCodeWithRead/{userCode}")
    public String getAllHealthcareNotificationByUserCodeWithRead(@PathVariable("userCode") String userCode) {
            if (userCode != null && userCode.trim().length() > 0) {

                    return notificationService.getAllHealthcareNotificationByUserCodeWithRead(userCode.trim());

            } else {
                    GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code should not be blank.");
                    return derr.toString();
            }
    }
	
    @GetMapping("/getAllHealthcareNotificationByUserCodeWithUnReadByPage/{userCode}")
    public String getAllHealthcareNotificationByUserCodeWithUnReadByPage(@PathVariable("userCode") String userCode,
                    @RequestParam(value = "page", defaultValue = "0") int page,
                    @RequestParam(value = "limit", defaultValue = "30") int limit) {

            if (userCode != null && userCode.trim().length() > 0) {

                    String notification = notificationService.getAllHealthcareNotificationByUserCodeWithUnRead(userCode.trim(), page, limit);

                    return notification;
            } else {
                    GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code should not be blank.");
                    return derr.toString();
            }
    }

    @GetMapping("/getAllHealthcareNotificationByUserCodeWithUnRead/{userCode}")
    public String getAllHealthcareNotificationByUserCodeWithUnRead(@PathVariable("userCode") String userCode) {
            if (userCode != null && userCode.trim().length() > 0) {

                    return notificationService.getAllHealthcareNotificationByUserCodeWithUnRead(userCode.trim());

            } else {
                    GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code should not be blank.");
                    return derr.toString();
            }
    }
}
