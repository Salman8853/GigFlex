/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.healthcarenotification.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "healthcare_notification")
public class HealthcareNotification extends CommonAttributes implements Serializable{
    
    
        private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "healthcare_notification_code", unique = true)
	private String healthcareNotificationCode;

	@Column(length = 65535, columnDefinition = "text",name = "message")
	private String message;
	
	@Column(name = "shortmessage")
	private String shortMessage;
	
	@Column(name = "appointment_code")
	private String appointmentCode;

	@Column(name = "user_code")
	private String userCode;

	@Column(name = "isread")
	private Boolean isRead;
	
	@Column(name = "user_type")
	private String userType;

	@PrePersist
	private void assignUUID() {
		if (this.getHealthcareNotificationCode() == null || this.getHealthcareNotificationCode().length() == 0) {
			this.setHealthcareNotificationCode(UUID.randomUUID().toString());
		}
	}

	public HealthcareNotification() {
		super();

	}
	
	public HealthcareNotification(Long id, String healthcareNotificationCode, String message,
			String shortMessage, String appointmentCode, String userCode,
			Boolean isRead, String userType) {
		super();
		this.id = id;
		this.healthcareNotificationCode = healthcareNotificationCode;
		this.message = message;
		this.shortMessage = shortMessage;
		this.appointmentCode = appointmentCode;
		this.userCode = userCode;
		this.isRead = isRead;
		this.userType = userType;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

        public String getHealthcareNotificationCode() {
            return healthcareNotificationCode;
        }

        public void setHealthcareNotificationCode(String healthcareNotificationCode) {
            this.healthcareNotificationCode = healthcareNotificationCode;
        }

        public String getAppointmentCode() {
            return appointmentCode;
        }

        public void setAppointmentCode(String appointmentCode) {
            this.appointmentCode = appointmentCode;
        }

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getShortMessage() {
		return shortMessage;
	}

	public void setShortMessage(String shortMessage) {
		this.shortMessage = shortMessage;
	}
	

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

}
