/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.healthcarenotification.service;

import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotificationRequest;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotificationUpdate;

/**
 *
 * @author amit.kumar
 */
public interface HealthcareNotificationService {

    public String saveHealthcareNotification(HealthcareNotificationRequest notificationReq, String ip);
	
    public void saveHealthcareNotification(HealthcareNotification notification);
    
    public String updateHealthcareNotificationByNotificationCode(HealthcareNotificationUpdate notificationReq, String notificationCode, String ip);

    public String getAllHealthcareNotificationByUserCodeWithRead(String userCode, int page, int limit);

    public String getAllHealthcareNotificationByUserCodeWithRead(String userCode);

    public String getAllHealthcareNotificationByUserCodeWithUnRead(String userCode, int page, int limit);

    public String getAllHealthcareNotificationByUserCodeWithUnRead(String userCode);
    
    
}
