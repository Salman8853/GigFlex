/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.api;

import com.gigflex.prototype.microservices.jobs.dtob.AssignToWorkerReq;
import com.gigflex.prototype.microservices.jobs.dtob.AssignToWorkerReqNew;
import com.gigflex.prototype.microservices.jobs.dtob.AssignToWorkerStatusReq;
import com.gigflex.prototype.microservices.jobs.dtob.AssignWorkerInProgerssStatusReq;
import com.gigflex.prototype.microservices.jobs.dtob.CancelToworkerReq;
import com.gigflex.prototype.microservices.jobs.dtob.JobDurationUpdate;
import com.gigflex.prototype.microservices.jobs.dtob.JobsRequest;
import com.gigflex.prototype.microservices.jobs.dtob.RejectToworkerreq;
import com.gigflex.prototype.microservices.jobs.dtob.JobsUpdateRequest;
import com.gigflex.prototype.microservices.jobs.service.JobsService;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirbhay.p
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
public class JobsController {
    
    @Autowired
    JobsService jobsService;
    
    
    @PostMapping("/createWorkerJob")
    public String createWorkerJob(@RequestBody JobsRequest wsr, HttpServletRequest req) {
		if (wsr != null && wsr.getOrganizationCode()!=null && 
                        wsr.getOrganizationCode().trim().length()>0 && wsr.getProcedureCode()!=null && wsr.getProcedureCode().trim().length()>0 
                        && wsr.getRepeatType()!=null && wsr.getRepeatType().trim().length()>0 && wsr.getRepeatValue()!=null && wsr.getRepeatValue()>0
                        && ((wsr.getPatientCode()!=null && wsr.getPatientCode().trim().length()>0) || (wsr.getPatientDetail()!=null && wsr.getPatientDetail().getPatientName()!=null &&  wsr.getPatientDetail().getPatientName().length() > 0                                                                     
                                && wsr.getPatientDetail().getPatientLatitude() != null && wsr.getPatientDetail().getPatientLatitude().trim().length() >0
                                && wsr.getPatientDetail().getPatientLongitude() != null && wsr.getPatientDetail().getPatientLongitude().trim().length() > 0                               
                                && wsr.getPatientDetail().getPhoneNumber() != null && wsr.getPatientDetail().getPhoneNumber().trim().length() > 0                          
                                && wsr.getPatientDetail().getPhoneCountryCode() != null &&  wsr.getPatientDetail().getPhoneCountryCode().trim().length() > 0
                                && wsr.getPatientDetail().getOrganizationCode() != null && wsr.getPatientDetail().getOrganizationCode().trim().length() > 0
                                 && wsr.getPatientDetail().getPatientAddress()!= null && wsr.getPatientDetail().getPatientAddress().trim().length() > 0
                               ))) {
                     if(wsr.getStartDate()!=null && wsr.getStartDate().trim().length()>0 && wsr.getEndDate()!=null && wsr.getEndDate().trim().length()>0 &&
                             wsr.getStartTime()!=null && wsr.getStartTime().trim().length()>0 && ( ( wsr.getDurationHours()!=null && wsr.getDurationHours()>0) || ( wsr.getDurationMinute()!=null && wsr.getDurationMinute()>0)))
                    {
                        
                     boolean boolsdt=   GigflexDateUtil.validateDateFormat(wsr.getStartDate().trim(),GigflexConstants.YYYY_MM_DD);
                     boolean booledt=   GigflexDateUtil.validateDateFormat(wsr.getEndDate().trim(),GigflexConstants.YYYY_MM_DD);
                     if(boolsdt==false || booledt==false)
                                {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send start date and end date in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();
                                }


                     boolean boolstm=   GigflexDateUtil.validateDateFormat(wsr.getStartTime().trim(),GigflexConstants.HH_MM_SS);
                     if(boolstm==false )
                                {GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send start time in correct format("+GigflexConstants.HH_MM_SS+")");
				return derr.toString();
                                }
                        
                     //&& wsr.getDaysList()!=null && wsr.getDaysList().size()>0 
                     if(wsr.getRepeatType().equalsIgnoreCase("Month"))
                     {
                         if(wsr.getIsDateOfMonth()==null)
                         {
                             GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Date Of Month should not be blank in repeat type MONTH");
				return derr.toString();
                         }
                     }
                     if(wsr.getRepeatType().equalsIgnoreCase("Week"))
                     {
                         if(wsr.getDaysList().size()==0)
                         {
                             GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Days List size should not be zero in repeat type WEEK");
				return derr.toString();
                         }
                     }
                      return jobsService.createWorkerJob(wsr, req.getRemoteHost());
                    } else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Start Date,End Date, Start Time and Duration should not be blank.");
			return derr.toString();
		}
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Organization Code, Procedure Code, Repeat Type, Repeat Value and (Patient Code or Patient Detail) should not be blank.");
			return derr.toString();
		}

	}
    
   @PutMapping("/updateJobDurationByJobDurationCode/{jobDurationCode}")
	public String updateJobDurationByJobDurationCode(@PathVariable String jobDurationCode,  @RequestBody JobDurationUpdate jobDurationUpdate,
			HttpServletRequest httpRequest) {
		if(jobDurationUpdate!=null && jobDurationCode!=null && jobDurationCode.trim().length()>0 && jobDurationUpdate.getStartTime()!=null && jobDurationUpdate.getStartTime().trim().length()>0
                        && ( ( jobDurationUpdate.getDurationHours()!=null && jobDurationUpdate.getDurationHours()>0) || ( jobDurationUpdate.getDurationMinute()!=null && jobDurationUpdate.getDurationMinute()>0)))
        {
            try {
                                Boolean st=GigflexDateUtil.validateDateFormat(jobDurationUpdate.getStartTime().trim(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                                if(st==false )
                                {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send date in correct format("+GigflexConstants.DD_MM_YYYY_HH_MM_SS+") ");
				return derr.toString();
                                }
			} catch (Exception ex) {
				ex.printStackTrace();
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send date in correct format("+GigflexConstants.DD_MM_YYYY_HH_MM_SS+") ");
				return derr.toString();
			}
            
            return jobsService.updateJobDurationByJobDurationCode(jobDurationCode,jobDurationUpdate, httpRequest.getRemoteHost());
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Job Duration Code, Start Time, Duration Hours and Duration Minute should not be blank.");
            return derr.toString();
        }

	}
    
        
        @PutMapping("/updateWorkerJobSeriesByJobCode/{jobCode}")
    public String updateWorkerJobSeriesByJobsCode(@PathVariable String jobCode, @RequestBody JobsUpdateRequest wsr, HttpServletRequest req) {
		if (jobCode!=null && jobCode.trim().length()>0 && wsr != null &&  
                        wsr.getProcedureCode()!=null && wsr.getProcedureCode().trim().length()>0 
                        && wsr.getRepeatType()!=null && wsr.getRepeatType().trim().length()>0 && wsr.getRepeatValue()!=null && wsr.getRepeatValue()>0
                        && wsr.getPatientCode()!=null && wsr.getPatientCode().trim().length()>0 ) {
                     if(wsr.getStartDate()!=null && wsr.getStartDate().trim().length()>0 && wsr.getEndDate()!=null && wsr.getEndDate().trim().length()>0 &&
                             wsr.getStartTime()!=null && wsr.getStartTime().trim().length()>0 && ( ( wsr.getDurationHours()!=null && wsr.getDurationHours()>0) || ( wsr.getDurationMinute()!=null && wsr.getDurationMinute()>0)))
                    {
                        
                     boolean boolsdt=   GigflexDateUtil.validateDateFormat(wsr.getStartDate().trim(),GigflexConstants.YYYY_MM_DD);
                     boolean booledt=   GigflexDateUtil.validateDateFormat(wsr.getEndDate().trim(),GigflexConstants.YYYY_MM_DD);
                     if(boolsdt==false || booledt==false)
                                {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send start date and end date in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();
                                }


                     boolean boolstm=   GigflexDateUtil.validateDateFormat(wsr.getStartTime().trim(),GigflexConstants.HH_MM_SS);
                     if(boolstm==false )
                                {GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send start time in correct format("+GigflexConstants.HH_MM_SS+")");
				return derr.toString();
                                }
                        
                     //&& wsr.getDaysList()!=null && wsr.getDaysList().size()>0 
                     if(wsr.getRepeatType().equalsIgnoreCase("Month"))
                     {
                         if(wsr.getIsDateOfMonth()==null)
                         {
                             GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Date Of Month should not be blank in repeat type MONTH");
				return derr.toString();
                         }
                     }
                     if(wsr.getRepeatType().equalsIgnoreCase("Week"))
                     {
                         if(wsr.getDaysList().size()==0)
                         {
                             GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Days List size should not be zero in repeat type WEEK");
				return derr.toString();
                         }
                     }
                      return jobsService.updateWorkerJobSeriesByJobsCode(jobCode.trim(),wsr, req.getRemoteHost());
                    } else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Start Date,End Date, Start Time and Duration should not be blank.");
			return derr.toString();
		}
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Job Code, Organization Code, Procedure Code, Repeat Type, Repeat Value and Patient Code should not be blank.");
			return derr.toString();
		}

	}
        
    @GetMapping("/getWorkerJobById/{id}")
    public String getWorkerJobById(@PathVariable Long id) {
        if (id != null && id > 0) {
            return jobsService.getWorkerJobById(id);
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "ID should not be blank.");
            return derr.toString();
        }
    }
    
    @GetMapping("/getWorkerJobByJobCode/{jobCode}")
    public String getWorkerJobByJobCode(@PathVariable String jobCode) {
        if (jobCode != null && jobCode.trim().length() > 0) {
            return jobsService.getWorkerJobByJobCode(jobCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Jobs Code should not be blank.");
            return derr.toString();
        }
    }
    
    @GetMapping("/getBasicWorkerJobByJobCode/{jobCode}")
    public String getBasicWorkerJobByJobCode(@PathVariable String jobCode) {
        if (jobCode != null && jobCode.trim().length() > 0) {
            return jobsService.getBasicWorkerJobByJobCode(jobCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Jobs Code should not be blank.");
            return derr.toString();
        }
    }
    
    
    
    @GetMapping("/getWorkerJobDurationByJobDurationCode/{jobDurationCode}")
    public String getWorkerJobDurationByJobDurationCode(@PathVariable String jobDurationCode) {
        if (jobDurationCode != null && jobDurationCode.trim().length() > 0) {
            return jobsService.getWorkerJobDurationByJobDurationCode(jobDurationCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code should not be blank.");
            return derr.toString();
        }
    }
    
    
    @GetMapping("/getEligibleWorkerForJobsByJobDurationCode/{jobDurationCode}")
    public String getEligibleWorkerForJobsByJobDurationCode(@PathVariable String jobDurationCode) {
        if (jobDurationCode != null && jobDurationCode.trim().length() > 0) {
            return jobsService.getEligibleWorkerForJobsByJobDurationCode(jobDurationCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code should not be blank.");
            return derr.toString();
        }
    }
    
    
    @GetMapping("/getJobsAssignToWorkerByJobsCode/{jobCode}")
    public String getJobsAssignToWorkerByJobsCode(@PathVariable String jobCode) {
        if (jobCode != null && jobCode.trim().length() > 0) {
            return jobsService.getJobsAssignToWorkerByJobsCode(jobCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Jobs Code should not be blank.");
            return derr.toString();
        }
    }    
    
     @GetMapping("/getJobsAssignToWorkerByJobsCodeSpecialRes/{jobCode}")
    public String getJobsAssignToWorkerByJobsCodeSpecialRes(@PathVariable String jobCode) {
        if (jobCode != null && jobCode.trim().length() > 0) {
            return jobsService.getJobsAssignToWorkerByJobsCodeSpecialRes(jobCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Jobs Code should not be blank.");
            return derr.toString();
        }
    }
    
     @GetMapping("/getJobsAssignToWorkerByJobAssignToWorkerCode/{jobAssignToWorkerCode}")
    public String getJobsAssignToWorkerByJobAssignToWorkerCode(@PathVariable String jobAssignToWorkerCode) {
        if (jobAssignToWorkerCode != null && jobAssignToWorkerCode.trim().length() > 0) {
            return jobsService.getJobsAssignToWorkerByJobAssignToWorkerCode(jobAssignToWorkerCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobAssignToWorker Code should not be blank.");
            return derr.toString();
        }
    }
    
    @GetMapping("/getJobsAssignToWorkerByJobsCodeAndJobDurationCode/{jobCode}/{jobDurationCode}")
    public String getJobsAssignToWorkerByJobsCodeAndJobDurationCode(@PathVariable String jobCode,@PathVariable String jobDurationCode  ) {
        if (jobCode != null  && jobCode.trim().length() > 0 && jobDurationCode!=null && jobDurationCode.trim().length()>0) {
            return jobsService.getJobsAssignToWorkerByJobsCodeAndJobDurationCode(jobCode.trim(),jobDurationCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Jobs Code, JobDuration Code and Worker Code should not be blank.");
            return derr.toString();
        }
    }
    
    
    @GetMapping("/getFullJobDetailsByJobDurationCode/{jobDurationCode}")
    public String getFullJobDetailsByJobDurationCode(@PathVariable String jobDurationCode  ) {
        if (jobDurationCode!=null && jobDurationCode.trim().length()>0) {
            return jobsService.getFullJobDetailsByJobDurationCode(jobDurationCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code and Worker Code should not be blank.");
            return derr.toString();
        }
    }
    
    
    @PutMapping("/assignToWorkerByJobDurationCode/{jobDurationCode}")
    public String assignToWorkerByJobDurationCode(@PathVariable String jobDurationCode,
            @RequestBody AssignToWorkerReqNew wsr, HttpServletRequest req) {
        if (wsr!=null && wsr.getWorkerCode()!=null && wsr.getWorkerCode().trim().length()>0  && jobDurationCode!=null && jobDurationCode.trim().length()>0) {
            return jobsService.assignToWorkerByJobDurationCode(wsr,jobDurationCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Jobs Code, JobDuration Code and Worker Code should not be blank.");
            return derr.toString();
        }
    }
    
    @PutMapping("/assignToWorkerByJobCodeAndJobDurationCode/{jobCode}/{jobDurationCode}")
    public String assignToWorkerByJobCodeAndJobDurationCode(@PathVariable String jobCode,@PathVariable String jobDurationCode,
            @RequestBody AssignToWorkerReq wsr, HttpServletRequest req) {
        if (wsr!=null && wsr.getWorkerCode()!=null && wsr.getWorkerCode().trim().length()>0 && jobCode != null  && jobCode.trim().length() > 0 && jobDurationCode!=null && jobDurationCode.trim().length()>0) {
            return jobsService.assignToWorkerByJobCodeAndJobDurationCode(wsr,jobCode.trim(),jobDurationCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Jobs Code, JobDuration Code and Worker Code should not be blank.");
            return derr.toString();
        }
    }
    
    
    @PutMapping("/assignToWorkerByJobAssignToWorkerCode/{jobAssignToWorkerCode}")
    public String assignToWorkerByJobCodeAndJobDurationCode(@PathVariable String jobAssignToWorkerCode,
            @RequestBody AssignToWorkerReq wsr, HttpServletRequest req) {
        if (wsr!=null && wsr.getWorkerCode()!=null && wsr.getWorkerCode().trim().length()>0 && jobAssignToWorkerCode != null  && jobAssignToWorkerCode.trim().length() > 0 ) {
            return jobsService.assignToWorkerByJobAssignToWorkerCode(wsr,jobAssignToWorkerCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobAssignToWorker Code and Worker Code should not be blank.");
            return derr.toString();
        }
    }
    
    
    @PutMapping("/assignToWorkerAccepted/{jobAssignToWorkerCode}")
    public String assignToWorkerAccepted(@PathVariable String jobAssignToWorkerCode,
            @RequestBody AssignToWorkerStatusReq wsr, HttpServletRequest req) {
        if (wsr!=null && wsr.getWorkerCode()!=null && wsr.getWorkerCode().trim().length()>0 && jobAssignToWorkerCode != null  && jobAssignToWorkerCode.trim().length() > 0 ) {
            return jobsService.assignToWorkerAccepted(wsr,jobAssignToWorkerCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobAssignToWorker Code and Worker Code should not be blank.");
            return derr.toString();
        }
    }
      
    @PutMapping("/assignToWorkerRejected/{jobAssignToWorkerCode}")
    public String assignToWorkerRejected(@PathVariable String jobAssignToWorkerCode,
            @RequestBody AssignToWorkerStatusReq wsr, HttpServletRequest req) {
        if (wsr!=null && wsr.getWorkerCode()!=null && wsr.getWorkerCode().trim().length()>0 && jobAssignToWorkerCode != null && wsr.getComment()!=null && wsr.getComment().length()>0  && jobAssignToWorkerCode.trim().length() > 0 ) {
            return jobsService.assignToWorkerRejected(wsr,jobAssignToWorkerCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobAssignToWorker Code, Worker Code and Comment should not be blank.");
            return derr.toString();
        }
    }
    

    
     @GetMapping(path="/getAllJobsByWorkerCodeWithFilterByPage/{workerCode}/{status}/{stratDT}/{endDT}")
         public String getAllJobsByWorkerCodeWithFilterByPage(@PathVariable String workerCode,@PathVariable List<String> status,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
             
              String res="";
               
                if(workerCode!=null && workerCode.trim().length()>0 && status!=null && status.size()>0  ) {
                     if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
                     {
		            Date sDT = null;
		            Date eDT = null;
		   try {
                       boolean sbool=GigflexDateUtil.validateDateFormat(stratDT.trim(), GigflexConstants.YYYY_MM_DD);
                      boolean ebool=GigflexDateUtil.validateDateFormat(endDT.trim(), GigflexConstants.YYYY_MM_DD);
                        if(sbool == false || ebool == false) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();

			}
			sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();

			}

		     } catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
			return derr.toString();
		    }
                
                          if(sDT!=null && eDT!=null)
                         {
                            if (!(sDT.equals(eDT) || (eDT.after(sDT)))) 
                            {
                              GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			      return derr.toString();
                             }
                          }
                
                   }
                  else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		  }

             return jobsService.getAllJobsByWorkerCodeWithFilterByPage(workerCode.trim(),status,stratDT.trim(), endDT.trim(),page, limit);
           
             }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Worker Code and Status should not be blank.");
			return derr.toString();
		}
           
       }
          
         
         @GetMapping(path="/getDistanceCoveredByTechnician /{workerCode}/{stratDT}/{endDT}")
         public String getDistanceCoveredByTechnician(@PathVariable String workerCode,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestHeader HttpHeaders headers) {
             
              String res="";
               
                if(workerCode!=null && workerCode.trim().length()>0   ) {
                     if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
                     {
		            Date sDT = null;
		            Date eDT = null;
		   try {
                       boolean sbool=GigflexDateUtil.validateDateFormat(stratDT.trim(), GigflexConstants.YYYY_MM_DD);
                      boolean ebool=GigflexDateUtil.validateDateFormat(endDT.trim(), GigflexConstants.YYYY_MM_DD);
                        if(sbool == false || ebool == false) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();

			}
			sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(stratDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();

			}

		     } catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
			return derr.toString();
		    }
                
                          if(sDT!=null && eDT!=null)
                         {
                            if (!(sDT.equals(eDT) || (eDT.after(sDT)))) 
                            {
                              GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			      return derr.toString();
                             }
                          }
                
                   }
                  else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		  }

             return jobsService.getDistanceCoveredByTechnician(workerCode.trim(),stratDT.trim(), endDT.trim());
           
             }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Worker Code and Status should not be blank.");
			return derr.toString();
		}
           
       }
         
         @GetMapping(path="/getAllJobsByWorkerCodeWithFilterByPage/{workerCode}/{status}")
         public String getAllJobsByWorkerCodeWithFilterByPage(@PathVariable String workerCode,@PathVariable List<String> status,
            @RequestParam(value = "page", defaultValue = "0") int page,
                 @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) 
         {
              String res="";
               
                      if(workerCode!=null && workerCode.trim().length()>0 && status!=null && status.size()>0  ) {
    

                          return jobsService.getAllJobsByWorkerCodeWithFilterByPage(workerCode.trim(),status,null, null, page, limit);
           
                     }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Worker Code and Status should not be blank.");
			return derr.toString();
		     }
               
               
           
         }


    @GetMapping("gettodaysAppoinmentsByworkerCode/{workerCode}")
    public String gettodaysAppoinmentsforMobileByworkerCode(@PathVariable String workerCode)
    {
       if(workerCode!=null && workerCode.trim().length()>0)
       {
         return  jobsService .gettodaysAppoinmentsforMobileByworkerCode(workerCode);
       }else
       {
        GigflexResponse derr = new GigflexResponse(400, new Date(),"Driver Code should not be blank");
	return derr.toString();
       }
    }
    
     @PutMapping("/assignToWorkerAcceptedByJobDurationCode/{jobDurationCode}")
    public String assignToWorkerAcceptedByJobDurationCode(@PathVariable String jobDurationCode,
            @RequestBody AssignToWorkerReqNew wsr, HttpServletRequest req) {
        if (wsr!=null && wsr.getWorkerCode()!=null && wsr.getWorkerCode().trim().length()>0  && jobDurationCode!=null && jobDurationCode.trim().length()>0) {
            return jobsService.assignToWorkerAcceptedByJobDurationCode(wsr,jobDurationCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code and should not be blank.");
            return derr.toString();
        }
    }

     @PutMapping("/assignToWorkerrejectedByJobDurationCode/{jobDurationCode}")
    public String assignToWorkerrejectedByJobDurationCode(@PathVariable String jobDurationCode,
            @RequestBody RejectToworkerreq Req, HttpServletRequest req) {
        if (Req!=null && Req.getWorkerCode()!=null && Req.getWorkerCode().trim().length()>0  && jobDurationCode!=null && jobDurationCode.trim().length()>0&& Req.getComment()!=null && Req.getComment().trim().length()>0) {
            return jobsService.assignToWorkerrejectedByJobDurationCode(Req,jobDurationCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code,comments and worker Code should not be blank.");
            return derr.toString();
        }
    }
    
    @PutMapping("/assignToWorkercancelByJobDurationCode/{jobDurationCode}")
    public String assignToWorkercancelByJobDurationCode(
            @RequestBody CancelToworkerReq Req,@PathVariable String jobDurationCode, HttpServletRequest req) {
        if (Req!=null && jobDurationCode!=null && jobDurationCode.trim().length()>0&& Req.getComment()!=null && Req.getComment().trim().length()>0) {
            return jobsService.assignToWorkercancelByJobDurationCode(Req,jobDurationCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code comment should not be blank.");
            return derr.toString();
        }
    }
      @PutMapping("/assignToWorkerInProgressByJobDurationCode/{jobDurationCode}")
      public String assignToWorkerInProgressByJobDurationCode(
            @RequestBody AssignWorkerInProgerssStatusReq Req,@PathVariable String jobDurationCode, HttpServletRequest req) {
       if(jobDurationCode!=null && jobDurationCode.trim().length()>0){
           if (Req!=null && Req.getWorkerCode()!=null && Req.getWorkerCode().trim().length()>0 && Req.getCurruntLatitude()!=null && Req.getCurruntLatitude().trim().length()>0 && Req.getCurruntLongitude()!=null && Req.getCurruntLongitude().trim().length()>0 && Req.getComment()!=null && Req.getComment().trim().length()>0) {
            return jobsService.assignToWorkerInProgressByJobDurationCode(Req,jobDurationCode.trim(),req.getRemoteHost());
           } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "WorkerCode ,CurrentLatitude, CurruentLongitude,comments  should not be blank.");
            return derr.toString();
           }
        }else
        {
             GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code and should not be blank.");
            return derr.toString();
         }
    }
    
    @PutMapping("/assignToWorkercompleteByJobDurationCode/{jobDurationCode}")
      public String assignToWorkercompleteByJobDurationCode(
            @RequestBody AssignWorkerInProgerssStatusReq Req,@PathVariable String jobDurationCode, HttpServletRequest req) {
         if(jobDurationCode!=null && jobDurationCode.trim().length()>0)
         { 
            if (Req!=null && Req.getWorkerCode()!=null && Req.getWorkerCode().trim().length()>0 &&Req.getCurruntLatitude()!=null && Req.getCurruntLatitude().trim().length()>0 && Req.getCurruntLongitude()!=null && Req.getCurruntLongitude().trim().length()>0 && Req.getComment()!=null && Req.getComment().trim().length()>0 ) {
            return jobsService.assignToWorkercompleteByJobDurationCode(Req,jobDurationCode.trim(),req.getRemoteHost());
            } else {
             GigflexResponse derr = new GigflexResponse(400, new Date(), "WorkerCode ,CurrentLatitude, CurruentLongitude,comment  should not be blank.");
             return derr.toString();
            }
         }else
         {
          GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code and should not be blank.");
             return derr.toString();
         }
    }
       @PutMapping("/assignToWorkerPendingByJobDurationCode/{jobDurationCode}")
      public String assignToWorkerPendingByJobDurationCode(
            @RequestBody RejectToworkerreq Req,@PathVariable String jobDurationCode, HttpServletRequest req) {
        if (Req!=null && Req.getWorkerCode()!=null && Req.getWorkerCode().trim().length()>0  && jobDurationCode!=null && jobDurationCode.trim().length()>0) {
            return jobsService.assignToWorkerPendingByJobDurationCode(Req,jobDurationCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code and should not be blank.");
            return derr.toString();
        }
    }  
      
       @PutMapping("/assignToWorkerexpiredByJobDurationCode/{jobDurationCode}")
      public String assignToWorkerexpiredByJobDurationCode(
            @RequestBody CancelToworkerReq Req,@PathVariable String jobDurationCode, HttpServletRequest req) {
        if (Req!=null && jobDurationCode!=null && jobDurationCode.trim().length()>0) {
            return jobsService.assignToWorkerexpiredByJobDurationCode(Req,jobDurationCode.trim(),req.getRemoteHost());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "JobDuration Code and should not be blank.");
            return derr.toString();
        }
    }  
      
      
      @GetMapping(path = "/getJobForDashboardByOrganizationCode/{organizationCode}/{startDT}/{endDT}")
	public String getJobForDashboardByOrganizationCode(@PathVariable String organizationCode,@PathVariable String startDT,@PathVariable String endDT ) {
                           
                if (organizationCode != null && organizationCode.trim().length() > 0) {
                    
                    if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
                    {
                        Date sDT = null;
                        Date eDT = null;
                        try {
                                sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(startDT.trim());
                                eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
                                if(sDT == null || eDT == null) {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                        "Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
                                        return derr.toString();
                                }

                        } catch (Exception ex) {
                                ex.printStackTrace();
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                "Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
                                return derr.toString();
                        }

                        if(sDT!=null && eDT!=null)
                        {
                           if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                               GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                "End Date must be after Start Date.");
                                return derr.toString();
                           }
                        }

                    }
                    else {
                            GigflexResponse derr = new GigflexResponse(400, new Date(),
                                            "Start Date and End Date should not be blank.");
                            return derr.toString();
                    }
                     return jobsService.getJobForDashboardByOrganizationCode(organizationCode.trim(),startDT,endDT);

		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Organization Code should not be blank.");
			return derr.toString();
		}              
	}
        
        @GetMapping(path = "/getJobForDashboardByOrganizationCode/{organizationCode}")
	public String getJobForDashboardByOrganizationCode(@PathVariable String organizationCode) {
                           
                if (organizationCode != null && organizationCode.trim().length() > 0) {
                      return jobsService.getJobForDashboardByOrganizationCode(organizationCode.trim(),null,null);

		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Organization Code should not be blank.");
			return derr.toString();
		}              
	}
        
        @GetMapping(path="/getAllJobsByOrganizationCodeWithFilterByPage/{organizationCode}/{status}/{startDT}/{endDT}")
        public String getAllJobsByOrganizationCodeWithFilterByPage(@PathVariable String organizationCode,@PathVariable List<String> status,
            @PathVariable String startDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
            String res="";
              
            if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(startDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
                }
                else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}		
		
			return jobsService.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode.trim(),status,startDT.trim(), endDT.trim(),page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
          }
    
          @GetMapping(path="/getAllJobsByOrganizationCodeWithFilterByPage/{organizationCode}/{status}")
          public String getAllJobsByOrganizationCodeWithFilterByPage(@PathVariable String organizationCode,@PathVariable List<String> status,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {        
              
                if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

                      return jobsService.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode.trim(),status,null, null,page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
         }
      
          
          
          @GetMapping(path="/getAllJobsByOrganizationCodeWithFilter/{organizationCode}/{status}/{startDT}/{endDT}")
        public String getAllJobsByOrganizationCodeWithFilter(@PathVariable String organizationCode,@PathVariable List<String> status,
            @PathVariable String startDT,@PathVariable String endDT) {
            String res="";
              
            if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(startDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
                }
                else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}		
		
			return jobsService.getAllJobsByOrganizationCodeWithFilter(organizationCode.trim(),status,startDT.trim(), endDT.trim());
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
          }
        
        
        
        
        
        @GetMapping(path="/getAllJobsByOrganizationCodeWithFilterDateTime/{organizationCode}/{status}/{startDT}/{endDT}")
        public String getAllJobsByOrganizationCodeWithFilterDateTime(@PathVariable String organizationCode,@PathVariable List<String> status,
            @PathVariable String startDT,@PathVariable String endDT) {
            String res="";
              
            if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
                    Boolean sst=GigflexDateUtil.validateDateFormat(startDT.trim(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    Boolean est=GigflexDateUtil.validateDateFormat(endDT.trim(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    if(sst == false || est == false) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send startDT and endDT in correct format("+GigflexConstants.DD_MM_YYYY_HH_MM_SS+")");
				return derr.toString();
			}
			sDT = new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(startDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send startDT and endDT in correct format("+GigflexConstants.DD_MM_YYYY_HH_MM_SS+")");
				return derr.toString();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send startDT and endDT in correct format("+GigflexConstants.DD_MM_YYYY_HH_MM_SS+")");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
                }
                else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}		
		
			return jobsService.getAllJobsByOrganizationCodeWithFilterDateTime(organizationCode.trim(),status,startDT.trim(), endDT.trim());
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
          }
        
          @GetMapping(path="/getAllJobsByOrganizationCodeWithFilter/{organizationCode}/{status}/{startDT}/{endDT}/{patientCode}")
        public String getAllJobsByOrganizationCodeWithFilter(@PathVariable String organizationCode,@PathVariable List<String> status,
            @PathVariable String startDT,@PathVariable String endDT,@PathVariable String patientCode) {
            String res="";
              
            if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  && patientCode!=null && patientCode.trim().length()>0) {

            if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(startDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
                }
                else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}		
		
			return jobsService.getAllJobsByOrganizationCodeWithFilter(organizationCode.trim(),status,startDT.trim(), endDT.trim(),patientCode.trim());
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code, Status and Patient Code should not be blank.");
			return derr.toString();
		}
          }
    
          @GetMapping(path="/getAllJobsByOrganizationCodeWithFilter/{organizationCode}/{status}")
          public String getAllJobsByOrganizationCodeWithFilter(@PathVariable String organizationCode,@PathVariable List<String> status) {        
              
                if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

                      return jobsService.getAllJobsByOrganizationCodeWithFilter(organizationCode.trim(),status,null, null);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
         }
          
          
            @GetMapping(path="/getAppointmentDetailOfTechnicianByOrganizationCode/{organizationCode}/{status}/{startDT}/{endDT}")
            public String getAppointmentDetailOfTechnicianByOrganizationCode(@PathVariable String organizationCode,@PathVariable List<String> status,
            @PathVariable String startDT,@PathVariable String endDT) {
            String res="";
              
            if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(startDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
                }
                else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}		
		
			return jobsService.getAppointmentDetailOfTechnicianByOrganizationCode(organizationCode.trim(),status,startDT.trim(), endDT.trim());
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
          }
            
            
          @GetMapping(path="/getAllJobsByOrganizationCodeWithFilterForTest/{organizationCode}/{status}")
          public String getAllJobsByOrganizationCodeWithFilterForTest(@PathVariable String organizationCode,@PathVariable List<String> status) {        
              
                if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

                      return jobsService.getAllJobsByOrganizationCodeWithFilterForTest(organizationCode.trim(),status,null, null);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
         }
            
           @GetMapping(path="/getAppointmentDetailOfTechnicianByOrganizationCodeForTest/{organizationCode}/{status}/{startDT}/{endDT}")
           public String getAppointmentDetailOfTechnicianByOrganizationCodeForTest(@PathVariable String organizationCode,@PathVariable List<String> status,
            @PathVariable String startDT,@PathVariable String endDT) {
            String res="";
              
            if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(startDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
                }
                else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}		
		
			return jobsService.getAppointmentDetailOfTechnicianByOrganizationCodeForTest(organizationCode.trim(),status,startDT.trim(), endDT.trim());
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
          }
          
            
        @GetMapping(path="/getAllJobsByOrganizationCodeWithFilterForTest/{organizationCode}/{status}/{startDT}/{endDT}")
        public String getAllJobsByOrganizationCodeWithFilterForTest(@PathVariable String organizationCode,@PathVariable List<String> status,
            @PathVariable String startDT,@PathVariable String endDT) {
            String res="";
              
            if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(startDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
                }
                else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}		
		
			return jobsService.getAllJobsByOrganizationCodeWithFilterForTest(organizationCode.trim(),status,startDT.trim(), endDT.trim());
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
          }
        
        @GetMapping(path="/getAppointmentDetailOfTechnicianByOrganizationCodeByPage/{organizationCode}/{status}/{startDT}/{endDT}")
           public String getAppointmentDetailOfTechnicianByOrganizationCodeByPage(@PathVariable String organizationCode,@PathVariable List<String> status,
            @PathVariable String startDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
            String res="";
              
            if(organizationCode!=null && organizationCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(startDT.trim());
			eDT = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
				return derr.toString();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send startDT and endDT in correct format("+GigflexConstants.YYYY_MM_DD+")");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
                }
                else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}		
		
			return jobsService.getAppointmentDetailOfTechnicianByOrganizationCodeByPage(organizationCode.trim(),status,startDT.trim(), endDT.trim(),page,limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code and Status should not be blank.");
			return derr.toString();
		}
          }
          
            
        
}
