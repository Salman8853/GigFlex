package com.gigflex.prototype.microservices.jobs.dtob;

/**
 * 
 * @author nirbhay.p
 *
 */

public class AssignToWorkerReqNew  {

    
    
    private String workerCode; 
    
   

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

   
    
}