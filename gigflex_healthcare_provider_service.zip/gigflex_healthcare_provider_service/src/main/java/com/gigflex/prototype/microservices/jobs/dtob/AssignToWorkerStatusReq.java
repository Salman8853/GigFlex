package com.gigflex.prototype.microservices.jobs.dtob;

/**
 * 
 * @author nirbhay.p
 *
 */

public class AssignToWorkerStatusReq  {

    
    
    private String workerCode; 
    
   
    private String comment;  

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    
    
}