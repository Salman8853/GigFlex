/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.dtob;

import java.util.Date;

/**
 *
 * @author nirbhay.p
 */
public class CoveredDistanceRes {
    private String jobsDurationCode;
    private Date startTimeStamp ;
    
    private Date endTimeStamp ;
    
    private String startTime ;
    
    private String endTime ;
    private String patientName;
    private String workerName;
    private String patientCode;
    private String distanceValue;
    private Double durationValue;
    private String distanceText;
    private String durationText;
    private Boolean isHome;
    private String oldLat;
    private String oldLong;
    private String curLat;
    private String curLong;
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    

    public String getJobsDurationCode() {
        return jobsDurationCode;
    }

    public void setJobsDurationCode(String jobsDurationCode) {
        this.jobsDurationCode = jobsDurationCode;
    }

    public Date getStartTimeStamp() {
        return startTimeStamp;
    }

    public void setStartTimeStamp(Date startTimeStamp) {
        this.startTimeStamp = startTimeStamp;
    }

    public Date getEndTimeStamp() {
        return endTimeStamp;
    }

    public void setEndTimeStamp(Date endTimeStamp) {
        this.endTimeStamp = endTimeStamp;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public String getDistanceValue() {
        return distanceValue;
    }

    public void setDistanceValue(String distanceValue) {
        this.distanceValue = distanceValue;
    }

    public Double getDurationValue() {
        return durationValue;
    }

    public void setDurationValue(Double durationValue) {
        this.durationValue = durationValue;
    }

    public String getDistanceText() {
        return distanceText;
    }

    public void setDistanceText(String distanceText) {
        this.distanceText = distanceText;
    }

    public String getDurationText() {
        return durationText;
    }

    public void setDurationText(String durationText) {
        this.durationText = durationText;
    }

    public Boolean getIsHome() {
        return isHome;
    }

    public void setIsHome(Boolean isHome) {
        this.isHome = isHome;
    }

    public String getOldLat() {
        return oldLat;
    }

    public void setOldLat(String oldLat) {
        this.oldLat = oldLat;
    }

    public String getOldLong() {
        return oldLong;
    }

    public void setOldLong(String oldLong) {
        this.oldLong = oldLong;
    }

    public String getCurLat() {
        return curLat;
    }

    public void setCurLat(String curLat) {
        this.curLat = curLat;
    }

    public String getCurLong() {
        return curLong;
    }

    public void setCurLong(String curLong) {
        this.curLong = curLong;
    }
    
    
    
}
