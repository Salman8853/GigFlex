/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.dtob;

import com.gigflex.prototype.microservices.worker.dtob.Worker;
import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public class EligibleWorkerRes {
    private String jobsDurationCode;
    
    private String jobsCode;  
    
    private String jobDurationStartTime;
    
    private List<WorkerWithDistance> workerWithDistanceList;

    public String getJobDurationStartTime() {
        return jobDurationStartTime;
    }

    public void setJobDurationStartTime(String jobDurationStartTime) {
        this.jobDurationStartTime = jobDurationStartTime;
    }
    
    public String getJobsDurationCode() {
        return jobsDurationCode;
    }

    public void setJobsDurationCode(String jobsDurationCode) {
        this.jobsDurationCode = jobsDurationCode;
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }

    public List<WorkerWithDistance> getWorkerWithDistanceList() {
        return workerWithDistanceList;
    }

    public void setWorkerWithDistanceList(List<WorkerWithDistance> workerWithDistanceList) {
        this.workerWithDistanceList = workerWithDistanceList;
    }

   
    
}
