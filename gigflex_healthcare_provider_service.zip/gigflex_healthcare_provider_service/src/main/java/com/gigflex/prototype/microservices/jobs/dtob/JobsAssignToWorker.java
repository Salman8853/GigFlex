package com.gigflex.prototype.microservices.jobs.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.util.Date;

import java.util.UUID;

import javax.persistence.PrePersist;
import org.hibernate.annotations.GenericGenerator;

/**
 * 
 * @author nirbhay.p
 *
 */
@Entity
@Table(name = "jobs_assign_to_worker")
public class JobsAssignToWorker extends CommonAttributes implements Serializable {


    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "jobs_assign_worker_code", unique = true)
    private String jobsAassignWorkerCode;
    
    @Column(name = "jobs_duration_code", nullable=false)
    private String jobsDurationCode;
    
    @Column(name = "jobs_code" , nullable=false)
    private String jobsCode; 
    
    @Column(name = "worker_code")
    private String workerCode; 
    
    @Column(name = "distance")
    private Double distance;
    
    @Column(name = "driving_time_in_sec")
    private Integer drivingTimeInSec; 
    
    @Column(name = "status", nullable=false)
    private String status; 
    
    @Column(name = "comment")
    private String comment; 
    
    @Column(name = "start_lat")
    private String startLat;  
    
    @Column(name = "start_long")
    private String startLong; 
    
    @Column(name = "end_lat")
    private String endLat;  
    
    @Column(name = "end_long")
    private String endLong;  
    
    @Column(name = "appointment_id")
    private String appointmentId; 
   
   @PrePersist
    private void assignUUID() {
        if(this.getJobsAassignWorkerCode()==null || this.getJobsAassignWorkerCode().length()==0)
        {
            this.setJobsAassignWorkerCode(UUID.randomUUID().toString());
        }
    }

    public Integer getDrivingTimeInSec() {
        return drivingTimeInSec;
    }

    public void setDrivingTimeInSec(Integer drivingTimeInSec) {
        this.drivingTimeInSec = drivingTimeInSec;
    }

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getJobsAassignWorkerCode() {
        return jobsAassignWorkerCode;
    }

    public void setJobsAassignWorkerCode(String jobsAassignWorkerCode) {
        this.jobsAassignWorkerCode = jobsAassignWorkerCode;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getJobsDurationCode() {
        return jobsDurationCode;
    }

    public void setJobsDurationCode(String jobsDurationCode) {
        this.jobsDurationCode = jobsDurationCode;
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }

    public String getStartLat() {
        return startLat;
    }

    public void setStartLat(String startLat) {
        this.startLat = startLat;
    }

    public String getStartLong() {
        return startLong;
    }

    public void setStartLong(String startLong) {
        this.startLong = startLong;
    }

    public String getEndLat() {
        return endLat;
    }

    public void setEndLat(String endLat) {
        this.endLat = endLat;
    }

    public String getEndLong() {
        return endLong;
    }

    public void setEndLong(String endLong) {
        this.endLong = endLong;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }

   
    
}