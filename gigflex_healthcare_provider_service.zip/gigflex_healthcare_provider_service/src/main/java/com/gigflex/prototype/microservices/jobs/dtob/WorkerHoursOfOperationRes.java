/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.dtob;

/**
 *
 * @author nirbhay.p
 */
public class WorkerHoursOfOperationRes {
    private String startDateTime;
    private String endDateTime; 
    private String fromTime;
    private String toTime; 
    private Integer dayCode;
    private String workerhoursOfOperationCode;
    private String dateFormat;
    private String timeFormat; 

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }
    

    public String getStartDateTime() {
        return startDateTime;
    }

    public void setStartDateTime(String startDateTime) {
        this.startDateTime = startDateTime;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public Integer getDayCode() {
        return dayCode;
    }

    public void setDayCode(Integer dayCode) {
        this.dayCode = dayCode;
    }

    public String getWorkerhoursOfOperationCode() {
        return workerhoursOfOperationCode;
    }

    public void setWorkerhoursOfOperationCode(String workerhoursOfOperationCode) {
        this.workerhoursOfOperationCode = workerhoursOfOperationCode;
    }
    
}
