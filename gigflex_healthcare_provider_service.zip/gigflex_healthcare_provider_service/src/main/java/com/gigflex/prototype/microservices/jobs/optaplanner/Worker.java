/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.optaplanner;

import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursOfOperation;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOff;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public class Worker {
    private String workerCode;
    private String lat;
    private String lang;
    private List<String>skillList;
    private List<WorkerTimeOff> workertimeof;
    private String workerTimeZone;
    private HashMap <Integer,WorkerHoursOfOperation> workerHOPMap;

    public String getWorkerTimeZone() {
        return workerTimeZone;
    }

    public void setWorkerTimeZone(String workerTimeZone) {
        this.workerTimeZone = workerTimeZone;
    }

    public HashMap<Integer, WorkerHoursOfOperation> getWorkerHOPMap() {
        return workerHOPMap;
    }

    public void setWorkerHOPMap(HashMap<Integer, WorkerHoursOfOperation> workerHOPMap) {
        this.workerHOPMap = workerHOPMap;
    }
    
    
    public Worker() {
        
    }
   
    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public List<String> getSkillList() {
        return skillList;
    }

    public void setSkillList(List<String> skillList) {
        this.skillList = skillList;
    }

    

    public List<WorkerTimeOff> getWorkertimeof() {
        return workertimeof;
    }

    public void setWorkertimeof(List<WorkerTimeOff> workertimeof) {
        this.workertimeof = workertimeof;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    
}
