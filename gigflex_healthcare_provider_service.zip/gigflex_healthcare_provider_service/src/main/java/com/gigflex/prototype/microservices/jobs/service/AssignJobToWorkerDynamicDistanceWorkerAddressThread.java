/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.service;

import com.gigflex.prototype.microservices.jobs.dtob.Jobs;
import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.jobs.dtob.JobsDuration;
import com.gigflex.prototype.microservices.jobs.repository.JobsAssignToWorkerRepository;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GoogleDistanceDuration;
import com.gigflex.prototype.microservices.util.GoogleDistanceDurationResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AssignJobToWorkerDynamicDistanceWorkerAddressThread implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(AssignJobToWorkerDynamicDistanceWorkerAddressThread.class);
    private Worker wkr;
    private JobsAssignToWorkerRepository jobsAssignToWorkerRepository;
    private Date startDate;
    private String timeZone;
    private String googleAPIKEY;

    public AssignJobToWorkerDynamicDistanceWorkerAddressThread(Worker wkr, JobsAssignToWorkerRepository jobsAssignToWorkerRepository, Date startDate, String timeZone, String googleAPIKEY) {
        super();
        this.wkr = wkr;
        this.jobsAssignToWorkerRepository = jobsAssignToWorkerRepository;
        this.startDate = startDate;
        this.googleAPIKEY = googleAPIKEY;
        this.timeZone = timeZone;
    }

    @Override
    public void run() {
        LOG.info("================Start AssignJobToWorkerDynamicDistanceWorkerAddressThread===============");
        try {
            if (wkr != null && startDate != null && timeZone != null) {
                Date localStartDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timeZone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                if (localStartDate != null) {
                    String sDate = GigflexDateUtil.convertDateToString(localStartDate, GigflexConstants.YYYY_MM_DD);
                    if (sDate != null && sDate.length() > 0) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        String sdtStr = sDate + " 00:00:00";
                        Date sDT = GigflexDateUtil.convertStringDateToGMT(sdtStr, timeZone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                        if (sDT != null) {
                            HashMap<String, String> startDatePatientCodeMap = new HashMap<>();
                            List<Object> objlst = jobsAssignToWorkerRepository.getAllJobsByWorkerCodeWithFilterForChangeAddressThread(wkr.getWorkerCode(), stlst, sDT);
                            if (objlst != null && objlst.size() > 0) {
                                for (int i = 0; i < objlst.size(); i++) {
                                    Object[] arr = (Object[]) objlst.get(i);
                                    if (arr.length >= 4) {
                                        Jobs jobData = (Jobs) arr[0];
                                        JobsDuration jdData = (JobsDuration) arr[1];
                                        JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                        PatientDetails pDetail = (PatientDetails) arr[3];
                                        if (jobData != null && jdData != null && jawData != null && pDetail != null) {
                                            String mapKey = "";
                                            if (jdData.getStartTime() != null) {
                                                Date startDate = jdData.getStartTime();
                                                Date timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timeZone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                                                String sdat = GigflexDateUtil.convertDateToString(timestampStartTime, GigflexConstants.YYYY_MM_DD);
                                                mapKey = jobData.getOrganizationCode() + "$" + sdat;
                                            }

                                            if (!startDatePatientCodeMap.containsKey(mapKey)) {
                                                if (jawData.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED) || jawData.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED)) {
                                                    GoogleDistanceDurationResponse gddres = getGoogleDistanceDurationResponse(wkr.getLatitude(), wkr.getLongitude(), pDetail.getPatientLatitude(), pDetail.getPatientLongitude());
                                                    if (gddres != null && gddres.getDistanceValue() != null && gddres.getDurationValue() != null) {
                                                        try {
                                                            double mileCon = 1609.344;
                                                            Double distance = gddres.getDistanceValue() / mileCon;
                                                            jawData.setDistance(distance);
                                                            jawData.setDrivingTimeInSec(gddres.getDurationValue());
                                                            jobsAssignToWorkerRepository.save(jawData);
                                                        } catch (Exception ee) {
                                                            LOG.error("Error in AssignJobToWorkerDynamicDistanceThread save dynamic distance>>>>>>", ee);
                                                        }
                                                    }
                                                }
                                                startDatePatientCodeMap.put(mapKey, jobData.getPatientCode());
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                LOG.info("AssignJobToWorkerDynamicDistanceWorkerAddressThread >>>>>> in ELSE");
            }
        } catch (Exception e) {
            LOG.error("Error in AssignJobToWorkerDynamicDistanceWorkerAddressThread >>>>>>", e);
        }
        LOG.info("================End AssignJobToWorkerDynamicDistanceWorkerAddressThread===============");
    }

    private GoogleDistanceDurationResponse getGoogleDistanceDurationResponse(String lat1, String lon1, String lat2, String lon2) {
        try {
            if (lat1 != null && lat1.trim().length() > 0 && lon1 != null && lon1.trim().length() > 0 && lat2 != null && lat2.trim().length() > 0 && lon2 != null && lon2.trim().length() > 0) {
                GoogleDistanceDurationResponse res = GoogleDistanceDuration.getGoogleDistanceDuration(googleAPIKEY, lat1.trim(), lon1.trim(), lat2.trim(), lon2.trim());
                if (res != null && res.getStatus()) {

                    return res;

                }
            }
        } catch (Exception e) {
            LOG.error("Error in AssignJobToWorkerDynamicDistanceWorkerAddressThread>>>", e);
        }
        return null;
    }
}
