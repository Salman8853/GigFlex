/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.organizationapproval.repository;

import com.gigflex.prototype.microservices.organizationapproval.dtob.OrganizationApprovalAuthority;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 *
 * @author nirbhay.p
 */
public interface OrganizationApprovalAuthorityRepository extends JpaRepository<OrganizationApprovalAuthority, Long>{
    
    @Query("SELECT oaa FROM OrganizationApprovalAuthority oaa WHERE oaa.isDeleted != TRUE")
    public List<OrganizationApprovalAuthority> getAllOAA();
    
    @Query("SELECT oaa FROM OrganizationApprovalAuthority oaa WHERE oaa.id=:id AND oaa.isDeleted != TRUE")
    public OrganizationApprovalAuthority getOAAById(Long id);
    
    @Query("SELECT oaa FROM OrganizationApprovalAuthority oaa WHERE oaa.organizationApprovalAuthorityCode=:organizationApprovalAuthorityCode AND oaa.isDeleted != TRUE")
    public OrganizationApprovalAuthority getOAAByCode(String organizationApprovalAuthorityCode);
    
    @Query("SELECT oaa FROM OrganizationApprovalAuthority oaa WHERE oaa.organizationCode=:organizationCode AND oaa.isDeleted != TRUE")
    public List<OrganizationApprovalAuthority> getOAAByOrgCode(String organizationCode);
    
    @Query("SELECT oaa FROM OrganizationApprovalAuthority oaa WHERE oaa.authorityCode=:authorityCode AND oaa.isDeleted != TRUE")
    public List<OrganizationApprovalAuthority> getOAAByAuthorityCode(String authorityCode);
    
    @Query("SELECT oaa FROM OrganizationApprovalAuthority oaa WHERE oaa.authorityCode=:authorityCode AND oaa.isDeleted != TRUE  AND (oaa.isProcessed = FALSE OR oaa.isProcessed IS NULL)")
    public List<OrganizationApprovalAuthority> getPendingOAAByAuthorityCode(String authorityCode);
    
    @Query("SELECT oaa FROM OrganizationApprovalAuthority oaa WHERE oaa.authorityCode=:authorityCode AND oaa.organizationCode=:organizationCode AND (oaa.isProcessed = FALSE OR oaa.isProcessed IS NULL)")
    public OrganizationApprovalAuthority validateOAA(String authorityCode,String organizationCode);
    
}
