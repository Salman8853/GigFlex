/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationbaseprocedure.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organizationbaseprocedure.dtob.OrganizationBaseProcedure;
import com.gigflex.prototype.microservices.organizationbaseprocedure.dtob.OrganizationBaseProcedureRequest;
import com.gigflex.prototype.microservices.organizationbaseprocedure.dtob.OrganizationBaseProcedureResponse;
import com.gigflex.prototype.microservices.organizationbaseprocedure.repository.OrganizationBaseProcedureDao;
import com.gigflex.prototype.microservices.organizationbaseprocedure.service.OrganizationBaseProcedureService;
import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMaster;
import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureSkillMapping;
import com.gigflex.prototype.microservices.proceduremaster.repository.ProcedureMasterDao;
import com.gigflex.prototype.microservices.proceduremaster.repository.ProcedureSkillMappingDao;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service 
public class OrganizationBaseProcedureServiceImpl implements OrganizationBaseProcedureService {

    private static final Logger LOG = LoggerFactory.getLogger(OrganizationBaseProcedureServiceImpl.class);
    
    @Autowired
    private OrganizationBaseProcedureDao orgBaseProcedureDao;
    @Autowired
    ProcedureSkillMappingDao procedureSkillMappingRep;
    
    @Autowired
    private ProcedureMasterDao procedureMasterRep;
    
    @Autowired
    private OrganizationRepository organizationDao;
    
    @Override
    public String findAllProcedureByOrganizationCode(String organizationCode) {
        
         String res = "";
		try {
                    
                       JSONObject jsonobj = new JSONObject();
                       if(organizationCode != null)
                       {                          
                            List<OrganizationBaseProcedure> obpList = orgBaseProcedureDao.getAllByOrganizationCode(organizationCode);
                            List<OrganizationBaseProcedureResponse> obpResList = new ArrayList<OrganizationBaseProcedureResponse>();
                            if(obpList != null && obpList.size()> 0)
                            {  
                                for(OrganizationBaseProcedure obp : obpList)
                                {
                                    String procedureCode =obp.getProcedureCode();
                                    String orgCode= obp.getOrganizationCode();
                                    OrganizationBaseProcedureResponse obpRes= new OrganizationBaseProcedureResponse();
                                    
                                    List<SkillMaster> skillMasterList = procedureSkillMappingRep.getSkillByProcedureCode(procedureCode);
                                    obpRes.setId(obp.getId());
                                    obpRes.setProcedureCode(procedureCode);
                                    obpRes.setOrganizationCode(orgCode); 
                                    obpRes.setOrganizationBaseProcedureCode(obp.getOrganizationBaseProcedureCode());
                                    obpRes.setProcedureName(obp.getProcedureName());
                                    obpRes.setProcedureDescription(obp.getProcedureDescription());
                                    obpRes.setProcedureIcon(obp.getProcedureIcon());
                                    ProcedureMaster pm=procedureMasterRep.getProcedureMasterByProcedureCode(procedureCode);
                                    if(pm!=null && pm.getId()>0)
                                    {
                                        obpRes.setProcedureId(pm.getProcedureId());
                                    }
                                    if(skillMasterList != null && skillMasterList.size()>0)
                                    {
                                        obpRes.setSkillMasterList(skillMasterList);
                                    }
                                    
                                    Organization org = organizationDao.findByOrganizationCode(orgCode);
                                    
                                    if(org != null)
                                    {
                                        obpRes.setOrganizationName(org.getOrganizationName()); 
                                    }
                                    
                                    obpResList.add(obpRes);
                                }
                                                            
                                if (obpResList != null && obpResList.size() >0) {
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Success");
                                    jsonobj.put("timestamp", new Date());
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(obpResList);
                                    jsonobj.put("data", new JSONArray(Detail));
                                } else {
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("message", "Record Not Found.");
                                        jsonobj.put("timestamp", new Date());
                                }
                            }
                            else
                            {
                                jsonobj.put("responsecode",404);
                                jsonobj.put("message", "Record Not Found");
                                jsonobj.put("timestamp", new Date());

                            }
			
                       }
                        else
                        {
                            jsonobj.put("responsecode",400);
                            jsonobj.put("message", "Organization Code should not be blank");
                            jsonobj.put("timestamp", new Date());
			
                        }                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }

    @Override
    public String findProcedureByOrganizationCodeAndProcedureCode(String organizationCode, String procedureCode) {
        
        String res = "";
		try {
                    
                       JSONObject jsonobj = new JSONObject();
                       if(organizationCode != null && procedureCode != null)
                       {                          
                            OrganizationBaseProcedure obp = orgBaseProcedureDao.getByOrganizationCodeAndProcedureCode(organizationCode,procedureCode);
                            OrganizationBaseProcedureResponse obpRes = null;
                            if(obp != null && obp.getId()> 0) 
                            {                                  
                                obpRes = new OrganizationBaseProcedureResponse();
                                List<SkillMaster> skillMasterList = procedureSkillMappingRep.getSkillByProcedureCode(procedureCode);
                                obpRes.setId(obp.getId());
                                obpRes.setProcedureCode(procedureCode);
                                obpRes.setOrganizationCode(organizationCode); 
                                obpRes.setOrganizationBaseProcedureCode(obp.getOrganizationBaseProcedureCode());
                                obpRes.setProcedureName(obp.getProcedureName());
                                obpRes.setProcedureDescription(obp.getProcedureDescription());
                                obpRes.setProcedureIcon(obp.getProcedureIcon());

                                ProcedureMaster pm=procedureMasterRep.getProcedureMasterByProcedureCode(procedureCode);
                                    if(pm!=null && pm.getId()>0)
                                    {
                                        obpRes.setProcedureId(pm.getProcedureId());
                                    }
                                if(skillMasterList != null && skillMasterList.size()>0)
                                {
                                    obpRes.setSkillMasterList(skillMasterList);
                                }

                                Organization org = organizationDao.findByOrganizationCode(organizationCode);

                                if(org != null)
                                {
                                    obpRes.setOrganizationName(org.getOrganizationName()); 
                                }
                                
                            if (obpRes != null && obpRes.getId() > 0) {
                                jsonobj.put("responsecode", 200);
                                jsonobj.put("message", "Success");
                                jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
                                String Detail = mapperObj.writeValueAsString(obpRes);
                                jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Record Not Found.");
                                    jsonobj.put("timestamp", new Date());
                            }
                            }
                            else
                            {
                                jsonobj.put("responsecode",404);
                                jsonobj.put("message", "Record Not Found");
                                jsonobj.put("timestamp", new Date());
                            }			
                       }
                        else
                        {
                            jsonobj.put("responsecode",400);
                            jsonobj.put("message", "Organization Code & Procedure Code should not be blank");
                            jsonobj.put("timestamp", new Date());			
                        }                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }

    @Override
    public String updateProcedureByOrganizationBasedProcedureCode(String organizationBaseProcedureCode,OrganizationBaseProcedureRequest orgBaseProcedureReq, String ip) {
       
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (orgBaseProcedureReq != null && organizationBaseProcedureCode != null && organizationBaseProcedureCode.trim().length() >0  ) {
				if (orgBaseProcedureReq.getOrganizationCode() != null
						&& orgBaseProcedureReq.getOrganizationCode().trim().length() > 0
                                        && orgBaseProcedureReq.getProcedureCode() != null && orgBaseProcedureReq.getProcedureCode().trim().length() > 0 
                                        & orgBaseProcedureReq.getProcedureName() != null && orgBaseProcedureReq.getProcedureName().trim().length() >0
                                        && orgBaseProcedureReq.getProcedureDescription() != null && orgBaseProcedureReq.getProcedureDescription().trim().length() >0
                                        && orgBaseProcedureReq.getProcedureIcon() != null && orgBaseProcedureReq.getProcedureIcon().trim().length() >0)
                                {
                                    
                                       OrganizationBaseProcedure  alreadyExist = orgBaseProcedureDao.getForCheckByOrganizationBaseProcedureCodeOrgCodeAndProcedureCode(organizationBaseProcedureCode,orgBaseProcedureReq.getOrganizationCode(),orgBaseProcedureReq.getProcedureCode());
                                    					
					if (alreadyExist == null ) {
                                            
                                                OrganizationBaseProcedure obpInDb = orgBaseProcedureDao.getByOrganizationBaseProcedureCode(organizationBaseProcedureCode);
                                               
                                                obpInDb.setIpAddress(ip);
                                                obpInDb.setOrganizationCode(orgBaseProcedureReq.getOrganizationCode());
                                                obpInDb.setProcedureCode(orgBaseProcedureReq.getProcedureCode());  
                                                obpInDb.setProcedureName(orgBaseProcedureReq.getProcedureName());
                                                obpInDb.setProcedureDescription(orgBaseProcedureReq.getProcedureDescription());
                                                obpInDb.setProcedureIcon(orgBaseProcedureReq.getProcedureIcon());  

                                                OrganizationBaseProcedure obpRes = orgBaseProcedureDao.save(obpInDb);
                                              
						if (obpRes != null && obpRes.getId() > 0) {
                                                            
                                                    jsonobj.put("responsecode", 200);
                                                    jsonobj.put("message", "Organization Base Procedure updation has been done");
                                                    jsonobj.put("timestamp", new Date());
                                                    ObjectMapper mapperObj = new ObjectMapper();
                                                    String Detail = mapperObj.writeValueAsString(obpRes);
                                                    jsonobj.put("data", new JSONObject(Detail));
						} else {
                                                    jsonobj.put("responsecode", 400);
                                                    jsonobj.put("message",
                                                                    "Organization Base Procedure updation has been failed.");
                                                    jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 409);
						jsonobj.put("message", "Organization Base Procedure  already exist. ");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Organization Code , Procedure Code,Procedure Name,Procedure Description & Procedure Icon  should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String saveOrganizationBaseProcedure(OrganizationBaseProcedureRequest orgBaseProcedureReq, String ip) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (orgBaseProcedureReq != null ) {
				if (orgBaseProcedureReq.getProcedureCode() != null
						&& orgBaseProcedureReq.getProcedureCode().trim().length() > 0 
                                        && orgBaseProcedureReq.getOrganizationCode() != null && orgBaseProcedureReq.getOrganizationCode().trim().length() > 0
                                        && orgBaseProcedureReq.getProcedureName() != null && orgBaseProcedureReq.getProcedureName().trim().length() >0
                                        && orgBaseProcedureReq.getProcedureDescription() != null && orgBaseProcedureReq.getProcedureDescription().trim().length() >0
                                        && orgBaseProcedureReq.getProcedureIcon() != null && orgBaseProcedureReq.getProcedureIcon().trim().length() >0) {

                                        OrganizationBaseProcedure obpExist = orgBaseProcedureDao.getByOrganizationCodeAndProcedureCode(orgBaseProcedureReq.getOrganizationCode(),orgBaseProcedureReq.getProcedureCode());
                                        
                                        if(obpExist != null && obpExist.getId() > 0)
                                        {
                                            jsonobj.put("responsecode", 409);
                                            jsonobj.put("timestamp", new Date());
                                            jsonobj.put("message", "Record already exist.");
                                        }
                                        else
                                        {
                                            OrganizationBaseProcedure obpResponse = new OrganizationBaseProcedure();
                                            obpResponse.setOrganizationCode(orgBaseProcedureReq.getOrganizationCode());
                                            obpResponse.setProcedureCode(orgBaseProcedureReq.getProcedureCode());
                                            obpResponse.setIpAddress(ip);
                                            obpResponse.setProcedureName(orgBaseProcedureReq.getProcedureName());
                                            obpResponse.setProcedureDescription(orgBaseProcedureReq.getProcedureDescription());
                                            obpResponse.setProcedureIcon(orgBaseProcedureReq.getProcedureIcon());  

                                            OrganizationBaseProcedure obpRes = orgBaseProcedureDao.save(obpResponse);
                                            
                                            if (obpRes != null && obpRes.getId() >0) 
                                            {
                                                jsonobj.put("responsecode", 200);
                                                jsonobj.put("timestamp", new Date());
                                                jsonobj.put("message","Organization Based Procedure has been added successfully.");
                                                ObjectMapper mapperObj = new ObjectMapper();
                                                String Detail = mapperObj.writeValueAsString(obpRes);
                                                jsonobj.put("data", new JSONObject(Detail));
                                            }
                                            else
                                            {
                                                jsonobj.put("responsecode", 400);
                                                jsonobj.put("timestamp", new Date());
                                                jsonobj.put("message", "Failed");
                                            }
                                        }
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Procedure Code , Organization Code,Procedure Name,Procedure Description & Procedure Icon  should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
    }
    
}
