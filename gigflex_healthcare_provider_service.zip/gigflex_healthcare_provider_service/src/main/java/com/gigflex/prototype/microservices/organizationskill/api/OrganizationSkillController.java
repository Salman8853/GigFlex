package com.gigflex.prototype.microservices.organizationskill.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.organizationskill.dtob.OrgSkillRequest;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkillRequest;
import com.gigflex.prototype.microservices.organizationskill.service.OrganizationSkillService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class OrganizationSkillController {
	
	@Autowired
	OrganizationSkillService orgSkillService;
	
	@GetMapping("/getSkillsByOrganizationCode/{organizationCode}")
	public String getSkillsByOrganizationCode(@PathVariable String organizationCode) {
		return orgSkillService.getSkillsByOrgCode(organizationCode);
	}
	
	@GetMapping(path="/getSkillsByOrganizationCodeByPage/{organizationCode}")
    public String getSkillsByOrganizationCodeByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String skills = orgSkillService.getSkillsByOrgCode(page, limit, organizationCode);
      
        return skills;
       
    }
	
	@GetMapping("/organizationSkill/{search}")
	public String search(@PathVariable("search") String search) {
		return orgSkillService.search(search);
	}
	
	@GetMapping("/getAllOrganizationSkill")
	public String getAllOrganizationSkill() {
		return orgSkillService.getAllOrganizationSkill();
	}
	
	@GetMapping("/getAllOrganizationSkillWithNames")
	public String getAllOrganizationSkillWithNames() {
		return orgSkillService.getAllOrganizationSkillWithNames();
	}
	
	@GetMapping(path="/getOrganizationSkillByPage")
    public String getOrganizationSkillByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String orgSkill = orgSkillService.getOrganizationSkill(page, limit);
      
        return orgSkill;
       
    }

@GetMapping(path="/getOrganizationSkillWithNamesByPage")
public String getOrganizationSkillWithNamesByPage(@RequestParam(value = "page", defaultValue = "0") int page,
        @RequestParam(value = "limit", defaultValue = "30") int limit) {

    String orgSkill = orgSkillService.getOrganizationSkillWithNamesByPage(page, limit);
  
    return orgSkill;
   
}

	@GetMapping("/getOrganizationSkill/{id}")
	public String getAllOrganizationSkillById(@PathVariable Long id) {
		return orgSkillService.getOrganizationSkillById(id);
	}
	
	@PostMapping("/saveOrganizationSkill")
	public String saveAllOrganizationSkill(
			 @RequestBody OrganizationSkillRequest orgSkillrqst,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return orgSkillService.saveOrganizationSkill(orgSkillrqst, ip);

	}

	@DeleteMapping("/deleteOrganizationSkill/{id}")
	public String deleteAllOrganizationSkillById(@PathVariable("id") Long id) {
		return orgSkillService.deleteOrganizationSkillById(id);
	}
	
	@DeleteMapping("/softDeleteOrganizationSkill/{id}")
	public String softDeleteOrganizationSkillById(@PathVariable("id") Long id) {
		return orgSkillService.softDeleteOrganizationSkillById(id);
	}
	
	@DeleteMapping("/softMultipleDeleteOrganizationSkillById/{idList}")
	public String softMultipleDeleteOrganizationSkillById(@PathVariable("idList") List<Long> idList) {
		if(idList != null && idList.size()>0){
			return orgSkillService.softMultipleDeleteById(idList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
	}
	

	@PutMapping("/updateOrganizationSkill/{id}")
	public String updateRolePermissionsById(@PathVariable Long id,
			@Valid @RequestBody OrgSkillRequest orgSkillrqst,
			HttpServletRequest request) {
		if (id == null) {
			return "Organizations Skill with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return orgSkillService.updateOrganizationSkillById(id, orgSkillrqst, ip);
		}
	}
}


