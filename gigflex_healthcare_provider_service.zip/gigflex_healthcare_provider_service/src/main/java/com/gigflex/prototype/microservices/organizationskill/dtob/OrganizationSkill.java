package com.gigflex.prototype.microservices.organizationskill.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import javax.persistence.GenerationType;

@Entity
@Table(name="organization_skill")
public class OrganizationSkill extends CommonAttributes implements Serializable {
	
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "skill_code" , nullable=false)
    private String skillCode;

    @Column(name = "organization_code" , nullable=false)
    private String organizationCode;
    @Column(name = "color")
    private String color;

    @Column(name = "skill_image")
    private String skillImage;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
         
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSkillCode() {
		return skillCode;
	}

	public void setSkillCode(String skillCode) {
		this.skillCode = skillCode;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

        public String getSkillImage() {
            return skillImage;
        }

        public void setSkillImage(String skillImage) {
            this.skillImage = skillImage;
        }	 
 
}
