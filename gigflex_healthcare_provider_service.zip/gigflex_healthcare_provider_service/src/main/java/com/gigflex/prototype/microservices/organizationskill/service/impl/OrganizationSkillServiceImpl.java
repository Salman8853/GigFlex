package com.gigflex.prototype.microservices.organizationskill.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.service.HealthcareNotificationService;
import com.gigflex.prototype.microservices.organizationskill.dtob.SkillData;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrgSkillRequest;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrgSkillResponse;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkillRequest;
import com.gigflex.prototype.microservices.organizationskill.repository.OrganizationSkillDao;
import com.gigflex.prototype.microservices.organizationskill.search.OrganizationSkillSpecificationsBuilder;
import com.gigflex.prototype.microservices.organizationskill.service.OrganizationSkillService;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.skillmaster.repository.SkillMasterDao;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import java.util.HashSet;
import java.util.Set;

@Service
public class OrganizationSkillServiceImpl implements OrganizationSkillService{
	
	@Autowired
	private OrganizationSkillDao orgSkillDao;
	
    @Autowired
	OrganizationRepository orgRep;
    
    @Autowired
    SkillMasterDao skillRep;
	
	@Autowired
        HealthcareNotificationService notificationService;

	@Override
	public String getAllOrganizationSkill() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<OrganizationSkill> orgSkilllst = orgSkillDao.getAllOrganizationSkill();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (orgSkilllst != null && orgSkilllst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(orgSkilllst);
				jsonobj.put("data", new JSONArray(Detail));
			}
			 else
	            {
	                jsonobj.put("responsecode", 404);
	            jsonobj.put("message", "Record Not Found");
	            jsonobj.put("timestamp", new Date());
	            }
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
		return res;
	}

	@Override
	public String getOrganizationSkillById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			OrganizationSkill orgSkilllst = orgSkillDao.getOrganizationSkillById(id);
			
			if ( orgSkilllst != null && orgSkilllst.getId() > 0) {
                            OrgSkillResponse orgres=new OrgSkillResponse();
                            orgres.setColor(orgSkilllst.getColor());
                            orgres.setId(orgSkilllst.getId());
                            orgres.setOrganizationCode(orgSkilllst.getOrganizationCode());
                            orgres.setSkillCode(orgSkilllst.getSkillCode());
                            orgres.setSkillImage(orgSkilllst.getSkillImage());
                            SkillMaster sm=skillRep.getSkillMasterBySkillCode(orgSkilllst.getSkillCode());
                            if(sm!=null && sm.getId()>0)
                            {
                                orgres.setSkillName(sm.getSkillName());
                            }
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(orgres);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveOrganizationSkill(OrganizationSkillRequest orgskillrqst,
			String ip) {
		
		String res = "";
		try {
			JSONArray jarr = new JSONArray();


			if(orgskillrqst != null){
				
				
				
			if ((orgskillrqst.getOrganizationCode() != null && orgskillrqst.getOrganizationCode().trim().length() > 0)
					&& (orgskillrqst.getSkillList() != null && orgskillrqst.getSkillList().size() > 0)) {
     int i=0;
     for(SkillData skills : orgskillrqst.getSkillList() ){
		if(skills != null && skills.getSkillImage()!=null && skills.getSkillImage().trim().length() > 0){
			
			JSONObject jsonobj = new JSONObject();
			
			OrganizationSkill orgSkill = orgSkillDao.getSkillMasterCheckForSave(skills.getSkillCode().trim(), orgskillrqst.getOrganizationCode());
			if (orgSkill != null && orgSkill.getId() > 0) {
				jsonobj.put("skillcode", skills.getSkillCode());
                                jsonobj.put("responsecode", 409);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record already exist.");
			} else {
			Organization org = orgRep
					.findByOrganizationCode(orgskillrqst
							.getOrganizationCode());
			if (org != null && org.getId() > 0) {
			SkillMaster skill = skillRep.getSkillCode(skills.getSkillCode().trim());
			if (skill != null && org.getId() > 0) {
				
				OrganizationSkill orgSkilllst = new OrganizationSkill();
				orgSkilllst.setOrganizationCode(orgskillrqst.getOrganizationCode());
				orgSkilllst.setSkillCode(skills.getSkillCode().trim());
				orgSkilllst.setColor(skills.getColor());
                                orgSkilllst.setSkillImage(skills.getSkillImage()); 
				orgSkilllst.setIpAddress(ip);

				OrganizationSkill orgSkillRes = orgSkillDao.save(orgSkilllst);
				
					if (orgSkillRes != null && orgSkillRes.getId() > 0) {
//						 kafkaService.sendOrganizationSkill(orgSkillRes);
                                                jsonobj.put("responsecode", 200);
                                                jsonobj.put("skillcode", skills.getSkillCode());
                                                jsonobj.put("timestamp", new Date());
						jsonobj.put("message",
								"Organization Code and Skill Code has been added successfully.");
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(orgSkillRes);
						jsonobj.put("data", new JSONObject(Detail));
                                                
                                                HealthcareNotification notification = new HealthcareNotification();

                                                String bodyContent = "Dear User"
                                                                + ",New skill has been added in your organization. Details are given below-"
                                                                + "Skill Name : " + skill.getSkillName()+ "," + "Skill Code : "
                                                                + skill.getSkillCode();
                                                String shortMessage = "Organization Skill has been added successfully.";

                                                notification.setUserCode(orgSkillRes.getOrganizationCode());
                                                notification.setMessage(bodyContent);
                                                notification.setUserType("All");
                                                notification.setShortMessage(shortMessage);
                                                notification.setAppointmentCode("");
                                                notification.setIsRead(Boolean.FALSE);
                                                notification.setIpAddress(ip);

                                                notificationService.saveHealthcareNotification(notification);

                                                
					} else {
                                                jsonobj.put("responsecode", 400);
                                                jsonobj.put("skillcode", skills.getSkillCode());
                                                jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}
					
					
		} else {
			jsonobj.put("message", "Skill Code Not Found.");
			jsonobj.put("responsecode", 400);
                        jsonobj.put("skillcode", skills.getSkillCode());
			jsonobj.put("timestamp", new Date());
		}
		} else {
		jsonobj.put("message", "Organization Code Not Found.");
		jsonobj.put("responsecode", 400);
                jsonobj.put("skillcode", skills.getSkillCode());
		jsonobj.put("timestamp", new Date());
		}
		}

			jarr.add(jsonobj);
	}
	
	}

	if (jarr.size() > 0) {
		res = jarr.toString();
	} else {
		GigflexResponse derr = new GigflexResponse(400, new Date(),
				"Multiple add failed.");
		res = derr.toString();
	}

	
			}
			 else {
				 GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Organization Code and Skill Code should not be blank");
					res = derr.toString();
				
			}
			}
		
	
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteOrganizationSkillById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<OrganizationSkill> orgSkilldata = orgSkillDao.findById(id);
					
			if (orgSkilldata.isPresent() && orgSkilldata.get() != null) {
				orgSkillDao.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Organization Skill has been deleted.");
				jsonobj.put("timestamp", new Date());
				
//				kafkaService.sendDeleteOrganizationSkill(orgSkilldata.get());
				
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String updateOrganizationSkillById(Long id,
			OrgSkillRequest orgskillrqst, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && orgskillrqst != null) {
				if ((orgskillrqst.getOrganizationCode() != null && orgskillrqst.getOrganizationCode().trim().length() > 0)
						&& (orgskillrqst.getSkillCode() != null && orgskillrqst.getSkillCode().trim().length() > 0)) {
					OrganizationSkill orgSkillinDb = orgSkillDao.getOrganizationSkillById(id);
					
					OrganizationSkill orgSkills = orgSkillDao.getSkillMasterCheckForUpdate(id, orgskillrqst.getSkillCode(), orgskillrqst.getOrganizationCode());

					if (orgSkills != null && orgSkills.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record already exist.");
					} else {
					
					Organization org = orgRep
							.findByOrganizationCode(orgskillrqst
									.getOrganizationCode());
					if (org != null && org.getId() > 0) {
					SkillMaster skill = skillRep.getSkillCode(orgskillrqst.getSkillCode());
					
					if (skill != null && skill.getId() > 0) {
						
					if (orgSkillinDb != null && orgSkillinDb.getId() > 0) {
						
						OrganizationSkill orgSkill = orgSkillinDb;
						orgSkill.setOrganizationCode(orgskillrqst.getOrganizationCode());
						orgSkill.setSkillCode(orgskillrqst.getSkillCode());
                                                orgSkill.setColor(orgskillrqst.getColor());
						orgSkill.setIpAddress(ip);
                                                orgSkill.setSkillImage(orgskillrqst.getSkillImage());
						
						OrganizationSkill orgSkillRes = orgSkillDao.save(orgSkill);
						if (orgSkillRes != null && orgSkillRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"Organization Skill updation has been done");
                                                        jsonobj.put("timestamp", new Date());
                                                        ObjectMapper mapperObj = new ObjectMapper();
                                                        String Detail = mapperObj
                                                                        .writeValueAsString(orgSkillRes);
                                                        jsonobj.put("data", new JSONObject(Detail));

                                                        HealthcareNotification notification = new HealthcareNotification();

                                                        String bodyContent = "Dear User"
                                                                        + ",Skill has been updated in your organization. Details are given below-"
                                                                        + "Skill Name : " + skill.getSkillName()+ "," + "Skill Code : "
                                                                        + skill.getSkillCode();
                                                        String shortMessage = "Organization Skill has been updated successfully.";

                                                        notification.setUserCode(orgSkillRes.getOrganizationCode());
                                                        notification.setMessage(bodyContent);
                                                        notification.setUserType("All");
                                                        notification.setShortMessage(shortMessage);
                                                        notification.setAppointmentCode("");
                                                        notification.setIsRead(Boolean.FALSE);
                                                        notification.setIpAddress(ip);

                                                        notificationService.saveHealthcareNotification(notification);

                                                        
                                                        
							
//							kafkaService.sendUpdateOrganizationSkill(orgSkillRes);
							
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Organization Skill updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Organization Skill ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
					
					
				} else {
					jsonobj.put("message", "Skill Code Not Found.");
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
				}
				} else {
				jsonobj.put("message", "Organization Code Not Found.");
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				}
				}
			
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Organization Code and Skill Code should not be blank");
					jsonobj.put("timestamp", new Date());
				}
	        	}
	        	else {
					jsonobj.put("responsecode", 400);
	                jsonobj.put("message", "Input data is not valid.");
	                jsonobj.put("timestamp", new Date());
				}

				res = jsonobj.toString();
			} catch (JSONException ex) {
				GigflexResponse derr = new GigflexResponse(500, new Date(),
						"JSON parsing exception is occurred.");
				res = derr.toString();
				ex.printStackTrace();
			} catch (Exception ex) {
				GigflexResponse derr = new GigflexResponse(500, new Date(),
						"Exception is occurred.");
				res = derr.toString();
				ex.printStackTrace();
			}
			return res;
	}

	@Override
	public String softDeleteOrganizationSkillById(Long id) {
		String res = "";
		try {
		JSONObject jsonobj = new JSONObject();
		OrganizationSkill orgSkillinDb = orgSkillDao.getOrganizationSkillById(id);
		
		if (orgSkillinDb != null && orgSkillinDb.getId() > 0) {
			orgSkillinDb.setIsDeleted(true);
			OrganizationSkill orgSkillRes = orgSkillDao.save(orgSkillinDb);
		if (orgSkillRes != null && orgSkillRes.getId()>0) {
		jsonobj.put("responsecode", 200);
		jsonobj.put("timestamp", new Date());

		jsonobj.put("message", "Organization Skill deleted successfully.");

//		kafkaService.sendUpdateOrganizationSkill(orgSkillRes);
		} else {
		jsonobj.put("responsecode", 400);
		jsonobj.put("timestamp", new Date());
		jsonobj.put("message", "Failed");
		}

		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("timestamp", new Date());
		jsonobj.put("message", "Record Not Found");
		}
		res = jsonobj.toString();
		} catch (Exception ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(),
		"JSON parsing exception occurred.");
		res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteById(List<Long> idList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (Long id : idList) {
				if(id != null && id >0){
				JSONObject jsonobj = new JSONObject();

					OrganizationSkill orgSkillinDb = orgSkillDao.getOrganizationSkillById(id);
					
					if (orgSkillinDb != null && orgSkillinDb.getId() > 0) {
						
						orgSkillinDb.setIsDeleted(true);
						OrganizationSkill orgSkillRes = orgSkillDao.save(orgSkillinDb);
						if (orgSkillRes != null && orgSkillRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message", "Organization Skill deleted successfully.");
//							kafkaService.sendUpdateOrganizationSkill(orgSkillRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("Id", id);
						jsonobj.put("message", "Record Not Found");
					}
				
				jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllOrganizationSkillWithNames() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = orgSkillDao.getAllOrganizationSkillWithNames();
			List<OrgSkillResponse> maplst = new ArrayList<OrgSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {
						OrgSkillResponse ows = new OrgSkillResponse();

						OrganizationSkill data = (OrganizationSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
                                                ows.setColor(data.getColor());

						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
                                                ows.setSkillImage(data.getSkillImage());

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}
	
	@Override
	public String getOrganizationSkill(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
	        Pageable pageableRequest = PageRequest.of(page, limit);
	        List<OrganizationSkill> org = orgSkillDao.getAllOrganizationSkill(pageableRequest);
                int count=0;
                List<OrganizationSkill> orgcnt = orgSkillDao.getAllOrganizationSkill();
                if(orgcnt!=null && orgcnt.size()>0)
                {
                    count=orgcnt.size();
                }
                
			if (org != null && org.size() > 0) {
                              jsonobj.put("responsecode", 200);
                            jsonobj.put("message", "Success");
                            jsonobj.put("count", count);
                            jsonobj.put("timestamp", new Date());
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(org);
                            jsonobj.put("data", new JSONArray(Detail));
			}
			 else
	            {
	                jsonobj.put("responsecode", 400);
	            jsonobj.put("message", "Record Not Found");
	            jsonobj.put("timestamp", new Date());
	            }
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
	    return res;
	}

	@Override
	public String getOrganizationSkillWithNamesByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
	        Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = orgSkillDao.getAllOrganizationSkillWithNames(pageableRequest);
                        List<OrgSkillResponse> maplst = new ArrayList<OrgSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
                            List<Object> objlstcnt = orgSkillDao.getAllOrganizationSkillWithNames();
			int count=0;
                        if(objlstcnt!=null && objlstcnt.size()>0)
                        {
                            count=objlstcnt.size();
                        }
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {
						OrgSkillResponse ows = new OrgSkillResponse();

						OrganizationSkill data = (OrganizationSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
					        ows.setColor(data.getColor());

						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
                                                ows.setSkillImage(data.getSkillImage());

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
                                        jsonobj.put("count", count);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
            if(search != null && search.trim().length() > 0){
			JSONObject jsonobj = new JSONObject();
			
			OrganizationSkillSpecificationsBuilder builder = new OrganizationSkillSpecificationsBuilder();
		        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
		        java.util.regex.Matcher matcher = pattern.matcher(search + ",");
		        while (matcher.find()) {
		            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
		        }
		         
		        Specification<OrganizationSkill> spec = builder.build();
                        if(spec!=null){
		        List<OrganizationSkill> orglst = orgSkillDao.findAll(spec);
			if(orglst != null && orglst.size() > 0){
			for(OrganizationSkill org : orglst){
				if(org.getIsDeleted() != null && org.getIsDeleted() != true){

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(org);
					JSONObject jsonobjNew = new JSONObject();
					jsonobjNew.put("OrganizationSkill", new JSONObject(Detail));
					jarr.add(jsonobjNew);

			} 
				
			} 
			if (jarr.size() > 0) {
				
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			jsonobj.put("data", jarr);
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}
			
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}}
                        else{
                            jsonobj.put("responsecode", 400);
			    jsonobj.put("message", "Record Not Found!");
			    jsonobj.put("timestamp", new Date());
                        }
			res = jsonobj.toString();
		
            }else{
            	GigflexResponse derr = new GigflexResponse(400, new Date(),
    					"Input data is not valid.");
    			res = derr.toString();

            }
			
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getSkillsByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (organizationCode != null && organizationCode.length() > 0) {
				
                            
                            List<Object> objlst = orgSkillDao.getOrganizationSkillsByOrganizationCode(organizationCode);
			List<OrgSkillResponse> maplst = new ArrayList<OrgSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {
						OrgSkillResponse ows = new OrgSkillResponse();

						OrganizationSkill data = (OrganizationSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
					        ows.setColor(data.getColor());

						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
                                                ows.setSkillImage(data.getSkillImage()); 

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Organization Code should not be blank.");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getSkillsByOrgCode(int page, int limit,
			String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);

			if (organizationCode != null && organizationCode.length() > 0) {
			
                            List<Object> objlst = orgSkillDao.getOrganizationSkillsByOrganizationCode(organizationCode,pageableRequest);
			List<OrgSkillResponse> maplst = new ArrayList<OrgSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
                            int count=0;
                             List<Object> objlstcnt = orgSkillDao.getOrganizationSkillsByOrganizationCode(organizationCode);
                             if(objlstcnt!=null && objlstcnt.size()>0)
                             {
                                count= objlstcnt.size();
                             }
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {
						OrgSkillResponse ows = new OrgSkillResponse();

						OrganizationSkill data = (OrganizationSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
					        ows.setColor(data.getColor());

						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
                                                ows.setSkillImage(data.getSkillImage());

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("count", count);
                                        jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Organization Code should not be blank.");
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
