package com.gigflex.prototype.microservices.organizationworkinglocationhours.api;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob.OrganizationWorkingLocationHoursRequest;
import com.gigflex.prototype.microservices.organizationworkinglocationhours.service.OrganizationWorkingLocationHoursService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
public class OrganizationWorkingLocationHoursController {
	
	@Autowired
	OrganizationWorkingLocationHoursService orgWrkLovHrsService;
	
	@GetMapping("/organizationWorkingLocationHours/{search}")
	public String search(@PathVariable("search") String search) {
		return orgWrkLovHrsService.search(search);
	}
	
	@GetMapping("/getOrganizationWorkingLocationHoursByOrgCode/{organizationCode}")
	public String getOrganizationWorkingLocationHours(@PathVariable String organizationCode) {
		return orgWrkLovHrsService.getOrganizationWorkingLocationHoursByOrganizationCode(organizationCode);
	}
	
	@GetMapping("/getOrganizationWorkingLocationHoursByOrgCodeByPage/{organizationCode}")
	public String getOrganizationWorkingLocationHours(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
		String orgWrkLoc =orgWrkLovHrsService.getOrganizationWorkingLocationHoursByOrganizationCode(organizationCode, page, limit);
		return orgWrkLoc;
	}
	
	@GetMapping("/getOrganizationWorkingLocationHoursByWorkingLocationCode/{workingLocationCode}")
	public String getOrganizationWorkingLocationHoursByWorkingLocationCode(@PathVariable String workingLocationCode) {
		return orgWrkLovHrsService.getOrganizationWorkingLocationHoursByWorkingLocationCode(workingLocationCode);
	}
	
	@GetMapping("/getAllOrganizationWorkingLocationHoursWithNames")
	public String getAllOrganizationWorkingLocationHoursWithNames() {
		return orgWrkLovHrsService.getAllOrganizationWorkingLocationHoursWithNames();
	}
	
	@GetMapping(path="/getAllOrganizationWorkingLocationHoursWithNamesByPage")
    public String getAllOrganizationWorkingLocationHoursWithNamesByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String orgWrkLoc = orgWrkLovHrsService.getOrganizationWorkingLocationHoursWithNamesByPage(page, limit);
      
        return orgWrkLoc;
       
    }
	
	@PostMapping("/saveOrganizationWorkingLocationHours")
    public String saveOrganizationWorkingLocationHours(@RequestBody List<OrganizationWorkingLocationHoursRequest> orgWrkLocHrsReq, HttpServletRequest request){
  	    String ip=request.getRemoteAddr();
  	   return orgWrkLovHrsService.saveOrganizationWorkingLocationHours(orgWrkLocHrsReq, ip);
  	
    }
	
	

}
