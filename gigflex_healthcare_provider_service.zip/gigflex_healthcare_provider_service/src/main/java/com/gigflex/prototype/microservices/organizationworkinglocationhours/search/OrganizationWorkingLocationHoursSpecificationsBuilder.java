package com.gigflex.prototype.microservices.organizationworkinglocationhours.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob.OrganizationWorkingLocationHours;
import com.gigflex.prototype.microservices.util.SearchCriteria;


public class OrganizationWorkingLocationHoursSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public OrganizationWorkingLocationHoursSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public OrganizationWorkingLocationHoursSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<OrganizationWorkingLocationHours> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<OrganizationWorkingLocationHours>> specs = new ArrayList<Specification<OrganizationWorkingLocationHours>>();
        for (SearchCriteria param : params) {
            specs.add(new OrganizationWorkingLocationHoursSpecification(param));
        }
 
        Specification<OrganizationWorkingLocationHours> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
