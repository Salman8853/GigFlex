/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.patient.api;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.patient.dtob.PatientRequest;
import com.gigflex.prototype.microservices.patient.service.PatientService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author amit.kumar
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
public class PatientController {
    
    @Autowired
    PatientService patientService;
    
    @GetMapping("/getPatientDetailByOrganizationCode/{organizationCode}")
	public String getPatientDetailByOrganizationCode(@PathVariable String organizationCode) {
		return patientService.getPatientDetailByOrganizationCode(organizationCode);
	}
        
        @GetMapping("/getPatientDetailByPatientCode/{patientCode}")
       public String getPatientDetailByPatientCode(@PathVariable String patientCode) {
               return patientService.getPatientDetailByPatientCode(patientCode);
       }
        
     @GetMapping("/getPatientDetailWithoutHavingLatLong/")
       public String getPatientDetailWithoutHavingLatLong() {
               return patientService.getPatientDetailWithoutHavingLatLong();
       }
       
       
       @PostMapping("/savePatientDetail")
	public String savePatientDetail(
			 @RequestBody PatientRequest pRequest,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return patientService.savePatientDetail(pRequest, ip);

	}
        
        @PutMapping("/updatePatientDetailByPatientCode/{patientCode}")
	public String updatePatientDetailByPatientCode(@PathVariable String patientCode,
			 @RequestBody PatientRequest pRequest,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return patientService.updatePatientDetail(patientCode,pRequest, ip);

	}
                
       @PostMapping("/uploadPatientDocumentFile")
       public String uploadPatientDocumentFile(@RequestParam("file") MultipartFile file,@RequestParam("patientCode") String patientCode) {
        String res = "";
        String respon = patientService.storePatientDocumentFile(file,patientCode);
        try {
            JSONObject jSONObject = new JSONObject(respon);
            if (jSONObject.has("responsecode") && jSONObject.getInt("responsecode") == 200) {

                String fileName = jSONObject.getString("filename");
                String filepath = jSONObject.getString("filepath");
//                String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
//                        .path("/healthcareservice/downloadFile/")
//                        .path(fileName)
//                        .toUriString();
                JSONObject jsonobj = new JSONObject();
                jsonobj.put("responsecode", 200);
                jsonobj.put("message", "success");
                jsonobj.put("filename", fileName);
                jsonobj.put("filepath", filepath);
                res = jsonobj.toString();
            } else {
                res = respon;
            }
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;

      }    
       
       
       @GetMapping("/getPatientDocumentMappingByPatientDocumentMappingCode/{patientDocumentMappingCode}")
       public String getPatientDocumentMappingByPatientDocumentMappingCode(@PathVariable String patientDocumentMappingCode) {
               return patientService.getPatientDocumentMappingByPatientDocumentMappingCode(patientDocumentMappingCode);
       }       
	
	@DeleteMapping("/softDeletePatientDocumentByPatientDocumentMappingCode/{patientDocumentMappingCode}")
	public String softDeletePatientDocumentByPatientDocumentMappingCode(@PathVariable("patientDocumentMappingCode") String patientDocumentMappingCode) {
		return patientService.softDeletePatientDocumentByPatientDocumentMappingCode(patientDocumentMappingCode);
	}
	
	@DeleteMapping("/softMultipleDeletePatientDocumentByPatientDocumentMappingCode/{patientDocumentMappingCodeList}")
	public String softMultipleDeletePatientDocumentByPatientDocumentMappingCode(@PathVariable("patientDocumentMappingCodeList") List<String> patientDocumentMappingCodeList) {
		if(patientDocumentMappingCodeList != null && patientDocumentMappingCodeList.size()>0){
			return patientService.softMultipleDeletePatientDocumentByPatientDocumentMappingCode(patientDocumentMappingCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
	}
       
       
}
