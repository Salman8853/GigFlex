/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.patient.dtob;

import java.util.List;

/**
 *
 * @author amit.kumar
 */
public class PatientResponse {
    
    private String patientName;
    private String patientCode;
    private String patientAddress;
    private String zipCode;
    private String patientState;
    private String patientCountry;
    private String patientCity;
    private String phoneNumber;
    private String mobileNumber;
    private String patientLatitude;
    private String patientLongitude;
    private String phoneCountryCode;
    private String mobileCountryCode;
    private String organizationCode;
    private String patientEmail;
    private Boolean isActive;
    private String patientHistoryDescription;
    private List<PatientDocumentMappingReq>  PatientDocumentMappingReqList;

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }    

    public String getPatientEmail() {
        return patientEmail;
    }

    public void setPatientEmail(String patientEmail) {
        this.patientEmail = patientEmail;
    }
    

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }    

    public String getPhoneCountryCode() {
        return phoneCountryCode;
    }

    public void setPhoneCountryCode(String phoneCountryCode) {
        this.phoneCountryCode = phoneCountryCode;
    }

    public String getMobileCountryCode() {
        return mobileCountryCode;
    }

    public void setMobileCountryCode(String mobileCountryCode) {
        this.mobileCountryCode = mobileCountryCode;
    }    
    
    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }    

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public String getPatientAddress() {
        return patientAddress;
    }

    public void setPatientAddress(String patientAddress) {
        this.patientAddress = patientAddress;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getPatientState() {
        return patientState;
    }

    public void setPatientState(String patientState) {
        this.patientState = patientState;
    }

    public String getPatientCountry() {
        return patientCountry;
    }

    public void setPatientCountry(String patientCountry) {
        this.patientCountry = patientCountry;
    }

    public String getPatientCity() {
        return patientCity;
    }

    public void setPatientCity(String patientCity) {
        this.patientCity = patientCity;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPatientLatitude() {
        return patientLatitude;
    }

    public void setPatientLatitude(String patientLatitude) {
        this.patientLatitude = patientLatitude;
    }  

    public String getPatientLongitude() {
        return patientLongitude;
    }

    public void setPatientLongitude(String patientLongitude) {
        this.patientLongitude = patientLongitude;
    }

    public String getPatientHistoryDescription() {
        return patientHistoryDescription;
    }

    public void setPatientHistoryDescription(String patientHistoryDescription) {
        this.patientHistoryDescription = patientHistoryDescription;
    }

    public List<PatientDocumentMappingReq> getPatientDocumentMappingReqList() {
        return PatientDocumentMappingReqList;
    }

    public void setPatientDocumentMappingReqList(List<PatientDocumentMappingReq> PatientDocumentMappingReqList) {
        this.PatientDocumentMappingReqList = PatientDocumentMappingReqList;
    }
    
    
}
