package com.gigflex.prototype.microservices.patient.repository;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author amit.kumar
 */

@Repository
public interface PatientDao extends JpaRepository<PatientDetails,Long>,JpaSpecificationExecutor<PatientDetails>{
    
    @Query("SELECT pd FROM PatientDetails pd  WHERE pd.isDeleted != TRUE AND pd.isActive = TRUE  AND pd.organizationCode = :organizationCode")
    public List<PatientDetails> getPatientDetailsByOrgCode(@Param("organizationCode") String organizationCode);

    @Query("SELECT pd FROM PatientDetails pd  WHERE pd.isDeleted != TRUE AND pd.isActive = TRUE  AND pd.phoneNumber = :phoneNumber")
    public PatientDetails findByPhoneNumber(@Param("phoneNumber") String phoneNumber);

    @Query("SELECT pd FROM PatientDetails pd  WHERE pd.isDeleted != TRUE AND pd.isActive = TRUE  AND pd.patientCode = :patientCode")
    public PatientDetails getPatientDetailsBypatientCode(@Param("patientCode") String patientCode);

    @Query("SELECT pd FROM PatientDetails pd  WHERE pd.isDeleted != TRUE AND pd.isActive = TRUE  AND ( pd.patientLatitude = :patientLatitude OR pd.patientLongitude = :patientLongitude) ")
    public List<PatientDetails> getPatientDetailWithoutHavingLatLong(@Param("patientLatitude") String patientLatitude ,@Param("patientLongitude") String patientLongitude  );
    
    
   @Query("SELECT pd FROM PatientDetails pd ,Jobs j WHERE pd.isDeleted != TRUE AND j.isDeleted != TRUE AND pd.patientCode=j.patientCode AND j.jobsCode=:jobsCode")
    public PatientDetails getPatientDetailByjobCode(@Param("jobsCode") String jobsCode); 
    
    @Query("SELECT pd FROM PatientDetails pd  WHERE pd.isDeleted != TRUE AND pd.patientCode = :patientCode")
    public PatientDetails getPatientDetailBypatientCode(@Param("patientCode") String patientCode);
       
}
