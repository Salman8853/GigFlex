package com.gigflex.prototype.microservices.patient.service;

import com.gigflex.prototype.microservices.patient.dtob.PatientRequest;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author amit.kumar
 */
public interface PatientService {

    public String getPatientDetailByOrganizationCode(String organizationCode);

    public String getPatientDetailByPatientCode(String patientCode);

    public String getPatientDetailWithoutHavingLatLong();

    public String savePatientDetail(PatientRequest pRequest, String ip);

    public String updatePatientDetail(String patientCode, PatientRequest pRequest, String ip);

    public String storePatientDocumentFile(MultipartFile file,String patientCode);
    
    public String softMultipleDeletePatientDocumentByPatientDocumentMappingCode(List<String> patientDocumentMappingCodeList);
    
    public String softDeletePatientDocumentByPatientDocumentMappingCode(String patientDocumentMappingCode);

    public String getPatientDocumentMappingByPatientDocumentMappingCode(String patientDocumentMappingCode);
    
      
}
