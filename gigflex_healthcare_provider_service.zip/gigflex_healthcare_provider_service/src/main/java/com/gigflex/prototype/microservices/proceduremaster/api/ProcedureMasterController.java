/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.proceduremaster.api;

import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMasterRequest;
import com.gigflex.prototype.microservices.proceduremaster.service.ProcedureMasterService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author amit.kumar
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class ProcedureMasterController {
    
    @Autowired
    public ProcedureMasterService procedureMasterService;


    @GetMapping("/getAllProcedureMaster")
    public String getAllProcedureMaster(){
            return procedureMasterService.findAllProcedureMaster();
    }
	
    @GetMapping(path="/getAllProcedureMasterByPage")
    public String getAllProcedureMasterByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String daysMaster = procedureMasterService.getAllProcedureMasterByPage(page, limit);
      
        return daysMaster;
       
    }
	
    @GetMapping("/getProcedureMaster/{id}")
    public String getProcedureMasterById(@PathVariable Integer id){
            return procedureMasterService.findProcedureMasterById(id);
    }

    @GetMapping("/getByProcedureCode/{procedureCode}")
    public String getProcedureMasterByCode(@PathVariable String procedureCode) {
            return procedureMasterService.findByProcedureCode(procedureCode);
    }
	
    @PostMapping("/saveProcedureMaster")
      public String saveNewProcedureMaster( @RequestBody ProcedureMasterRequest procedureMasterRequest,HttpServletRequest request){
                  String ip = request.getRemoteAddr();

            return procedureMasterService.saveProcedureMaster(procedureMasterRequest,ip);

      }
    
	   
    @DeleteMapping("/softDeleteByProcedureCode/{procedureCode}")
     public String softDeleteByProcedureCode(@PathVariable String procedureCode){
         return procedureMasterService.softDeleteProcedureMasterByProcedureCode(procedureCode);
     }

    @DeleteMapping("/softMultipleDeleteByProcedureCode/{procedureCodeList}")
         public String softMultipleDeleteByUserCode(@PathVariable List<String> procedureCodeList) {
                 if(procedureCodeList != null && procedureCodeList.size()>0){
                         return procedureMasterService.softMultipleDeleteByProcedureCode(procedureCodeList);
                 }else{
                          GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
                    return derr.toString();
                 }

         }
	    
    @PutMapping("/updateProcedureMaster/{procedureCode}")
        public String updateProcedureMaster(@PathVariable String procedureCode, @RequestBody ProcedureMasterRequest procedureMasterReq,HttpServletRequest request) {

                if (procedureCode == null) {
                        return  "Procedure Master with procedureCode : (" + procedureCode + ") Not found.";
                } else {
                        String ip = request.getRemoteAddr();

                        return procedureMasterService.updateProcedureMasterByProcedureCode(procedureCode, procedureMasterReq,ip);
                }
        }
    
    
}
