/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.proceduremaster.repository;

import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureSkillMapping;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface ProcedureSkillMappingDao extends JpaRepository<ProcedureSkillMapping,Integer>,JpaSpecificationExecutor<ProcedureSkillMapping>{

    @Query("SELECT sm FROM SkillMaster sm ,ProcedureSkillMapping psm  WHERE sm.isDeleted != TRUE AND psm.isDeleted != TRUE AND sm.skillCode = psm.skillCode AND psm.procedureCode = :procedureCode")
    public List<SkillMaster> getSkillByProcedureCode(@Param("procedureCode") String procedureCode);

    @Query("SELECT psm FROM ProcedureSkillMapping psm  WHERE psm.isDeleted != TRUE AND psm.procedureCode = :procedureCode")
    public List<ProcedureSkillMapping> getProcedureSkillByProcedureCode(@Param("procedureCode") String procedureCode);
    
    @Query("SELECT psm.skillCode FROM ProcedureSkillMapping psm  WHERE psm.isDeleted != TRUE AND psm.procedureCode = :procedureCode")
    public List<String> getProcedureSkillCodesByProcedureCode(@Param("procedureCode") String procedureCode);
    
}
