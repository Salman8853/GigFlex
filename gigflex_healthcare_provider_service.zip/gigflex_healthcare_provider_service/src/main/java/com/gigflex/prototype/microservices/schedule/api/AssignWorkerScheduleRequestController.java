/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.api;

import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleRequestToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.*;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.gigflex.prototype.microservices.schedule.service.AssignScheduleRequestToWorkerService;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author abhishek
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class AssignWorkerScheduleRequestController {
    @Autowired
    AssignScheduleRequestToWorkerService assignScheduleRequestToWorkerService;
    
    @GetMapping("/getAssigntoWorkerScheduleRequestByWorkerCode/{workerCode}")
     public String getAssigntoWorkerScheduleRequestByWorkerCode(@PathVariable("workerCode")  String workerCode){
      if(workerCode!=null && workerCode.trim().length()>0){
      return assignScheduleRequestToWorkerService.getAssigntoWorkerScheduleRequestByWorkerCode(workerCode);
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker Code should not be blank");
         return derr.toString();  
      }
    }
     
     
    
    @GetMapping(path="/getAllSceduleByWorkerCodeWithFilterByPage/{workerCode}/{status}/{stratDT}/{endDT}")
    public String getAllSceduleByWorkerCodeWithFilterByPage(@PathVariable String workerCode,@PathVariable List<String> status,
            @PathVariable String stratDT,@PathVariable String endDT,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        if(workerCode!=null && workerCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat("yyyy-MM-dd").parse(stratDT.trim());
			eDT = new SimpleDateFormat("yyyy-MM-dd").parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format(yyyy-MM-dd)");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}
		
		
			return assignScheduleRequestToWorkerService.getAllSceduleByWorkerCodeWithFilterByPage(workerCode.trim(),status,stratDT.trim(), endDT.trim(),page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Worker Code and Status should not be blank.");
			return derr.toString();
		}
	
       
    }
    
    
    
     @GetMapping(path="/getAllSceduleByWorkerCodeWithFilterByPage/{workerCode}/{status}")
    public String getAllSceduleByWorkerCodeWithFilterByPage(@PathVariable String workerCode,@PathVariable List<String> status,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        if(workerCode!=null && workerCode.trim().length()>0 && status!=null && status.size()>0  ) {

            
		
			return assignScheduleRequestToWorkerService.getAllSceduleByWorkerCodeWithFilterByPage(workerCode.trim(),status,null, null,page, limit);
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Worker Code and Status should not be blank.");
			return derr.toString();
		}
	
       
    }
     
     @GetMapping("/getAssigntoWorkerScheduleRequestByWorkerCodeByPage/{workerCode}")
     public String getAssigntoWorkerScheduleRequestByWorkerCodeByPage(@PathVariable("workerCode")  String workerCode,
             @RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit){
      if(workerCode!=null && workerCode.trim().length()>0){
      return assignScheduleRequestToWorkerService.getAssigntoWorkerScheduleRequestByWorkerCodeByPage(workerCode,page, limit);
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker Code should not be blank");
         return derr.toString();  
      }
    }
    
    @GetMapping("/getAvailableWorkerWithSameFilterByAssignScheduletoWorkerCode/{assignScheduletoWorkerCode}")
     public String getAvailableWorkerWithSameFilterByAssignScheduletoWorkerCode(@PathVariable("assignScheduletoWorkerCode")  String assignScheduletoWorkerCode){
      if(assignScheduletoWorkerCode!=null && assignScheduletoWorkerCode.trim().length()>0){
      return assignScheduleRequestToWorkerService.getAvailableWorkerWithSameFilterByAssignScheduletoWorkerCode(assignScheduletoWorkerCode);
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "AssignedScheduletoWorker Code can not be blank");
         return derr.toString();  
      }
    }
    
    @PostMapping("/assigntoWorkerScheduleRequest")
    public String assignScheduleToWorker(@RequestBody AssignScheduleRequestToWorker assignScheduleRequest, HttpServletRequest req) {
        if (assignScheduleRequest != null && assignScheduleRequest.getScheduleRequestCode()!=null && assignScheduleRequest.getScheduleRequestCode().trim().length()>0
                && assignScheduleRequest.getScheduleRequestAssignmentCode()!=null && assignScheduleRequest.getScheduleRequestAssignmentCode().trim().length()>0
                && assignScheduleRequest.getWorkerCode()!=null &&  assignScheduleRequest.getWorkerCode().trim().length()>0) {
            return assignScheduleRequestToWorkerService.saveAssignScheduleRequestToWorker(assignScheduleRequest, req.getRemoteAddr());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
            return derr.toString();
        }
    }
    @PostMapping("/scheduleRequestAccepted")
     public String saveAcceptedScheduleRequest(@RequestBody ScheduleAcceptRejectedRequest sar,HttpServletRequest req){
      if(sar!=null && sar.getAssignScheduletoWorkerCode()!=null && sar.getAssignScheduletoWorkerCode().trim().length()>0){
      return assignScheduleRequestToWorkerService.saveAcceptedScheduleRequest(sar.getAssignScheduletoWorkerCode().trim(), req.getRemoteAddr());
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "AssignedScheduletoWorkerCode can not be blank");
         return derr.toString();  
      }
    }
     
    @PostMapping("/scheduleRequestRejected")
     public String saveRejectedScheduleRequest(@RequestBody ScheduleAcceptRejectedRequest sar,HttpServletRequest req){
        if (sar != null && sar.getAssignScheduletoWorkerCode()!=null && sar.getAssignScheduletoWorkerCode().trim().length()>0){
            return assignScheduleRequestToWorkerService.saveRejectedScheduleRequest(sar.getAssignScheduletoWorkerCode().trim(), req.getRemoteAddr());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "AssignedScheduletoWorkerCode can not be blank");
            return derr.toString();

        }
    }

     
    @PostMapping("/changeAssignToWorkerScheduleRequest")
     public String changeAssignToWorkerScheduleRequest( @RequestBody ChangeAssignScheduleToWorkerInputRequest changeAssignScheduleToWorkerInputRequest,HttpServletRequest req){
      if(changeAssignScheduleToWorkerInputRequest!=null && changeAssignScheduleToWorkerInputRequest.getAssignScheduletoWorkerCode()!=null && changeAssignScheduleToWorkerInputRequest.getAssignScheduletoWorkerCode().length()>0
              && changeAssignScheduleToWorkerInputRequest.getChangeToWorkerCode()!=null && changeAssignScheduleToWorkerInputRequest.getChangeToWorkerCode().length()>0
              && changeAssignScheduleToWorkerInputRequest.getChangedByWorkerCode()!=null && changeAssignScheduleToWorkerInputRequest.getChangedByWorkerCode().length()>0){
      return assignScheduleRequestToWorkerService.changeAssignToWorkerScheduleRequest(changeAssignScheduleToWorkerInputRequest, req.getRemoteAddr());
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "AssignedScheduletoWorkerCode, ChangedByWorkerCode, ChangeToWorkerCode should not be blank");
         return derr.toString();  
      }
    }
     
     
    @PostMapping("/approvalChangeAssignToWorkerScheduleRequest")
     public String approvalChangeAssignToWorkerScheduleRequest( @RequestBody ApprovalChangeAssignScheduleToWorkerInputRequest changeRequest,HttpServletRequest req){
      if(changeRequest!=null && changeRequest.getIsApproved()!=null && changeRequest.getChangeAssignScheduletoWorkerCode()!=null &&changeRequest.getChangeAssignScheduletoWorkerCode().length()>0)
      {
      return assignScheduleRequestToWorkerService.approvalChangeAssignToWorkerScheduleRequest(changeRequest, req.getRemoteAddr());
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "ChangeAssignScheduletoWorkerCode, IsApproved should not be blank");
         return derr.toString();  
      }
    }

}
