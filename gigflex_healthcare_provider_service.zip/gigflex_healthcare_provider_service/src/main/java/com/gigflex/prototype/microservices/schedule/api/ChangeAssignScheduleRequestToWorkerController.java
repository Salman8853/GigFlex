/**
 * 
 */
package com.gigflex.prototype.microservices.schedule.api;

import com.gigflex.prototype.microservices.schedule.dtob.ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.schedule.service.ChangeAssignScheduleRequestToWorkerService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author ajit.p
 *
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
public class ChangeAssignScheduleRequestToWorkerController {

	@Autowired
	ChangeAssignScheduleRequestToWorkerService changeAssignScheduleRequestToWorkerService;

	@GetMapping("/getTradeShiftDetailtByOrganizationCode/{organizationCode}")
	public String getTradeShiftDetailtByOrganizationCode(@PathVariable String organizationCode) {
		if (organizationCode != null && organizationCode.trim().length() > 0) {
			return changeAssignScheduleRequestToWorkerService.getTradeWorkerListByOrganizationCode(organizationCode);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Organization Code should not be blank.");
			return derr.toString();
		}

	}

	@GetMapping("/getTradeShiftDetailtByWorkerCode/{workerCode}")
	public String getTradeShiftDetailtByWorkerCode(@PathVariable String workerCode) {
		if (workerCode != null && workerCode.trim().length() > 0) {
			return changeAssignScheduleRequestToWorkerService.getTradeWorkerListByWorkerCode(workerCode);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker Code should not be blank.");
			return derr.toString();
		}

	}
        
     @PostMapping("/changeAssignScheduleRequestToWorker")
     public String changeAssignScheduleRequestToWorker( @RequestBody ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest casWorkerByScheduleRequestCodeRequest,HttpServletRequest req){
      if(casWorkerByScheduleRequestCodeRequest!=null && casWorkerByScheduleRequestCodeRequest.getScheduleRequestCode()!=null && casWorkerByScheduleRequestCodeRequest.getScheduleRequestCode().length()>0
              && casWorkerByScheduleRequestCodeRequest.getChangeToWorkerCode()!=null && casWorkerByScheduleRequestCodeRequest.getChangeToWorkerCode().length()>0
              && casWorkerByScheduleRequestCodeRequest.getChangedByWorkerCode()!=null && casWorkerByScheduleRequestCodeRequest.getChangedByWorkerCode().length()>0){
      return changeAssignScheduleRequestToWorkerService.changeAssignScheduleRequestToWorker(casWorkerByScheduleRequestCodeRequest, req.getRemoteAddr());
      }
      else{
         GigflexResponse derr = new GigflexResponse(400, new Date(), "ScheduleRequestCode, ChangedByWorkerCode, ChangeToWorkerCode should not be blank");
         return derr.toString();  
      }
    }
	
        
     @PutMapping("/updateAssignScheduleRequestToWorker/{scheduleRequestCode}/{id}")
	public String updateAssignScheduleRequestToWorkerByID(@RequestBody ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest caswRequest,@PathVariable Long id,
			 HttpServletRequest req) {
		if (id != null && id.toString().trim().length() > 0) {
			return changeAssignScheduleRequestToWorkerService.updateAssignScheduleRequestToWorkerByID(id,caswRequest, req.getRemoteAddr());
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
			return derr.toString();
		}

	}
     

}
