/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author abhishek
 */
@Entity
@Table(name = "change_assign_schedule_to_worker")
public class ChangeAssignScheduleToWorker extends CommonAttributes implements Serializable {
     private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "change_assign_schedule_to_worker_code", unique = true)
    private String changeAssignScheduletoWorkerCode;
    
    @Column(name = "assign_schedule_to_worker_code")
    private String assignScheduletoWorkerCode;
    
    @Column(name = "changed_by_worker_code")
    private String changedByWorkerCode;
    
    @Column(name = "change_to_worker_code")
    private String changeToWorkerCode;
    
    @Column(name = "isapproved")
    private Boolean isApproved;
    
    
    @PrePersist
    private void assignUUID() {
        if(this.getChangeAssignScheduletoWorkerCode()==null || this.getChangeAssignScheduletoWorkerCode().length()==0)
        {
            this.setChangeAssignScheduletoWorkerCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getChangeAssignScheduletoWorkerCode() {
        return changeAssignScheduletoWorkerCode;
    }

    public void setChangeAssignScheduletoWorkerCode(String changeAssignScheduletoWorkerCode) {
        this.changeAssignScheduletoWorkerCode = changeAssignScheduletoWorkerCode;
    }

    public String getAssignScheduletoWorkerCode() {
        return assignScheduletoWorkerCode;
    }

    public void setAssignScheduletoWorkerCode(String assignScheduletoWorkerCode) {
        this.assignScheduletoWorkerCode = assignScheduletoWorkerCode;
    }

    public String getChangedByWorkerCode() {
        return changedByWorkerCode;
    }

    public void setChangedByWorkerCode(String changedByWorkerCode) {
        this.changedByWorkerCode = changedByWorkerCode;
    }

    public String getChangeToWorkerCode() {
        return changeToWorkerCode;
    }

    public void setChangeToWorkerCode(String changeToWorkerCode) {
        this.changeToWorkerCode = changeToWorkerCode;
    }

    

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }


}
