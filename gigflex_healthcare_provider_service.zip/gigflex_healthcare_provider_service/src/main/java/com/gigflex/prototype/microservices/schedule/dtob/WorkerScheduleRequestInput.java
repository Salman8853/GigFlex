package com.gigflex.prototype.microservices.schedule.dtob;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.patient.dtob.PatientResponse;
import java.util.Date;
import java.util.List;



/**
 * 
 * @author nirbhay.p
 *
 */

public class WorkerScheduleRequestInput {

    private String organizationCode;
    
    private String start ;
    
    private String end ;
    
    private String jobName;
    
    private String workingLocationCode;
    
    private String patientCode;
    
    private PatientResponse patientDetail;

    public PatientResponse getPatientDetail() {
        return patientDetail;
    }

    public void setPatientDetail(PatientResponse patientDetail) {
        this.patientDetail = patientDetail;
    }     
    
    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }
    
    private List<WorkerScheduleRequestAssignmentInputList> assignmentList;
    
    public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

    public List<WorkerScheduleRequestAssignmentInputList> getAssignmentList() {
        return assignmentList;
    }

    public void setAssignmentList(List<WorkerScheduleRequestAssignmentInputList> assignmentList) {
        this.assignmentList = assignmentList;
    }
    
    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }
    

    public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public void setEnd(String end) {
        this.end = end;
    }

    
    

}