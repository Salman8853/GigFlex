package com.gigflex.prototype.microservices.schedule.dtob;

import java.util.Date;

/**
 * 
 * @author nirbhay.p
 *
 */

public class WorkerScheduleRequestRes  {


    private Long id;  
    
    private String scheduleRequestCode;
    
  
    private String patientCode;    
    
    private String jobName;
    
    private String organizationCode;
    
    private String startDT ;
    
    private String endDT ;
    
     private Date startDTTimestamp ;
    
    private Date endDTTimestamp ;
    
    private Boolean isProcessed; 
    
    private Boolean isPublished; 

    public Date getStartDTTimestamp() {
        return startDTTimestamp;
    }

    public void setStartDTTimestamp(Date startDTTimestamp) {
        this.startDTTimestamp = startDTTimestamp;
    }

    public Date getEndDTTimestamp() {
        return endDTTimestamp;
    }

    public void setEndDTTimestamp(Date endDTTimestamp) {
        this.endDTTimestamp = endDTTimestamp;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getScheduleRequestCode() {
        return scheduleRequestCode;
    }

    public void setScheduleRequestCode(String scheduleRequestCode) {
        this.scheduleRequestCode = scheduleRequestCode;
    }

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getStartDT() {
        return startDT;
    }

    public void setStartDT(String startDT) {
        this.startDT = startDT;
    }

    public String getEndDT() {
        return endDT;
    }

    public void setEndDT(String endDT) {
        this.endDT = endDT;
    }

    public Boolean getIsProcessed() {
        return isProcessed;
    }

    public void setIsProcessed(Boolean isProcessed) {
        this.isProcessed = isProcessed;
    }

    public Boolean getIsPublished() {
        return isPublished;
    }

    public void setIsPublished(Boolean isPublished) {
        this.isPublished = isPublished;
    }
    
   
    
}