/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

/**
 *
 * @author nirbhay.p
 */
public class WorkerScheduleRequestUpdate {
    private String start ;
    
    private String end ;
    
    private String jobName;
    
    private String workingLocationCode;

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getWorkingLocationCode() {
        return workingLocationCode;
    }

    public void setWorkingLocationCode(String workingLocationCode) {
        this.workingLocationCode = workingLocationCode;
    }
    
    
    
}
