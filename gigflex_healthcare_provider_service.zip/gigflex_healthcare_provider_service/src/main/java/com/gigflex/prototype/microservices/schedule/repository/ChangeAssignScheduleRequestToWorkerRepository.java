/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.schedule.dtob.ChangeAssignScheduleToWorker;
import com.gigflex.prototype.microservices.worker.dtob.Worker;

/**
 *
 * @author abhishek
 */
public interface ChangeAssignScheduleRequestToWorkerRepository extends JpaRepository<ChangeAssignScheduleToWorker,Long>{
    
   @Query("SELECT asw FROM ChangeAssignScheduleToWorker asw WHERE asw.isDeleted != TRUE and asw.changeAssignScheduletoWorkerCode = :changeAssignScheduletoWorkerCode")
    public ChangeAssignScheduleToWorker getChangeAssignScheduleToWorker(@Param("changeAssignScheduletoWorkerCode") String changeAssignScheduletoWorkerCode);
   
    @Query("SELECT a, b, c FROM ChangeAssignScheduleToWorker a, AssignScheduleToWorker b, WorkerScheduleRequest c WHERE a.isDeleted != TRUE AND a.assignScheduletoWorkerCode = b.assignScheduletoWorkerCode AND b.scheduleRequestCode = c.scheduleRequestCode AND a.changedByWorkerCode = :changedByWorkerCode")
    public List<Object> getTradeWorkerListByWorkerCode(@Param("changedByWorkerCode") String changedByWorkerCode);
    
//    @Query("SELECT wr FROM Worker wr ,ChangeAssignScheduleToWorker a, AssignScheduleToWorker b, WorkerScheduleRequest c WHERE c.isDeleted != TRUE AND a.isApproved != TRUE AND wr.workerCode = a.changeToWorkerCode AND a.assignScheduletoWorkerCode = b.assignScheduletoWorkerCode AND b.scheduleRequestCode = c.scheduleRequestCode AND c.organizationCode = :organizationCode")
//    public List<Worker> getTradeWorkerListByOrganizationCode(@Param("organizationCode") String organizationCode);
//    
//    @Query("SELECT a, (SELECT w FROM Worker w WHERE w.workerCode = a.changedByWorkerCode) FROM ChangeAssignScheduleToWorker a WHERE a.isApproved != TRUE AND a.isDeleted != TRUE AND a.changeToWorkerCode = :changeToWorkerCode  ")
//    public List<Object> getTradeWorkerListByWorkerCodeEmployee(@Param("changeToWorkerCode") String changeToWorkerCode);

    @Query("SELECT a,(SELECT w.name FROM Worker w WHERE w.workerCode = a.changedByWorkerCode), (SELECT w.name FROM Worker w WHERE w.workerCode = a.changeToWorkerCode) FROM ChangeAssignScheduleToWorker a, AssignScheduleToWorker b, WorkerScheduleRequest c WHERE c.isDeleted != TRUE AND a.assignScheduletoWorkerCode = b.assignScheduletoWorkerCode AND b.scheduleRequestCode = c.scheduleRequestCode AND c.organizationCode = :organizationCode ORDER BY a.id DESC")
    public List<Object> getTradeWorkerListByOrganizationCode(@Param("organizationCode") String organizationCode);
    
    @Query("SELECT a,(SELECT w.name FROM Worker w WHERE w.workerCode = a.changedByWorkerCode), (SELECT w.name FROM Worker w WHERE w.workerCode = a.changeToWorkerCode) FROM ChangeAssignScheduleToWorker a WHERE  a.isDeleted != TRUE AND a.changedByWorkerCode = :changedByWorkerCode ORDER BY a.id DESC")
    public List<Object> getTradeWorkerListByWorkerCodeEmployee(@Param("changedByWorkerCode") String changedByWorkerCode);

    @Query("SELECT asw FROM ChangeAssignScheduleToWorker asw WHERE asw.isDeleted != TRUE and asw.id = :id")
    public ChangeAssignScheduleToWorker getChangeAssignScheduleByID(@Param("id") Long id);
      
}
