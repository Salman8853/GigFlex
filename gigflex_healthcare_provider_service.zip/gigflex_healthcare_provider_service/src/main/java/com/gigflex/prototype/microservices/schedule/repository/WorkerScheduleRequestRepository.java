/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.repository;

import java.util.Date;
import java.util.List;
import org.springframework.data.domain.Pageable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequest;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignment;
import com.gigflex.prototype.microservices.worker.dtob.Worker;


/**
 *
 * @author nirbhay.p
 */
public interface WorkerScheduleRequestRepository extends JpaRepository<WorkerScheduleRequest,Long> {
	
    @Query("SELECT oaa FROM WorkerScheduleRequest oaa WHERE oaa.scheduleRequestCode=:scheduleRequestCode AND oaa.isDeleted != TRUE")
    public WorkerScheduleRequest getByScheduleRequestCode(@Param("scheduleRequestCode") String scheduleRequestCode);
    
    @Query("SELECT oaa,ps FROM WorkerScheduleRequest oaa , PatientDetails ps WHERE ps.patientCode = oaa.patientCode AND ps.isActive = TRUE AND oaa.organizationCode=:organizationCode AND oaa.isDeleted != TRUE")
    public List<Object> getListByOrganizationCode(@Param("organizationCode") String organizationCode);
    
    @Query("SELECT oaa,ps FROM WorkerScheduleRequest oaa , PatientDetails ps WHERE ps.patientCode = oaa.patientCode AND ps.isActive = TRUE AND oaa.organizationCode=:organizationCode AND oaa.isDeleted != TRUE")
    public List<Object> getListByOrganizationCodeByPage(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
    
    @Query("SELECT oaa,wsa,ps FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, PatientDetails ps WHERE ps.patientCode = oaa.patientCode AND ps.isActive = TRUE AND wsa.scheduleRequestCode = oaa.scheduleRequestCode AND oaa.isDeleted != TRUE AND oaa.id = :id")
    public List<Object> getWorkerScheduleRequestById(@Param("id") Long id);

    @Query("SELECT oaa,wsa FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, Organization o WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND oaa.isDeleted != TRUE AND oaa.organizationCode = o.organizationCode AND oaa.organizationCode = :organizationCode")
    public List<Object> getWorkerScheduleRequestByOrgCode(@Param("organizationCode") String organizationCode);

    @Query("SELECT oaa,wsa,ps FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa,PatientDetails ps WHERE ps.patientCode = oaa.patientCode AND ps.isActive = TRUE AND wsa.scheduleRequestCode = oaa.scheduleRequestCode AND oaa.scheduleRequestCode=:scheduleRequestCode AND oaa.isDeleted != TRUE")
    public List<Object> findByScheduleRequestCode(@Param("scheduleRequestCode") String scheduleRequestCode);

    @Query("SELECT oaa,wsa FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND oaa.isDeleted != TRUE AND oaa.id = :id")
    public List<Object> getWorkerScheduleRequestById(@Param("id") Long id,Pageable pageableRequest);

    @Query("SELECT oaa,wsa FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, Organization o WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND oaa.isDeleted != TRUE AND oaa.organizationCode = o.organizationCode AND oaa.organizationCode = :organizationCode")
    public List<Object> getWorkerScheduleRequestByOrgCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);

    @Query("SELECT oaa,wsa,ps FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa,PatientDetails ps WHERE ps.patientCode = oaa.patientCode AND ps.isActive = TRUE AND wsa.scheduleRequestCode = oaa.scheduleRequestCode AND oaa.scheduleRequestCode=:scheduleRequestCode AND oaa.isDeleted != TRUE")
    public List<Object> findByScheduleRequestCode(@Param("scheduleRequestCode") String scheduleRequestCode,Pageable pageableRequest);

    @Query("SELECT s.skillName FROM  SkillMaster s WHERE s.skillCode = :skillCode AND s.isDeleted != TRUE")
    public String getSkillNameByCode(@Param("skillCode") String skillCode);
    
    @Query("SELECT s.color FROM  OrganizationSkill s WHERE s.skillCode = :skillCode AND s.organizationCode = :organizationCode AND s.isDeleted != TRUE")
    public String getSkillColorByCodeAndOrgcode(@Param("skillCode") String skillCode,@Param("organizationCode") String organizationCode);
    
    @Query("SELECT wl.location FROM  WorkingLocation wl WHERE wl.workingLocationCode = :workingLocationCode AND wl.isDeleted != TRUE")
    public String getLocationByCode(@Param("workingLocationCode") String workingLocationCode);
    
    //    @Query("SELECT oaa,wsa,s.skillName,wl.location,c.certificationName FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, SkillMaster s,WorkingLocation wl, CertificationsMaster c WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND wsa.skillCode = s.skillCode AND wsa.locationCode = wl.workingLocationCode AND  c.certificationCode = wsa.certificationCode  AND oaa.isDeleted != TRUE AND oaa.id = :id")
//	public List<Object> getWorkerScheduleRequestById(@Param("id") Long id);
//    
//    @Query("SELECT oaa,wsa,s.skillName,wl.location,c.certificationName FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, SkillMaster s,WorkingLocation wl, CertificationsMaster c WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND wsa.skillCode = s.skillCode AND wsa.locationCode = wl.workingLocationCode AND  wsa.certificationCode = c.certificationCode  AND oaa.isDeleted != TRUE  AND oaa.id = :id")
//	public List<Object> getWorkerScheduleRequestById(@Param("id") Long id,Pageable pageableRequest);
//    
//    @Query("SELECT oaa,wsa,s.skillName,wl.location,c.certificationName FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, Organization o, SkillMaster s,WorkingLocation wl, CertificationsMaster c WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND wsa.skillCode = s.skillCode AND wsa.locationCode = wl.workingLocationCode AND  c.certificationCode = wsa.certificationCode  AND oaa.isDeleted != TRUE AND oaa.organizationCode = o.organizationCode AND oaa.organizationCode = :organizationCode")
////    @Query("SELECT oaa,wsa FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, Organization o WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND oaa.isDeleted != TRUE AND oaa.organizationCode = o.organizationCode AND oaa.organizationCode = :organizationCode")
//    public List<Object> getWorkerScheduleRequestByOrgCode(@Param("organizationCode") String organizationCode);
//    
//    @Query("SELECT oaa,wsa,s.skillName,wl.location,c.certificationName FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, Organization o, SkillMaster s,WorkingLocation wl, CertificationsMaster c WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND wsa.skillCode = s.skillCode AND wsa.locationCode = wl.workingLocationCode AND  c.certificationCode = wsa.certificationCode  AND oaa.isDeleted != TRUE AND oaa.organizationCode = o.organizationCode AND oaa.organizationCode = :organizationCode")
//    public List<Object> getWorkerScheduleRequestByOrgCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
//    
//    @Query("SELECT oaa,wsa,s.skillName,wl.location,c.certificationName FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, SkillMaster s,WorkingLocation wl, CertificationsMaster c WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND wsa.skillCode = s.skillCode AND wsa.locationCode = wl.workingLocationCode AND  c.certificationCode = wsa.certificationCode  AND oaa.isDeleted != TRUE AND oaa.scheduleRequestCode=:scheduleRequestCode")
//    public List<Object> findByScheduleRequestCode(@Param("scheduleRequestCode") String scheduleRequestCode);
//    
//    @Query("SELECT oaa,wsa,s.skillName,wl.location,c.certificationName FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wsa, SkillMaster s,WorkingLocation wl, CertificationsMaster c WHERE wsa.scheduleRequestCode = oaa.scheduleRequestCode AND wsa.skillCode = s.skillCode AND wsa.locationCode = wl.workingLocationCode AND  c.certificationCode = wsa.certificationCode  AND oaa.isDeleted != TRUE AND oaa.scheduleRequestCode=:scheduleRequestCode")
//    public List<Object> findByScheduleRequestCode(@Param("scheduleRequestCode") String scheduleRequestCode,Pageable pageableRequest);
//    
//    @Query("SELECT oaa,wass FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wass WHERE oaa.scheduleRequestCode=wass.scheduleRequestCode AND oaa.organizationCode=:organizationCode AND oaa.startDT>=:startDT AND oaa.endDT<=:endDT AND oaa.isDeleted != TRUE AND oaa.isPublished = TRUE")
//    public List<Object> getScheduleCalendar(@Param("organizationCode") String organizationCode,@Param("startDT") Date startDT,@Param("endDT") Date endDT);
    
    @Query("SELECT oaa,wass FROM WorkerScheduleRequest oaa, WorkerScheduleRequestAssignment wass WHERE oaa.scheduleRequestCode=wass.scheduleRequestCode AND oaa.organizationCode=:organizationCode AND oaa.isDeleted != TRUE AND oaa.isPublished = TRUE AND ( ((:startDT >= oaa.startDT   AND :startDT <= oaa.endDT )  OR (:endDT >= oaa.startDT AND :endDT <= oaa.endDT)) OR (:startDT < oaa.startDT AND :endDT > oaa.endDT )) ")
    public List<Object> getScheduleCalendar(@Param("organizationCode") String organizationCode,@Param("startDT") Date startDT,@Param("endDT") Date endDT);
    
    @Query("SELECT wkr FROM Worker wkr, OrganizationWorkerSkill ows WHERE ows.workerCode=wkr.workerCode AND wkr.isDeleted != TRUE AND wkr.workerCode NOT IN(:busyworkerList) AND ows.skillCode = :skillCode AND ows.organizationCode = :organizationCode AND ows.experienceInDays>=:experienceInDays")
    public List<Worker> getSameSkillAvailableWorkerListByOrganizationCode(@Param("experienceInDays")Long experienceInDays , @Param("skillCode")String skillCode , @Param("organizationCode")String organizationCode , @Param("busyworkerList")List<String> busyworkerList);

    @Query("SELECT wkr FROM Worker wkr, OrganizationWorkerSkill ows WHERE ows.workerCode=wkr.workerCode AND wkr.isDeleted != TRUE AND  ows.skillCode = :skillCode AND ows.organizationCode = :organizationCode AND ows.experienceInDays>=:experienceInDays")
    public List<Worker> getSameSkillAvailableWorkerListByOrganizationCodewithIN(@Param("experienceInDays")Long experienceInDays , @Param("skillCode")String skillCode , @Param("organizationCode")String organizationCode );
 
    @Query("SELECT wsra FROM WorkerScheduleRequestAssignment wsra WHERE wsra.isDeleted != TRUE AND wsra.scheduleRequestCode = :scheduleRequestCode")
    public List<WorkerScheduleRequestAssignment> getScheduleAssgnByScheduleRequestCode(@Param("scheduleRequestCode") String scheduleRequestCode);
    
    @Query("SELECT COUNT(astw) FROM AssignScheduleToWorker astw WHERE astw.isDeleted != TRUE AND astw.scheduleRequestAssignmentCode = :scheduleRequestAssignmentCode")
    public Long getCountOfRequestedStaff(@Param("scheduleRequestAssignmentCode") String scheduleRequestAssignmentCode);

    @Query("SELECT SUM(requestedStaff) FROM WorkerScheduleRequestAssignment WHERE scheduleRequestCode= :scheduleRequestCode")
	public Long getRequestedStaffCount(@Param("scheduleRequestCode") String scheduleRequestCode);
    
    @Query("SELECT COUNT(asw.id) FROM AssignScheduleToWorker asw, WorkerScheduleRequest wsr WHERE asw.status = :status AND wsr.scheduleRequestCode = :scheduleRequestCode")
  	public Long getScheduleAcceptedStatusCount(@Param("scheduleRequestCode") String scheduleRequestCode, @Param("status") String status);

    
    @Query("SELECT COUNT(astw.id) FROM AssignScheduleToWorker astw, WorkerScheduleRequest r WHERE astw.isDeleted != TRUE AND astw.status = :status  AND astw.scheduleRequestCode = r.scheduleRequestCode AND astw.scheduleRequestAssignmentCode = :scheduleRequestAssignmentCode AND  r.startDT >= :startDate AND r.endDT <= :endDate")
  	public Long getScheduleAcceptedForDateRange(@Param("scheduleRequestAssignmentCode") String scheduleRequestAssignmentCode, @Param("status") String status, @Param("startDate") Date startDate, @Param("endDate") Date endDate);

    
    @Query("SELECT COUNT(r) FROM WorkerScheduleRequest r WHERE r.startDT >= :startDate AND r.endDT <= :endDate")
  	public Long getTotalStaffByDateRange(@Param("startDate") Date startDate, @Param("endDate") Date endDate);

//    @Query("SELECT oaa FROM WorkerScheduleRequest oaa WHERE oaa.isDeleted != TRUE AND oaa.id = :id")
//	public WorkerScheduleRequest getWorkerScheduleRequestById(@Param("id") Long id);
//    
//    @Query("SELECT oaa FROM WorkerScheduleRequest oaa, Organization o WHERE oaa.isDeleted != TRUE AND oaa.organizationCode = o.organizationCode AND oaa.organizationCode = :organizationCode")
//    public WorkerScheduleRequest getWorkerScheduleRequestByOrgCode(@Param("organizationCode") String organizationCode);

    @Query("SELECT oaa FROM WorkerScheduleRequest oaa WHERE oaa.organizationCode=:organizationCode AND oaa.isDeleted != TRUE")
    public List<WorkerScheduleRequest> getByOrganizationCode(@Param("organizationCode") String organizationCode);

}











