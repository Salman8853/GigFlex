/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.certificationsmaster.repository.CertificationsMasterRepository;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationskill.repository.OrganizationSkillDao;
import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.AvailableWorkerBasedOnScheduleFilterRes;
import com.gigflex.prototype.microservices.schedule.dtob.ScheduleCalendarRequest;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestRes;
import com.gigflex.prototype.microservices.schedule.dtob.ScheduleRequestresponse;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequest;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignment;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignmentInputList;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignmentResponse;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignmentWithName;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestInput;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleStatus;
import com.gigflex.prototype.microservices.schedule.repository.AssignScheduleRequestToWorkerRepository;
import com.gigflex.prototype.microservices.schedule.repository.WorkerScheduleRequestAssignmentRepository;
import com.gigflex.prototype.microservices.schedule.repository.WorkerScheduleRequestRepository;
import com.gigflex.prototype.microservices.schedule.service.WorkerScheduleRequestService;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateFormatConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.patient.dtob.PatientResponse;
import com.gigflex.prototype.microservices.patient.repository.PatientDao;
import com.gigflex.prototype.microservices.schedule.dtob.AssigntoWorkerScheduleResponse;
import com.gigflex.prototype.microservices.schedule.dtob.AssigntoWorkerScheduleResponseNew;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestUpdate;
import com.gigflex.prototype.microservices.schedule.service.AssignScheduleRequestToWorkerService;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.workinglocation.repository.WorkingLocationRepository;
import java.util.Calendar;

/**
 *
 * @author nirbhay.p
 */
@Service
public class WorkerScheduleRequestServiceImpl implements WorkerScheduleRequestService {

	@Autowired
	WorkerScheduleRequestRepository workerScheduleRequestRepository;

	@Autowired
	WorkerScheduleRequestAssignmentRepository workerScheduleRequestAssignmentRepository;

	@Autowired
	AssignScheduleRequestToWorkerRepository assignScheduleRequestToWorkerRepository;

	@Autowired
	OrganizationRepository organizationRepository;
	@Autowired
	OrganizationSkillDao organizationSkillDao;
	@Autowired
	CertificationsMasterRepository certificationsMasterRepository;
        @Autowired
        TimeZoneRepository timeZoneDao;
        @Autowired
	WorkingLocationRepository workLocRep;
        
        @Autowired
        PatientDao patientDao;
        @Autowired
        GlobalSettingRepository globalSettingRepository;
        @Autowired
        LocalSettingRepository localSettingRepository;
        @Autowired
        UserTypeRepository utr;
        
        @Autowired
        AssignScheduleRequestToWorkerService assignScheduleRequestToWorkerService;

	@Override
	public String saveWorkerScheduleRequest(WorkerScheduleRequestInput schReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (schReq != null && schReq.getOrganizationCode() != null
					&& schReq.getOrganizationCode().trim().length() > 0 && schReq.getStart() != null
					&& schReq.getEnd() != null && schReq.getAssignmentList() != null
					&& schReq.getAssignmentList().size() > 0 && schReq.getJobName() != null
					&& schReq.getJobName().trim().length() > 0 && schReq.getPatientDetail() != null && schReq.getPatientDetail().getPatientName() != null &&  schReq.getPatientDetail().getPatientName().length() > 0                                                                     
                                && schReq.getPatientDetail().getPatientLatitude() != null && schReq.getPatientDetail().getPatientLatitude().trim().length() >0
                                && schReq.getPatientDetail().getPatientLongitude() != null && schReq.getPatientDetail().getPatientLongitude().trim().length() > 0                               
                                && schReq.getPatientDetail().getPhoneNumber() != null && schReq.getPatientDetail().getPhoneNumber().trim().length() > 0                          
                                && schReq.getPatientDetail().getPhoneCountryCode() != null &&  schReq.getPatientDetail().getPhoneCountryCode().trim().length() > 0
                                && schReq.getPatientDetail().getOrganizationCode() != null && schReq.getPatientDetail().getOrganizationCode().trim().length() > 0
                                 && schReq.getPatientDetail().getPatientAddress()!= null && schReq.getPatientDetail().getPatientAddress().trim().length() > 0
                               ) {
                            
                            
                             // && schReq.getPatientDetail().getPatientEmail() != null && schReq.getPatientDetail().getPatientEmail().trim().length() > 0
				WorkerScheduleRequest wsr = new WorkerScheduleRequest();
				Organization org = organizationRepository.findByOrganizationCode(schReq.getOrganizationCode().trim());
				if (org != null && org.getId() > 0) {
				String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
//                                String datefoemat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, org.getOrganizationCode(), GigflexConstants.DATEFORMAT);
//                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, org.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
//                           	if(datefoemat!=null && datefoemat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
//                                {
//                                    dtFormat=datefoemat.trim()+" "+timeformat.trim();
//                                }
                                
                                try {
                                    Date sdate=null;
                                    Date edate=null;
						sdate = new SimpleDateFormat(dtFormat).parse(schReq.getStart().trim());
                                                edate = new SimpleDateFormat(dtFormat).parse(schReq.getEnd().trim());
						if (sdate == null || edate==null) {
							GigflexResponse derr = new GigflexResponse(400, new Date(),
									"Plz send date in correct format("+dtFormat+") ");
							return derr.toString();
						}

					} catch (Exception ex) {
						ex.printStackTrace();
						GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send date in correct format("+dtFormat+") ");
						return derr.toString();
					}
                                
                                //WorkingLocation wl = workLocRep.findByWorkingLocationCode(schReq.getWorkingLocationCode().trim());
					//if (wl != null && wl.getId() > 0) {
                                Date sdt = null;//new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(schReq.getStart().trim());
				Date edt = null;//new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse( schReq.getEnd().trim());
				//TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                    String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, org.getOrganizationCode(), GigflexConstants.TimeZone);
                    if(timezoneCode!=null && timezoneCode.length()>0 )
                    {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if(tzd!=null && tzd.getTimeZoneName()!=null && tzd.getTimeZoneName().length()>0 )
                    {
                        String timezone=tzd.getTimeZoneName();
				sdt = GigflexDateUtil.convertStringDateToGMT(schReq.getStart().trim(), timezone,dtFormat);
				edt = GigflexDateUtil.convertStringDateToGMT(schReq.getEnd().trim(), timezone,dtFormat);
                    }
                    
                    if(sdt==null || edt==null)
                    {
                        jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Exception is occurred in date parsing.Date Format should be "+dtFormat);
					return jsonobj.toString();
                    }
                                wsr.setEndDT(edt);
                                wsr.setIpAddress(ip);
                                wsr.setIsProcessed(Boolean.FALSE);
                                wsr.setIsPublished(Boolean.FALSE);
                                wsr.setOrganizationCode(schReq.getOrganizationCode().trim());
                                wsr.setJobName(schReq.getJobName().trim());
                                wsr.setWorkingLocationCode(schReq.getWorkingLocationCode());
                                wsr.setStartDT(sdt);
                                PatientDetails pDetailResponse = null;
                                if(schReq.getPatientCode()!= null && schReq.getPatientCode().trim().length() > 0 )
                                {
                                    wsr.setPatientCode(schReq.getPatientCode());
                                                                         
                                    PatientResponse pRequest = schReq.getPatientDetail();
                                    PatientDetails pDetail = patientDao.getPatientDetailsBypatientCode(schReq.getPatientCode());
                                    
                                    if(pDetail != null && pDetail.getId()>0)
                                    {
                                        pDetail.setPatientName(pRequest.getPatientName());
                                        pDetail.setIpAddress(ip);                                    
                                        pDetail.setOrganizationCode(pRequest.getOrganizationCode());
                                        pDetail.setPatientAddress(pRequest.getPatientAddress());
                                        pDetail.setPatientCountry(pRequest.getPatientCountry());
                                        pDetail.setPatientState(pRequest.getPatientState());
                                        pDetail.setPatientCity(pRequest.getPatientCity());
                                        pDetail.setZipCode(pRequest.getZipCode());
                                        pDetail.setPatientLatitude(pRequest.getPatientLatitude());
                                        pDetail.setPatientLongitude(pRequest.getPatientLongitude());
                                        pDetail.setMobileNumber(pRequest.getMobileNumber());
                                        pDetail.setPhoneNumber(pRequest.getPhoneNumber());
                                        pDetail.setPatientEmail(pRequest.getPatientEmail());
                                        pDetail.setmCountryCode(pRequest.getMobileCountryCode());
                                        pDetail.setpCountryCode(pRequest.getPhoneCountryCode()); 
                                        if(pRequest.isIsActive()!=null)
                                        {
                                            pDetail.setIsActive(pRequest.isIsActive()); 
                                        }
                                        else
                                        {
                                            pDetail.setIsActive(true); 
                                        }
                                        
                                        pDetailResponse  =  patientDao.save(pDetail);
                                        
                                    }
                                    else
                                    {
                                    jsonobj.put("responsecode", 400);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Patient Detail does not exist");
                                    return jsonobj.toString();
                                    }
                                    
                                    
                                    
                                    
                                }
                                else
                                {
                                    PatientResponse pRequest = schReq.getPatientDetail();
                                
                                    PatientDetails pDetail = new PatientDetails();

                                    pDetail.setPatientName(pRequest.getPatientName());
                                    pDetail.setIpAddress(ip); 
                                    pDetail.setOrganizationCode(pRequest.getOrganizationCode());
                                    pDetail.setPatientAddress(pRequest.getPatientAddress());
                                    pDetail.setPatientCountry(pRequest.getPatientCountry());
                                    pDetail.setPatientState(pRequest.getPatientState());
                                    pDetail.setPatientCity(pRequest.getPatientCity());
                                    pDetail.setZipCode(pRequest.getZipCode());
                                    pDetail.setPatientLatitude(pRequest.getPatientLatitude());
                                    pDetail.setPatientLongitude(pRequest.getPatientLongitude());
                                    pDetail.setMobileNumber(pRequest.getMobileNumber());
                                    pDetail.setPhoneNumber(pRequest.getPhoneNumber());
                                    pDetail.setPatientEmail(pRequest.getPatientEmail());
                                    pDetail.setmCountryCode(pRequest.getMobileCountryCode());
                                    pDetail.setpCountryCode(pRequest.getPhoneCountryCode()); 
                                    if(pRequest.isIsActive()!=null )
                                    {
                                        pDetail.setIsActive(pRequest.isIsActive()); 
                                    }
                                    else
                                    {
                                        pDetail.setIsActive(true); 
                                    }

                                    pDetailResponse  =  patientDao.save(pDetail);
                                
                                       
                                }
                                
                                 
                                 if(pDetailResponse != null && pDetailResponse.getId() > 0)
                                {
                                    wsr.setPatientCode(pDetailResponse.getPatientCode());
                                }
                                else
                                {
                                    jsonobj.put("responsecode", 400);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Worker Schedule Request & Patient Detail has been not added due to failure.");

                                    return jsonobj.toString();
                                }
                                
                                
                                
                                WorkerScheduleRequest wsrResponse = workerScheduleRequestRepository.save(wsr);
                                
                                JSONArray jarr = new JSONArray();
					String assignres = "";
					if (wsrResponse != null && wsrResponse.getId() > 0 
                                                && pDetailResponse != null && pDetailResponse.getId() > 0) {
						int i = 0;
						for (WorkerScheduleRequestAssignmentInputList ass : schReq.getAssignmentList()) {
							i++;
                                                            
                                                            if(ass != null)
                                                            {

                                                                        boolean certist = true;
									if (ass.getCertificationCode() != null
											&& ass.getCertificationCode().trim().length() > 0) {
										ass.setCertificationCode(ass.getCertificationCode().trim());
										CertificationsMaster serti = certificationsMasterRepository
												.getCertificationsMasterByCertificationCode(ass.getCertificationCode());
										if (!(serti != null && serti.getId() > 0)) {
											certist = false;
                                                                                      ass.setCertificationCode(null); 
                                                                                        
										}
                                                                                
									}
                                                                        
									if (certist) {
										
									} 
                                                                        else {
										assignres += " " + i + ". Given Certifications does not exist.";
									}
                                                                        
                                                                        WorkerScheduleRequestAssignment wsrAss = new WorkerScheduleRequestAssignment();
                                                                        wsrAss.setCertificationCode(ass.getCertificationCode());
                                                                        wsrAss.setCostPerHours(ass.getCostPerHours());
                                                                        wsrAss.setIpAddress(ip);
                                                                        wsrAss.setRequestedStaff(ass.getRequestedStaff());
                                                                        wsrAss.setExpDays(ass.getExpDays());
                                                                        wsrAss.setLocationCode(ass.getLocationCode());
                                                                        wsrAss.setRequiredHours(ass.getRequiredHours());
                                                                        wsrAss.setScheduleRequestCode(wsrResponse.getScheduleRequestCode());
                                                                        wsrAss.setSkillCode(ass.getSkillCode());
                                                                        WorkerScheduleRequestAssignment wsrAssRes = workerScheduleRequestAssignmentRepository
                                                                                        .save(wsrAss);
                                                                        if (wsrAssRes != null && wsrAssRes.getId() > 0) {
                                                                                ObjectMapper mapperObj = new ObjectMapper();
                                                                                String Detail = mapperObj.writeValueAsString(wsrAssRes);
                                                                                jarr.add(new JSONObject(Detail));
                                                                        }
       							} 
                                                         else
                                                         {
                                                                assignres += " " + i
										+ ". schedule assignment should not be blank.";
                                                         }

						}
						if(jarr.size()==0)
                                                {
                                                    jsonobj.put("responsecode", 400);
                                                    jsonobj.put("timestamp", new Date());
                                                    workerScheduleRequestRepository.deleteById(wsrResponse.getId());
                                                    String msg = null;
                                                    if(pDetailResponse !=  null && pDetailResponse.getId() > 0)
                                                    {
                                                        patientDao.deleteById(pDetailResponse.getId()); 
                                                        msg =  "Worker Schedule Request & Patient Detail has been not added due to (";
                                                    }
                                                    else
                                                    {
                                                        msg = "Worker Schedule Request has been not added due to (";
                                                    }

                                                    jsonobj.put("message", msg+ assignres +").");
                                                }
                                                else
                                                {
                                                jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						if (assignres.length() > 0) {
                                                    
                                                    
                                                     String msg = null;
                                                    if(pDetailResponse !=  null && pDetailResponse.getId() > 0)
                                                    {                                                       
                                                        msg =  "Worker Schedule Request & Patient Detail has been added without some Schedule Assignment due to (";
                                                    }
                                                    else
                                                    {
                                                        msg = "Worker Schedule Request has been added without some Schedule Assignment due to ("; 
                                                    }
                                                    
                                                    
							jsonobj.put("message",
									msg+assignres + ")");
                                                      //  optaStartThread( wsrResponse.getScheduleRequestCode());
                                                        
						} else {
                                                    
                                                    String msg = null;
                                                    if(pDetailResponse !=  null && pDetailResponse.getId() > 0)
                                                    {                                                        
                                                        msg =  "Worker Schedule Request & Patient Detail has been added successfully.";
                                                    }
                                                    else
                                                    {
                                                        msg = "Worker Schedule Request has been added successfully."; 
                                                    }
                                                    
							jsonobj.put("message", msg);
                                                        
                                                        
                                        //                optaStartThread( wsrResponse.getScheduleRequestCode());
						}
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsrResponse);
						JSONObject jobj = new JSONObject(Detail);
						jobj.put("assignmentList", jarr);
						jsonobj.put("data", jobj);
                                                }
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Worker Schedule Request & Patient Detail has been not added.");
					}
					}else{
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "TimeZone not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Given organization does not exist.");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid input data.");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String addWorkerScheduleRequestAssignment(String scheduleCode, WorkerScheduleRequestAssignmentInputList ass,
			String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerScheduleRequest wsrResponse = workerScheduleRequestRepository.getByScheduleRequestCode(scheduleCode);
			if (wsrResponse != null && wsrResponse.getId() > 0) {
				if (ass != null && ass.getSkillCode() != null && ass.getSkillCode().trim().length() > 0
						&& ass.getExpDays() != null && ass.getExpDays() >= 0 
						 && ass.getRequestedStaff() != null
						&& ass.getRequestedStaff() > 0) {

					boolean skillst = false;
					boolean certist = true;
					if (ass.getSkillCode() != null && ass.getSkillCode().trim().length() > 0) {
						ass.setSkillCode(ass.getSkillCode().trim());
						OrganizationSkill oskill = organizationSkillDao
								.getByOrgCodeAndSkillCode(wsrResponse.getOrganizationCode().trim(), ass.getSkillCode());
						if (!(oskill != null && oskill.getId() > 0)) {
							skillst = false;
						} else {
							skillst = true;
						}
					}
					if (skillst) {

						if (ass.getCertificationCode() != null && ass.getCertificationCode().trim().length() > 0) {
							ass.setCertificationCode(ass.getCertificationCode().trim());
							CertificationsMaster serti = certificationsMasterRepository
									.getCertificationsMasterByCertificationCode(ass.getCertificationCode());
							if (!(serti != null && serti.getId() > 0)) {
								certist = false;
							}
						}
						if (certist) {
							WorkerScheduleRequestAssignment wsrAss = new WorkerScheduleRequestAssignment();
							wsrAss.setCertificationCode(ass.getCertificationCode());
							wsrAss.setCostPerHours(ass.getCostPerHours());
							wsrAss.setIpAddress(ip);
							wsrAss.setRequestedStaff(ass.getRequestedStaff());
							wsrAss.setExpDays(ass.getExpDays());
							wsrAss.setLocationCode(ass.getLocationCode());
							wsrAss.setRequiredHours(ass.getRequiredHours());
							wsrAss.setScheduleRequestCode(wsrResponse.getScheduleRequestCode());
							wsrAss.setSkillCode(ass.getSkillCode());
							WorkerScheduleRequestAssignment wsrAssRes = workerScheduleRequestAssignmentRepository
									.save(wsrAss);
							if (wsrAssRes != null && wsrAssRes.getId() > 0) {

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message",
										"Worker Schedule Request Assignment has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(wsrAssRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message",
										"Worker Schedule Request Assignment has not been added successfully.");
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Given Certifications does not exist.");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Given Skill does not exist for this Organization.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Skill, Experience and Requested Staff should not be blank.");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Schedule Code does not exist.");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestByScheduleRequestCode(String scheduleRequestCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(scheduleRequestCode);
				WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
				List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
				WorkerScheduleRequest workerScheduleRequest = null;
                                PatientDetails pDetail = null;
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
							WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
							wsan.setWorkerScheduleRequestAssignment(ws);
                                                        
                                                        
							
							if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
								String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
							wsan.setSkillName(skillName);
							}
							if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
								String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
								wsan.setLocation(location);
							}
							if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

							CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
							if(cm != null && cm.getId() > 0){
							wsan.setCertificationName(cm.getCertificationName());
							}
							}
							workerScheduleRequest = (WorkerScheduleRequest) arr[0];
							wsan.setJobName(workerScheduleRequest.getJobName());
//						    wsan.setLocation((String) arr[2]);
                                                        
                                                        pDetail = (PatientDetails) arr[2];
							

							wsrlst.add(wsan);

						}

					}

					if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
						WorkerScheduleRequestRes wsres=new WorkerScheduleRequestRes();
						String frmDt = "";
						String toDt = "";
                                                
                                String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                String datefoemat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                           	if(datefoemat!=null && datefoemat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=datefoemat.trim()+" "+timeformat.trim();
                                }
						
						String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TimeZone);
						
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                        if (tzd != null && tzd.getId() > 0) {
                                                        String timezone = tzd.getTimeZoneName();
                                                        if(timezone!=null && timezone.length()>0 )
                                                        {
							Date fromDate = workerScheduleRequest.getStartDT();
							fromDate = GigflexDateUtil.getGMTtoLocationDate(fromDate, timezone, dtFormat);
                                                        frmDt=GigflexDateUtil.convertDateToString(fromDate, dtFormat);
							Date toDate = workerScheduleRequest.getEndDT();
							toDate = GigflexDateUtil.getGMTtoLocationDate(toDate,timezone, dtFormat);
                                                        toDt=GigflexDateUtil.convertDateToString(toDate, dtFormat);
                                                        }
							wsres.setStartDT(frmDt);
							wsres.setEndDT(toDt);
						}
						wsres.setId(workerScheduleRequest.getId());
                                                wsres.setIsProcessed(workerScheduleRequest.getIsProcessed());
                                                wsres.setIsPublished(workerScheduleRequest.getIsPublished());
                                                wsres.setJobName(workerScheduleRequest.getJobName());
                                                wsres.setOrganizationCode(workerScheduleRequest.getOrganizationCode());
                                                wsres.setPatientCode(workerScheduleRequest.getPatientCode());
                                                wsres.setScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
						wsr.setWorkerScheduleRequestRes(wsres);
                                                wsr.setPatientDetails(pDetail);
						wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsr);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id != null && id > 0) {
				List<Object> objlst = workerScheduleRequestRepository.getWorkerScheduleRequestById(id);
				WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
				List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
				WorkerScheduleRequest workerScheduleRequest = null;
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
							WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
							wsan.setWorkerScheduleRequestAssignment(ws);
                                                        
                                                        PatientDetails pDetails = (PatientDetails) arr[2];
							
                                                        
							if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
								String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
							wsan.setSkillName(skillName);
							}
							if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
								String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
								wsan.setLocation(location);
							}
							if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

							CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
							if(cm != null && cm.getId() > 0){
							wsan.setCertificationName(cm.getCertificationName());
							}
							}
							workerScheduleRequest = (WorkerScheduleRequest) arr[0];
							wsan.setJobName(workerScheduleRequest.getJobName());

							wsrlst.add(wsan);

						}
					}

					if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
						
						
						WorkerScheduleRequestRes wsres=new WorkerScheduleRequestRes();
						String frmDt = "";
						String toDt = "";
                                                
                                String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                String datefoemat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                           	if(datefoemat!=null && datefoemat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=datefoemat.trim()+" "+timeformat.trim();
                                }
						
						String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TimeZone);
						
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                        if (tzd != null && tzd.getId() > 0) {
                                                        String timezone = tzd.getTimeZoneName();
                                                        if(timezone!=null && timezone.length()>0 )
                                                        {
							Date fromDate = workerScheduleRequest.getStartDT();
							fromDate = GigflexDateUtil.getGMTtoLocationDate(fromDate, timezone, dtFormat);
                                                        frmDt=GigflexDateUtil.convertDateToString(fromDate, dtFormat);
							Date toDate = workerScheduleRequest.getEndDT();
							toDate = GigflexDateUtil.getGMTtoLocationDate(toDate,timezone, dtFormat);
                                                        toDt=GigflexDateUtil.convertDateToString(toDate, dtFormat);
                                                        }
							wsres.setStartDT(frmDt);
							wsres.setEndDT(toDt);
						}
						wsres.setId(workerScheduleRequest.getId());
                                                wsres.setIsProcessed(workerScheduleRequest.getIsProcessed());
                                                wsres.setIsPublished(workerScheduleRequest.getIsPublished());
                                                wsres.setJobName(workerScheduleRequest.getJobName());
                                                wsres.setOrganizationCode(workerScheduleRequest.getOrganizationCode());
                                                wsres.setPatientCode(workerScheduleRequest.getPatientCode());
                                                wsres.setScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
						wsr.setWorkerScheduleRequestRes(wsres);
						
						wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsr);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String getWorkerScheduleRequestByOrganizationCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null && organizationCode.trim().length() > 0) {
				List<Object> wsList = workerScheduleRequestRepository.getListByOrganizationCode(organizationCode);
				if(wsList != null && wsList.size() > 0){
				List<WorkerScheduleRequestAssignmentResponse> wsrlist = new ArrayList<WorkerScheduleRequestAssignmentResponse>();
                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                                String timezone =null;
                                TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                if(tzd!=null && tzd.getId()>0)
                                {
                                timezone = tzd.getTimeZoneName();
                                }
                                String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                String datefoemat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                           	if(datefoemat!=null && datefoemat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=datefoemat.trim()+" "+timeformat.trim();
                                }
//				for(WorkerScheduleRequest workerScheduleRequest : wsList){
                                    
                                    for (int j = 0; j < wsList.size(); j++) {
					Object[] arrList = (Object[]) wsList.get(j);
                                       
                                        WorkerScheduleRequest workerScheduleRequest = (WorkerScheduleRequest) arrList[0];
					List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
					WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
					List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
//					WorkerScheduleRequest workerScheduleRequest = null;

						WorkerScheduleRequestRes wsres=new WorkerScheduleRequestRes();
						String frmDt = "";
						String toDt = "";
                                                
                                
						
						
                                                        if(timezone!=null && timezone.length()>0 )
                                                        {
							Date fromDate = workerScheduleRequest.getStartDT();
							fromDate = GigflexDateUtil.getGMTtoLocationDate(fromDate, timezone, dtFormat);
                                                        frmDt=GigflexDateUtil.convertDateToString(fromDate, dtFormat);
							Date toDate = workerScheduleRequest.getEndDT();
							toDate = GigflexDateUtil.getGMTtoLocationDate(toDate,timezone, dtFormat);
                                                        toDt=GigflexDateUtil.convertDateToString(toDate, dtFormat);
                                                        }
							wsres.setStartDT(frmDt);
							wsres.setEndDT(toDt);
						
						wsres.setId(workerScheduleRequest.getId());
                                                wsres.setIsProcessed(workerScheduleRequest.getIsProcessed());
                                                wsres.setIsPublished(workerScheduleRequest.getIsPublished());
                                                wsres.setJobName(workerScheduleRequest.getJobName());
                                                wsres.setOrganizationCode(workerScheduleRequest.getOrganizationCode());
                                                wsres.setPatientCode(workerScheduleRequest.getPatientCode());
                                                wsres.setScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
						wsr.setWorkerScheduleRequestRes(wsres);
					
                                        PatientDetails pDetail = (PatientDetails) arrList[1];
					wsr.setPatientDetails(pDetail); 
					if (objlst != null && objlst.size() > 0) {
						for (int i = 0; i < objlst.size(); i++) {
							Object[] arr = (Object[]) objlst.get(i);
							if (arr.length >= 2) {
								WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
								WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
								wsan.setWorkerScheduleRequestAssignment(ws);
								
								if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
									String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
								wsan.setSkillName(skillName);
								}
								if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
									String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
									wsan.setLocation(location);
								}
								if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

								CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
								if(cm != null && cm.getId() > 0){
								wsan.setCertificationName(cm.getCertificationName());
								}
								}
								workerScheduleRequest = (WorkerScheduleRequest) arr[0];
								wsan.setJobName(workerScheduleRequest.getJobName());
								wsrlst.add(wsan);

							}

						}

//						if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
//							
//							Date frmDt = null;
//							Date toDt = null;
//							
//							
//                    if(timezone!=null && timezone.length()>0 )
//                    {
//								Date fromDate = workerScheduleRequest.getStartDT();
//								frmDt = GigflexDateUtil.getGMTtoLocationDate(
//										fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
//								Date toDate = workerScheduleRequest.getEndDT();
//								toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
//										timezone, "yyyy-MM-dd HH:mm:ss");
//                    }
//								workerScheduleRequest.setStartDT(frmDt);
//								workerScheduleRequest.setEndDT(toDt);
//							
//							
//							wsr.setWorkerScheduleRequest(workerScheduleRequest);
//							wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
//							
//						} 
                                                wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
					} 
					if(wsr != null && wsr.getWorkerScheduleRequestRes() != null){
						wsrlist.add(wsr);
					}
				}
				
				if (wsrlist != null && wsrlist.size() > 0) {
					
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wsrlist);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String publishedWorkerScheduleRequest(Boolean pub, String scheduleCode, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
//			WorkerScheduleRequest wsr = new WorkerScheduleRequest();
			WorkerScheduleRequest wsrResponse = workerScheduleRequestRepository.getByScheduleRequestCode(scheduleCode);
		
			if (wsrResponse != null && wsrResponse.getId() > 0) {
				
//				Date frmDt = null;
//				Date toDt = null;
//				
//				WorkingLocation wl = workLocRep
//						.findByWorkingLocationCode(wsrResponse
//								.getWorkingLocationCode().trim());
//
//				if (wl != null && wl.getId() > 0
//						&& wl.getTimeZone() != null
//						&& wl.getTimeZone().trim().length() > 0) {
//					TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
//                   String timezone = tzd.getTimeZoneName();
//                    if(timezone!=null && timezone.length()>0 )
//                    {
//					Date fromDate = wsrResponse.getStartDT();
//					frmDt = GigflexDateUtil.getGMTtoLocationDate(
//							fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
//					Date toDate = wsrResponse.getEndDT();
//					toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
//							timezone, "yyyy-MM-dd HH:mm:ss");
//                    }
//					wsrResponse.setStartDT(frmDt);
//					wsrResponse.setEndDT(toDt);
//				}
				
				wsrResponse.setIsPublished(pub);
				wsrResponse.setIpAddress(ip);
				WorkerScheduleRequest wsrRes = workerScheduleRequestRepository.save(wsrResponse);
				if (wsrRes != null && wsrRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Worker Schedule has been published");
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wsrRes);
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed.");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Schedule Code does not exist.");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getScheduleCalendar(ScheduleCalendarRequest calreq) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = workerScheduleRequestRepository.getScheduleCalendar(calreq.getOrganizationCode(),
					calreq.getStartDate(), calreq.getEndDate());
			if (objlst != null && objlst.size() > 0) {
				List<ScheduleRequestresponse> arrresss = new ArrayList<ScheduleRequestresponse>();
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					ScheduleRequestresponse resss = new ScheduleRequestresponse();
                                        
                                        WorkerScheduleRequest workerScheduleRequest = (WorkerScheduleRequest) arr[0];
                                        WorkerScheduleRequestRes wsres=new WorkerScheduleRequestRes();
                                        
                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TimeZone);
                                        String timezone =null;
                                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                        if(tzd!=null && tzd.getId()>0)
                                        {
                                        timezone = tzd.getTimeZoneName();
                                        }
                                        String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                        {
                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                        }
                                        
                                        
                                        String frmDt = "";
					String toDt = "";
                                        Date fdt=null;
                                        Date tdt=null;
                                        if(timezone!=null && timezone.length()>0 )
                                        {
                                            Date fromDate = workerScheduleRequest.getStartDT();
                                            fromDate = GigflexDateUtil.getGMTtoLocationDate(fromDate, timezone, dtFormat);
                                            fdt=fromDate;
                                            frmDt=GigflexDateUtil.convertDateToString(fromDate, dtFormat);
                                            Date toDate = workerScheduleRequest.getEndDT();
                                            toDate = GigflexDateUtil.getGMTtoLocationDate(toDate,timezone, dtFormat);
                                            tdt=toDate;
                                            toDt=GigflexDateUtil.convertDateToString(toDate, dtFormat);
                                        }
                                        wsres.setEndDTTimestamp(tdt);
                                        wsres.setStartDTTimestamp(fdt);
                                        wsres.setStartDT(frmDt);
                                        wsres.setEndDT(toDt);
                                        wsres.setId(workerScheduleRequest.getId());
                                        wsres.setIsProcessed(workerScheduleRequest.getIsProcessed());
                                        wsres.setIsPublished(workerScheduleRequest.getIsPublished());
                                        wsres.setJobName(workerScheduleRequest.getJobName());
                                        wsres.setOrganizationCode(workerScheduleRequest.getOrganizationCode());
                                        wsres.setPatientCode(workerScheduleRequest.getPatientCode());
                                        wsres.setScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());

                                        resss.setWorkerScheduleRequest(wsres);
                                        WorkerScheduleRequestAssignment ws=(WorkerScheduleRequestAssignment) arr[1];
                                        resss.setWorkerScheduleRequestAssignment(ws);
                                        
                                        if(workerScheduleRequest!=null && ws!=null)
                                        {
                                           List<AssignScheduleToWorker> asw= assignScheduleRequestToWorkerRepository.getAssignedScheduledToWorkerByReqCodeAndAssignCode(workerScheduleRequest.getScheduleRequestCode(), ws.getScheduleRequestAssignmentCode());
                                           if(asw!=null && asw.size()>0)
                                           {
                                              resss.setAssignScheduleToWorker(asw);
                                           }
                                        }
                                            
                                        
                                        if (ws!=null && ws.getSkillCode() != null && ws.getSkillCode().length() > 0) {
                       String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
                       resss.setSkillName(skillName);
                       String color = workerScheduleRequestRepository.getSkillColorByCodeAndOrgcode(ws.getSkillCode(),workerScheduleRequest.getOrganizationCode());
                       resss.setSkillColor(color);
                   }
                   
                   if (ws!=null &&  ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0) {
                       
                       CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
                       if (cm != null && cm.getId() > 0) {
                           resss.setCertificationName(cm.getCertificationName());
                       }
                   }
                                        arrresss.add(resss);
				}
				if (arrresss != null && arrresss.size() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Success");
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(arrresss);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record does not exist.");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record does not exist.");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestByScheduleRequestCode(String scheduleRequestCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(scheduleRequestCode,
						pageableRequest);
				WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
				List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
				WorkerScheduleRequest workerScheduleRequest = null;
                                PatientDetails pDetail = null;
				if (objlst != null && objlst.size() > 0) {
                                    List<Object> objlstcnt = workerScheduleRequestRepository.findByScheduleRequestCode(scheduleRequestCode);
                                    int count=0;
                                    if(objlstcnt!=null && objlstcnt.size()>0)
                                    {
                                        count=objlstcnt.size();
                                    }
                                    for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
							WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
							wsan.setWorkerScheduleRequestAssignment(ws);
                                                        
                                                        
							
							if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
								String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
							wsan.setSkillName(skillName);
							}
							if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
								String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
								wsan.setLocation(location);
							}
							if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

							CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
							if(cm != null && cm.getId() > 0){
							wsan.setCertificationName(cm.getCertificationName());
							}
							}
							workerScheduleRequest = (WorkerScheduleRequest) arr[0];
                                                        pDetail = (PatientDetails) arr[2];
							wsan.setJobName(workerScheduleRequest.getJobName());

							wsrlst.add(wsan);

						}

					}

					if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
						
                                            WorkerScheduleRequestRes wsres=new WorkerScheduleRequestRes();
						String frmDt = "";
						String toDt = "";
                                                
                                String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                String datefoemat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                           	if(datefoemat!=null && datefoemat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=datefoemat.trim()+" "+timeformat.trim();
                                }
						
						String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TimeZone);
						
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                        if (tzd != null && tzd.getId() > 0) {
                                                        String timezone = tzd.getTimeZoneName();
                                                        if(timezone!=null && timezone.length()>0 )
                                                        {
							Date fromDate = workerScheduleRequest.getStartDT();
							fromDate = GigflexDateUtil.getGMTtoLocationDate(fromDate, timezone, dtFormat);
                                                        frmDt=GigflexDateUtil.convertDateToString(fromDate, dtFormat);
							Date toDate = workerScheduleRequest.getEndDT();
							toDate = GigflexDateUtil.getGMTtoLocationDate(toDate,timezone, dtFormat);
                                                        toDt=GigflexDateUtil.convertDateToString(toDate, dtFormat);
                                                        }
							wsres.setStartDT(frmDt);
							wsres.setEndDT(toDt);
						}
						wsres.setId(workerScheduleRequest.getId());
                                                wsres.setIsProcessed(workerScheduleRequest.getIsProcessed());
                                                wsres.setIsPublished(workerScheduleRequest.getIsPublished());
                                                wsres.setJobName(workerScheduleRequest.getJobName());
                                                wsres.setOrganizationCode(workerScheduleRequest.getOrganizationCode());
                                                wsres.setPatientCode(workerScheduleRequest.getPatientCode());
                                                wsres.setScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
						wsr.setWorkerScheduleRequestRes(wsres);
                                            
						wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
                                                wsr.setPatientDetails(pDetail); 
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsr);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
                                                jsonobj.put("count", count);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestById(Long id, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (id != null && id > 0) {
				List<Object> objlst = workerScheduleRequestRepository.getWorkerScheduleRequestById(id, pageableRequest);
				WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
				List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
				WorkerScheduleRequest workerScheduleRequest = null;
				if (objlst != null && objlst.size() > 0) {
                                    int count=0;
                                    List<Object> objlstcnt = workerScheduleRequestRepository.getWorkerScheduleRequestById(id);
                                    if(objlstcnt!=null && objlstcnt.size()>0)
                                    {
                                        count=objlstcnt.size();
                                    }
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
							WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
							wsan.setWorkerScheduleRequestAssignment(ws);
							
							if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
								String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
							wsan.setSkillName(skillName);
							}
							if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
								String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
								wsan.setLocation(location);
							}
							if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

							CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
							if(cm != null && cm.getId() > 0){
							wsan.setCertificationName(cm.getCertificationName());
							}
							}
							workerScheduleRequest = (WorkerScheduleRequest) arr[0];
							wsan.setJobName(workerScheduleRequest.getJobName());

							wsrlst.add(wsan);

						}

					}

					if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
						
						WorkerScheduleRequestRes wsres=new WorkerScheduleRequestRes();
						String frmDt = "";
						String toDt = "";
                                                
                                String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                String datefoemat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                           	if(datefoemat!=null && datefoemat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=datefoemat.trim()+" "+timeformat.trim();
                                }
						
						String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TimeZone);
						
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                        if (tzd != null && tzd.getId() > 0) {
                                                        String timezone = tzd.getTimeZoneName();
                                                        if(timezone!=null && timezone.length()>0 )
                                                        {
							Date fromDate = workerScheduleRequest.getStartDT();
							fromDate = GigflexDateUtil.getGMTtoLocationDate(fromDate, timezone, dtFormat);
                                                        frmDt=GigflexDateUtil.convertDateToString(fromDate, dtFormat);
							Date toDate = workerScheduleRequest.getEndDT();
							toDate = GigflexDateUtil.getGMTtoLocationDate(toDate,timezone, dtFormat);
                                                        toDt=GigflexDateUtil.convertDateToString(toDate, dtFormat);
                                                        }
							wsres.setStartDT(frmDt);
							wsres.setEndDT(toDt);
						}
						wsres.setId(workerScheduleRequest.getId());
                                                wsres.setIsProcessed(workerScheduleRequest.getIsProcessed());
                                                wsres.setIsPublished(workerScheduleRequest.getIsPublished());
                                                wsres.setJobName(workerScheduleRequest.getJobName());
                                                wsres.setOrganizationCode(workerScheduleRequest.getOrganizationCode());
                                                wsres.setPatientCode(workerScheduleRequest.getPatientCode());
                                                wsres.setScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
						wsr.setWorkerScheduleRequestRes(wsres);
						wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsr);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
                                                jsonobj.put("count", count);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestByOrganizationCode(String organizationCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
			Pageable pageableRequest = PageRequest.of(page, limit);

			if (organizationCode != null && organizationCode.trim().length() > 0) {
                            
                                List<Object> wsList = workerScheduleRequestRepository.getListByOrganizationCodeByPage(organizationCode,pageableRequest);
//				List<WorkerScheduleRequest> wsList = workerScheduleRequestRepository.getListByOrganizationCodeByPage(organizationCode,pageableRequest);
				if(wsList != null && wsList.size() > 0){
                                int count =0;
                                List<Object> wsListcnt = workerScheduleRequestRepository.getListByOrganizationCode(organizationCode);
                                String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                String datefoemat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                                String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                           	if(datefoemat!=null && datefoemat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                {
                                    dtFormat=datefoemat.trim()+" "+timeformat.trim();
                                }
                                String timezone = null;
                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
						
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                                        if (tzd != null && tzd.getId() > 0) {
                                                         timezone = tzd.getTimeZoneName();
                                                        }
                                
                                if(wsListcnt!=null && wsListcnt.size()>0)
                                {
                                   count= wsListcnt.size();
                                }
				List<WorkerScheduleRequestAssignmentResponse> wsrlist = new ArrayList<WorkerScheduleRequestAssignmentResponse>();

                                 for (int j = 0; j < wsList.size(); j++) {
					Object[] arrList = (Object[]) wsList.get(j);
                                       
                                        WorkerScheduleRequest workerScheduleRequest = (WorkerScheduleRequest) arrList[0];
                                        PatientDetails pDetail = (PatientDetails) arrList[1];
					List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
					WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
					List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
//					WorkerScheduleRequest workerScheduleRequest = null;
					WorkerScheduleRequestRes wsres=new WorkerScheduleRequestRes();
						String frmDt = "";
						String toDt = "";
                                                
                                
						
						
                                                        if(timezone!=null && timezone.length()>0 )
                                                        {
							Date fromDate = workerScheduleRequest.getStartDT();
							fromDate = GigflexDateUtil.getGMTtoLocationDate(fromDate, timezone, dtFormat);
                                                        frmDt=GigflexDateUtil.convertDateToString(fromDate, dtFormat);
							Date toDate = workerScheduleRequest.getEndDT();
							toDate = GigflexDateUtil.getGMTtoLocationDate(toDate,timezone, dtFormat);
                                                        toDt=GigflexDateUtil.convertDateToString(toDate, dtFormat);
                                                        }
							wsres.setStartDT(frmDt);
							wsres.setEndDT(toDt);
						
						wsres.setId(workerScheduleRequest.getId());
                                                wsres.setIsProcessed(workerScheduleRequest.getIsProcessed());
                                                wsres.setIsPublished(workerScheduleRequest.getIsPublished());
                                                wsres.setJobName(workerScheduleRequest.getJobName());
                                                wsres.setOrganizationCode(workerScheduleRequest.getOrganizationCode());
                                                wsres.setPatientCode(workerScheduleRequest.getPatientCode());
                                                wsres.setScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
						wsr.setWorkerScheduleRequestRes(wsres);
					wsr.setPatientDetails(pDetail); 
					if (objlst != null && objlst.size() > 0) {
						for (int i = 0; i < objlst.size(); i++) {
							Object[] arr = (Object[]) objlst.get(i);
							if (arr.length >= 2) {
								WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
								WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
								wsan.setWorkerScheduleRequestAssignment(ws);
								
								if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
									String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
								wsan.setSkillName(skillName);
								}
								if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
									String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
									wsan.setLocation(location);
								}
								if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

								CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
								if(cm != null && cm.getId() > 0){
								wsan.setCertificationName(cm.getCertificationName());
								}
								}
								workerScheduleRequest = (WorkerScheduleRequest) arr[0];
								wsan.setJobName(workerScheduleRequest.getJobName());
								wsrlst.add(wsan);

							}

						}

//						if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
//							
//							Date frmDt = null;
//							Date toDt = null;
//							
//							WorkingLocation wl = workLocRep
//									.findByWorkingLocationCode(workerScheduleRequest
//											.getWorkingLocationCode().trim());
//
//							if (wl != null && wl.getId() > 0
//									&& wl.getTimeZone() != null
//									&& wl.getTimeZone().trim().length() > 0) {
//								TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
//                   String timezone = tzd.getTimeZoneName();
//                    if(timezone!=null && timezone.length()>0 )
//                    {
//								Date fromDate = workerScheduleRequest.getStartDT();
//								frmDt = GigflexDateUtil.getGMTtoLocationDate(
//										fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
//								Date toDate = workerScheduleRequest.getEndDT();
//								toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
//										timezone, "yyyy-MM-dd HH:mm:ss");
//                    }
//								workerScheduleRequest.setStartDT(frmDt);
//								workerScheduleRequest.setEndDT(toDt);
//							}
//							
//							wsr.setWorkerScheduleRequest(workerScheduleRequest);
//							wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
//							
//						} 
wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
					} 
					if(wsr != null && wsr.getWorkerScheduleRequestRes() != null){
						wsrlist.add(wsr);
					}
				}
				
				if (wsrlist != null && wsrlist.size() > 0) {
					
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wsrlist);
					jsonobj.put("responsecode", 200);
					jsonobj.put("count", count);
                                        jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getTargetAchieved(String scheduleRequestCode) {
		String res = "";
		String status = null;
		double targetInPercent = 0.0;
		try {
			JSONObject jsonobj = new JSONObject();
			AssignScheduleToWorker assignScheduleToWorker = assignScheduleRequestToWorkerRepository
					.getWorkerScheduleRequestCode(scheduleRequestCode);
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {
					status = GigflexConstants.assignedScheduleAcceptedStatus;
					Long requestedStaffCount = workerScheduleRequestRepository
							.getRequestedStaffCount(scheduleRequestCode);
					Long scheduleAcceptedStatusCount = workerScheduleRequestRepository
							.getScheduleAcceptedStatusCount(scheduleRequestCode, status);
					if (requestedStaffCount > 0) {
						if (scheduleAcceptedStatusCount > 0) {
							targetInPercent = (scheduleAcceptedStatusCount * 100) / requestedStaffCount;

							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Target Achieved is :" + targetInPercent + " %");
							jsonobj.put("achievedTarget", targetInPercent);
						} else {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Target Achieved is :" + targetInPercent + " %");
							jsonobj.put("achievedTarget", targetInPercent);
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Staff Count Not Found.");
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found.");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;

	}

	@Override
	public String getAvailableWorkerBasedOnScheduleFilterByScheduleRequestCode(String scheduleRequestCode) {
		String res = "";
		try {

			JSONObject jsonobj = new JSONObject();
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(scheduleRequestCode);
				WorkerScheduleRequest wsr = null;

				if (objlst != null && objlst.size() > 0) {
					List<AvailableWorkerBasedOnScheduleFilterRes> asslst = new ArrayList<AvailableWorkerBasedOnScheduleFilterRes>();
					for (int i = 0; i < objlst.size(); i++) {

						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							AvailableWorkerBasedOnScheduleFilterRes aeb = new AvailableWorkerBasedOnScheduleFilterRes();
							wsr = (WorkerScheduleRequest) arr[0];
							WorkerScheduleRequestAssignment wsra = (WorkerScheduleRequestAssignment) arr[1];
                                                        
                                                        PatientDetails pDetail = (PatientDetails) arr[2];//
                                                        aeb.setPatientDetails(pDetail); 
                                                        
							if (wsr != null && wsr.getId() > 0 && wsr.getStartDT() != null && wsr.getEndDT() != null
									&& wsra != null && wsra.getId() > 0) {

								List<String> busyWorkerLst = new ArrayList<String>();
								List<Object> busyObj = assignScheduleRequestToWorkerRepository
										.getBusyWorkerLisInOtherScheduletInStartEnd(wsr.getStartDT(), wsr.getEndDT(),wsra.getScheduleRequestAssignmentCode());
								if (busyObj != null && busyObj.size() > 0) {
									for (Object objectWr : busyObj) {
										if (objectWr != null && objectWr.toString().length() > 0) {
											busyWorkerLst.add((String) objectWr);
										}
									}
								}
								boolean stNot = true;
								Long experienceInDays = 0L;
								String skillcode = null;
								String certificatecode = null;
								String orgCode = wsr.getOrganizationCode();

								List<String> newWorkerLst = new ArrayList<String>();
								List<Worker> wrlstRes = null;
								experienceInDays = wsra.getExpDays();
								skillcode = wsra.getSkillCode();
								certificatecode = wsra.getCertificationCode();
								if (skillcode != null && skillcode.trim().length() > 0) {
									if (busyWorkerLst != null && busyWorkerLst.size() > 0) {
										List<Worker> wrlst = workerScheduleRequestRepository
												.getSameSkillAvailableWorkerListByOrganizationCode(experienceInDays,
														skillcode, orgCode, busyWorkerLst);
										wrlstRes = wrlst;
										for (Worker wr : wrlst) {
											newWorkerLst.add(wr.getWorkerCode());
										}
										stNot = false;
									} else {
										List<Worker> wrlst = workerScheduleRequestRepository
												.getSameSkillAvailableWorkerListByOrganizationCodewithIN(
														experienceInDays, skillcode, orgCode);
										wrlstRes = wrlst;
										for (Worker wr : wrlst) {
											newWorkerLst.add(wr.getWorkerCode());
										}
										stNot = false;
									}
								}
								if (certificatecode != null && certificatecode.trim().length() > 0) {
									if (stNot == false && wrlstRes != null && wrlstRes.size() > 0) {
										List<Worker> wrlst = assignScheduleRequestToWorkerRepository
												.getSameCertificateAvailableWorkerListWithIN(certificatecode, orgCode,
														newWorkerLst);
										wrlstRes = wrlst;
										newWorkerLst = new ArrayList<String>();
										for (Worker wr : wrlst) {
											newWorkerLst.add(wr.getWorkerCode());
										}
									} else {
										if (stNot) {
											List<Worker> wrlst = assignScheduleRequestToWorkerRepository
													.getSameCertificateAvailableWorkerListWithNotIN(certificatecode,
															wsr.getOrganizationCode(), busyWorkerLst);
											wrlstRes = wrlst;
											newWorkerLst = new ArrayList<String>();
											for (Worker wr : wrlst) {
												newWorkerLst.add(wr.getWorkerCode());
											}
											stNot = false;
										}
									}

								}

								// if (exp_year != null && exp_month != null && exp_days != null && (exp_year >
								// 0 || exp_month > 0 || exp_days > 0)) {
								// if (stNot == false && wrlstRes != null && wrlstRes.size() > 0) {
								// List<Worker> wrlst
								// =assignScheduleRequestToWorkerRepository.getSameExperienceAvailableWorkerListWithIN(exp_year,
								// exp_month, exp_days, wsr.getOrganizationCode(),newWorkerLst);
								// wrlstRes = wrlst;
								// newWorkerLst = new ArrayList<String>();
								// for (Worker wr : wrlst) {
								// newWorkerLst.add(wr.getWorkerCode());
								// }
								// } else {
								// if (stNot) {
								// List<Worker> wrlst
								// =assignScheduleRequestToWorkerRepository.getSameExperienceAvailableWorkerListWithNotIN(exp_year,
								// exp_month, exp_days, wsr.getOrganizationCode(),busyWorkerLst);
								// wrlstRes = wrlst;
								// newWorkerLst = new ArrayList<String>();
								// for (Worker wr : wrlst) {
								// newWorkerLst.add(wr.getWorkerCode());
								// }
								// stNot = false;
								// }
								// }
								//
								// }
								// List<Worker> wrlst =
								// assignScheduleRequestToWorkerRepository.getSmaeSkillAvailableWorkerList(assignScheduletoWorkerCode,busyWorkerLst);
								List<WorkerScheduleStatus> wrlstResWithstatus =new ArrayList<WorkerScheduleStatus>();
                                                                if (wrlstRes != null && wrlstRes.size() > 0) {
									
                                                                        aeb.setScheduleRequestAssignmentCode(wsra.getScheduleRequestAssignmentCode());
                                                                        for(Worker wr:wrlstRes)
                                                                        {
                                                                            WorkerScheduleStatus wss=new WorkerScheduleStatus();
                                                                            wss.setWorker(wr);
                                                                            AssignScheduleToWorker astw=assignScheduleRequestToWorkerRepository.getAssignedScheduledToWorkerByWorkerScheduleRequestAssignment(scheduleRequestCode, wsra.getScheduleRequestAssignmentCode(), wr.getWorkerCode());
                                                                            if(astw!=null && astw.getId()>0 && astw.getStatus()!=null && astw.getStatus().trim().length()>0)
                                                                            {
                                                                               wss.setAssignWorkerStatus(astw.getStatus());
                                                                            }
                                                                            wrlstResWithstatus.add(wss);
                                                                        }
									aeb.setWorkerCount(wrlstRes.size());
									aeb.setWorkerListWithStatus(wrlstResWithstatus);
									asslst.add(aeb);

								} else {
									aeb.setScheduleRequestAssignmentCode(wsra.getScheduleRequestAssignmentCode());
									aeb.setWorkerCount(wrlstRes.size());
									aeb.setWorkerListWithStatus(wrlstResWithstatus);
									asslst.add(aeb);

								}

							}

						}

					}
					if (asslst != null && asslst.size() > 0) {
						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Same skill available worker list");
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(asslst);
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");
					}
					res = jsonobj.toString();

				} else {
					GigflexResponse derr = new GigflexResponse(500, new Date(), "Record not found.");
					res = derr.toString();
				}

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid.");
				res = derr.toString();
			}

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getPercentageOfScheduleFulfilment(String scheduleRequestCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				AssignScheduleToWorker assignScheduleToWorker = assignScheduleRequestToWorkerRepository
						.getWorkerScheduleRequestCode(scheduleRequestCode);
				if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {

					List<WorkerScheduleRequestAssignment> wsra = workerScheduleRequestRepository
							.getScheduleAssgnByScheduleRequestCode(scheduleRequestCode);

					Double scheduleFulfillment = 0.0;
					for (WorkerScheduleRequestAssignment wsra1 : wsra) {

						Integer staff = wsra1.getRequestedStaff();

						Long reqStaff = workerScheduleRequestRepository
								.getCountOfRequestedStaff(wsra1.getScheduleRequestAssignmentCode());
						if (staff > 0) {
							if (reqStaff > 0) {

								scheduleFulfillment = (double) ((reqStaff * 100) / staff);

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Schedule Fullfilled :" + scheduleFulfillment + " %");
								jsonobj.put("scheduleFulfillment", scheduleFulfillment);

							} else {
								jsonobj.put("responsecode", 404);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Schedule Fullfilled :" + scheduleFulfillment + " %");
								jsonobj.put("scheduleFulfillment", scheduleFulfillment);
							}

						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Staff Not Found.");

						}
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found.");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWeeklyReportByDates(String scheduleRequestAssignmentCode, String status, String strtDate, String enDate) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (scheduleRequestAssignmentCode != null && scheduleRequestAssignmentCode.trim().length() > 0 && status != null && status.trim().length() > 0 ) {
				WorkerScheduleRequestAssignment assignScheduleToWorker = assignScheduleRequestToWorkerRepository
						.getWorkerScheduleRequestAssignmentCode(scheduleRequestAssignmentCode);
				if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {
					if (status.equalsIgnoreCase(GigflexConstants.assignedScheduleAcceptedStatus)) {
						Date startDate = null;
						Date endDate = null;
						try {
							startDate = GigflexDateUtil.convertStringToDate(strtDate,GigflexDateFormatConstants.DD_MM_YYYY_HH_MM_SS);
							endDate = GigflexDateUtil.convertStringToDate(enDate,GigflexDateFormatConstants.DD_MM_YYYY_HH_MM_SS);
						} catch (Exception ex) {
							ex.printStackTrace();
							GigflexResponse derr = new GigflexResponse(400,
									new Date(),
									"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
							return derr.toString();
						}
						WorkingLocation wl = null;
						if(assignScheduleToWorker.getLocationCode() != null && assignScheduleToWorker.getLocationCode().trim().length()>0){
						
						 wl = workLocRep
								.findByWorkingLocationCode(assignScheduleToWorker
										.getLocationCode().trim());
						}
						if (wl != null && wl.getId() > 0) {

                                                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
							startDate = GigflexDateUtil
									.convertStringDateToGMT(strtDate.trim(), timezone,
											"yyyy-MM-dd HH:mm:ss");
							endDate = GigflexDateUtil
									.convertStringDateToGMT(enDate.trim(), timezone,
											"yyyy-MM-dd HH:mm:ss");
                    }

					Double scheduleFulfillmentWeekly = 0.0;

					Long reqStaffWeekly = workerScheduleRequestRepository
							.getScheduleAcceptedForDateRange(scheduleRequestAssignmentCode, status, startDate, endDate);

					Long staffWeekly = workerScheduleRequestRepository.getTotalStaffByDateRange(startDate, endDate);
							if (staffWeekly > 0) {
								if (reqStaffWeekly > 0) {

									scheduleFulfillmentWeekly = (double) ((reqStaffWeekly * 100) / staffWeekly);
									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message",
											"Schedule Fullfilled :"
													+ scheduleFulfillmentWeekly
													+ " %");
									jsonobj.put("scheduleFulfillment",
											scheduleFulfillmentWeekly);

								} else {
									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message",
											"Schedule Fullfilled :"
													+ scheduleFulfillmentWeekly
													+ " %");
									jsonobj.put("scheduleFulfillment",
											scheduleFulfillmentWeekly);
								}

							} else {
								jsonobj.put("responsecode", 404);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record Not Found.");

							}
						} else {
							jsonobj.put("message",
									"Working Location Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Status Not Matched.");

					}

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found.");

				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

//	@Override
//	public String getWorkerScheduleRequestByScheduleRequestCode(
//			String scheduleRequestCode) {
//		String res = "";
//        try {
//            JSONObject jsonobj = new JSONObject();
//            WorkerScheduleRequest wsrReslst = workerScheduleRequestRepository.getByScheduleRequestCode(scheduleRequestCode);
//            if ( wsrReslst!= null ) {
//                ObjectMapper mapperObj = new ObjectMapper();
//                String Detail = mapperObj.writeValueAsString(wsrReslst);
//                jsonobj.put("responsecode", 200);
//                jsonobj.put("timestamp", new Date());
//                jsonobj.put("message", "Success");
//                jsonobj.put("data", new JSONObject(Detail));
//                
//            }
//            else
//            {
//            jsonobj.put("responsecode", 404);
//            jsonobj.put("timestamp", new Date());
//            jsonobj.put("message", "Record Not Found");
//            }
//            res = jsonobj.toString();
//        } catch (JSONException | JsonProcessingException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
//	}

//	@Override
//	public String getWorkerScheduleRequestById(Long id) {
//		String res = "";
//        try {
//            JSONObject jsonobj = new JSONObject();
//            WorkerScheduleRequest wsrReslst = workerScheduleRequestRepository.getWorkerScheduleRequestById(id);
//            if ( wsrReslst!= null ) {
//                ObjectMapper mapperObj = new ObjectMapper();
//                String Detail = mapperObj.writeValueAsString(wsrReslst);
//                jsonobj.put("responsecode", 200);
//                jsonobj.put("timestamp", new Date());
//                jsonobj.put("message", "Success");
//                jsonobj.put("data", new JSONObject(Detail));
//                
//            }
//            else
//            {
//            jsonobj.put("responsecode", 404);
//            jsonobj.put("timestamp", new Date());
//            jsonobj.put("message", "Record Not Found");
//            }
//            res = jsonobj.toString();
//        } catch (JSONException | JsonProcessingException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
//	}

//	@Override
//	public String getWorkerScheduleRequestByOrganizationCode(
//			String organizationCode) {
//		String res = "";
//        try {
//            JSONObject jsonobj = new JSONObject();
//            WorkerScheduleRequest wsrReslst = workerScheduleRequestRepository.getWorkerScheduleRequestByOrgCode(organizationCode);
//            if ( wsrReslst!= null ) {
//                ObjectMapper mapperObj = new ObjectMapper();
//                String Detail = mapperObj.writeValueAsString(wsrReslst);
//                jsonobj.put("responsecode", 200);
//                jsonobj.put("timestamp", new Date());
//                jsonobj.put("message", "Success");
//                jsonobj.put("data", new JSONObject(Detail));
//                
//            }
//            else
//            {
//            jsonobj.put("responsecode", 404);
//            jsonobj.put("timestamp", new Date());
//            jsonobj.put("message", "Record Not Found");
//            }
//            res = jsonobj.toString();
//        } catch (JSONException | JsonProcessingException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
//	}

    @Override
    public String publishedWorkerScheduleRequestByOrganizationCode(Boolean pub, String orgCode, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        List<WorkerScheduleRequest> wsrResponseList = workerScheduleRequestRepository.getByOrganizationCode(orgCode);
		
                        if(wsrResponseList !=null && wsrResponseList.size() > 0)
                        {
                            List<WorkerScheduleRequest> wsrResponseSuccessResList = new ArrayList<WorkerScheduleRequest>();
                            List<WorkerScheduleRequest> wsrResponseFailerResList = new ArrayList<WorkerScheduleRequest>();
                            
                             for(int i =0 ;i <wsrResponseList.size() ;i++ )
                            {
                                    WorkerScheduleRequest wsrResponse = wsrResponseList.get(i);

                                    if (wsrResponse != null && wsrResponse.getId() > 0) {

        //				Date frmDt = null;
        //				Date toDt = null;
        //				
        //				WorkingLocation wl = workLocRep
        //						.findByWorkingLocationCode(wsrResponse
        //								.getWorkingLocationCode().trim());

        //				if (wl != null && wl.getId() > 0
        //						&& wl.getTimeZone() != null
        //						&& wl.getTimeZone().trim().length() > 0) {
        //				    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
        //                                    String timezone = tzd.getTimeZoneName();
        //                                     if(timezone!=null && timezone.length()>0 )
        //                                     {
        //					Date fromDate = wsrResponse.getStartDT();
        //					frmDt = GigflexDateUtil.getGMTtoLocationDate(
        //							fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
        //					Date toDate = wsrResponse.getEndDT();
        //					toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
        //							timezone, "yyyy-MM-dd HH:mm:ss");
        //                                     }
        //					wsrResponse.setStartDT(frmDt);
        //					wsrResponse.setEndDT(toDt);
        //				}

                                        wsrResponse.setIsPublished(pub);
                                        wsrResponse.setIpAddress(ip);
                                        WorkerScheduleRequest wsrRes = workerScheduleRequestRepository.save(wsrResponse);
                                        
                                        if(wsrRes != null && wsrRes.getId() > 0)
                                        {
                                            wsrResponseSuccessResList.add(wsrRes);
                                        }
                                        else
                                        {
                                            wsrResponseFailerResList.add(wsrRes);
                                        }
                                        
                                        
                                }
                        
			
				if (wsrResponseFailerResList.size() == 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Worker Schedule has been published");
//					ObjectMapper mapperObj = new ObjectMapper();
//					String Detail = mapperObj.writeValueAsString(wsrRes);
//					jsonobj.put("data", new JSONObject(Detail));
				} else {
                                    
                                    
                                    if(wsrResponseSuccessResList.size() > 0)
                                    {
                                        StringBuffer success = new StringBuffer();
                                        StringBuffer failed = new StringBuffer();
                                        for(int j=0 ; j<wsrResponseSuccessResList.size() ;j++)
                                        {
                                            WorkerScheduleRequest wsrRes = wsrResponseSuccessResList.get(j);
                                            success.append(wsrRes.getScheduleRequestCode()).append(",");
                                        }
                                     
                                        int lastIndex1 = success.lastIndexOf(",");
                                     
                                        success.deleteCharAt(lastIndex1);

                                        String strSuccess = success.toString();

                                        for(int j=0 ; j<wsrResponseFailerResList.size() ;j++)
                                        {
                                            WorkerScheduleRequest wsrRes = wsrResponseFailerResList.get(j);
                                            failed.append(wsrRes.getScheduleRequestCode()).append(",");
                                        }

                                        int lastIndex = failed.lastIndexOf(",");

                                        failed.deleteCharAt(lastIndex);

                                        String strFailure = failed.toString();
                                     
                                        jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Worker Schedule having Schedule Request Code " +strSuccess+" has been published and "
                                                + " Worker Schedule having Schedule Request Code " +strFailure +" has been failed to published.");
                                     
                                    }
                                    else
                                    {
                                        jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed.");
                                    }
                                    
				}

                           }
                        
                       	} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Schedule Code does not exist.");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String getScheduleCalendarForWorker(String workerCode, List<String> status, String stratDT, String endDT) {
        
        
       String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
           
            Date sDT = null;
            Date eDT = null;
            if (stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
//                                stratDT = stratDT + " 00:00:00";
//                                endDT = endDT + " 00:00:00";

                                //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                                sDT = GigflexDateUtil.convertStringToDate(stratDT.trim(), "yyyy-MM-dd HH:mm:ss");
                                eDT = GigflexDateUtil.convertStringToDate(endDT.trim(), "yyyy-MM-dd HH:mm:ss");
                                if (sDT == null || eDT == null) {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                            "Date conversion has been failed.");
                                    return derr.toString();
                                }
//                                Calendar cal = Calendar.getInstance();
//                                cal.setTime(eDT);
//                                cal.add(Calendar.DATE, 1);
//                                eDT = cal.getTime();
                            }
            List<Object> objlstCheck = null;

                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.assignedScheduleAcceptedStatus);
                        stlst.add(GigflexConstants.assignedScheduleChangedStatus);
                        stlst.add(GigflexConstants.assignedScheduleRejectedStatus);
                        stlst.add(GigflexConstants.assignedScheduleStatus);
                        status = stlst;
                    }

                    List<Object> objlst = null;
                    if (sDT != null && eDT != null) {
                        objlst = assignScheduleRequestToWorkerRepository.getAllSceduleByWorkerCodeWithFilterByPage(workerCode, status, sDT, eDT);
//                        objlstCheck = assignScheduleRequestToWorkerRepository.getAllSceduleByWorkerCodeWithFilterByPage(workerCode, status, sDT, eDT);
//                        if (objlstCheck != null && objlstCheck.size() > 0) {
//                            count = objlstCheck.size();
//                        }
                    } else {
                        objlst = assignScheduleRequestToWorkerRepository.getAllSceduleByWorkerCodeWithFilterByPage(workerCode, status);
//                        objlstCheck = assignScheduleRequestToWorkerRepository.getAllSceduleByWorkerCodeWithFilterByPage(workerCode, status);
//                        if (objlstCheck != null && objlstCheck.size() > 0) {
//                            count = objlstCheck.size();
//                        }
                    }
            
            List<AssigntoWorkerScheduleResponseNew> awslst=new ArrayList<AssigntoWorkerScheduleResponseNew>();
          //List<Object> asrwlst= assignScheduleRequestToWorkerRepository.getAssigntoWorkerScheduleRequestByWorkerCode(workerCode,pageableRequest);
           if(objlst!=null && objlst.size()>0) 
           {
           for (Object object : objlst) {
               AssigntoWorkerScheduleResponseNew aws=new AssigntoWorkerScheduleResponseNew();     
               Object[] obj = (Object[]) object;
               if(obj.length>=3)
               {
               aws.setAssignScheduleToWorker((AssignScheduleToWorker) obj[0]);
//               WorkerScheduleRequest wr=(WorkerScheduleRequest)obj[1];
//               Date frmDt = null;
//               Date toDt = null;
//
//               WorkingLocation wl = workLocRep.findByWorkingLocationCode(wr.getWorkingLocationCode().trim());
//
//               if (wl != null && wl.getId() > 0
//                       && wl.getTimeZone() != null
//                       && wl.getTimeZone().trim().length() > 0) {
//                   TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
//                   String timezone = tzd.getTimeZoneName();
//                    if(timezone!=null && timezone.length()>0 )
//                    {
//                   Date fromDate = wr.getStartDT();
//                   frmDt = GigflexDateUtil.getGMTtoLocationDate(
//                           fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
//                   Date toDate = wr.getEndDT();
//                   toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
//                           timezone, "yyyy-MM-dd HH:mm:ss");
//                    }
//                   wr.setStartDT(frmDt);
//                   wr.setEndDT(toDt);
//                    aws.setLocation(wl.getLocation());
//               }
//               
               
               
               
               
               
               
               
               
               
               
               WorkerScheduleRequest workerScheduleRequest = (WorkerScheduleRequest) obj[1];
                                        WorkerScheduleRequestRes wsres=new WorkerScheduleRequestRes();
                                        
                                        String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.TimeZone);
                                        String timezone =null;
                                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                        if(tzd!=null && tzd.getId()>0)
                                        {
                                        timezone = tzd.getTimeZoneName();
                                        }
                                        String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.DATEFORMAT);
                                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerScheduleRequest.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                        {
                                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                                        }
                                        
                                        
                                        String frmDt = "";
					String toDt = "";
                                        Date fdt=null;
                                        Date tdt=null;
                                        if(timezone!=null && timezone.length()>0 )
                                        {
                                            Date fromDate = workerScheduleRequest.getStartDT();
                                            fromDate = GigflexDateUtil.getGMTtoLocationDate(fromDate, timezone, dtFormat);
                                            fdt=fromDate;
                                            frmDt=GigflexDateUtil.convertDateToString(fromDate, dtFormat);
                                            Date toDate = workerScheduleRequest.getEndDT();
                                            toDate = GigflexDateUtil.getGMTtoLocationDate(toDate,timezone, dtFormat);
                                            tdt=toDate;
                                            toDt=GigflexDateUtil.convertDateToString(toDate, dtFormat);
                                        }
                                        wsres.setEndDTTimestamp(tdt);
                                        wsres.setStartDTTimestamp(fdt);
                                        wsres.setStartDT(frmDt);
                                        wsres.setEndDT(toDt);
                                        wsres.setId(workerScheduleRequest.getId());
                                        wsres.setIsProcessed(workerScheduleRequest.getIsProcessed());
                                        wsres.setIsPublished(workerScheduleRequest.getIsPublished());
                                        wsres.setJobName(workerScheduleRequest.getJobName());
                                        wsres.setOrganizationCode(workerScheduleRequest.getOrganizationCode());
                                        wsres.setPatientCode(workerScheduleRequest.getPatientCode());
                                        wsres.setScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
               
               
               
               aws.setWorkerScheduleRequest(wsres);
               WorkerScheduleRequestAssignment ws=(WorkerScheduleRequestAssignment)obj[2];
               aws.setWorkerScheduleRequestAssignment(ws);
               
                   if (ws.getSkillCode() != null && ws.getSkillCode().length() > 0) {
                       String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
                       aws.setSkillName(skillName);
                       String color = workerScheduleRequestRepository.getSkillColorByCodeAndOrgcode(ws.getSkillCode(),workerScheduleRequest.getOrganizationCode());
                       aws.setSkillColor(color);
                   }
                   
                   if (ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0) {
                       
                       CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
                       if (cm != null && cm.getId() > 0) {
                           aws.setCertificationName(cm.getCertificationName());
                       }
                   }
                   if (workerScheduleRequest.getOrganizationCode() != null && workerScheduleRequest.getOrganizationCode().length() > 0) {
                       
                       Organization o = organizationRepository.findByOrganizationCode(workerScheduleRequest.getOrganizationCode());
                       if (o != null && o.getId() > 0) {
                           aws.setOrganizationName(o.getOrganizationName());
                       }
                   }
                   
               awslst.add(aws);
           }
            }
           if(awslst!=null && awslst.size()>0)
           {
               jsonobj.put("responsecode", 200);
               jsonobj.put("timestamp", new Date());
               jsonobj.put("message", "Success");
              // jsonobj.put("count", count);
               ObjectMapper mapperObj = new ObjectMapper();
               String Detail = mapperObj.writeValueAsString(awslst);
               jsonobj.put("data", new JSONArray(Detail));
           }
           else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
           } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
           
          
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;
            
    
    
    }

    @Override
    public String updateWorkerScheduleRequestByScheduleRequestCode(WorkerScheduleRequestUpdate wsr, String scheduleRequestCode, String ip) {
          
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            WorkerScheduleRequest wr = workerScheduleRequestRepository.getByScheduleRequestCode(scheduleRequestCode);
            if (wr != null && wr.getId() > 0) {
                String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;

                Date sdt = null;
                Date edt = null;
                if (wsr.getStart() != null && wsr.getStart().trim().length() > 0 && wsr.getEnd() != null && wsr.getEnd().trim().length() > 0) {
                    try {
                        Date sdate = null;
                        Date edate = null;
                        sdate = new SimpleDateFormat(dtFormat).parse(wsr.getStart().trim());
                        edate = new SimpleDateFormat(dtFormat).parse(wsr.getEnd().trim());
                        if (sdate == null || edate == null) {
                            GigflexResponse derr = new GigflexResponse(400, new Date(),
                                    "Plz send date in correct format(" + dtFormat + ") ");
                            return derr.toString();
                        }

                    } catch (Exception ex) {
                        ex.printStackTrace();
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Plz send date in correct format(" + dtFormat + ") ");
                        return derr.toString();
                    }

                    String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, wr.getOrganizationCode(), GigflexConstants.TimeZone);
                    if (timezoneCode != null && timezoneCode.length() > 0) {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                            String timezone = tzd.getTimeZoneName();
                            sdt = GigflexDateUtil.convertStringDateToGMT(wsr.getStart().trim(), timezone, dtFormat);
                            edt = GigflexDateUtil.convertStringDateToGMT(wsr.getEnd().trim(), timezone, dtFormat);
                        }
                    }
                }

                if (sdt != null) {
                    wr.setStartDT(sdt);
                }

                if (edt != null) {
                    wr.setEndDT(edt);
                }

                if (wsr.getJobName() != null && wsr.getJobName().length() > 0) {
                    wr.setJobName(wsr.getJobName());
                }

                if (wsr.getWorkingLocationCode() != null && wsr.getWorkingLocationCode().length() > 0) {
                    wr.setWorkingLocationCode(wsr.getWorkingLocationCode());
                }
                wr.setIpAddress(ip);
                WorkerScheduleRequest wrres = workerScheduleRequestRepository.save(wr);
                if (wrres != null && wrres.getId() > 0) {
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Worker Schedule Request has been updated.");
                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Failed.");
                }
            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Records not found.");
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;
    }

//    
//    public void optaStartThread(String scheduleReqCode) {
//		Thread t = new Thread(new OptaStartThread(scheduleReqCode,workerScheduleRequestRepository,assignScheduleRequestToWorkerRepository,assignScheduleRequestToWorkerService));
//		t.start();
////        StartOptaPlanner sop=new StartOptaPlanner();
////        sop.startScheduleAssign(scheduleReqCode);
//	}
    
}
