/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author nirbhay.p
 */
@Entity
@Table(name = "local_setting")
public class LocalSetting extends CommonAttributes implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "global_setting_code")
    private String globalSettingCode;

    @Column(name = "local_setting_value")
    private String localSettingValue;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "local_setting_code", unique = true)
    private String localSettingCode;
    
    @Column(name = "user_code")
    private String userCode;
    
    @Column(name = "setting_type")
    private String settingType;
    
    @PrePersist
    private void assignUUID() {
        if(this.getLocalSettingCode()==null || this.getLocalSettingCode().length()==0)
        {
            this.setLocalSettingCode(UUID.randomUUID().toString());
        }
    }

    public String getGlobalSettingCode() {
        return globalSettingCode;
    }

    public void setGlobalSettingCode(String globalSettingCode) {
        this.globalSettingCode = globalSettingCode;
    }

    public String getLocalSettingCode() {
        return localSettingCode;
    }

    public void setLocalSettingCode(String localSettingCode) {
        this.localSettingCode = localSettingCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLocalSettingValue() {
        return localSettingValue;
    }

    public void setLocalSettingValue(String localSettingValue) {
        this.localSettingValue = localSettingValue;
    }


    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getSettingType() {
        return settingType;
    }

    public void setSettingType(String settingType) {
        this.settingType = settingType;
    }

   
}
