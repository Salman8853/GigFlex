/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.dtob;

/**
 *
 * @author nirbhay.p
 */
public class LocalSettingResponse {
    private Long id;
    
    private String localSettingCode;
    
    private String localSettingValue;

    private String globalSettingCode;

    private String userCode;
    
    private String globalSettingName;
    
    private String globalSettingValue;
    
    private String settingType;

    public String getSettingType() {
        return settingType;
    }

    public void setSettingType(String settingType) {
        this.settingType = settingType;
    }

    public String getLocalSettingValue() {
        return localSettingValue;
    }

    public void setLocalSettingValue(String localSettingValue) {
        this.localSettingValue = localSettingValue;
    }

    
    public String getGlobalSettingCode() {
        return globalSettingCode;
    }

    public void setGlobalSettingCode(String globalSettingCode) {
        this.globalSettingCode = globalSettingCode;
    }


    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getGlobalSettingName() {
        return globalSettingName;
    }

    public void setGlobalSettingName(String globalSettingName) {
        this.globalSettingName = globalSettingName;
    }

    public String getGlobalSettingValue() {
        return globalSettingValue;
    }

    public void setGlobalSettingValue(String globalSettingValue) {
        this.globalSettingValue = globalSettingValue;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLocalSettingCode() {
        return localSettingCode;
    }

    public void setLocalSettingCode(String localSettingCode) {
        this.localSettingCode = localSettingCode;
    }

    
    
}
