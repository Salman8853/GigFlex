/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.repository;

import com.gigflex.prototype.microservices.setting.dtob.LocalSetting;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface LocalSettingRepository  extends JpaRepository<LocalSetting, Long>{
    
        @Query("SELECT l,g.settingName,g.settingValue FROM LocalSetting l,GlobalSetting g WHERE g.isDeleted != TRUE AND l.isDeleted != TRUE AND g.globalSettingCode=l.globalSettingCode")
	public List<Object> getAllLocalSetting();
	
	@Query("SELECT l,g.settingName,g.settingValue FROM LocalSetting l,GlobalSetting g WHERE g.isDeleted != TRUE AND l.isDeleted != TRUE AND g.globalSettingCode=l.globalSettingCode")
	public List<Object> getAllLocalSetting(Pageable pageableRequest);
        
        @Query("SELECT l,g.settingName,g.settingValue FROM LocalSetting l,GlobalSetting g WHERE g.isDeleted != TRUE AND l.isDeleted != TRUE AND g.globalSettingCode=l.globalSettingCode AND l.userCode= :userCode")
	public List<Object> getAllLocalSettingByUserCode(@Param("userCode") String userCode);
	
	@Query("SELECT l,g.settingName,g.settingValue FROM LocalSetting l,GlobalSetting g WHERE g.isDeleted != TRUE AND l.isDeleted != TRUE AND g.globalSettingCode=l.globalSettingCode AND l.userCode= :userCode")
	public List<Object> getAllLocalSettingByUserCode(@Param("userCode") String userCode,Pageable pageableRequest);
        
        @Query("SELECT g FROM LocalSetting g WHERE g.isDeleted != TRUE AND g.userCode= :userCode AND g.globalSettingCode= :globalSettingCode")
	public LocalSetting getLocalSettingByUserCodeGlobalSetingCode(@Param("userCode") String userCode,@Param("globalSettingCode") String globalSettingCode);
        
        @Query("SELECT g FROM LocalSetting g WHERE g.isDeleted != TRUE AND g.localSettingCode= :localSettingCode ")
	public LocalSetting getLocalSettingByLocalSettingCode(@Param("localSettingCode") String localSettingCode);
        
        @Query("SELECT l,g.settingName,g.settingValue FROM LocalSetting l,GlobalSetting g WHERE g.isDeleted != TRUE AND l.isDeleted != TRUE AND g.globalSettingCode=l.globalSettingCode AND l.localSettingCode= :localSettingCode ")
	public Object getLocalSettingByLocalSettingCodeWithMapping(@Param("localSettingCode") String localSettingCode);
       
        @Query("SELECT l,g.settingName,g.settingValue FROM LocalSetting l,GlobalSetting g WHERE g.isDeleted != TRUE AND l.isDeleted != TRUE AND g.globalSettingCode=l.globalSettingCode AND l.userCode= :userCode AND g.settingName= :settingName ")
	public Object getLocalSettingByUserCodeSettingName(@Param("userCode") String userCode,@Param("settingName") String settingName);
        
        @Query("SELECT l,g.settingName,g.settingValue FROM LocalSetting l,GlobalSetting g WHERE g.isDeleted != TRUE AND l.isDeleted != TRUE AND g.globalSettingCode=l.globalSettingCode AND l.userCode= :userCode AND l.globalSettingCode= :globalSettingCode ")
	public Object getLocalSettingByUserCodeGlobalSettingCode(@Param("userCode") String userCode,@Param("globalSettingCode") String globalSettingCode);
        
        @Query("SELECT l FROM LocalSetting l WHERE l.isDeleted != TRUE AND l.globalSettingCode= :globalSettingCode ")
	public List<LocalSetting> getLocalSettingByGlobalSettingCode(@Param("globalSettingCode") String globalSettingCode);
        
        @Query("SELECT g FROM LocalSetting g WHERE g.isDeleted != TRUE AND g.userCode= :userCode AND g.globalSettingCode= :globalSettingCode AND g.id!= :id")
	public LocalSetting getLocalSettingByUserCodeGlobalSetingCodeNotID(@Param("userCode") String userCode,@Param("globalSettingCode") String globalSettingCode,@Param("id") Long id);
        
	@Query("SELECT g FROM LocalSetting g WHERE g.isDeleted != TRUE AND g.id= :id")
	public LocalSetting getLocalSettingByID(@Param("id") Long id);
        
        @Query("SELECT l,g.settingName,g.settingValue FROM LocalSetting l,GlobalSetting g WHERE g.isDeleted != TRUE AND l.isDeleted != TRUE AND g.globalSettingCode=l.globalSettingCode AND l.userCode= :userCode AND l.settingType= :settingType ")
	public List<Object> getLocalSettingByUserTypeSettingType(@Param("userCode") String userCode,@Param("settingType") String settingType);
        
        @Query("SELECT l,g FROM GlobalSetting g  LEFT JOIN LocalSetting l ON g.globalSettingCode=l.globalSettingCode WHERE g.isDeleted != TRUE  AND (l.userCode= :userCode OR l.userCode IS NULL ) AND g.settingType= :settingType ")
        public List<Object> getAllLocalSettingWithDefaultGlobalSettingByUserCode(@Param("userCode") String userCode,@Param("settingType") String settingType);
}
