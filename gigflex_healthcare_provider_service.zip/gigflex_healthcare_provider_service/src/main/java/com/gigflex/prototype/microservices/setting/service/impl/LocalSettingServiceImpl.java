/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.service.impl;
import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.setting.dtob.GlobalSetting;
import com.gigflex.prototype.microservices.setting.dtob.LocalSetting;
import com.gigflex.prototype.microservices.setting.dtob.LocalSettingReq;
import com.gigflex.prototype.microservices.setting.dtob.LocalSettingResponse;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.service.LocalSettingService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.workpreferedshift.dtob.WorkerPreferdShift;
import com.gigflex.prototype.microservices.workpreferedshift.repository.WorkerPreferdShiftRepository;
import java.util.ArrayList;
import java.util.Date;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
/**
 *
 * @author nirbhay.p
 */
@Service
public class LocalSettingServiceImpl implements LocalSettingService{

    @Autowired
    LocalSettingRepository localSettingRepository;
    @Autowired
    GlobalSettingRepository globalSettingRepository;
    @Autowired
    UserTypeRepository userTypeRepository;
    @Autowired
    OrganizationRepository organizationRepository;
    @Autowired
    WorkerPreferdShiftRepository preferdShiftRepository;
    @Override
    public String getAllLocalSettingByPage(int page, int limit) {
        
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);
                        List<LocalSettingResponse> gslst =new ArrayList<LocalSettingResponse>();
			List<Object> objlst = localSettingRepository.getAllLocalSetting(pageableRequest);
                        int count=0;
                        List<Object> cntlst = localSettingRepository.getAllLocalSetting();
                        if(cntlst!=null)
                        {
                        count=cntlst.size();
                        }
                        
                        if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
				Object[] arr = (Object[]) objlst.get(i);
                                    if (arr.length >= 3) {
                                        LocalSettingResponse lsr=new LocalSettingResponse();
                                        LocalSetting ls=(LocalSetting) arr[0];
                                        if(ls!=null && ls.getId()>0)
                                        {
                                            lsr.setGlobalSettingCode(ls.getGlobalSettingCode());
                                            lsr.setId(ls.getId());
                                            lsr.setSettingType(ls.getSettingType());
                                            lsr.setLocalSettingCode(ls.getLocalSettingCode());
                                            lsr.setLocalSettingValue(ls.getLocalSettingValue());
                                            lsr.setUserCode(ls.getUserCode());
                                            lsr.setGlobalSettingName((String) arr[1]);
                                            lsr.setGlobalSettingValue((String) arr[2]);
                                            gslst.add(lsr);
                                        }
                                    }
                                }
                        }
			if (gslst != null && gslst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(gslst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    
    }

    @Override
    public String getLocalSettingByUserCodeByPage(String userCode, int page, int limit) {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);
                        List<LocalSettingResponse> gslst =new ArrayList<LocalSettingResponse>();
			List<Object> objlst = localSettingRepository.getAllLocalSettingByUserCode(userCode,pageableRequest);
                        int count=0;
                        List<Object> cntlst = localSettingRepository.getAllLocalSettingByUserCode(userCode);
                        if(cntlst!=null)
                        {
                        count=cntlst.size();
                        }
                        
                        if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
				Object[] arr = (Object[]) objlst.get(i);
                                    if (arr.length >= 3) {
                                        LocalSettingResponse lsr=new LocalSettingResponse();
                                        LocalSetting ls=(LocalSetting) arr[0];
                                        if(ls!=null && ls.getId()>0)
                                        {
                                            lsr.setGlobalSettingCode(ls.getGlobalSettingCode());
                                            lsr.setId(ls.getId());
                                            lsr.setSettingType(ls.getSettingType());
                                            lsr.setLocalSettingCode(ls.getLocalSettingCode());
                                            lsr.setLocalSettingValue(ls.getLocalSettingValue());
                                            lsr.setUserCode(ls.getUserCode());
                                            lsr.setGlobalSettingName((String) arr[1]);
                                            lsr.setGlobalSettingValue((String) arr[2]);
                                            gslst.add(lsr);
                                        }
                                    }
                                }
                        }
			if (gslst != null && gslst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(gslst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String saveLocalSetting(LocalSettingReq localSettingReq, String ip) {
        
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        GlobalSetting gsett=globalSettingRepository.getGlobalSettingBySettingCode(localSettingReq.getGlobalSettingCode());
                        if(gsett!=null && gsett.getId()>0)
                        {
					LocalSetting gs = localSettingRepository.getLocalSettingByUserCodeGlobalSetingCode(localSettingReq.getUserCode(),localSettingReq.getGlobalSettingCode());

					if (gs != null && gs.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "This Local Setting already exists");
					} else {
						LocalSetting lset = new LocalSetting();

						lset.setGlobalSettingCode(localSettingReq.getGlobalSettingCode());
                                                lset.setLocalSettingValue(localSettingReq.getLocalSettingValue());
                                                lset.setUserCode(localSettingReq.getUserCode());
						lset.setIpAddress(ip);
                                                lset.setSettingType(localSettingReq.getSettingType());

						LocalSetting lsetRes = localSettingRepository.save(lset);

						

						if (lsetRes != null && lsetRes.getId() > 0) {
                                                    jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Local Setting has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(lsetRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
                                                    jsonobj.put("responsecode", 400);
                                                    jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
						}
					}
                        }
                        else
                        {
                            jsonobj.put("responsecode", 400);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Global Setting Code does not exist.");
                        }
				
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	
    
    }

    @Override
    public String updateLocalSettingById(LocalSettingReq localSettingReq, Long id, String ip) {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        GlobalSetting gsett=globalSettingRepository.getGlobalSettingBySettingCode(localSettingReq.getGlobalSettingCode());
                        if(gsett!=null && gsett.getId()>0)
                        {
                           LocalSetting lset= localSettingRepository.getLocalSettingByID(id);
                            if (lset != null && lset.getId() > 0) {
                            LocalSetting gs = localSettingRepository.getLocalSettingByUserCodeGlobalSetingCodeNotID(localSettingReq.getUserCode(),localSettingReq.getGlobalSettingCode(),id);

					if (gs != null && gs.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "This Local Setting already exists");
					} else {
						
						lset.setGlobalSettingCode(localSettingReq.getGlobalSettingCode());
                                                lset.setLocalSettingValue(localSettingReq.getLocalSettingValue());
                                                lset.setUserCode(localSettingReq.getUserCode());
						lset.setIpAddress(ip);
                                                lset.setSettingType(localSettingReq.getSettingType());
						LocalSetting lsetRes = localSettingRepository.save(lset);

						

						if (lsetRes != null && lsetRes.getId() > 0) {
                                                    jsonobj.put("responsecode", 200);
                                                    jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Local Setting has been updated successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(lsetRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
                                                    jsonobj.put("responsecode", 400);
                                                    jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
						}
					}
                                        }
                        else
                        {
                            jsonobj.put("responsecode", 400);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Id does not exist.");
                        }
                        }
                        else
                        {
                            jsonobj.put("responsecode", 400);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Global Setting Code does not exist.");
                        }
				
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String getLocalSettingByLocalSettingCode(String localSettingCode) {
        
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        Object obj = localSettingRepository.getLocalSettingByLocalSettingCodeWithMapping(localSettingCode);
                         LocalSettingResponse lsr=null;
                        if (obj!=null) {
				Object[] arr = (Object[]) obj;
                                    if (arr.length >= 3) {
                                       lsr=new LocalSettingResponse();
                                        LocalSetting ls=(LocalSetting) arr[0];
                                        if(ls!=null && ls.getId()>0)
                                        {
                                            lsr.setGlobalSettingCode(ls.getGlobalSettingCode());
                                            lsr.setId(ls.getId());
                                            lsr.setSettingType(ls.getSettingType());
                                            lsr.setLocalSettingCode(ls.getLocalSettingCode());
                                            lsr.setLocalSettingValue(ls.getLocalSettingValue());
                                            lsr.setUserCode(ls.getUserCode());
                                            lsr.setGlobalSettingName((String) arr[1]);
                                            lsr.setGlobalSettingValue((String) arr[2]);
                                            
                                        }
                                    }
                                }
                        
                        
                        
			if (lsr != null && lsr.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(lsr);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
   
    }

    @Override
    public String softDeleteLocalSettingByLocalSettingCode(String localSettingCode) {
       
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			 LocalSetting gs = localSettingRepository.getLocalSettingByLocalSettingCode(localSettingCode);
			

			if (gs != null && gs.getId() > 0) {
				gs.setIsDeleted(true);
				LocalSetting gsRes = localSettingRepository.save(gs);
				if (gsRes != null && gsRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					jsonobj.put("message",
							"Local Setting deleted successfully.");

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
    
    }

    @Override
    public String softMultipleDeleteLocalSettingByLocalSettingCode(List<String> localSettingCodeList) {
       
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String localSettingCode : localSettingCodeList) {
				if (localSettingCode != null && localSettingCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					 LocalSetting gs = localSettingRepository.getLocalSettingByLocalSettingCode(localSettingCode);
					

					if (gs != null && gs.getId() > 0) {
						gs.setIsDeleted(true);
						LocalSetting gsRes = localSettingRepository.save(gs);
						if (gsRes != null && gsRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
                                                        jsonobj.put("localSettingCode", localSettingCode);
							jsonobj.put("message",
									"Local Setting deleted successfully.");

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("localSettingCode", localSettingCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("localSettingCode", localSettingCode);
						jsonobj.put("message", "Record Not Found");
					}

					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String getLocalSettingByUserCodeSettingName(String userCode, String settingName) {
         
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        Object obj = localSettingRepository.getLocalSettingByUserCodeSettingName(userCode,settingName);
                         LocalSettingResponse lsr=null;
                        if (obj!=null) {
				Object[] arr = (Object[]) obj;
                                    if (arr.length >= 3) {
                                       lsr=new LocalSettingResponse();
                                        LocalSetting ls=(LocalSetting) arr[0];
                                        if(ls!=null && ls.getId()>0)
                                        {
                                            lsr.setGlobalSettingCode(ls.getGlobalSettingCode());
                                            lsr.setId(ls.getId());
                                            lsr.setSettingType(ls.getSettingType());
                                            lsr.setLocalSettingCode(ls.getLocalSettingCode());
                                            lsr.setLocalSettingValue(ls.getLocalSettingValue());
                                            lsr.setUserCode(ls.getUserCode());
                                            lsr.setGlobalSettingName((String) arr[1]);
                                            lsr.setGlobalSettingValue((String) arr[2]);
                                            
                                        }
                                    }
                                }
                        
                        
                        
			if (lsr != null && lsr.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(lsr);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
   
    
    }

    @Override
    public String getLocalSettingByUserCodeGlobalSettingCode(String userCode, String globalSettingCode) {
         
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        Object obj = localSettingRepository.getLocalSettingByUserCodeGlobalSettingCode(userCode,globalSettingCode);
                         LocalSettingResponse lsr=null;
                        if (obj!=null) {
				Object[] arr = (Object[]) obj;
                                    if (arr.length >= 3) {
                                       lsr=new LocalSettingResponse();
                                        LocalSetting ls=(LocalSetting) arr[0];
                                        if(ls!=null && ls.getId()>0)
                                        {
                                            lsr.setGlobalSettingCode(ls.getGlobalSettingCode());
                                            lsr.setId(ls.getId());
                                            lsr.setSettingType(ls.getSettingType());
                                            lsr.setLocalSettingCode(ls.getLocalSettingCode());
                                            lsr.setLocalSettingValue(ls.getLocalSettingValue());
                                            lsr.setUserCode(ls.getUserCode());
                                            lsr.setGlobalSettingName((String) arr[1]);
                                            lsr.setGlobalSettingValue((String) arr[2]);
                                            
                                        }
                                    }
                                }
                        
                        
                        
			if (lsr != null && lsr.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(lsr);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
   
    
    }

    @Override
    public String getLocalSettingByUserTypeSettingType(String userTypeCode, String settingType) {
           
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        List<LocalSettingResponse> gslst =new ArrayList<LocalSettingResponse>();
                        List<Object> objlst = localSettingRepository.getLocalSettingByUserTypeSettingType(userTypeCode,settingType);
                        
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
				Object[] arr = (Object[]) objlst.get(i);
                                    if (arr.length >= 3) {
                                        LocalSettingResponse lsr=new LocalSettingResponse();
                                        LocalSetting ls=(LocalSetting) arr[0];
                                        if(ls!=null && ls.getId()>0)
                                        {
                                            lsr.setGlobalSettingCode(ls.getGlobalSettingCode());
                                            lsr.setId(ls.getId());
                                            lsr.setSettingType(ls.getSettingType());
                                            lsr.setLocalSettingCode(ls.getLocalSettingCode());
                                            lsr.setLocalSettingValue(ls.getLocalSettingValue());
                                            lsr.setUserCode(ls.getUserCode());
                                            lsr.setGlobalSettingName((String) arr[1]);
                                            lsr.setGlobalSettingValue((String) arr[2]);
                                            gslst.add(lsr);
                                        }
                                    }
                                }
                        }
			if (gslst != null && gslst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(gslst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    
    }

    @Override
    public String getAllLocalSettingWithDefaultGlobalSettingByUserCode(String userCode) {
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        JSONArray jarr = new JSONArray();
                        String userType="";
                        Organization org=organizationRepository.findByOrganizationCode(userCode);
                        if(org!=null && org.getId()>0)
                        {
                            UserType ut=userTypeRepository.getUserTypeByUserTypeName("HealthcareProvider");
                            if(ut!=null && ut.getId()>0)
                            {
                                userType=ut.getUserTypeCode();
                            }
                        }
                        else
                        {
                            UserType ut=userTypeRepository.getUserTypeByUserTypeName("HealthcareTechnician");
                            if(ut!=null && ut.getId()>0)
                            {
                                userType=ut.getUserTypeCode();
                            }
                        }
                        
                        if(userType!=null && userType.length()>0)
                        {
                            List<String> settype= globalSettingRepository.getAllSettingTypeByUserType(userType);
                            if(settype!=null && settype.size()>0)
                            {
                                for(String set:settype)
                                {
                                    List<LocalSettingResponse> gslst=new ArrayList<LocalSettingResponse>();
                                    List<GlobalSetting> gslist=globalSettingRepository.getGlobalSettingByUserTypeSettingType(userType, set);
                                    for(GlobalSetting gs:gslist)
                                    {
                                         LocalSettingResponse lsr=new LocalSettingResponse();
                                        LocalSetting ls= localSettingRepository.getLocalSettingByUserCodeGlobalSetingCode(userCode, gs.getGlobalSettingCode());
                                        lsr.setGlobalSettingCode(gs.getGlobalSettingCode());
                                            lsr.setGlobalSettingName(gs.getSettingName());
                                            lsr.setGlobalSettingValue(gs.getSettingValue());
                                            lsr.setSettingType(gs.getSettingType());
                                            
                                            if(ls!=null && ls.getId()>0)
                                            {
                                            lsr.setId(ls.getId());
                                            lsr.setLocalSettingCode(ls.getLocalSettingCode());
                                            lsr.setLocalSettingValue(ls.getLocalSettingValue());
                                            lsr.setUserCode(ls.getUserCode());
                                            }
                                            
                                            gslst.add(lsr);
                                    }
                                    
//                                    
//                                    
//                                    
//                                    List<Object> objlst=localSettingRepository.getAllLocalSettingWithDefaultGlobalSettingByUserCode(userCode,set);
//                                    if (objlst != null && objlst.size() > 0) {
//				for (int i = 0; i < objlst.size(); i++) {
//				Object[] arr = (Object[]) objlst.get(i);
//                                    if (arr.length >= 2) {
//                                        LocalSettingResponse lsr=new LocalSettingResponse();
//                                        LocalSetting ls=(LocalSetting) arr[0];
//                                        GlobalSetting gs=(GlobalSetting) arr[1];
//                                            
//                                            lsr.setGlobalSettingCode(gs.getGlobalSettingCode());
//                                            lsr.setGlobalSettingName(gs.getSettingName());
//                                            lsr.setGlobalSettingValue(gs.getSettingValue());
//                                            lsr.setSettingType(gs.getSettingType());
//                                            
//                                            if(ls!=null && ls.getId()>0)
//                                            {
//                                            lsr.setId(ls.getId());
//                                            lsr.setLocalSettingCode(ls.getLocalSettingCode());
//                                            lsr.setLocalSettingValue(ls.getLocalSettingValue());
//                                            lsr.setUserCode(ls.getUserCode());
//                                            }
//                                            
//                                            gslst.add(lsr);
//                                        
//                                    }
//                                }
//                        }                                    
                                JSONObject job=new JSONObject();
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(gslst);
				job.put(set, new JSONArray(Detail));
                                jarr.add(job);
                                    
                                }
                            }
                            if(jarr!=null && jarr.size()>0)
                            {
                               jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("data", jarr);
                            }
                            else
                            {
                                jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                            }
                        }
                        else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                        
			res = jsonobj.toString();
                        
                }catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String updateSettingByUserCode(String userCode, List<LocalSettingResponse> locsetlst, String ip) {
        String res = "";
		try {
                    JSONObject jsonobj = new JSONObject();
                    for(LocalSettingResponse tsr:locsetlst)
                    {
//                        if(tsr.getLocalSettingCode()!=null && tsr.getLocalSettingCode().trim().length()>0)
//                        {
//                           LocalSetting ls= localSettingRepository.getLocalSettingByLocalSettingCode(tsr.getLocalSettingCode().trim());
                        LocalSetting ls = localSettingRepository.getLocalSettingByUserCodeGlobalSetingCode(userCode,tsr.getGlobalSettingCode());
                        if(ls!=null && ls.getId()>0)
                        {
                            ls.setLocalSettingValue(tsr.getLocalSettingValue());
                            ls.setIpAddress(ip);
                            localSettingRepository.save(ls);
                            continue;
                        }
//                        }
                        
                        LocalSetting lset=new LocalSetting();
                        lset.setGlobalSettingCode(tsr.getGlobalSettingCode());
                        lset.setIpAddress(ip);
                        lset.setLocalSettingValue(tsr.getLocalSettingValue());
                        lset.setSettingType(tsr.getSettingType());
                        lset.setUserCode(userCode);
                        localSettingRepository.save(lset);
                    }
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("message", "Success");
                    jsonobj.put("timestamp", new Date());
                    
                    res = jsonobj.toString();
                }catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String checkOrganizationSetting(String userCode) {
        
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                      
			
                        List<Object> cntlst = localSettingRepository.getAllLocalSettingByUserCode(userCode);
                        if(cntlst!=null && cntlst.size()>0)
                        {
                        
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Setting Found");
				jsonobj.put("timestamp", new Date());
                                JSONObject jobj = new JSONObject();
                                jobj.put("settingExist", Boolean.TRUE);
				jsonobj.put("data",jobj);
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Setting Not Found");
				jsonobj.put("timestamp", new Date());
                                JSONObject jobj = new JSONObject();
                                jobj.put("settingExist", Boolean.FALSE);
				jsonobj.put("data",jobj);
			}
                        
			res = jsonobj.toString();
		} catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    
    }

    @Override
    public String checkWorkerSetting(String workerCode) {
        
        
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                      
			
                        List<WorkerPreferdShift> wps = preferdShiftRepository.getWorkerPreferdShift(workerCode);
                        if(wps!=null && wps.size() >0)
                        {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Setting Found");
				jsonobj.put("timestamp", new Date());
                                JSONObject jobj = new JSONObject();
                                jobj.put("settingExist", Boolean.TRUE);
				jsonobj.put("data",jobj);
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Setting Not Found");
				jsonobj.put("timestamp", new Date());
                                JSONObject jobj = new JSONObject();
                                jobj.put("settingExist", Boolean.FALSE);
				jsonobj.put("data",jobj);
			}
                        
			res = jsonobj.toString();
		} catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
    
    }
    @Override
    public String getTimeslotByorganisationCode(String orgCode)
    {
        String res = "";
		try {
			JSONArray jarr = new JSONArray();
                        JSONObject jsonobj = new JSONObject();
        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.HealthcareProvider, orgCode, GigflexConstants.TIMEFORMAT);
      //String timeformat="HH:mm:ss";
        if(timeformat==null || timeformat.length()==0)
        { 
            timeformat=GigflexConstants.HH_MM_SS;
            
         }
            
        if(timeformat.equals("HH:mm:ss") || timeformat.equals("HH:mm"))
        {
             JSONObject j1 = new JSONObject();
           j1.put("text", "00:00");
           j1.put("value","00:00:00");
              jarr.add(j1);
          JSONObject j2 = new JSONObject();
           j2.put("text", "00:15");
           j2.put("value","00:15:00");           
           jarr.add(j2);
           JSONObject j3 = new JSONObject();
           j3.put("text", "00:30");
           j3.put("value","00:30:00");           
           jarr.add(j3);  
          JSONObject j4 = new JSONObject();
           j4.put("text", "00:45");
           j4.put("value","00:45:00");           
           jarr.add(j4);    
          JSONObject j5 = new JSONObject();
           j5.put("text", "01:00");
           j5.put("value","01:00:00");           
           jarr.add(j5); 
             JSONObject j6 = new JSONObject();
           j6.put("text", "01:15");
           j6.put("value","01:15:00");
              jarr.add(j6);
          JSONObject j7 = new JSONObject();
           j7.put("text", "01:30");
           j7.put("value","01:30:00");           
           jarr.add(j7);
           JSONObject j8 = new JSONObject();
           j8.put("text", "01:45");
           j8.put("value","01:45:00");           
           jarr.add(j8);  
          JSONObject j9 = new JSONObject();
           j9.put("text", "02:00");
           j9.put("value","02:00:00");           
           jarr.add(j9);    
          JSONObject j10 = new JSONObject();
           j10.put("text", "02:15");
           j10.put("value","02:15:00");
            jarr.add(j10); 
           JSONObject j11 = new JSONObject();
           j11.put("text", "02:30");
           j11.put("value","02:30:00"); 
           jarr.add(j11); 
           JSONObject j12 = new JSONObject();
           j12.put("text", "02:45");
           j12.put("value","02:45:00"); 
           jarr.add(j12); 
           JSONObject j13 = new JSONObject();
           j13.put("text", "03:00");
           j13.put("value","03:00:00"); 
           jarr.add(j13); 
           JSONObject j14 = new JSONObject();
           j14.put("text", "03:15");
           j14.put("value","03:15:00"); 
           jarr.add(j14); 
           JSONObject j15 = new JSONObject();
           j15.put("text", "03:30");
           j15.put("value","03:30:00"); 
           jarr.add(j15); 
           JSONObject j16 = new JSONObject();
           j16.put("text", "03:45");
           j16.put("value","03:45:00"); 
           jarr.add(j16);
           JSONObject j17 = new JSONObject();
           j17.put("text", "04:00");
           j17.put("value","04:00:00"); 
           jarr.add(j17);
           JSONObject j18 = new JSONObject();
           j18.put("text", "04:15");
           j18.put("value","04:15:00"); 
           jarr.add(j18);
           JSONObject j19 = new JSONObject();
           j19.put("text", "04:30");
           j19.put("value","04:30:00"); 
           jarr.add(j19);
           JSONObject j20 = new JSONObject();
           j20.put("text", "04:45");
           j20.put("value","04:45:00"); 
           jarr.add(j20);
            JSONObject j21 = new JSONObject();
           j21.put("text", "05:00");
           j21.put("value","05:00:00");
              jarr.add(j21);
          JSONObject j22 = new JSONObject();
           j22.put("text", "05:15");
           j22.put("value","05:15:00");           
           jarr.add(j22);
           JSONObject j23 = new JSONObject();
           j23.put("text", "05:30");
           j23.put("value","05:30:00");           
           jarr.add(j23);  
          JSONObject j24 = new JSONObject();
           j24.put("text", "05:45");
           j24.put("value","05:45:00");           
           jarr.add(j24);    
          JSONObject j25 = new JSONObject();
           j25.put("text", "06:00");
           j25.put("value","06:00:00");           
           jarr.add(j25); 
           JSONObject j26 = new JSONObject();
           j26.put("text", "06:15");
           j26.put("value","06:15:00");
              jarr.add(j26);
          JSONObject j27 = new JSONObject();
           j27.put("text", "06:30");
           j27.put("value","06:30:00");           
           jarr.add(j27);
           JSONObject j28 = new JSONObject();
           j28.put("text", "06:45");
           j28.put("value","06:45:00");           
           jarr.add(j28);  
          JSONObject j29 = new JSONObject();
           j29.put("text", "07:00");
           j29.put("value","07:00:00");           
           jarr.add(j29);    
          JSONObject j30 = new JSONObject();
           j30.put("text", "07:15");
           j30.put("value","07:15:00");
            jarr.add(j30); 
           JSONObject j31 = new JSONObject();
           j31.put("text", "07:30");
           j31.put("value","07:30:00"); 
           jarr.add(j31); 
           JSONObject j32 = new JSONObject();
           j32.put("text", "07:45");
           j32.put("value","07:45:00"); 
           jarr.add(j32); 
           JSONObject j33 = new JSONObject();
           j33.put("text", "08:00");
           j33.put("value","08:00:00"); 
           jarr.add(j33); 
           JSONObject j34 = new JSONObject();
           j34.put("text", "08:15");
           j34.put("value","08:15:00"); 
           jarr.add(j34); 
           JSONObject j35 = new JSONObject();
           j35.put("text", "08:30");
           j35.put("value","08:30:00"); 
           jarr.add(j35); 
           JSONObject j36 = new JSONObject();
           j36.put("text", "08:45");
           j36.put("value","08:45:00"); 
           jarr.add(j36);
           JSONObject j37 = new JSONObject();
           j37.put("text", "09:00");
           j37.put("value","09:00:00"); 
           jarr.add(j37);
           JSONObject j38 = new JSONObject();
           j38.put("text", "09:15");
           j38.put("value","09:15:00"); 
           jarr.add(j38);
           JSONObject j39 = new JSONObject();
           j39.put("text", "09:30");
           j39.put("value","09:30:00"); 
           jarr.add(j39);
           JSONObject j40 = new JSONObject();
           j40.put("text", "09:45");
           j40.put("value","09:45:00"); 
           jarr.add(j40);
            JSONObject j41 = new JSONObject();
           j41.put("text", "10:00");
           j41.put("value","10:00:00");
              jarr.add(j41);
          JSONObject j42 = new JSONObject();
           j42.put("text", "10:15");
           j42.put("value","10:15:00");           
           jarr.add(j42);
           JSONObject j43 = new JSONObject();
           j43.put("text", "10:30");
           j43.put("value","10:30:00");           
           jarr.add(j43);  
          JSONObject j44 = new JSONObject();
           j44.put("text", "10:45");
           j44.put("value","10:45:00");           
           jarr.add(j44);    
          JSONObject j45 = new JSONObject();
           j45.put("text", "11:00");
           j45.put("value","11:00:00");           
           jarr.add(j45); 
             JSONObject j46 = new JSONObject();
           j46.put("text", "11:15");
           j46.put("value","11:15:00");
              jarr.add(j46);
          JSONObject j47 = new JSONObject();
           j47.put("text", "11:30");
           j47.put("value","11:30:00");           
           jarr.add(j47);
           JSONObject j48 = new JSONObject();
           j48.put("text", "11:45");
           j48.put("value","11:45:00");           
           jarr.add(j48);  
          JSONObject j49 = new JSONObject();
           j49.put("text", "12:00");
           j49.put("value","12:00:00");           
           jarr.add(j49);    
          JSONObject j50 = new JSONObject();
           j50.put("text", "12:15");
           j50.put("value","12:15:00");
            jarr.add(j50); 
           JSONObject j51 = new JSONObject();
           j51.put("text", "12:30");
           j51.put("value","12:30:00"); 
           jarr.add(j51); 
           JSONObject j52 = new JSONObject();
           j52.put("text", "12:45");
           j52.put("value","12:45:00"); 
           jarr.add(j52); 
           JSONObject j53 = new JSONObject();
           j53.put("text", "13:00");
           j53.put("value","13:00:00"); 
           jarr.add(j53); 
           JSONObject j54 = new JSONObject();
           j54.put("text", "13:15");
           j54.put("value","13:15:00"); 
           jarr.add(j54); 
           JSONObject j55 = new JSONObject();
           j55.put("text", "13:30");
           j55.put("value","13:30:00"); 
           jarr.add(j55); 
           JSONObject j56 = new JSONObject();
           j56.put("text", "13:45");
           j56.put("value","13:45:00"); 
           jarr.add(j56);
           JSONObject j57 = new JSONObject();
           j57.put("text", "14:00");
           j57.put("value","14:00:00"); 
           jarr.add(j57);
           JSONObject j58 = new JSONObject();
           j58.put("text", "14:15");
           j58.put("value","14:15:00"); 
           jarr.add(j58);
           JSONObject j59 = new JSONObject();
           j59.put("text", "14:30");
           j59.put("value","14:30:00"); 
           jarr.add(j59);
           JSONObject j60 = new JSONObject();
           j60.put("text", "14:45");
           j60.put("value","14:45:00"); 
           jarr.add(j60);
            JSONObject j61 = new JSONObject();
           j61.put("text", "15:00");
           j61.put("value","15:00:00");
              jarr.add(j61);
          JSONObject j62 = new JSONObject();
           j62.put("text", "15:15");
           j62.put("value","15:15:00");           
           jarr.add(j62);
           JSONObject j63 = new JSONObject();
           j63.put("text", "15:30");
           j63.put("value","15:30:00");           
           jarr.add(j63);  
          JSONObject j64 = new JSONObject();
           j64.put("text", "15:45");
           j64.put("value","15:45:00");           
           jarr.add(j64);    
          JSONObject j65 = new JSONObject();
           j65.put("text", "16:00");
           j65.put("value","16:00:00");           
           jarr.add(j65); 
             JSONObject j66 = new JSONObject();
           j66.put("text", "16:15");
           j66.put("value","16:15:00");
              jarr.add(j66);
          JSONObject j67 = new JSONObject();
           j67.put("text", "16:30");
           j67.put("value","16:30:00");           
           jarr.add(j67);
           JSONObject j68 = new JSONObject();
           j68.put("text", "16:45");
           j68.put("value","16:45:00");           
           jarr.add(j68);  
          JSONObject j69 = new JSONObject();
           j69.put("text", "17:00");
           j69.put("value","17:00:00");           
           jarr.add(j69);    
          JSONObject j70 = new JSONObject();
           j70.put("text", "17:15");
           j70.put("value","17:15:00");
            jarr.add(j70); 
           JSONObject j71 = new JSONObject();
           j71.put("text", "17:30");
           j71.put("value","17:30:00"); 
           jarr.add(j71); 
           JSONObject j72 = new JSONObject();
           j72.put("text", "17:45");
           j72.put("value","17:45:00"); 
           jarr.add(j72); 
           JSONObject j74 = new JSONObject();
           j74.put("text", "18:00");
           j74.put("value","18:00:00"); 
           jarr.add(j74); 
           JSONObject j75 = new JSONObject();
           j75.put("text", "18:15");
           j75.put("value","18:15:00"); 
           jarr.add(j75); 
           JSONObject j76 = new JSONObject();
           j76.put("text", "18:30");
           j76.put("value","18:30:00"); 
           jarr.add(j76);
           JSONObject j77 = new JSONObject();
           j77.put("text", "18:45");
           j77.put("value","18:45:00"); 
           jarr.add(j77);
           JSONObject j78 = new JSONObject();
           j78.put("text", "19:00");
           j78.put("value","19:00:00"); 
           jarr.add(j78);
           JSONObject j79 = new JSONObject();
           j79.put("text", "19:15");
           j79.put("value","19:15:00"); 
           jarr.add(j79);
           JSONObject j80 = new JSONObject();
           j80.put("text", "19:30");
           j80.put("value","19:30:00"); 
           jarr.add(j80); 
           JSONObject j81 = new JSONObject();
           j81.put("text", "19:45");
           j81.put("value","19:45:00"); 
           jarr.add(j81);
           JSONObject j82 = new JSONObject();
           j82.put("text", "20:00");
           j82.put("value","20:00:00"); 
           jarr.add(j82);
            JSONObject j83 = new JSONObject();
           j83.put("text", "20:15");
           j83.put("value","20:15:00");
              jarr.add(j83);
          JSONObject j84 = new JSONObject();
           j84.put("text", "20:30");
           j84.put("value","20:30:00");           
           jarr.add(j84);
           JSONObject j85 = new JSONObject();
           j85.put("text", "20:45");
           j85.put("value","20:45:00");           
           jarr.add(j85);  
          JSONObject j86 = new JSONObject();
           j86.put("text", "21:00");
           j86.put("value","21:00:00");           
           jarr.add(j86);    
          JSONObject j87 = new JSONObject();
           j87.put("text", "21:15");
           j87.put("value","21:15:00");           
           jarr.add(j87); 
             JSONObject j88 = new JSONObject();
           j88.put("text", "21:30");
           j88.put("value","21:30:00");
              jarr.add(j88);
          JSONObject j89 = new JSONObject();
           j89.put("text", "21:45");
           j89.put("value","21:45:00");           
           jarr.add(j89);
           JSONObject j90 = new JSONObject();
           j90.put("text", "22:00");
           j90.put("value","22:00:00");           
           jarr.add(j90);  
          JSONObject j91 = new JSONObject();
           j91.put("text", "22:15");
           j91.put("value","22:15:00");           
           jarr.add(j91);    
          JSONObject j92 = new JSONObject();
           j92.put("text", "22:30");
           j92.put("value","22:30:00");
            jarr.add(j92); 
           JSONObject j93 = new JSONObject();
           j93.put("text", "22:45");
           j93.put("value","22:45:00"); 
           jarr.add(j93); 
           JSONObject j94 = new JSONObject();
           j94.put("text", "23:00");
           j94.put("value","23:00:00"); 
           jarr.add(j94); 
           JSONObject j95 = new JSONObject();
           j95.put("text", "23:15");
           j95.put("value","23:15:00"); 
           jarr.add(j95); 
           JSONObject j96 = new JSONObject();
           j96.put("text", "23:30");
           j96.put("value","23:30:00"); 
           jarr.add(j96); 
           JSONObject j97 = new JSONObject();
           j97.put("text", "23:45");
           j97.put("value","23:45:00"); 
           jarr.add(j97); 
           
           
        
                                jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Setting Found");
				jsonobj.put("timestamp", new Date());
                                jsonobj.put("data", jarr);
        }else if(timeformat.equals("hh:mm:ss a") || timeformat.equals("hh:mm a"))
        {
             JSONObject j1 = new JSONObject();
           j1.put("text", "12:00 AM");
           j1.put("value","00:00:00");
              jarr.add(j1);
          JSONObject j2 = new JSONObject();
           j2.put("text", "12:15 AM");
           j2.put("value","00:15:00");           
           jarr.add(j2);
           JSONObject j3 = new JSONObject();
           j3.put("text", "12:30 AM");
           j3.put("value","00:30:00");           
           jarr.add(j3);  
          JSONObject j4 = new JSONObject();
           j4.put("text", "12:45 AM");
           j4.put("value","00:45:00");           
           jarr.add(j4);    
          JSONObject j5 = new JSONObject();
           j5.put("text", "01:00 AM");
           j5.put("value","01:00:00");           
           jarr.add(j5); 
             JSONObject j6 = new JSONObject();
           j6.put("text", "01:15 AM");
           j6.put("value","01:15:00");
              jarr.add(j6);
          JSONObject j7 = new JSONObject();
           j7.put("text", "01:30 AM");
           j7.put("value","01:30:00");           
           jarr.add(j7);
           JSONObject j8 = new JSONObject();
           j8.put("text", "01:45 AM");
           j8.put("value","01:45:00");           
           jarr.add(j8);  
          JSONObject j9 = new JSONObject();
           j9.put("text", "02:00 AM");
           j9.put("value","02:00:00");           
           jarr.add(j9);    
          JSONObject j10 = new JSONObject();
           j10.put("text", "02:15 AM");
           j10.put("value","02:15:00");
            jarr.add(j10); 
           JSONObject j11 = new JSONObject();
           j11.put("text", "02:30 AM");
           j11.put("value","02:30:00"); 
           jarr.add(j11); 
           JSONObject j12 = new JSONObject();
           j12.put("text", "02:45 AM");
           j12.put("value","02:45:00"); 
           jarr.add(j12); 
           JSONObject j13 = new JSONObject();
           j13.put("text", "03:00 AM");
           j13.put("value","03:00:00"); 
           jarr.add(j13); 
           JSONObject j14 = new JSONObject();
           j14.put("text", "03:15 AM");
           j14.put("value","03:15:00"); 
           jarr.add(j14); 
           JSONObject j15 = new JSONObject();
           j15.put("text", "03:30 AM");
           j15.put("value","03:30:00"); 
           jarr.add(j15); 
           JSONObject j16 = new JSONObject();
           j16.put("text", "03:45 AM");
           j16.put("value","03:45:00"); 
           jarr.add(j16);
           JSONObject j17 = new JSONObject();
           j17.put("text", "04:00 AM");
           j17.put("value","04:00:00"); 
           jarr.add(j17);
           JSONObject j18 = new JSONObject();
           j18.put("text", "04:15 AM");
           j18.put("value","04:15:00"); 
           jarr.add(j18);
           JSONObject j19 = new JSONObject();
           j19.put("text", "04:30 AM");
           j19.put("value","04:30:00"); 
           jarr.add(j19);
           JSONObject j20 = new JSONObject();
           j20.put("text", "04:45 AM");
           j20.put("value","04:45:00"); 
           jarr.add(j20);
            JSONObject j21 = new JSONObject();
           j21.put("text", "05:00 AM");
           j21.put("value","05:00:00");
              jarr.add(j21);
          JSONObject j22 = new JSONObject();
           j22.put("text", "05:15 AM");
           j22.put("value","05:15:00");           
           jarr.add(j22);
           JSONObject j23 = new JSONObject();
           j23.put("text", "05:30 AM");
           j23.put("value","05:30:00");           
           jarr.add(j23);  
          JSONObject j24 = new JSONObject();
           j24.put("text", "05:45 AM");
           j24.put("value","05:45:00");           
           jarr.add(j24);    
          JSONObject j25 = new JSONObject();
           j25.put("text", "06:00 AM");
           j25.put("value","06:00:00");           
           jarr.add(j25); 
           JSONObject j26 = new JSONObject();
           j26.put("text", "06:15 AM");
           j26.put("value","06:15:00");
              jarr.add(j26);
          JSONObject j27 = new JSONObject();
           j27.put("text", "06:30 AM");
           j27.put("value","06:30:00");           
           jarr.add(j27);
           JSONObject j28 = new JSONObject();
           j28.put("text", "06:45 AM");
           j28.put("value","06:45:00");           
           jarr.add(j28);  
          JSONObject j29 = new JSONObject();
           j29.put("text", "07:00 AM");
           j29.put("value","07:00:00");           
           jarr.add(j29);    
          JSONObject j30 = new JSONObject();
           j30.put("text", "07:15 AM");
           j30.put("value","07:15:00");
            jarr.add(j30); 
           JSONObject j31 = new JSONObject();
           j31.put("text", "07:30 AM");
           j31.put("value","07:30:00"); 
           jarr.add(j31); 
           JSONObject j32 = new JSONObject();
           j32.put("text", "07:45 AM");
           j32.put("value","07:45:00"); 
           jarr.add(j32); 
           JSONObject j33 = new JSONObject();
           j33.put("text", "08:00 AM");
           j33.put("value","08:00:00"); 
           jarr.add(j33); 
           JSONObject j34 = new JSONObject();
           j34.put("text", "08:15 AM");
           j34.put("value","08:15:00"); 
           jarr.add(j34); 
           JSONObject j35 = new JSONObject();
           j35.put("text", "08:30 AM");
           j35.put("value","08:30:00"); 
           jarr.add(j35); 
           JSONObject j36 = new JSONObject();
           j36.put("text", "08:45 AM");
           j36.put("value","08:45:00"); 
           jarr.add(j36);
           JSONObject j37 = new JSONObject();
           j37.put("text", "09:00 AM");
           j37.put("value","09:00:00"); 
           jarr.add(j37);
           JSONObject j38 = new JSONObject();
           j38.put("text", "09:15 AM");
           j38.put("value","09:15:00"); 
           jarr.add(j38);
           JSONObject j39 = new JSONObject();
           j39.put("text", "09:30 AM");
           j39.put("value","09:30:00"); 
           jarr.add(j39);
           JSONObject j40 = new JSONObject();
           j40.put("text", "09:45 AM");
           j40.put("value","09:45:00"); 
           jarr.add(j40);
            JSONObject j41 = new JSONObject();
           j41.put("text", "10:00 AM");
           j41.put("value","10:00:00");
              jarr.add(j41);
          JSONObject j42 = new JSONObject();
           j42.put("text", "10:15 AM");
           j42.put("value","10:15:00");           
           jarr.add(j42);
           JSONObject j43 = new JSONObject();
           j43.put("text", "10:30 AM");
           j43.put("value","10:30:00");           
           jarr.add(j43);  
          JSONObject j44 = new JSONObject();
           j44.put("text", "10:45 AM");
           j44.put("value","10:45:00");           
           jarr.add(j44);    
          JSONObject j45 = new JSONObject();
           j45.put("text", "11:00 AM");
           j45.put("value","11:00:00");           
           jarr.add(j45); 
             JSONObject j46 = new JSONObject();
           j46.put("text", "11:15 AM");
           j46.put("value","11:15:00");
              jarr.add(j46);
          JSONObject j47 = new JSONObject();
           j47.put("text", "11:30 AM");
           j47.put("value","11:30:00");           
           jarr.add(j47);
           JSONObject j48 = new JSONObject();
           j48.put("text", "11:45 AM");
           j48.put("value","11:45:00");           
           jarr.add(j48);  
          JSONObject j49 = new JSONObject();
           j49.put("text", "12:00 PM");
           j49.put("value","12:00:00");           
           jarr.add(j49);    
          JSONObject j50 = new JSONObject();
           j50.put("text", "12:15 PM");
           j50.put("value","12:15:00");
            jarr.add(j50); 
           JSONObject j51 = new JSONObject();
           j51.put("text", "12:30 PM");
           j51.put("value","12:30:00"); 
           jarr.add(j51); 
           JSONObject j52 = new JSONObject();
           j52.put("text", "12:45 PM");
           j52.put("value","12:45:00"); 
           jarr.add(j52); 
           JSONObject j53 = new JSONObject();
           j53.put("text", "01:00 PM");
           j53.put("value","13:00:00"); 
           jarr.add(j53); 
           JSONObject j54 = new JSONObject();
           j54.put("text", "01:15 PM");
           j54.put("value","13:15:00"); 
           jarr.add(j54); 
           JSONObject j55 = new JSONObject();
           j55.put("text", "01:30 PM");
           j55.put("value","13:30:00"); 
           jarr.add(j55); 
           JSONObject j56 = new JSONObject();
           j56.put("text", "01:45 PM");
           j56.put("value","13:45:00"); 
           jarr.add(j56);
           JSONObject j57 = new JSONObject();
           j57.put("text", "02:00 PM");
           j57.put("value","14:00:00"); 
           jarr.add(j57);
           JSONObject j58 = new JSONObject();
           j58.put("text", "02:15 PM");
           j58.put("value","14:15:00"); 
           jarr.add(j58);
           JSONObject j59 = new JSONObject();
           j59.put("text", "02:30 PM");
           j59.put("value","14:30:00"); 
           jarr.add(j59);
           JSONObject j60 = new JSONObject();
           j60.put("text", "02:45 PM");
           j60.put("value","14:45:00"); 
           jarr.add(j60);
            JSONObject j61 = new JSONObject();
           j61.put("text", "03:00 PM");
           j61.put("value","15:00:00");
              jarr.add(j61);
          JSONObject j62 = new JSONObject();
           j62.put("text", "03:15 PM");
           j62.put("value","15:15:00");           
           jarr.add(j62);
           JSONObject j63 = new JSONObject();
           j63.put("text", "03:30 PM");
           j63.put("value","15:30:00");           
           jarr.add(j63);  
          JSONObject j64 = new JSONObject();
           j64.put("text", "03:45 PM");
           j64.put("value","15:45:00");           
           jarr.add(j64);    
          JSONObject j65 = new JSONObject();
           j65.put("text", "04:00 PM");
           j65.put("value","16:00:00");           
           jarr.add(j65); 
             JSONObject j66 = new JSONObject();
           j66.put("text", "04:15 PM");
           j66.put("value","16:15:00");
              jarr.add(j66);
          JSONObject j67 = new JSONObject();
           j67.put("text", "04:30 PM");
           j67.put("value","16:30:00");           
           jarr.add(j67);
           JSONObject j68 = new JSONObject();
           j68.put("text", "04:45 PM");
           j68.put("value","16:45:00");           
           jarr.add(j68);  
          JSONObject j69 = new JSONObject();
           j69.put("text", "05:00 PM");
           j69.put("value","17:00:00");           
           jarr.add(j69);    
          JSONObject j70 = new JSONObject();
           j70.put("text", "05:15 PM");
           j70.put("value","17:15:00");
            jarr.add(j70); 
           JSONObject j71 = new JSONObject();
           j71.put("text", "05:30 PM");
           j71.put("value","17:30:00"); 
           jarr.add(j71); 
           JSONObject j72 = new JSONObject();
           j72.put("text", "05:45 PM");
           j72.put("value","17:45:00"); 
           jarr.add(j72); 
           JSONObject j74 = new JSONObject();
           j74.put("text", "06:00 PM");
           j74.put("value","18:00:00"); 
           jarr.add(j74); 
           JSONObject j75 = new JSONObject();
           j75.put("text", "06:15 PM");
           j75.put("value","18:15:00"); 
           jarr.add(j75); 
           JSONObject j76 = new JSONObject();
           j76.put("text", "06:30 PM");
           j76.put("value","18:30:00"); 
           jarr.add(j76);
           JSONObject j77 = new JSONObject();
           j77.put("text", "06:45 PM");
           j77.put("value","18:45:00"); 
           jarr.add(j77);
           JSONObject j78 = new JSONObject();
           j78.put("text", "07:00 PM");
           j78.put("value","19:00:00"); 
           jarr.add(j78);
           JSONObject j79 = new JSONObject();
           j79.put("text", "07:15 PM");
           j79.put("value","19:15:00");
           jarr.add(j79);
           JSONObject j80 = new JSONObject();
           j80.put("text", "07:30 PM");
           j80.put("value","19:30:00"); 
           jarr.add(j80); 
           JSONObject j81 = new JSONObject();
           j81.put("text", "07:45 PM");
           j81.put("value","19:45:00"); 
           jarr.add(j81);
           JSONObject j82 = new JSONObject();
           j82.put("text", "08:00 PM");
           j82.put("value","20:00:00"); 
           jarr.add(j82);
            JSONObject j83 = new JSONObject();
           j83.put("text", "08:15 PM");
           j83.put("value","20:15:00");
              jarr.add(j83);
          JSONObject j84 = new JSONObject();
           j84.put("text", "08:30 PM");
           j84.put("value","20:30:00");           
           jarr.add(j84);
           JSONObject j85 = new JSONObject();
           j85.put("text", "08:45 PM");
           j85.put("value","20:45:00");           
           jarr.add(j85);  
          JSONObject j86 = new JSONObject();
           j86.put("text", "09:00 PM");
           j86.put("value","21:00:00");           
           jarr.add(j86);    
          JSONObject j87 = new JSONObject();
           j87.put("text", "09:15 PM");
           j87.put("value","21:15:00");           
           jarr.add(j87); 
             JSONObject j88 = new JSONObject();
           j88.put("text", "09:30 PM");
           j88.put("value","21:30:00");
              jarr.add(j88);
          JSONObject j89 = new JSONObject();
           j89.put("text", "09:45 PM");
           j89.put("value","21:45:00");           
           jarr.add(j89);
           JSONObject j90 = new JSONObject();
           j90.put("text", "10:00 PM");
           j90.put("value","22:00:00");           
           jarr.add(j90);  
          JSONObject j91 = new JSONObject();
           j91.put("text", "10:15 PM");
           j91.put("value","22:15:00");           
           jarr.add(j91);    
          JSONObject j92 = new JSONObject();
           j92.put("text", "10:30 PM");
           j92.put("value","22:30:00");
            jarr.add(j92); 
           JSONObject j93 = new JSONObject();
           j93.put("text", "10:45 PM");
           j93.put("value","22:45:00"); 
           jarr.add(j93); 
           JSONObject j94 = new JSONObject();
           j94.put("text", "11:00 PM");
           j94.put("value","23:00:00"); 
           jarr.add(j94); 
           JSONObject j95 = new JSONObject();
           j95.put("text", "11:15 PM");
           j95.put("value","23:15:00"); 
           jarr.add(j95); 
           JSONObject j96 = new JSONObject();
           j96.put("text", "11:30 PM");
           j96.put("value","23:30:00"); 
           jarr.add(j96); 
           JSONObject j97 = new JSONObject();
           j97.put("text", "11:45 PM");
           j97.put("value","23:45:00"); 
           jarr.add(j97); 
             
                                jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Setting Found");
				jsonobj.put("timestamp", new Date());
                                jsonobj.put("data", jarr);
        }else
        {
                               jsonobj.put("responsecode", 404);
				jsonobj.put("message", "TimeFormate  Not Found");
				jsonobj.put("timestamp", new Date());
                                
        }
      res = jsonobj.toString();  
       // GigflexConstants.
        
		} catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                 catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;

    
  }
}
