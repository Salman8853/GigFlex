/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.shift.dtob;

import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public class SaveMultiShiftRes {
    private Shift shift;
	
	private List<DaysCodeRes> daysCodeList;

    public Shift getShift() {
        return shift;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

    public List<DaysCodeRes> getDaysCodeList() {
        return daysCodeList;
    }

    public void setDaysCodeList(List<DaysCodeRes> daysCodeList) {
        this.daysCodeList = daysCodeList;
    }
        
}
