/**
 * 
 */
package com.gigflex.prototype.microservices.shift.dtob;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

/**
 * @author ajit.p
 *
 */
@Entity
@Table(name = "org_worker_shift")
public class Shift extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "organization_code", nullable = false)
	private String organizationCode;
	
	@Column(name = "working_location_code", nullable = false)
	private String workingLocationCode;
	
	@Column(name = "shift_name")
	private String shiftName;
	
	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "shift_code")
	private String shiftCode;
	
	@Column(name = "start_time", nullable = false)
	private Date startTime;
	
	@Column(name = "end_time", nullable = false)
	private Date endTime;
	
	@Column(name = "isactive")
	private Boolean isActive;

	public Shift() {
		super();
	}
	@PrePersist
    private void assignUUID() {
        if(this.getShiftCode()==null || this.getShiftCode().length()==0)
        {
            this.setShiftCode(UUID.randomUUID().toString());
        }
    }
	public Shift(Long id, String organizationCode, String shiftName, String shiftCode, Date startTime, Date endTime) {
		super();
		this.id = id;
		this.organizationCode = organizationCode;
		this.shiftName = shiftName;
		this.shiftCode = shiftCode;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public Shift(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}
	
	public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public String getShiftCode() {
		return shiftCode;
	}

	public void setShiftCode(String shiftCode) {
		this.shiftCode = shiftCode;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Shift [id=" + id + ", organizationCode=" + organizationCode + ", shiftName=" + shiftName
				+ ", shiftCode=" + shiftCode + ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}
	
	
	
}
