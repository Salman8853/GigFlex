package com.gigflex.prototype.microservices.shift.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.shift.dtob.Shift;
import com.gigflex.prototype.microservices.util.SearchCriteria;

public class ShiftSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public ShiftSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public ShiftSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<Shift> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<Shift>> specs = new ArrayList<Specification<Shift>>();
        for (SearchCriteria param : params) {
            specs.add(new ShiftSpecification(param));
        }
 
        Specification<Shift> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
