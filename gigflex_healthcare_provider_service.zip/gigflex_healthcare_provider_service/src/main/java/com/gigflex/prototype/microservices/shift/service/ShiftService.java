/**
 * 
 */
package com.gigflex.prototype.microservices.shift.service;

import com.gigflex.prototype.microservices.shift.dtob.MultiShiftRequest;
import java.util.List;

import com.gigflex.prototype.microservices.shift.dtob.ShiftRequest;

/**
 * @author ajit.p
 *
 */
public interface ShiftService {
	public String createShift(MultiShiftRequest shiftRequest, String ip);

	public String search(String search);

	public String updateShiftById(Long id, MultiShiftRequest shiftRequest, String ip);
 //       public String updateShiftByWorkingLocation(String locationCode, MultiShiftRequest shiftRequest, String ip);

//	public String getAllOrgWorkerShift(String organizationCode);
        public String getAllOrganizationWorkerShiftByLocationCode(String locationCode);
	public String softDeleteOrgWorkerShiftById(Long id);

	public String softMultipleDeleteById(List<Long> idList);

//	public String getAllShiftWithOrgCodeByPage(String organizationCode,
//			int page, int limit);
        public String getAllOrganizationWorkerShiftByLocationCodeByPage(String locationCode,
			int page, int limit);

}
