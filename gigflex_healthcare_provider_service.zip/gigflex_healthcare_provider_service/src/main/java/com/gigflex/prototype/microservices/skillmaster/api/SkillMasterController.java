package com.gigflex.prototype.microservices.skillmaster.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMasterRequest;
import com.gigflex.prototype.microservices.skillmaster.service.SkillMasterService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")

public class SkillMasterController {

	@Autowired
	public SkillMasterService skillMasterService;
	
	
	@GetMapping("/getSkillsWithNamesByIndustryCode/{industryCode}")
	public String getSkillsWithNamesByIndustryCode(@PathVariable String industryCode) {
		
                if(industryCode != null && industryCode.trim().length()>0){
			return skillMasterService.getSkillsWithNamesByIndustryCode(industryCode.trim());
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Industry Code should not be blank.");
	           return derr.toString();
		}
	}
	
	@GetMapping("/skills/{search}")
	public String search(@PathVariable("search") String search) {
		return skillMasterService.search(search);
	}

	@GetMapping("/getAllSkillMaster")
	public String getAllSkillMaster() {
		return skillMasterService.findAllSkillMaster();
	}
	
	@GetMapping(path="/getSkillMasterByPage")
    public String getSkillMasterByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String skillMaster = skillMasterService.getAllSkillMasterByPage(page, limit);
      
        return skillMaster;
       
    }
	
	@GetMapping("/getSkillsWithNames")
	public String getSkillsWithNames() {
		return skillMasterService.getSkillWithNames();
	}
	
	@GetMapping(path="/getSkillsWithNamesByPage")
    public String getSkillsWithNamesByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String skillMaster = skillMasterService.getSkillWithNames(page, limit);
      
        return skillMaster;
       
    }

	@GetMapping("/getSkillMaster/{id}")
	public String getSkillMasterById(@PathVariable Long id) {
		return skillMasterService.findSkillMasterById(id);
	}

	@GetMapping("/getSkillMasterrBySkillCode/{skillCode}")
	public String getSkillMasterBySkillCode(@PathVariable String skillCode) {
		return skillMasterService.getSkillMasterBySkillCode(skillCode);
	}

	@PostMapping("/saveSkillMaster")
	public String saveNewSkillMaster(
			 @RequestBody SkillMasterRequest skillMasterReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		
		return skillMasterService.saveSkillMaster(skillMasterReq, ip);

	}

	@DeleteMapping("/deleteSkillMaster/{id}")
	public String deleteSkillMasterById(@PathVariable Long id) {
		return skillMasterService.deleteSkillMasterById(id);
	}

	@DeleteMapping("/deleteSkillMasterBySkillCode/{skillCode}")
	public String deleteSkillMasterBySkillCode(@PathVariable String skillCode) {
		return skillMasterService.deleteBySkillCode(skillCode);
	}
	
	@DeleteMapping("/softDeleteSkillMasterBySkillCode/{skillCode}")
	public String softDeleteSkillMasterBySkillCode(@PathVariable String skillCode) {
		return skillMasterService.softDeleteBySkillCode(skillCode);
	}
	
	@DeleteMapping("/softMultipleDeleteBySkillCode/{skillCodeList}")
	public String softMultipleDeleteBySkillCode(@PathVariable List<String> skillCodeList) {
		if(skillCodeList != null && skillCodeList.size()>0){
			return skillMasterService.softMultipleDeleteBySkillCode(skillCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
		
	}


	@PutMapping("/updateSkillMaster/{id}")
	public String updateSkillMaster(@PathVariable Long id,
			 @RequestBody SkillMasterRequest skillMasterReq,
			HttpServletRequest request) {

		if (id == null) {
			return "Skill Master with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return skillMasterService.updateSkillMasterById(id, skillMasterReq,
					ip);

		}

	}

}
