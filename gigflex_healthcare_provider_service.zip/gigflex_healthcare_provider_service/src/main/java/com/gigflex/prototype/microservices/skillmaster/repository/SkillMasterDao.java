package com.gigflex.prototype.microservices.skillmaster.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignment;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;

@Repository
public interface SkillMasterDao extends JpaRepository<SkillMaster, Long>,JpaSpecificationExecutor<SkillMaster> {
//	public SkillMaster getSkillMasterBySkillCode(String skillCode);
//
//	@Transactional
//	public Integer deleteBySkillCode(String skillCode);
	
//	@Query("SELECT o.industryCode FROM Organization o WHERE o.isDeleted != TRUE AND o.organizationCode = :organizationCode ")
//	public String getSkillByIndustryAndOrganizationCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT s FROM OrganizationWorkerSkill s WHERE s.isDeleted != TRUE AND s.skillCode = :skillCode")
	public List<OrganizationWorkerSkill> getOrgWorkerSkillBySkillsCode(@Param("skillCode") String skillCode);
	
	@Query("SELECT s FROM WorkerScheduleRequestAssignment s WHERE s.isDeleted != TRUE AND s.skillCode = :skillCode")
	public List<WorkerScheduleRequestAssignment> getWorkerSchReqBySkillsCode(@Param("skillCode") String skillCode);
	
	@Query("SELECT s FROM SkillMaster s WHERE s.isDeleted != TRUE AND s.industryCode = :industryCode")
	public List<SkillMaster> getSkillsByIndustryCode(@Param("industryCode") String industryCode);
	
	@Query("SELECT s FROM SkillMaster s WHERE s.isDeleted != TRUE AND s.skillCode = :skillCode")
	public SkillMaster getSkillMasterBySkillCode(@Param("skillCode") String skillCode);
	
    @Query("SELECT s FROM SkillMaster s WHERE s.isDeleted != TRUE AND s.skillCode = :skillCode")
	public SkillMaster getSkillCode(@Param("skillCode") String skillCode);

	@Transactional
	public Integer deleteBySkillCode(String skillCode);

	@Query("SELECT s FROM SkillMaster s WHERE s.isDeleted != TRUE")
	public List<SkillMaster> getAllSkillMaster();
	
	@Query("SELECT s FROM SkillMaster s WHERE s.isDeleted != TRUE")
	public List<SkillMaster> getAllSkillMaster(Pageable pageableRequest);

	@Query("SELECT s FROM SkillMaster s WHERE s.isDeleted != TRUE AND s.id = :id")
	public SkillMaster getSkillMasterById(@Param("id") Long id);
	
	@Query("SELECT s FROM SkillMaster s WHERE s.isDeleted != TRUE AND s.skillName = :skillName")
	public SkillMaster getBySkillName(@Param("skillName") String skillName);
	
	@Query("SELECT org FROM OrganizationSkill org WHERE org.isDeleted != TRUE AND org.skillCode = :skillCode")
	public List<OrganizationSkill> getBySkillCode(@Param("skillCode") String skillCode);
	
	@Query("SELECT a FROM SkillMaster a WHERE a.isDeleted != TRUE AND a.industryCode = :industryCode AND a.skillName =:skillName")
	public SkillMaster getSkillMasterCheckForSave(@Param("industryCode") String industryCode,@Param("skillName") String skillName);
	
	@Query("SELECT a FROM SkillMaster a WHERE a.isDeleted != TRUE AND a.id != :id AND a.industryCode = :industryCode AND a.skillName =:skillName")
	public SkillMaster getSkillMasterCheckForUpdate(@Param("id") Long id,@Param("industryCode") String industryCode,@Param("skillName") String skillName);

	@Query("SELECT a,b.industryName FROM SkillMaster a ,IndustryMaster b WHERE a.isDeleted != TRUE AND a.industryCode=b.industryCode")
	public List<Object> getAllSkillWithNames();
        
        @Query("SELECT a,b.industryName FROM SkillMaster a ,IndustryMaster b WHERE a.isDeleted != TRUE AND a.industryCode=b.industryCode AND a.industryCode= :industryCode")
	public List<Object> getAllSkillWithNamesByIndustryCode(@Param("industryCode") String industryCode);
	
	@Query("SELECT a,b.industryName FROM SkillMaster a ,IndustryMaster b WHERE a.isDeleted != TRUE AND a.industryCode=b.industryCode")
	public List<Object> getAllSkillWithNames(Pageable pageableRequest);
	@Query("Select  DISTINCT sm FROM SkillMaster sm,OrganizationWorkerSkill org WHERE org.workerCode=:workerCode AND org.skillCode=sm.skillCode" )
        public  List<SkillMaster> getWorkerSkillByworkercode(@Param("workerCode") String workerCode);
}
