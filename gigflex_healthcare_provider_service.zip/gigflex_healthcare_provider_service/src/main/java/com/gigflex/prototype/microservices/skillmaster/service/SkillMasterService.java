package com.gigflex.prototype.microservices.skillmaster.service;

import java.util.List;

import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMasterRequest;

public interface SkillMasterService {

	
	public String search(String search);
	public String findAllSkillMaster();
	
	public String getSkillWithNames();
	
	public String getSkillWithNames(int page, int limit);
	
	public String getAllSkillMasterByPage(int page, int limit);

	public String findSkillMasterById(Long id);

	public String saveSkillMaster(SkillMasterRequest skillMasterReq, String ip);
	
	public String updateSkillMasterById(Long id,
			SkillMasterRequest skillMasterReq, String ip);

	public String deleteSkillMasterById(Long id);

	public String getSkillMasterBySkillCode(String skillCode);

	public String deleteBySkillCode(String skillCode);
	
	public String softDeleteBySkillCode(String skillCode);
	
    public String softMultipleDeleteBySkillCode(List<String> skillCodeList);
    
    public String getSkillsWithNamesByIndustryCode(String industryCode);


}
