package com.gigflex.prototype.microservices.uploadqueue.api;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueueRequest;
import com.gigflex.prototype.microservices.uploadqueue.service.UploadQueueService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
public class UploadQueueController {
	
	@Autowired
	public UploadQueueService UploadQueueService;
	
	@GetMapping("/uploadQueue/{search}")
	public String search(@PathVariable("search") String search) {
		return UploadQueueService.search(search);
	}

	
	@GetMapping("/getUploadQueueByUploadCode/{uploadCode}")
	public String getUploadQueueByUploadCode(@PathVariable String uploadCode) {
		return UploadQueueService.getAllUploadQueueByCode(uploadCode);
	}

	@PostMapping("/saveUploadQueue")
	public String saveNewUploadQueue(
			 @RequestBody UploadQueueRequest UploadQueueReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		
		return UploadQueueService.saveUploadQueue(UploadQueueReq, ip);

	}

}
