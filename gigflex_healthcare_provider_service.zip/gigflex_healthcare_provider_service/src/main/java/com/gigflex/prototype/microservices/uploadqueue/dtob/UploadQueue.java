package com.gigflex.prototype.microservices.uploadqueue.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;


@Entity
@Table(name = "upload_queue")
public class UploadQueue extends CommonAttributes implements Serializable {
	
	
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
	
	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "upload_code", unique = true)
	private String uploadCode;
	
	@Column(name = "file_name")
	private String fileName;
	
	@Column(name = "total_records")
	private Long totalRecords;
	
	@Column(name = "processed_records")
	private Long processedRecords;
	
	@Column(name = "falied_records")
	private Long faliedRecords;
	
	@PrePersist
	private void assignUUID() {
		if (this.getUploadCode() == null || this.getUploadCode().length() == 0) {
			this.setUploadCode(UUID.randomUUID().toString());
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getUploadCode() {
		return uploadCode;
	}

	public void setUploadCode(String uploadCode) {
		this.uploadCode = uploadCode;
	}

	public Long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Long totalRecords) {
		this.totalRecords = totalRecords;
	}

	public Long getProcessedRecords() {
		return processedRecords;
	}

	public void setProcessedRecords(Long processedRecords) {
		this.processedRecords = processedRecords;
	}

	public Long getFaliedRecords() {
		return faliedRecords;
	}

	public void setFaliedRecords(Long faliedRecords) {
		this.faliedRecords = faliedRecords;
	}


}
