package com.gigflex.prototype.microservices.uploadqueue.dtob;


public class UploadQueueRequest {
	
	private String fileName;
	
	private Long totalRecords;
	
	private Long processedRecords;
	
	private Long faliedRecords;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Long totalRecords) {
		this.totalRecords = totalRecords;
	}

	public Long getProcessedRecords() {
		return processedRecords;
	}

	public void setProcessedRecords(Long processedRecords) {
		this.processedRecords = processedRecords;
	}

	public Long getFaliedRecords() {
		return faliedRecords;
	}

	public void setFaliedRecords(Long faliedRecords) {
		this.faliedRecords = faliedRecords;
	}
	
	

}
