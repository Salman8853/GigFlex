package com.gigflex.prototype.microservices.uploadqueue.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueue;


public interface UploadQueueDao extends JpaRepository<UploadQueue, Long>,JpaSpecificationExecutor<UploadQueue> {
	
	@Query("SELECT a FROM UploadQueue a WHERE a.isDeleted != TRUE AND a.uploadCode = :uploadCode")
	public UploadQueue getUploadQueueByUploadCode(@Param("uploadCode") String uploadCode);

}
