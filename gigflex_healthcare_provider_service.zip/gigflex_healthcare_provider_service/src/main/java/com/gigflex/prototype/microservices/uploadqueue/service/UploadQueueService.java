package com.gigflex.prototype.microservices.uploadqueue.service;

import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueueRequest;

public interface UploadQueueService {
	
	public String search(String search);
	
	public String getAllUploadQueueByCode(String uploadCode);
	
	public String saveUploadQueue(UploadQueueRequest uploadRequest, String ip);

}
