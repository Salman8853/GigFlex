package com.gigflex.prototype.microservices.usertype.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.usertype.dtob.UserTypeRequest;
import com.gigflex.prototype.microservices.usertype.service.UserTypeService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class UserTypeController {

	@Autowired
	public UserTypeService userTypeService;

	@GetMapping("/UserType/{search}")
	public String search(@PathVariable("search") String search) {
		return userTypeService.search(search);
	}

	@GetMapping("/getAllUserType")
	public String getAllUserType() {
		return userTypeService.getAllUserType();
	}

	@GetMapping(path = "/getUserTypeByPage")
	public String getUserTypeByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String userType = userTypeService.getAllUserTypeByPgae(page, limit);

		return userType;

	}

	@GetMapping("/getUserType/{id}")
	public String getUserTypeById(@PathVariable Long id) {
		return userTypeService.getUserTypeById(id);
	}

	@GetMapping("/getUserTypeByUserTypeCode/{userTypeCode}")
	public String getUserTypeByUserTypeCode(@PathVariable String userTypeCode) {
		return userTypeService.getUserTypeByUserTypeCode(userTypeCode);
	}

	@PostMapping("/saveUserType")
	public String saveUserType(@RequestBody UserTypeRequest userTypeReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return userTypeService.saveNewUserType(userTypeReq, ip);

	}

	@PutMapping("/updateUserType/{id}")
	public String updateUserType(@PathVariable Long id,
			@RequestBody UserTypeRequest userTypeReq, HttpServletRequest request) {

		if (id == null) {
			return "UserType with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return userTypeService.updateUserTypeById(id, userTypeReq, ip);

		}

	}

	@DeleteMapping("/softDeleteUserTypeByUserTypeCode/{userTypeCode}")
	public String softDeleteUserTypeByUserTypeCode(
			@PathVariable String userTypeCode) {
		return userTypeService.softDeleteByUserTypeCode(userTypeCode);
	}

	@DeleteMapping("/softMultipleDeleteByUserTypeCode/{userTypeCodeList}")
	public String softMultipleDeleteByUserTypeCode(
			@PathVariable List<String> userTypeCodeList) {
		if (userTypeCodeList != null && userTypeCodeList.size() > 0) {
			return userTypeService
					.softMultipleDeleteByUserTypeCode(userTypeCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

}
