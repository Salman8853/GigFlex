package com.gigflex.prototype.microservices.usertype.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.usertype.dtob.UserType;

public interface UserTypeRepository extends JpaRepository<UserType, Long>,JpaSpecificationExecutor<UserType>{
	
	@Query("SELECT m FROM UserType m WHERE m.isDeleted != TRUE")
	public List<UserType> getAllUserType();
	
	@Query("SELECT m FROM UserType m WHERE m.isDeleted != TRUE")
	public List<UserType> getAllUserType(Pageable pageableRequest);
	
	@Query("SELECT m FROM UserType m WHERE m.isDeleted != TRUE AND m.userTypeCode = :userTypeCode")
	public UserType getUserTypeByUserTypeCode(@Param("userTypeCode") String userTypeCode);
	
	@Query("SELECT m FROM UserType m WHERE m.isDeleted != TRUE AND m.id = :id")
	public UserType getUserTypeById(@Param("id") Long id);
	
	@Query("SELECT m FROM UserType m WHERE m.isDeleted != TRUE AND m.userTypeName = :userTypeName")
	public UserType getUserTypeByUserTypeName(@Param("userTypeName") String userTypeName);
	
        @Query("SELECT m FROM UserType m WHERE m.isDeleted != TRUE AND m.userTypeName = :userTypeName AND m.id != :id")
	public UserType getUserTypeByUserTypeNameNotID(@Param("userTypeName") String userTypeName, @Param("id") Long id);
	
}
