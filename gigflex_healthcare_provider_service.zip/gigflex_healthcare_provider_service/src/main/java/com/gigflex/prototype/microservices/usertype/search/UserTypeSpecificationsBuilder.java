package com.gigflex.prototype.microservices.usertype.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.util.SearchCriteria;




public class UserTypeSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public UserTypeSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public UserTypeSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<UserType> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<UserType>> specs = new ArrayList<Specification<UserType>>();
        for (SearchCriteria param : params) {
            specs.add(new UserTypeSpecification(param));
        }
 
        Specification<UserType> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
