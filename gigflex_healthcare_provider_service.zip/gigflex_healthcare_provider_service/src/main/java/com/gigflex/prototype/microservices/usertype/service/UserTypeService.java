package com.gigflex.prototype.microservices.usertype.service;

import java.util.List;

import com.gigflex.prototype.microservices.usertype.dtob.UserTypeRequest;

public interface UserTypeService {
	
	public String getAllUserType();
	public String getUserTypeById(Long id);
	public String getUserTypeByUserTypeCode(String userTypeCode);
	public String saveNewUserType(UserTypeRequest userTypeReq, String ip);
	public String updateUserTypeById( Long id,UserTypeRequest userTypeReq, String ip);
	public String softDeleteByUserTypeCode(String userTypeCode);
    public String softMultipleDeleteByUserTypeCode(List<String> userTypeCodeList);
    public String getAllUserTypeByPgae(int page, int limit);
    public String search(String search);

}
