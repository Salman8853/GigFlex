/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

/**
 *
 * @author abhishek
 */
public class GigflexConstants {
    public static final String assignedScheduleStatus = "pending";
    public static final String assignedScheduleAcceptedStatus = "fulfilled";
    public static final String assignedScheduleRejectedStatus = "reschedule";
    public static final String assignedScheduleChangedStatus = "changed";
    
    public static final String HealthcareProvider = "HealthcareProvider";
    public static final String HealthcareTechnician = "HealthcareTechnician";
    public static final String TimeZone="TimeZone";
    public static final String FULLTIME_STAFF_AUTO_ASSIGN="FullTime.Staff.AutomaticAssign";
    public static final String  YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";
    public static final String  DD_MM_YYYY_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String  HH_MM_SS = "HH:mm:ss";
    public static final String  YYYY_MM_DD = "yyyy-MM-dd";
    public static final String  DD_MMMM_YYYY ="dd MMMM yyyy";
    public static final String DATEFORMAT="DateFormat";
    public static final String TIMEFORMAT="TimeFormat";
    
    public static final String JOBSTATUS_PENDING = "pending";
    public static final String JOBSTATUS_ASSIGNED = "assigned";
    public static final String JOBSTATUS_ACCEPTED = "accepted";
    public static final String JOBSTATUS_REJECTED = "rejected";
    public static final String JOBSTATUS_CANCELLED = "cancelled";
    public static final String JOBSTATUS_INPROGRESS = "inprogress";
    public static final String JOBSTATUS_COMPLETED = "completed";
    public static final String JOBSTATUS_EXPIRED = "expired";
    public static final int REAPONSECODE_SUCCESS=200; 
    public static final int REAPONSECODE_FAILED=400;
    public static final int REAPONSECODE_NOTVALID=400;
    public static final int REAPONSECODE_NOTFOUND=404;
    public static final int REAPONSECODE_UNAUTHORIZED=401;
    public static final int REAPONSECODE_ALREADYEXIST=409;
    public static final int REAPONSECODE_EXCEPTION=500;
    public static final String NOTIFICATION_USER_TYPE_ADMIN = "Admin";
    public static final String NOTIFICATION_USER_TYPE_WORKER = "Worker";
    public static final String NOTIFICATION_USER_TYPE_ALL = "All";
    public static final String CONFIGURE_MINUTES_NAME = "ConfigureMinutes";
    public static final String ALERT_MINUTES = "AlertMinutes";
    public static final String EXPIRED_MINUTES = "ExpiredMinutes";
    public static final String IS_RECURSIVE = "isRecursive";
    public static final String MAIL_NOTIFICATIONS = "mail_notifications";
    public static final String SMS_NOTIFICATIONS ="sms_notifications";  
    public static final int STATUS_COUNT_INTERVAL_IN_HOURS=1;
    public static final String ORG_WORKING_DAY_1="Working.Days.Sun";
    public static final String ORG_WORKING_DAY_2="Working.Days.Mon";
    public static final String ORG_WORKING_DAY_3="Working.Days.Tue";
    public static final String ORG_WORKING_DAY_4="Working.Days.Wed";
    public static final String ORG_WORKING_DAY_5="Working.Days.thu";
    public static final String ORG_WORKING_DAY_6="Working.Days.Fri";
    public static final String ORG_WORKING_DAY_7="Working.Days.Sat";
    public static final String ORG_WORKING_TIME_START="WorkingTime.StartTime";
    public static final String ORG_WORKING_TIME_END="WorkingTime.EndTime";
    public static final String ORG_SPEC_NON_WORKING_DAYS="Specific.Non.Working.Days";
    public static final Double WORKING_DISTANCE_IN_MILES=20.00;
}
