package com.gigflex.prototype.microservices.util;

public class GigflexDateFormatConstants {

	
	public static final String  DD_MM_YYYY_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
        public static final String  YYYY_MM_DD = "yyyy-MM-dd";
}
