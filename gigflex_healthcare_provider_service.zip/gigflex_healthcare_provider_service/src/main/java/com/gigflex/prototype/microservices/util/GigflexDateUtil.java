/**
 * 
 */
package com.gigflex.prototype.microservices.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;

/**
 * @author ajit.p
 *
 */
public class GigflexDateUtil {

    public static boolean validateDateFormat(String strDate,String format)
   {
	/* Check if date is 'null' */
	if (strDate==null || strDate.trim().equals(""))
	{
	    return false;
	}
	/* Date is not 'null' */
	else
	{
	    /*
	     * Set preferred date format,
	     * For example MM-dd-yyyy, MM.dd.yyyy,dd.MM.yyyy etc.*/
	    SimpleDateFormat sdfrmt = new SimpleDateFormat(format);
	    sdfrmt.setLenient(false);
	    /* Create Date object
	     * parse the string into date 
             */
	    try
	    {
	        Date javaDate = sdfrmt.parse(strDate.trim()); 
	        System.out.println(strDate+" is valid date format");
                return true;
	    }
	    /* Date format is invalid */
	    catch (Exception e)
	    {
                e.printStackTrace();
	        System.out.println(strDate+" is Invalid Date format");
	        return false;
	    }
	    /* Return true if date format is valid */
	   
	}
   }
    
	public static Date convertStringToDate(String startDate, String format){ //throws Exception {

            Date date = null;
            try
            {
               date = new SimpleDateFormat(format).parse(startDate);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
		
	   return date;
	}
	
        public static String convertDateToString(Date date, String format) {//throws Exception {

		String strdate = null;
                try{
               strdate= new SimpleDateFormat(format).format(date);
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
		return strdate;
	}
        
	 public static Date convertStringDateToGMT(String dateInfo,String timezone,String dateFormate){
         Date utilDate=null;
         try{
             if(dateInfo!=null && timezone!=null){
             LocalDateTime ldt = LocalDateTime.parse(dateInfo,DateTimeFormatter.ofPattern(dateFormate)); 
             ZoneId z = ZoneId.of(timezone);
             ZonedDateTime zdt = ldt.atZone( z );
             utilDate=Date.from(zdt.toInstant());
             System.out.println("==utilDate==="+utilDate);
             }
         }
         catch(Exception e){
             e.printStackTrace();
         }
         return utilDate;
     }
     
    public static Date getGMTtoLocationDate(Date d1,String timezone,String dateFormat) throws Exception{
        DateTimeFormatter format = null;
        ZonedDateTime zdt = null;
        try {
            format = DateTimeFormatter.ofPattern(dateFormat);
            // DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            Instant instant = d1.toInstant();
            ZoneId z = ZoneId.of(timezone);
            LocalDateTime ldt = instant.atZone(z).toLocalDateTime();
            zdt = ldt.atZone(ZoneId.of(timezone));
            System.out.println("====formated date====" + format.format(zdt));
            return new SimpleDateFormat(dateFormat).parse(format.format(zdt));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        
    }
    
    public static boolean isDate(String date, String dateformat) {
        if (date == null) {
            return false;
        }
        //set the format to use as a constructor argument
        SimpleDateFormat sdf = new SimpleDateFormat(dateformat);
        if (date.trim().length() != sdf.toPattern().length()) {
            return false;
        }

        sdf.setLenient(false);

        try {
            sdf.parse(date.trim());
        } catch (ParseException pe) {
            return false;
        }
        return true;
    }

    public static String getNameFromDayCode(Integer day)
    {
        try{
        HashMap <Integer,String> dayCodeWithNameMap=new HashMap<>();
        dayCodeWithNameMap.put(1, "Sunday");
        dayCodeWithNameMap.put(2, "Monday");
        dayCodeWithNameMap.put(3, "Tuesday");
        dayCodeWithNameMap.put(4, "Wednesday");
        dayCodeWithNameMap.put(5, "Thursday");
        dayCodeWithNameMap.put(6, "Friday");
        dayCodeWithNameMap.put(7, "Saturday");
        if(dayCodeWithNameMap.containsKey(day))
        {
            return dayCodeWithNameMap.get(day);
        }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return null;
    }
    
    }
