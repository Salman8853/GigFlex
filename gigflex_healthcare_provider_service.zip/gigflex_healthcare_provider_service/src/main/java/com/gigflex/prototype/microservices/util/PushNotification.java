/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.util;

import atg.taglib.json.util.JSONObject;
import java.io.OutputStreamWriter;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;


/**
 *
 * @author amit.kumar
 */
public class PushNotification {
    public final static String AUTH_KEY_FCM = "AIzaSyC6EMCV7R55YU7NSRJp7Bj0ebuqFqBoikQ";
    public final static String API_URL_FCM = "https://fcm.googleapis.com/fcm/send";
     public static void main(String a[]) {

        pushFCMNotification(API_URL_FCM,AUTH_KEY_FCM,"eN2-_wlVb2Y:APA91bFGHAWWr_ydJMLhjr9ufKg6zBDampXhXfv8WudKxnd6umPAAiSSTWlipELt3XGgETDgbzlc9exmp9hIx-9Bn4dEuh0ydwoz9e5AbBL-Na8B4bn9COYmL9judprIBHmjvCMua7mC", "Test", "Hello");
    }
    
     
     public static void pushFCMNotification(String FMCurl, String authKey, String DeviceId, String title, String body) {

       try {
            URL url = new URL(FMCurl);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

            conn.setUseCaches(false);
            conn.setDoInput(true);
            conn.setDoOutput(true);

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "key=" + authKey);
            conn.setRequestProperty("Content-Type", "application/json");

            JSONObject data = new JSONObject();
            data.put("to", DeviceId.trim());   
            //data.put("to", "356823073570676"); 
            JSONObject info = new JSONObject();
            info.put("title", title); // Notification title
            info.put("body", body); // Notification body
            data.put("notification", info);

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data.toString());
            wr.flush();
            wr.close();

            int responseCode = conn.getResponseCode();
            System.out.println("Response Code : " + responseCode);
            System.out.println("Response  : " + conn.getResponseMessage());

        } catch (Exception ex) {
            System.out.println("Error in Andriod pushFCMNotification ::" + ex);
            ex.printStackTrace();
        }
       
       
    }
}
