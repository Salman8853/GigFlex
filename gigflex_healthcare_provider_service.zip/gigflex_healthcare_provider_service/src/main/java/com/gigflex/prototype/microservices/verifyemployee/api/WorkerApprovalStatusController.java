/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.verifyemployee.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import java.util.Base64;

import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.verifyemployee.dtob.MultipleWorkerApprovalStatusRequest;
import com.gigflex.prototype.microservices.verifyemployee.dtob.SingleWorkerApprovalStatusRequest;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatusRequest;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatusRequestSave;
import com.gigflex.prototype.microservices.verifyemployee.service.WorkerApprovalStatusService;

/**
 *
 * @author nirbhay.p
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class WorkerApprovalStatusController {
    @Autowired 
    WorkerApprovalStatusService approvalStatusService;
    
    @GetMapping("/workerApprovalStatus/{search}")
	public String search(@PathVariable("search") String search) {
		return approvalStatusService.search(search);
	}

    
    @GetMapping("/getWorkerAndOrganizationFromWAS/{organizationCode}")
    public String getWorkerAndOrganizationFromWAS(@PathVariable String organizationCode){
    	return approvalStatusService.getWorkerAndOrganization(organizationCode);
    }
    
    @GetMapping("/getPendingWorkerForApproval/{organizationCode}")
    public String getPendingWorkerForApproval(@PathVariable String organizationCode){
    	return approvalStatusService.getPendingWorkerForApproval(organizationCode);
    }
    
    @GetMapping("/getWorkApprovalStatusByOrganizationCode/{organizationCode}")
    public String getWorkApprovalStatusByOrganizationCode(@PathVariable String organizationCode){
    	return approvalStatusService.getWorkApprovalStatusByOrganizationCode(organizationCode);
    }
    
    @GetMapping("/getWorkApprovalStatusWithCertificatesDetailsByOrganizationCode/{organizationCode}")
    public String getWorkApprovalStatusWithCertificatesDetailsByOrganizationCode(@PathVariable String organizationCode){
    	return approvalStatusService.getWorkApprovalStatusWithCertificatesDetailsByOrganizationCode(organizationCode);
    }
    
    @GetMapping("/getWorkerAndOrganizationFromWASByPage/{organizationCode}")
    public String getWorkerAndOrganizationFromWASByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String data = approvalStatusService.getWorkerAndOrganization(organizationCode,page, limit);
      
        return data;
    	
    }
    
    @GetMapping(path="/getAllWASByPage")
    public String getAllWASByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String WAS = approvalStatusService.getWorkerApprovalStatusByPage(page, limit);
      
        return WAS;
       
    }
    
    @GetMapping(path="/getAllWASWithNamesByPage")
    public String getAllWASWithNamesByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

    	 String WAS = approvalStatusService.getWorkerApprovalStatusWithNamesByPage(page, limit);
      
        return WAS;
       
    }
    
    @GetMapping("/verifyWorker")
    public String verifyWorker(@FormParam("tok") String tok,
			@FormParam("tok1") String tok1, @FormParam("tok2") String tok2,
			@FormParam("tok3") String tok3){
    	String res = "";
		try {
			if (tok != null && tok.length() > 0 && tok1.length() > 0
					&& tok2 != null && tok2.length() > 0 && tok3 != null
					&& tok3.length() > 0) {
				Boolean status = false;
				byte bttok[] = Base64.getDecoder().decode(tok);
				String workerCode = new String(bttok);
				
				byte bttok1[] = Base64.getDecoder().decode(tok1);
				String organizationCode = new String(bttok1);

				byte bttok2[] = Base64.getDecoder().decode(tok2);
				String approvedByCode = new String(bttok2);

				byte bttok3[] = Base64.getDecoder().decode(tok3);
				String status1 = new String(bttok3);
				if (status1.equalsIgnoreCase("true")) {
					status = true;
				}
				if(organizationCode != null && organizationCode.length()>0 && workerCode != null && workerCode.length()>0 
						&& approvedByCode != null && approvedByCode.length()>0 && status != null){
					res = approvalStatusService.verifyWorker(organizationCode, workerCode, approvedByCode, status);
			} else {
					res = "Given input is Invalid";
				}
			} else {
				res = "Given input is Invalid";
			}
		} catch (Exception e) {
			res = "Given input is Invalid";
			e.printStackTrace();
		}
		return res;
    	
    }
    
    @GetMapping("/getPendingWorkerForApprovalByPage/{organizationCode}")
    public String getPendingWorkerForApprovalByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
    @RequestParam(value = "limit", defaultValue = "30") int limit) {

String data = approvalStatusService.getPendingWorkerForApproval(organizationCode,page, limit);

return data;
    	
    }
    
    @GetMapping("/WAS")
    public String getAllWAS(){
    	return approvalStatusService.getAllWAS();
    }
    
    @GetMapping("/getAllWAS")
    public String getAllWorkerApprovalStatus(){
    	return approvalStatusService.getAllWorkerApprovalStatus();
    }
    
    @RequestMapping(path = "/verifyEmployee", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public String verifyWorkerApprovalStatus(@RequestBody WorkerApprovalStatusRequest approvalStatusRequest, HttpServletRequest request){
    	
        if (approvalStatusRequest != null  && approvalStatusRequest.getId() > 0) {
            return approvalStatusService.verifyEmployeeStatus(approvalStatusRequest,request.getRemoteAddr());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Invalid Input Data");
            return derr.toString();
        }
    	
    }
    
    
    @PostMapping(path = "/verifySingleEmployee")
    public String verifySingleEmployee(@RequestBody SingleWorkerApprovalStatusRequest singleWorkerApprovalStatusRequest, HttpServletRequest request){
    	
        if (singleWorkerApprovalStatusRequest != null) {
            return approvalStatusService.verifySingleEmployee(singleWorkerApprovalStatusRequest,request.getRemoteAddr());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Invalid Input Data");
            return derr.toString();
        }
    	
    }
    
    @PostMapping( "/verifyMultipleEmployee")
    public String verifyMultipleEmployee(@RequestBody MultipleWorkerApprovalStatusRequest multipleWorkerApprovalStatusRequest, HttpServletRequest request){
    	
        if (multipleWorkerApprovalStatusRequest != null  && multipleWorkerApprovalStatusRequest.getApprovedByCode() !=null && multipleWorkerApprovalStatusRequest.getApprovedByCode().length() > 0
                && multipleWorkerApprovalStatusRequest.getWorkerApprovalStatusRequestList()!=null && multipleWorkerApprovalStatusRequest.getWorkerApprovalStatusRequestList().size() >0 ) {
            return approvalStatusService.verifyMultipleEmployee(multipleWorkerApprovalStatusRequest,request.getRemoteAddr());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Invalid Input Data");
            return derr.toString();
        }
    	
    }

    @GetMapping("/WAS/{id}")
    public String getWASById(@PathVariable long id){
    	return approvalStatusService.getWASByID(id);
    }
    
   @DeleteMapping("/WAS/{id}") 
   public String deleteWASById(@PathVariable long id){
	  return approvalStatusService.deleteWASById(id);
   }
   
   @DeleteMapping("/softDeleteWASById/{id}") 
   public String softDeleteWASById(@PathVariable long id){
	  return approvalStatusService.softDeleteWASById(id);
   }
   
   @DeleteMapping("/softDeleteWASByWorkerAndOrgCode/{workerCode}/{organizationCode}") 
   public String softDeleteWASByWorkerAndOrgCode(@PathVariable String workerCode,@PathVariable String organizationCode){
	  return approvalStatusService.softDeleteByWorkerAndOrgCode(workerCode, organizationCode);
   }
   
   @DeleteMapping("/softMultipleDeleteWASById/{idList}")
	public String softMultipleDeleteWASById(@PathVariable("idList") List<Long> idList) {
		if(idList != null && idList.size()>0){
			return approvalStatusService.softMultipleDeleteById(idList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
	}

   
   @PutMapping("/updateWAS/{id}")
	public String updateWAS(@PathVariable Long id, @RequestBody WorkerApprovalStatus was, HttpServletRequest request) {
	if(was!=null)
        {
             if(was.getOrganization_Code()!=null && was.getOrganization_Code().trim().length()>0 
                   && was.getWorkerCode()!=null && was.getWorkerCode().trim().length()>0 &&  was.getIsApproved()!=null)
           {
             was.setOrganization_Code(was.getOrganization_Code().trim());
             was.setWorkerCode(was.getWorkerCode().trim());
            was.setIpAddress(request.getRemoteAddr());
            return approvalStatusService.updateWAS(was, id);
            }else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "Organization Code, Worker Code and Approval Status should not be blank.");
            return derr.toString();    
                    }
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
            return derr.toString();
        }
	}
        
        
        @PostMapping("/saveWAS")
	public String createWAS(@RequestBody WorkerApprovalStatus was, HttpServletRequest req) {
		if(was!=null)
        {
           if(was.getOrganization_Code()!=null && was.getOrganization_Code().trim().length()>0 
                   && was.getWorkerCode()!=null && was.getWorkerCode().trim().length()>0 )
           {
             was.setOrganization_Code(was.getOrganization_Code().trim());
             was.setWorkerCode(was.getWorkerCode().trim());
               was.setIpAddress(req.getRemoteAddr());
            return  approvalStatusService.createWAS(was);
           }else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "Organization Code and Worker Code should not be blank.");
            return derr.toString();    
                    }
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
            return derr.toString();
        }
		
			
	}
        
        
        @PostMapping("/saveWorkerApprovalStatus")
    	public String createWorkingLocation(@RequestBody WorkerApprovalStatusRequestSave wasReqSave, HttpServletRequest request) {
    		if(wasReqSave!=null)
            {
    			String ip = request.getRemoteAddr();
                return  approvalStatusService.saveWorkerApprovalStatus(wasReqSave, ip);
            }
            else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
                return derr.toString();
            }
    		
    			
    	}
}
