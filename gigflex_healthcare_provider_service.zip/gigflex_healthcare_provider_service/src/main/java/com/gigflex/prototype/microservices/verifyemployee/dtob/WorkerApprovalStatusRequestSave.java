package com.gigflex.prototype.microservices.verifyemployee.dtob;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkerApprovalStatusRequestSave {
	
    private String workerCode ;

    private String organization_Code ;
    
     private String color;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
     
     

    @JsonProperty("isApproved")
    private final Boolean isApproved = Boolean.FALSE;

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public String getOrganization_Code() {
		return organization_Code;
	}

	public void setOrganization_Code(String organization_Code) {
		this.organization_Code = organization_Code;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

//	public void setIsApproved(Boolean isApproved) {
//		this.isApproved = isApproved;
//	}
    
    

}
