package com.gigflex.prototype.microservices.verifyemployee.dtob;

import java.util.Date;


public class WorkerOrganizationNameResponse {

    private Long id;

    private String workerCode;

    private String organization_Code;

    private Boolean isApproved;

    private Date approvedDate;

    private String approvedByCode;

    private String organizationName;

    private String workerName;

    private String color;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getOrganization_Code() {
        return organization_Code;
    }

    public void setOrganization_Code(String organization_Code) {
        this.organization_Code = organization_Code;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }

    public Date getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(Date approvedDate) {
        this.approvedDate = approvedDate;
    }

    public String getApprovedByCode() {
        return approvedByCode;
    }

    public void setApprovedByCode(String approvedByCode) {
        this.approvedByCode = approvedByCode;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

}
