package com.gigflex.prototype.microservices.verifyemployee.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.util.SearchCriteria;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;



public class WorkerApprovalStatusSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public WorkerApprovalStatusSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public WorkerApprovalStatusSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<WorkerApprovalStatus> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<WorkerApprovalStatus>> specs = new ArrayList<Specification<WorkerApprovalStatus>>();
        for (SearchCriteria param : params) {
            specs.add(new WorkerApprovalStatusSpecification(param));
        }
 
        Specification<WorkerApprovalStatus> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
