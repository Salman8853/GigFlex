package com.gigflex.prototype.microservices.worker.api;


import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.TokenUtility;
import com.gigflex.prototype.microservices.verifyemployee.service.WorkerApprovalStatusService;
import com.gigflex.prototype.microservices.worker.dtob.WorkerDetailsReq;
import com.gigflex.prototype.microservices.worker.dtob.WorkerHomelocationReq;


import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.worker.dtob.WorkerLogoRequest;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileForMobileReq;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileProfessionalTabForMobileRes;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileReq;
import com.gigflex.prototype.microservices.worker.dtob.WorkerRequest;
import com.gigflex.prototype.microservices.worker.service.WorkerService;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMethod;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
public class WorkerController {

	@Autowired
	WorkerService workerService;
	@Autowired
	WorkerApprovalStatusService approvalStatusService;
        @Autowired
        TokenUtility tokenutility;
        @Autowired
	UserRepository userRepository;
	
	@GetMapping("/workers/{search}")
	public String search(@PathVariable("search") String search) {
		return workerService.search(search);
	}

	@GetMapping("/getAllWorkers")
	public String getAllWorkers() {
		return workerService.getAllWorkers();
	}

	
	@GetMapping(path="/getAllWorkersByPage")
    public String getAllWorkersByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String worker = workerService.getAllWorkersByPage(page, limit);
      
        return worker;
       
    }

	@GetMapping("/getWorker/{id}")
	public String getWorkerById(@PathVariable long id) {
		return workerService.getWorkerById(id);
	}

//	@GetMapping("/getWorkerAndOrganizationFromWAS/{organizationCode}")
//	public String getWorkerAndOrganizationFromWAS(
//			@PathVariable String organizationCode) {
//		return approvalStatusService.getWorkerAndOrganization(organizationCode);
//	}

	@GetMapping("/getOrganizationByWorkerCode/{workerCode}")
	public String getOrganizationByWorkerCode(@PathVariable String workerCode,@RequestHeader HttpHeaders headers) {
               String res="";
               res=tokenutility.userValidation(headers, workerCode);
               if(res.equalsIgnoreCase("true"))
              {
                 return workerService.getOrganizationByWorkerCode(workerCode);
              }else
                  {
                     return res;
                  }
	
	}
	
	@GetMapping("/getOrganizationByWorkerCodeByPage/{workerCode}")
	public String getOrganizationByWorkerCodeByPage(@PathVariable String workerCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) 
        {    String res="";
               res=tokenutility.userValidation(headers, workerCode);
              if(res.equalsIgnoreCase("true"))
              {
                  return workerService.getOrganizationByWorkerCode(workerCode,page, limit);
              }else
                  {
                     return res;
                  }
	}

//	@GetMapping("/getPendingWorkerForApproval/{organizationCode}")
//	public String getPendingWorkerForApproval(
//			@PathVariable String organizationCode) {
//		return approvalStatusService
//				.getPendingWorkerForApproval(organizationCode);
//	}

	@GetMapping("/getWorkerByWorkerCode/{workerCode}")
	public String getWorkerByWorkerCode(@PathVariable String workerCode,@RequestHeader HttpHeaders headers)
        {        
            String res="";
         
//           Users u=  userRepository.findByUsername(userName);
                res=tokenutility.userValidation(headers, workerCode);
                
                  if(res.equalsIgnoreCase("true"))
                     {
                       return workerService.findWorkerByWorkerCode(workerCode);
                    }else
                  {
                     return res;
                  }
	}

	@GetMapping("/getWorkerApprovalStatusByWorkerCode/{workerCode}")
	public String getWorkerApprovalStatusByWorkerCode(
			@PathVariable String workerCode) {
		return approvalStatusService
				.getWorkerApprovalStatusByWorkerCode(workerCode);
	}
	
	@GetMapping("/getAllWorkerApprovalStatus")
	public String getAllWorkerApprovalStatus() {
		return approvalStatusService.getAllWorkerApprovalStatus();
	}

	@PostMapping("/saveNewWorker")
	public String saveWorker(@RequestBody WorkerRequest workerReq,
			HttpServletRequest httpRequest) {
		if (workerReq != null) {
			 String ip=httpRequest.getRemoteAddr();
			 return workerService.saveWorker(workerReq, ip);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}
	}

	@DeleteMapping("/deleteWorker/{id}")
	public String deleteWorkerById(@PathVariable long id) {
		return workerService.deleteWorkerById(id);
	}

	@DeleteMapping("/deleteWorkerByWorkerCode/{workerCode}")
	public String deleteWorkerByWorkerCode(@PathVariable String workerCode) {
		return workerService.deleteByWorkerCode(workerCode);
	}

	@DeleteMapping("/softDeleteWorkerByWorkerCode/{workerCode}")
	public String softDeleteWorkerByWorkerCode(@PathVariable String workerCode) {
		return workerService.softDeleteByWorkerCode(workerCode);
	}

	@DeleteMapping("/softMultipleDeleteByWorkerCode/{workerCodeList}")
	public String softMultipleDeleteByWorkerCode(
			@PathVariable List<String> workerCodeList) {
		if (workerCodeList != null && workerCodeList.size() > 0) {
			return workerService.softMultipleDeleteByWorkerCode(workerCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

	@PutMapping("/updateWorker/{id}")
	public String updateWorker(@PathVariable Long id,
			@RequestBody WorkerRequest workerReq, HttpServletRequest httpRequest) {
		if (workerReq != null) {
			 String ip=httpRequest.getRemoteAddr();
			return workerService.updateWorker(id, workerReq, ip);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

	@PutMapping("/updateWorkerLogoByWorkerCode/{workerCode}")
	public String updateWorkerLogoByWorkerCode(@PathVariable String workerCode,
			@RequestBody WorkerLogoRequest workerLogoReq,
			HttpServletRequest httpRequest) {
		if (workerLogoReq != null) {
			String ip = httpRequest.getRemoteAddr();
			return workerService.updateWorkerLogoByWorkerCode(workerLogoReq,
					workerCode, ip);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}
                

	}
        @RequestMapping(value = "/getworkerprofiletabsbyworkercode/{workerCode}",method = RequestMethod.GET)
        public String workerProfileTabsByWorkerCode(@PathVariable String workerCode,@RequestHeader HttpHeaders headers)
        {     String res="";
         
//           Users u=  userRepository.findByUsername(userName);
                res=tokenutility.userValidation(headers, workerCode);
                
                  if(res.equalsIgnoreCase("true"))
                  {
                    if(workerCode!=null && workerCode.trim().length()>0)
                    {
                           res=  workerService.getworkerprofileByworkerCode(workerCode);
                    }else
                    {
                       res="WorkerCode Should Not be left blank or Empty";
                    }
                  }else{
                  return res;
                  }
            
        return res;
         
        }
          @PutMapping(value = "/updateworkerprofiletabsbyworkercode/{workerCode}")
        public String workerProfileTabsByWorkerCode(@RequestBody WorkerProfileReq req,@PathVariable String workerCode)
        {  String res ="";
             if(workerCode!=null && workerCode.trim().length()>0 &&req!=null && req.getName()!=null && req.getName().trim().length()>0 && req.getEmail()!=null && req.getEmail().trim().length()>0 && req.getWork_phone()!=null && req.getWork_phone().trim().length()>0 && req.getHome_phone()!=null && req.getHome_phone().trim().length()>0)
             {
               res= workerService.putworkerprofileByworkerCode(req,workerCode);
             }else
             {
               res="WorkerCode ,Name,Email,HomePhone,WorkPhone Should Not be left blank or Empty";
             }
           return res;
        }
       @PutMapping("/updateworkerhomelocationByworkerCode/{workerCode}")
       public String updateWorkerHomeLocationByworkerCode(@RequestBody WorkerHomelocationReq req,@PathVariable String workerCode )
       {  String res="";
             if(req!=null && workerCode!=null && workerCode.trim().length()>0 &&req.getLatitude()!=null && req.getLatitude().trim().length()>0 && req.getLongitude()!=null && req.getLongitude().trim().length()>0 && req.getDistance()!=0 && req.getDistance()>0)
             {
                res=  workerService.updateworkerhomelocationByworkerCode(req,workerCode);
             }else
             {
               res="Latitude ,Longitude ,Distance should not be left blank";
             }
          return res;
       }
           
        @GetMapping("/getworkerhomelocationByworkerCode/{workerCode}")
         public String getWorkerHomeLocationByworkerCode(@PathVariable String workerCode ,@RequestHeader HttpHeaders headers)
         {
             String res ="";
               res=tokenutility.userValidation(headers, workerCode);
                
                  if(res.equalsIgnoreCase("true"))
                  {
                     if(workerCode!=null && workerCode.trim().length()>0)
                      {
                           res=  workerService.getworkerHomelocationByworkerCode(workerCode);
                      }else
                      {
                          res="WorkerCode Should Not be left blank or Empty";
                      }
                  }else
                  {
                    return res;
                  }
          
              return res;
         }
         
       @GetMapping("/getworkerdetailByworkerCode/{workerCode}/{orgCode}")
       public String getWorkerDetailsByworkerCode(@PathVariable String workerCode,@PathVariable String orgCode,@RequestHeader HttpHeaders headers)
       {  String res="";
             res=tokenutility.userValidation(headers, workerCode);
              if(res.equalsIgnoreCase("true"))
              {
                   if(workerCode!=null && workerCode.trim().length()>0 &&orgCode!=null && orgCode.trim().length()>0)
                  {
                       res=  workerService.getworkerdetailsByworkerCode(workerCode,orgCode);
          
                  } else
                  {
                     res="workercode  and orgCode Should not be  Blank";
                 }
              }else
              {
                return res;
              }
          
           return res;
       }
         
      
       @PutMapping("/updateworkerdetailByworkercode/{workerCode}")
      public String updateworkerdetailsByworkerCode(@RequestBody WorkerDetailsReq workerdetailreq,@PathVariable String workerCode)
      {   String res="";
          if(workerCode!=null && workerCode.trim().length()>0)
        {
           res=workerService.UpdateworkerdetailsByworkerCode(workerdetailreq,workerCode);
        }else
          {
              
             res="WorkerCode should not be Blank !!"; 
         }
          return res;
      }
      @GetMapping("/getSkillsByorgCodeAndworkerCode/{workerCode}/{orgCode}")
      public String getSkillsByorgCodeAndworkerCode(@PathVariable String workerCode,@PathVariable String orgCode,@RequestHeader HttpHeaders headers)
      {
          String res="";
             res=tokenutility.userValidation(headers, workerCode);
              if(res.equalsIgnoreCase("true"))
              {
                    if(workerCode!=null && workerCode.trim().length()>0 && orgCode!=null && orgCode.trim().length()>0)
                     {
                    res=   workerService.getSkillsByOrgCodeAndworkerCode(workerCode.trim(),orgCode.trim());
                      }else
                     {
                    res="WorkerCode And orgCode Should not be Blank"; 
                     }
              }else
              {
                return res;
              }
            
      
      return res;
      }
      @GetMapping("/getWorkerProfilePersonalTabforMobileByworkerCode/{workerCode}")
      public String getWorkerProfilePersonalTabforMobileByworkerCode(@PathVariable String workerCode)
      {
          if(workerCode!=null &&workerCode.trim().length()>0 )
          {
            return workerService.getWorkerProfilePersonalTabforMobileByworkerCode(workerCode);
          }else
          {
            GigflexResponse derr = new GigflexResponse(400, new Date(),
					"WorkerCode should not be Blank");
			return derr.toString();
          }
      }
      
        @GetMapping("/getWorkerProfileforMobileByworkerCode/{workerCode}")
      public String getWorkerProfileforMobileByworkerCode(@PathVariable String workerCode)
      {
          if(workerCode!=null &&workerCode.trim().length()>0 )
          {
            return workerService.getWorkerProfileforMobileByworkerCode(workerCode);
          }else
          {
            GigflexResponse derr = new GigflexResponse(400, new Date(),
					"WorkerCode should not be Blank");
			return derr.toString();
          }
      }
      
       @GetMapping("/getWorkerProfileProfessionalTabforMobileByworkerCode/{workerCode}")
      public String getWorkerProfileProfessionalTabforMobileByworkerCode(@PathVariable String workerCode)
      {
          if(workerCode!=null &&workerCode.trim().length()>0 )
          {
            return workerService.getWorkerProfileProfessionalTabforMobileByworkerCode(workerCode);
          }else
          {
            GigflexResponse derr = new GigflexResponse(400, new Date(),
					"WorkerCode should not be Blank");
			return derr.toString();
          }
      }
      //updateWorkerProfileProfessionalTabforMobileByworkerCode
      @PutMapping("/updateworkerProfilePersonelTabByworkerCode/{workerCode}")
      public String updateworkerProfilePersonelTabByworkerCode(@RequestBody WorkerProfileProfessionalTabForMobileRes req,@PathVariable String workerCode)
      {
          if(workerCode!=null && workerCode.trim().length()>0)
          { 
              if(req!=null && req.getName()!=null && req.getName().trim().length()>0 
                           && req.getEmail()!=null && req.getEmail().trim().length()>0 
                           && req.getDob()!=null && req.getDob().trim().length()>0
                           && req.getLatitude()!=null && req.getLatitude().trim().length()>0 
                           && req.getLongitude()!=null && req.getLongitude().trim().length()>0 
                           && req.getAddress()!=null && req.getAddress().trim().length()>0 
                           &&req.getCountry()!=null && req.getCountry().trim().length()>0
                           && req.getCity()!=null && req.getCity().trim().length()>0 
                           &&req.getPostCode()!=null && req.getPostCode().trim().length()>0
                           && req.getMobileNo()!=null && req.getMobileNo().trim().length()>0
                           &&  req.getEmergencyNo()!=null && req.getEmergencyNo().trim().length()>0
                           )
              {
                  if(req.getPassword()!=null && req.getCpassword()!=null)
                  {
                     if(!req.getPassword().equals(req.getCpassword()))
                     {
                      GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Password and ConfirmPassword mismatch");
			return derr.toString();
                     }
                  
                  }
               return  workerService.updateWorkerProfileProfessionalTabforMobileByworkerCode(req,workerCode);       
              }else
              {
               GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Check Mandatory Fields");
			return derr.toString();
              }
             
          }else
          {
           GigflexResponse derr = new GigflexResponse(400, new Date(),
					"WorkerCode should not be Blank");
			return derr.toString();
          }
      }
      @PutMapping("/updateWorkerProfileProfessionalTabforMobileByworkerCode/{workerCode}")
      public String updateWorkerProfileProfessionalTabforMobileByworkerCode(@RequestBody WorkerProfileForMobileReq req,@PathVariable String workerCode)
      {
        if(workerCode!=null && workerCode.trim().length()>0)
        {
           if(req!=null && req.getSkilmaster().size()>0 )
           {
                 return     workerService .UpdateworkerProfilePersonelTabByworkerCode( req, workerCode);
           }else
           {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Skill List should not be empty");
	   return derr.toString();
           }
        }else
        {
           GigflexResponse derr = new GigflexResponse(400, new Date(),"WorkerCode should not be Blank");
	   return derr.toString();
        }
      
      }
//   public String updateworkerProfileForMobileByworkerCode(@RequestBody UpdateWrkrProfileforMobileByworkerCode req,@PathVariable  String workerCode)
//   {
//     if(workerCode!=null && workerCode.trim().length()>0)
//     {
//        if(req!=null && req.getName()!=null && req.getName().trim().length()>0 
//                           && req.getEmail()!=null && req.getEmail().trim().length()>0 
//                           && req.getDob()!=null && req.getDob().trim().length()>0
//                           && req.getAddress()!=null && req.getAddress().trim().length()>0 
//                           &&req.getCountry()!=null && req.getCountry().trim().length()>0
//                           && req.getCity()!=null && req.getCity().trim().length()>0 
//                           &&req.getPostCode()!=null && req.getPostCode().trim().length()>0
//                           && req.getMobileNo()!=null && req.getMobileNo().trim().length()>0
//                           &&  req.getEmergencyNo()!=null && req.getEmergencyNo().trim().length()>0
//                           &&req.getDesignation()!=null && req.getDesignation().trim().length()>0)
//        {
//            
//      return     workerService.updateworkerProfileForMobileByworkerCode(req,workerCode);
//        }else
//        {
//         GigflexResponse derr = new GigflexResponse(400, new Date(),"Check Mandatory Fields");
//			return derr.toString();
//        }
//     }else
//     {
//         GigflexResponse derr = new GigflexResponse(400, new Date(),"WorkerCode not found");
//	   return derr.toString();
//     }
//   }
//  
//   

}
     
