package com.gigflex.prototype.microservices.worker.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.util.Date;

import java.util.UUID;

import javax.persistence.PrePersist;

/**
 * 
 * @author ajit.p
 *
 */
@Entity
@Table(name = "worker")
public class Worker extends CommonAttributes implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    @Column(name = "name")
    private String name;
    @Column(name = "email")
    private String email;
    
//    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
//    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "worker_code", unique = true)
    private String workerCode;
    
    @Column(name = "department_code")
    private String departmentCode;
    
    @Column(name = "phone")
    private String phone;
    @Column(name = "work_phone")
    private String work_phone;
   @Column(name = "home_phone")
    private String home_phone;
    @Column(name = "exp_year")
    private Integer expYear;  
    @Column(name = "exp_month")
    private Integer expMonth;  
    @Column(name = "exp_days")
    private Integer expDays; 

    @Column(name = "qualification")
    private String qualification; 
    
    @Column(name = "external_emp_code")
    private String externalEmpCode; 
    
    @Column(name = "pre_working_hours")
    private String preWorkingHours; 
   
    @Column(name = "isactive")
    private Boolean isActive; 
    
    @Column(name = "worker_status_code")
    private String workerStatusCode;
    
    @Column(name = "worker_logo")
    private String workerLogo;
    @Column(name = "hcountrycode")
    private String homecountryCode;
    @Column(name = "wcountrycode")
    private String workcountryCode;
    @Column(name = "address1")
    private String address1;
     @Column(name = "address2")
    private String address2;
   @Column(name = "zipcode")
    private String zipcode;
    @Column(name = "state")
    private String state;
   @Column(name = "country")
   private String country;
   @Column(name = "city")
   private String city;
   @Column(name = "latitude")
   private String latitude;
   @Column(name = "longitude")
   private String longitude;
  @Column(name = "distance")
  private Long distance;
  
  @Column(name = "language")
  private String language;
  
  @Column(name = "designation")
  private String designation;
  @Column(name = "dob",columnDefinition = "DATE")
   private Date dob;
  
  private String employmentTypeCode;
   @PrePersist
    private void assignUUID() {
        if(this.getWorkerCode()==null || this.getWorkerCode().length()==0)
        {
            this.setWorkerCode(UUID.randomUUID().toString());
        }
    }
    
    
    public Worker() {
		super();
	}

	
    
	public Worker(Long id, String name, String email, String workerCode,
			String departmentCode, String phone, Integer expYear, Integer expMonth,
			Integer expDays, String qualification, String externalEmpCode,
			String preWorkingHours, Boolean isActive, String workerStatusCode,
			String workerLogo) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.workerCode = workerCode;
		this.departmentCode = departmentCode;
		this.phone = phone;
		this.expYear = expYear;
		this.expMonth = expMonth;
		this.expDays = expDays;
		this.qualification = qualification;
		this.externalEmpCode = externalEmpCode;
		this.preWorkingHours = preWorkingHours;
		this.isActive = isActive;
		this.workerStatusCode = workerStatusCode;
		this.workerLogo = workerLogo;
	}

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }


	public Worker(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

    public String getWork_phone() {
        return work_phone;
    }

    public void setWork_phone(String work_phone) {
        this.work_phone = work_phone;
    }

    public String getHome_phone() {
        return home_phone;
    }

    public void setHome_phone(String home_phone) {
        this.home_phone = home_phone;
    }

	public Integer getExpYear() {
		return expYear;
	}

	public void setExpYear(Integer expYear) {
		this.expYear = expYear;
	}

	public Integer getExpMonth() {
		return expMonth;
	}

	public void setExpMonth(Integer expMonth) {
		this.expMonth = expMonth;
	}

	public Integer getExpDays() {
		return expDays;
	}

	public void setExpDays(Integer expDays) {
		this.expDays = expDays;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getExternalEmpCode() {
		return externalEmpCode;
	}

	public void setExternalEmpCode(String externalEmpCode) {
		this.externalEmpCode = externalEmpCode;
	}

	public String getPreWorkingHours() {
		return preWorkingHours;
	}

	public void setPreWorkingHours(String preWorkingHours) {
		this.preWorkingHours = preWorkingHours;
	}

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
	public String getWorkerStatusCode() {
		return workerStatusCode;
	}

	public void setWorkerStatusCode(String workerStatusCode) {
		this.workerStatusCode = workerStatusCode;
	}

	public String getWorkerLogo() {
		return workerLogo;
	}


	public void setWorkerLogo(String workerLogo) {
		this.workerLogo = workerLogo;
	}

    public String getHomecountryCode() {
        return homecountryCode;
    }

    public void setHomecountryCode(String homecountryCode) {
        this.homecountryCode = homecountryCode;
    }

    public String getWorkcountryCode() {
        return workcountryCode;
    }

    public void setWorkcountryCode(String workcountryCode) {
        this.workcountryCode = workcountryCode;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public Long getDistance() {
        return distance;
    }

    public void setDistance(Long distance) {
        this.distance = distance;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getEmploymentTypeCode() {
        return employmentTypeCode;
    }

    public void setEmploymentTypeCode(String employmentTypeCode) {
        this.employmentTypeCode = employmentTypeCode;
    }
    


	@Override
	public String toString() {
		return "Worker [id=" + id + ", name=" + name + ", email=" + email + ", workerCode=" + workerCode
				+ ", departmentCode=" + departmentCode + ", phone=" + phone + ", expYear=" + expYear + ", expMonth="
				+ expMonth + ", expDays=" + expDays + ", qualification=" + qualification + ", externalEmpCode="
				+ externalEmpCode + ", preWorkingHours=" + preWorkingHours + ", isActive=" + isActive
				+ ", workerStatusCode=" + workerStatusCode + "]";
	} 
   
	
   

}