package com.gigflex.prototype.microservices.worker.dtob;

public class WorkerApprovalStatusResponse {
	
    private Long workApprovalStatusId;
	
    private Boolean isApproved;
    
    private String organizationCode;
    
    private String organizationName;


	public Long getWorkApprovalStatusId() {
		return workApprovalStatusId;
	}

	public void setWorkApprovalStatusId(Long workApprovalStatusId) {
		this.workApprovalStatusId = workApprovalStatusId;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	
	

}
