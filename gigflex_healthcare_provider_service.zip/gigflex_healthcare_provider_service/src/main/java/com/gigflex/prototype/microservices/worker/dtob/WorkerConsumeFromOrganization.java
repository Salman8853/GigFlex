/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;

/**
 *
 * @author nirbhay.p
 */
public class WorkerConsumeFromOrganization extends CommonAttributes {

    private Long id;
    private String name;
    private String email;
    private String workerCode;
    private String departmentCode;
    private String phone;

    private int expYear;

    private int expMonth;

    private int expDays;

    private String qualification;

    private String externalEmpCode;

    private String preWorkingHours;

    private Boolean isActive;

    private String workerStatusCode;
    
    private String workerLogo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getExpYear() {
        return expYear;
    }

    public void setExpYear(int expYear) {
        this.expYear = expYear;
    }

    public int getExpMonth() {
        return expMonth;
    }

    public void setExpMonth(int expMonth) {
        this.expMonth = expMonth;
    }

    public int getExpDays() {
        return expDays;
    }

    public void setExpDays(int expDays) {
        this.expDays = expDays;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getExternalEmpCode() {
        return externalEmpCode;
    }

    public void setExternalEmpCode(String externalEmpCode) {
        this.externalEmpCode = externalEmpCode;
    }

    public String getPreWorkingHours() {
        return preWorkingHours;
    }

    public void setPreWorkingHours(String preWorkingHours) {
        this.preWorkingHours = preWorkingHours;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

   

    public String getWorkerStatusCode() {
        return workerStatusCode;
    }

    public void setWorkerStatusCode(String workerStatusCode) {
        this.workerStatusCode = workerStatusCode;
    }

	public String getWorkerLogo() {
		return workerLogo;
	}

	public void setWorkerLogo(String workerLogo) {
		this.workerLogo = workerLogo;
	}

}
