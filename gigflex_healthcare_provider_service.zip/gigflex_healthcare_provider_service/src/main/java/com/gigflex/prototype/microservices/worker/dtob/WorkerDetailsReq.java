/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.dtob;

import java.util.List;

/**
 *
 * @author m.salman
 */
public class WorkerDetailsReq {
    
    private Integer expYear;
    private Integer expMonth;
    List<SkillMasterReq> skilmaster;
    List<CertificationMasterReq> certificationmaster;

    public Integer getExpYear() {
        return expYear;
    }

    public void setExpYear(Integer expYear) {
        this.expYear = expYear;
    }

    public Integer getExpMonth() {
        return expMonth;
    }

    public void setExpMonth(Integer expMonth) {
        this.expMonth = expMonth;
    }

    public List<SkillMasterReq> getSkilmaster() {
        return skilmaster;
    }

    public void setSkilmaster(List<SkillMasterReq> skilmaster) {
        this.skilmaster = skilmaster;
    }

    public List<CertificationMasterReq> getCertificationmaster() {
        return certificationmaster;
    }

    public void setCertificationmaster(List<CertificationMasterReq> certificationmaster) {
        this.certificationmaster = certificationmaster;
    }

   
}
