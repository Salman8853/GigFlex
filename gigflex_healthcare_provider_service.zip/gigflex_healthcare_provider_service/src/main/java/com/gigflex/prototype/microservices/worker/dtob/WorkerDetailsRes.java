/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.dtob;

import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;
import java.util.List;

/**
 *
 * @author m.salman
 */
public class WorkerDetailsRes {
     private String name;
    private String workerCode;
    private Integer expYear;
    private Integer expMonth;
    List<SkillMaster> skilmaster;
    List<CertificationsMaster>  certificationmaster;

    public WorkerDetailsRes() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public Integer getExpYear() {
        return expYear;
    }

    public void setExpYear(Integer expYear) {
        this.expYear = expYear;
    }

    public Integer getExpMonth() {
        return expMonth;
    }

    public void setExpMonth(Integer expMonth) {
        this.expMonth = expMonth;
    }

    public List<SkillMaster> getSkilmaster() {
        return skilmaster;
    }

    public void setSkilmaster(List<SkillMaster> skilmaster) {
        this.skilmaster = skilmaster;
    }

    public List<CertificationsMaster> getCertificationmaster() {
        return certificationmaster;
    }

    public void setCertificationmaster(List<CertificationsMaster> certificationmaster) {
        this.certificationmaster = certificationmaster;
    }

    
}
