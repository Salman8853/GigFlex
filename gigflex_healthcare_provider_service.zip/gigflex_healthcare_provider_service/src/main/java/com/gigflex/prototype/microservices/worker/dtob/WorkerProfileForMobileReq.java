/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.dtob;

import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import java.util.List;

/**
 *
 * @author m.salman
 */
public class WorkerProfileForMobileReq {
       private String workerLogo;
    List<CertificationMasterReq>  certificationmaster;
    List<SkillMasterReq> skilmaster;
    private String employmentTypeCode;
    private List <OrganizationWiseApproval> organizationWiseApprovalList;

    public String getEmploymentTypeCode() {
        return employmentTypeCode;
    }

    public void setEmploymentTypeCode(String employmentTypeCode) {
        this.employmentTypeCode = employmentTypeCode;
    }

    public List<OrganizationWiseApproval> getOrganizationWiseApprovalList() {
        return organizationWiseApprovalList;
    }

    public void setOrganizationWiseApprovalList(List<OrganizationWiseApproval> organizationWiseApprovalList) {
        this.organizationWiseApprovalList = organizationWiseApprovalList;
    }
    
    
 

    public String getWorkerLogo() {
        return workerLogo;
    }

    public void setWorkerLogo(String workerLogo) {
        this.workerLogo = workerLogo;
    }

    public List<SkillMasterReq> getSkilmaster() {
        return skilmaster;
    }

    public void setSkilmaster(List<SkillMasterReq> skilmaster) {
        this.skilmaster = skilmaster;
    }

    public List<CertificationMasterReq> getCertificationmaster() {
        return certificationmaster;
    }

    public void setCertificationmaster(List<CertificationMasterReq> certificationmaster) {
        this.certificationmaster = certificationmaster;
    }

    
}
