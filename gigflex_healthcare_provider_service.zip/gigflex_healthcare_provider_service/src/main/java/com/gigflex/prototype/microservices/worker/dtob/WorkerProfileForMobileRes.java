/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.dtob;

import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import java.util.List;

/**
 *
 * @author m.salman
 */
public class WorkerProfileForMobileRes {
     private String workerLogo;
   
    List<SkillMaster> skilmaster;
    List<CertificationsMasterRes>  certificationmasterResList;
    private String employmentTypeCode;
    private String employmentTypeName;
    private List <OrganizationWiseApproval> organizationWiseApprovalList;

    public String getEmploymentTypeCode() {
        return employmentTypeCode;
    }

    public void setEmploymentTypeCode(String employmentTypeCode) {
        this.employmentTypeCode = employmentTypeCode;
    }

    public String getEmploymentTypeName() {
        return employmentTypeName;
    }

    public void setEmploymentTypeName(String employmentTypeName) {
        this.employmentTypeName = employmentTypeName;
    }

    public List<OrganizationWiseApproval> getOrganizationWiseApprovalList() {
        return organizationWiseApprovalList;
    }

    public void setOrganizationWiseApprovalList(List<OrganizationWiseApproval> organizationWiseApprovalList) {
        this.organizationWiseApprovalList = organizationWiseApprovalList;
    }
    

    public String getWorkerLogo() {
        return workerLogo;
    }

    public void setWorkerLogo(String workerLogo) {
        this.workerLogo = workerLogo;
    }

  

    public List<SkillMaster> getSkilmaster() {
        return skilmaster;
    }

    public void setSkilmaster(List<SkillMaster> skilmaster) {
        this.skilmaster = skilmaster;
    }

    public List<CertificationsMasterRes> getCertificationmasterResList() {
        return certificationmasterResList;
    }

    public void setCertificationmasterResList(List<CertificationsMasterRes> certificationmasterResList) {
        this.certificationmasterResList = certificationmasterResList;
    }

    
}
