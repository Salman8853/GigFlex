/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.dtob;

/**
 *
 * @author m.salman
 */
public class WorkerProfileReq {
      
    private String name;
    private String email;
    private String work_phone;
    private String home_phone;
    private String homecountryCode;
    private String workcountryCode;
    private String workerLogo;
    public WorkerProfileReq() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWork_phone() {
        return work_phone;
    }

    public void setWork_phone(String work_phone) {
        this.work_phone = work_phone;
    }

    public String getHome_phone() {
        return home_phone;
    }

    public void setHome_phone(String home_phone) {
        this.home_phone = home_phone;
    }

    public String getHomecountryCode() {
        return homecountryCode;
    }

    public void setHomecountryCode(String homecountryCode) {
        this.homecountryCode = homecountryCode;
    }

    public String getWorkcountryCode() {
        return workcountryCode;
    }

    public void setWorkcountryCode(String workcountryCode) {
        this.workcountryCode = workcountryCode;
    }

    public String getWorkerLogo() {
        return workerLogo;
    }

    public void setWorkerLogo(String workerLogo) {
        this.workerLogo = workerLogo;
    }

   
}
