/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.worker.dtob;

import java.util.Date;

/**
 *
 * @author amit.kumar
 */
public class WorkerRes {
    
     
    private Long id;      
    private String name;    
    private String email;
    private String workerCode; 
    private String departmentCode;  
    private String phone;
    private String work_phone;
    private String home_phone;
    private Integer expYear;  
    private Integer expMonth;  
    private Integer expDays; 
    private String qualification; 
    private String externalEmpCode; 
    private String preWorkingHours; 
    private Boolean isActive; 
    private String workerStatusCode;
    private String workerLogo;
    private String homecountryCode;
    private String workcountryCode;
    private String address1;
    private String address2;
    private String zipcode;
    private String state;
    private String country;
    private String city;
    private String latitude;
    private String longitude;
    private Long distance;
    private String language;
    private String designation;      
    private Date dob;
    private String employmentTypeCode;
    private String employmentTypeName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getWork_phone() {
        return work_phone;
    }

    public void setWork_phone(String work_phone) {
        this.work_phone = work_phone;
    }

    public String getHome_phone() {
        return home_phone;
    }

    public void setHome_phone(String home_phone) {
        this.home_phone = home_phone;
    }

    public Integer getExpYear() {
        return expYear;
    }

    public void setExpYear(Integer expYear) {
        this.expYear = expYear;
    }

    public Integer getExpMonth() {
        return expMonth;
    }

    public void setExpMonth(Integer expMonth) {
        this.expMonth = expMonth;
    }

    public Integer getExpDays() {
        return expDays;
    }

    public void setExpDays(Integer expDays) {
        this.expDays = expDays;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getExternalEmpCode() {
        return externalEmpCode;
    }

    public void setExternalEmpCode(String externalEmpCode) {
        this.externalEmpCode = externalEmpCode;
    }

    public String getPreWorkingHours() {
        return preWorkingHours;
    }

    public void setPreWorkingHours(String preWorkingHours) {
        this.preWorkingHours = preWorkingHours;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public String getWorkerStatusCode() {
        return workerStatusCode;
    }

    public void setWorkerStatusCode(String workerStatusCode) {
        this.workerStatusCode = workerStatusCode;
    }

    public String getWorkerLogo() {
        return workerLogo;
    }

    public void setWorkerLogo(String workerLogo) {
        this.workerLogo = workerLogo;
    }

    public String getHomecountryCode() {
        return homecountryCode;
    }

    public void setHomecountryCode(String homecountryCode) {
        this.homecountryCode = homecountryCode;
    }

    public String getWorkcountryCode() {
        return workcountryCode;
    }

    public void setWorkcountryCode(String workcountryCode) {
        this.workcountryCode = workcountryCode;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public Long getDistance() {
        return distance;
    }

    public void setDistance(Long distance) {
        this.distance = distance;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getEmploymentTypeName() {
        return employmentTypeName;
    }

    public void setEmploymentTypeName(String employmentTypeName) {
        this.employmentTypeName = employmentTypeName;
    }

    public String getEmploymentTypeCode() {
        return employmentTypeCode;
    }

    public void setEmploymentTypeCode(String employmentTypeCode) {
        this.employmentTypeCode = employmentTypeCode;
    }
    
    
}
