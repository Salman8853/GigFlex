package com.gigflex.prototype.microservices.worker.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.util.SearchCriteria;
import com.gigflex.prototype.microservices.worker.dtob.Worker;



public class WorkerSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public WorkerSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public WorkerSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<Worker> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<Worker>> specs = new ArrayList<Specification<Worker>>();
        for (SearchCriteria param : params) {
            specs.add(new WorkerSpecification(param));
        }
 
        Specification<Worker> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
