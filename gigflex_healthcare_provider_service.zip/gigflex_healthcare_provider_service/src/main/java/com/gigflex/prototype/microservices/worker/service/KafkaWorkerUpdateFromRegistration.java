package com.gigflex.prototype.microservices.worker.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;

@Service
public class KafkaWorkerUpdateFromRegistration {
	
	 private Worker worker;

		@Autowired
		WorkerRepository workerRepository;
		
		@Autowired
		UserRepository userRepository;
		
	    private static final Logger LOG = LoggerFactory.getLogger(KafkaWorkerUpdateFromRegistration.class);
	    
	    @KafkaListener(topics = "UpdateWorkerFromRegistration")
	    public void listen(@Payload String message) {
			ObjectMapper objectMapper = new ObjectMapper();
			LOG.info("received message='{}'", message);
			try {
				Worker workerReq = objectMapper.readValue(message, Worker.class);
				Worker workerInDb=workerRepository.findByWorkerCode(worker.getWorkerCode());
				if(workerInDb!=null && workerInDb.getId()>0)
                {
					Users user=userRepository.findByUserCode(workerReq.getWorkerCode());
                    if(workerInDb!=null && workerInDb.getId()>0)
                    {
                    	workerInDb.setName(workerReq.getName());
            			workerInDb.setEmail(workerReq.getEmail());
            			workerInDb.setDepartmentCode(workerReq.getDepartmentCode());
            			workerInDb.setPhone(workerReq.getPhone());
            			workerInDb.setExpYear(workerReq.getExpYear());
            			workerInDb.setExpMonth(workerReq.getExpMonth());
            			workerInDb.setExpDays(workerReq.getExpDays());
            			workerInDb.setQualification(workerReq.getQualification());
            			workerInDb.setExternalEmpCode(workerReq.getExternalEmpCode());
            			workerInDb.setPreWorkingHours(workerReq.getPreWorkingHours());
            			workerInDb.setIsActive(workerReq.getIsActive());
            			workerInDb.setWorkerStatusCode(workerReq.getWorkerStatusCode());
            			workerInDb.setIpAddress(workerReq.getIpAddress());
            			workerInDb.setWorkerLogo(workerReq.getWorkerLogo());
                        workerInDb.setIsDeleted(workerReq.getIsDeleted());
                        
		workerRepository.save(workerInDb);
                    }
                    if(user!=null && user.getId()>0)
                    {
                        user.setIsActive(workerReq.getIsActive());
                        user.setName(workerReq.getName());
                        user.setEmail(workerReq.getEmail());
                        userRepository.save(user);
                    }
                }
			} catch (JsonParseException e) {
				LOG.error("In KafkaWorkerUpdateFromRegistration >>>>", e);
			} catch (JsonMappingException e) {
				LOG.error("In KafkaWorkerUpdateFromRegistration >>>>", e);
			} catch (IOException e) {
				LOG.error("In KafkaWorkerUpdateFromRegistration >>>>", e);
			}catch (Exception e) {
				LOG.error("In KafkaWorkerUpdateFromRegistration >>>>", e);
			}
	    }
}
