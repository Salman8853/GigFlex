package com.gigflex.prototype.microservices.worker.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.certificationsmaster.repository.CertificationsMasterRepository;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.employmenttype.dtob.EmploymentType;
import com.gigflex.prototype.microservices.employmenttype.repository.EmploymentTypeRepository;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.service.HealthcareNotificationService;
import com.gigflex.prototype.microservices.jobs.repository.JobsAssignToWorkerRepository;
import com.gigflex.prototype.microservices.jobs.service.AssignJobToWorkerDynamicDistanceWorkerAddressThread;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organizationskill.repository.OrganizationSkillDao;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.repository.OrgWorkerSkillDao;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.skillmaster.repository.SkillMasterDao;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.util.TokenUtility;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.verifyemployee.repository.WorkerApprovalStatusRepository;


import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.dtob.WorkerApprovalStatusResponse;
import com.gigflex.prototype.microservices.worker.dtob.WorkerDetailsReq;

import com.gigflex.prototype.microservices.worker.dtob.WorkerDetailsRes;
import com.gigflex.prototype.microservices.worker.dtob.WorkerHomelocationReq;
import com.gigflex.prototype.microservices.worker.dtob.WorkerLogoRequest;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileReq;
import com.gigflex.prototype.microservices.workeroffdays.dtob.WorkerOffdays;
import com.gigflex.prototype.microservices.worker.dtob.WorkerRequest;
import com.gigflex.prototype.microservices.worker.dtob.WorkerResponse;
import com.gigflex.prototype.microservices.workerworkinghours.dtob.WorkerWorkingHours;
import com.gigflex.prototype.microservices.worker.dtob.CertificationMasterReq;
import com.gigflex.prototype.microservices.worker.dtob.CertificationsMasterRes;
import com.gigflex.prototype.microservices.worker.dtob.OrganizationWiseApproval;
import com.gigflex.prototype.microservices.worker.dtob.SkillMasterReq;
import com.gigflex.prototype.microservices.worker.dtob.UpdateWrkrProfileforMobileByworkerCode;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileForMobileReq;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileForMobileRes;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileProfessionalTabForMobileRes;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.worker.search.WorkerSpecificationsBuilder;
import com.gigflex.prototype.microservices.workeroffdays.service.WorkerOffdaysService;
import com.gigflex.prototype.microservices.worker.service.WorkerService;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;
import com.gigflex.prototype.microservices.workercertifications.repository.WorkerCertificationsRepository;
import com.gigflex.prototype.microservices.workerworkinghours.service.WorkerWorkingHoursService;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * 
 * @author ajit.p
 *
 */
@Service
public class WorkerServiceImpl implements WorkerService {

	private static final Logger LOG = LoggerFactory
			.getLogger(WorkerServiceImpl.class);
        @Autowired
         KafkaService kafkaService;
                
	@Autowired
	WorkerRepository workerRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	WorkerApprovalStatusRepository wasRepository;

	@Autowired
	OrganizationRepository orgRepository;

	@Autowired
	WorkerOffdaysService workerOffdaysservice;

	@Autowired
	WorkerWorkingHoursService workerWorkingHourService;
	@Autowired
        SkillMasterDao skillmaster;
        @Autowired
        CertificationsMasterRepository certfktmaster;
        @Autowired
        WorkerCertificationsRepository wrkrcertfkt;
        @Autowired
        OrgWorkerSkillDao orgworkerskill;
        @Autowired
        OrganizationSkillDao orgskilldao;
        @Autowired
        TokenUtility tokenUtility;
        @Autowired
        BCryptPasswordEncoder bCryptPasswordEncoder;
        
        @Autowired
	private SkillMasterDao skillMasterDao;
        @Autowired
        EmploymentTypeRepository employmentTypeRepository;
        @Autowired
        WorkerApprovalStatusRepository workerApprovalStatusRepository;
        
        @Autowired
    TimeZoneRepository timeZoneDao;

    @Autowired
    GlobalSettingRepository globalSettingRepository;
    @Autowired
    LocalSettingRepository localSettingRepository;
    @Autowired
    UserTypeRepository utr;
        
	private static final Logger logger = LoggerFactory.getLogger(Worker.class);

        @Autowired
        private HealthcareNotificationService notificationService;
        
         @Autowired
    JobsAssignToWorkerRepository jobsAssignToWorkerRepository;
         
         @Value("${google.api.key}")
    private String googleKey; 
        
	@Override
	public String getAllWorkers() {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//
//			List<Object> objlst = workerRepository.getAllWorkersWithApprovedAndId();
//			List<WorkerResponse> maplst = new ArrayList<WorkerResponse>();
//			if (objlst != null && objlst.size() > 0) {
//				for (int i = 0; i < objlst.size(); i++) {
//					Object[] arr = (Object[]) objlst.get(i);
//					if (arr.length >= 3) {
//						WorkerResponse workerInDb = new WorkerResponse();
//
//						Worker data = (Worker) arr[0];
//
//						workerInDb.setId(data.getId());
//						workerInDb.setWorkerCode(data.getWorkerCode());
//						workerInDb.setName(data.getName());
//						workerInDb.setEmail(data.getEmail());
//						workerInDb.setDepartmentCode(data.getDepartmentCode());
//						workerInDb.setPhone(data.getPhone());
//						workerInDb.setExpYear(data.getExpYear());
//						workerInDb.setExpMonth(data.getExpMonth());
//						workerInDb.setExpDays(data.getExpDays());
//						workerInDb.setQualification(data.getQualification());
//						workerInDb.setExternalEmpCode(data.getExternalEmpCode());
//						workerInDb.setPreWorkingHours(data.getPreWorkingHours());
//						workerInDb.setIsActive(data.getIsActive());
//						workerInDb.setWorkerStatusCode(data.getWorkerStatusCode());
//						workerInDb.setWorkerLogo(data.getWorkerLogo());
//						
//						workerInDb.setWorkApprovalStatusId((Long) arr[1]);
//
//						workerInDb.setIsApproved((Boolean) arr[2]);
//
//						maplst.add(workerInDb);
//
//					}
//				}
//				if (maplst.size() > 0) {
//					ObjectMapper mapperObj = new ObjectMapper();
//					String Detail = mapperObj.writeValueAsString(maplst);
//					jsonobj.put("responsecode", 200);
//					jsonobj.put("message", "Success");
//					jsonobj.put("timestamp", new Date());
//					jsonobj.put("data", new JSONArray(Detail));
//				} else {
//					jsonobj.put("responsecode", 404);
//					jsonobj.put("message", "Record Not Found");
//					jsonobj.put("timestamp", new Date());
//				}
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found");
//				jsonobj.put("timestamp", new Date());
//			}
//
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		}
//		return res;
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerResponse> maplst = new ArrayList<WorkerResponse>();

			List<Worker> workerlst = workerRepository.getAllWorkers();
			
			if (workerlst != null && workerlst.size() > 0) {
				for(Worker worker : workerlst){

					List<Object> wasList = workerRepository.findWorkerApprovalStatusByWorkerCode(worker.getWorkerCode());
					if (wasList != null && wasList.size() > 0) {
						
						WorkerResponse workerInDb = new WorkerResponse();
						workerInDb.setWorker(worker);
						List<WorkerApprovalStatusResponse> waslst = new ArrayList<WorkerApprovalStatusResponse>();
						for (int i = 0; i < wasList.size(); i++) {
							Object[] arr = (Object[]) wasList.get(i);
							if (arr.length >= 2) {
								WorkerApprovalStatus was = (WorkerApprovalStatus) arr[0];
							WorkerApprovalStatusResponse wasr = new WorkerApprovalStatusResponse();
							wasr.setIsApproved(was.getIsApproved());
							wasr.setWorkApprovalStatusId(was.getId());
						    wasr.setOrganizationCode(was.getOrganization_Code());
						    wasr.setOrganizationName((String) arr[1]);

						    waslst.add(wasr);
							
						}
						workerInDb.setWorkerApprovalStatusResponseList(waslst);
						maplst.add(workerInDb);
					}
				}
				if(maplst.size() > 0){
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());
			}
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} 
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in getAllWorkers.");
			res = derr.toString();
		}
		logger.info("Output is" + res);
		return res;
	}

	@Override
	public String getWorkerById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Worker workerData = workerRepository.getWorkerById(id);
			if (workerData != null && workerData.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerData);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		}
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveWorker(WorkerRequest workerReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (workerReq != null) {
				Worker workerInDb = new Worker();

				workerInDb.setName(workerReq.getName());
				workerInDb.setEmail(workerReq.getEmail());
				workerInDb.setDepartmentCode(workerReq.getDepartmentCode());
				workerInDb.setPhone(workerReq.getPhone());
				workerInDb.setExpYear(workerReq.getExpYear());
				workerInDb.setExpMonth(workerReq.getExpMonth());
				workerInDb.setExpDays(workerReq.getExpDays());
				workerInDb.setQualification(workerReq.getQualification());
				workerInDb.setExternalEmpCode(workerReq.getExternalEmpCode());
				workerInDb.setPreWorkingHours(workerReq.getPreWorkingHours());
				workerInDb.setIsActive(workerReq.getIsActive());
				workerInDb.setWorkerStatusCode(workerReq.getWorkerStatusCode());
				workerInDb.setIpAddress(ip);
				workerInDb.setWorkerLogo(workerReq.getWorkerLogo());

				Worker workerResponse = workerRepository.save(workerInDb);

				if (workerResponse != null && workerResponse.getId() > 0) {
					WorkerOffdays workOffdays = new WorkerOffdays();
					WorkerWorkingHours workWorkingHours = new WorkerWorkingHours();
					workOffdays.setWorkerCode(workerResponse.getWorkerCode());
					workerOffdaysservice.saveWorkerOffdays(workOffdays);
					workWorkingHours.setWorkerCode(workerResponse
							.getWorkerCode());
					workerWorkingHourService
							.saveWorkerWorkingHours(workWorkingHours);
                                        
                                        
                                        HealthcareNotification notification = new HealthcareNotification();

                                        String workerName = workerResponse.getName();
                                    
                                        String bodyContentShortMessage = "Worker has been added successfully.Details are given below-"
                                                    + "Worker Name : "+workerName; 
                                    
                                        String shortMessage = "Worker"+workerName+" has been added successfully.";

                                        notification.setUserCode(workerResponse.getWorkerCode());
                                        notification.setMessage(bodyContentShortMessage);
                                        notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                                        notification.setShortMessage(shortMessage);
                                        notification.setAppointmentCode("");
                                        notification.setIsRead(Boolean.FALSE);
                                        notification.setIpAddress(ip);

                                        notificationService.saveHealthcareNotification(notification);
                                        
                                        
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Worker has been added successfully.");
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj
							.writeValueAsString(workerResponse);
					jsonobj.put("data", new JSONObject(Detail));
//					kafkaService.sendAddWorker(workerResponse);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Worker has been not added successfully.");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in Worker table.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String deleteWorkerById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<Worker> workerData = workerRepository.findById(id);
			if (workerData.isPresent() && workerData.get() != null) {
				workerRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker has been deleted.");
//				kafkaService.sendDeleteWorker(workerData.get());
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
			}
			jsonobj.put("timestamp", new Date());
			res = jsonobj.toString();
		} 
                catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in Worker table.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String updateWorker(Long id, WorkerRequest workerReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			Worker workerlst = workerRepository.getWorkerById(id);
			if (workerlst != null && workerlst.getId() > 0) {
				Worker workerInDb = workerlst;

				workerInDb.setName(workerReq.getName());
				workerInDb.setEmail(workerReq.getEmail());
				workerInDb.setDepartmentCode(workerReq.getDepartmentCode());
				workerInDb.setPhone(workerReq.getPhone());
				workerInDb.setExpYear(workerReq.getExpYear());
				workerInDb.setExpMonth(workerReq.getExpMonth());
				workerInDb.setExpDays(workerReq.getExpDays());
				workerInDb.setQualification(workerReq.getQualification());
				workerInDb.setExternalEmpCode(workerReq.getExternalEmpCode());
				workerInDb.setPreWorkingHours(workerReq.getPreWorkingHours());
				workerInDb.setIsActive(workerReq.getIsActive());
				workerInDb.setWorkerStatusCode(workerReq.getWorkerStatusCode());
				workerInDb.setIpAddress(ip);
				workerInDb.setWorkerLogo(workerReq.getWorkerLogo());

				Worker workerData = workerRepository.save(workerInDb);
				if (workerData != null) {
                                    try{
                                    HealthcareNotification notification = new HealthcareNotification();
                                    String workerName = workerData.getName();
                                    String bodyContentShortMessage = "Worker has been updated successfully.Details are given below-"
                                    + "Worker Name : "+workerName; 
                                    
                                    String shortMessage = "Worker"+workerName+" has been updated successfully.";

                                    notification.setUserCode(workerData.getWorkerCode());
                                    notification.setMessage(bodyContentShortMessage);
                                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                                    notification.setShortMessage(shortMessage);
                                    notification.setAppointmentCode("");
                                    notification.setIsRead(Boolean.FALSE);
                                    notification.setIpAddress(ip);

                                    notificationService.saveHealthcareNotification(notification);
                                    }catch(Exception ee)
                                    {
                                        ee.printStackTrace();
                                    }
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Worker updated successfully");
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(workerData);
                                    jsonobj.put("data", new JSONObject(Detail));
                                    kafkaService.sendWorkerForUpdate(workerData);
                            } else {
                                    jsonobj.put("responsecode", 400);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Worker is not updated successfully");
                            }
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker is not found for update");
			}
			res = jsonobj.toString();
		} 
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in Worker table.");
			res = derr.toString();
		}
		return res;

	}

	@Override
	public String findWorkerByWorkerCode(String workerCode) {
		String res = "";
//                String userName = tokenUtility.getUserNameFromToken(oldtoken);
             
                       try {
			JSONObject jsonobj = new JSONObject();
//                        Users u= userRepository.findByUsername(userName);
                       
                        
                        Worker workerlst = workerRepository.findByWorkerCode(workerCode);
                        if (workerlst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerlst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
                      
			
		  } catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		  } catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Worker worker = workerRepository.findByWorkerCode(workerCode);
			Integer deleteByWorkerCode = workerRepository
					.deleteByWorkerCode(workerCode);
			if (deleteByWorkerCode != 0 && worker != null && worker.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker has been deleted.");
				jsonobj.put("timestamp", new Date());
//				kafkaService.sendDeleteWorker(worker);
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} 
                catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getOrganizationByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerCode != null && workerCode.trim().length() > 0) {
				List<Object> workerlst = workerRepository
						.getOrganizationByWorkerCode(workerCode);
				if (workerlst != null && workerlst.size() > 0) {
					JSONArray jarr = new JSONArray();
					int cnt = 0;
					for (int i = 0; i < workerlst.size(); i++) {
						Object arr[] = (Object[]) workerlst.get(i);
						if (arr.length >= 3) {
							cnt++;
							JSONObject jSONObject = new JSONObject();
							jSONObject.put("organizationCode",
									arr[0].toString());
							jSONObject.put("organizationName",
									arr[1].toString());
                                                        if(arr[2]!=null)
                                                        {
                                                           jSONObject.put("color",
									arr[2]); 
                                                        }else
                                                        {
                                                          jSONObject.put("color",
									""); 
                                                        }
							jarr.add(jSONObject);
						}
					}
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Success");
					jsonobj.put("organizationCount", cnt);
					jsonobj.put("data", jarr);

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Code should not be blank.");
			}
			res = jsonobj.toString();
		} 
                catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateWorkerLogoByWorkerCode(WorkerLogoRequest workerLogoReq,
			String workerCode, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerLogoReq != null) {
				if (workerLogoReq.getWorkerLogo() != null
						&& workerLogoReq.getWorkerLogo().length() > 0) {
					Worker worker = workerRepository
							.findByWorkerCode(workerCode);
					if (worker != null) {

						worker.setWorkerLogo(workerLogoReq.getWorkerLogo());
						worker.setIpAddress(ip);

						Worker workerRes = workerRepository.save(worker);
						if (workerRes != null && workerRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"Worker Logo updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(workerRes);
							jsonobj.put("data", new JSONObject(Detail));
							 kafkaService.sendWorkerForUpdate(workerRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Worker Logo updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Worker Code is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Worker Logo should not be blank");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByWorkerCode(String workerCode) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Worker worker = workerRepository.findByWorkerCode(workerCode);
			if (worker != null && worker.getId() > 0) {

				Users user = userRepository.findByUserCode(workerCode);
				if (user != null && user.getId() > 0
						&& user.getIsOwner() == true) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Owner should not be deleted");

				} else {

					worker.setIsDeleted(true);
					Worker wrkRes = workerRepository.save(worker);

					if (wrkRes != null && wrkRes.getId() > 0) {

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Worker deleted successfully.");
						kafkaService.sendWorkerForUpdate(wrkRes);
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteByWorkerCode>>>>>>", ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteByWorkerCode>>>>>>", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByWorkerCode(List<String> workerCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String workerCode : workerCodeList) {
				if (workerCode != null && workerCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					workerCode = workerCode.trim();

					Worker worker = workerRepository
							.findByWorkerCode(workerCode);

					if (worker != null && worker.getId() > 0) {

						try {

							Users user = userRepository
									.findByUserCode(workerCode);
							if (user != null && user.getId() > 0
									&& user.getIsOwner() == true) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", workerCode);
								jsonobj.put("message",
										"Owner should not be deleted");

							} else {
								worker.setIsDeleted(true);
								Worker wrkRes = workerRepository.save(worker);
								if (wrkRes != null && wrkRes.getId() > 0) {
									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("code", workerCode);
									jsonobj.put("message",
											"Worker deleted successfully.");
								kafkaService.sendWorkerForUpdate(wrkRes);
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("code", workerCode);
									jsonobj.put("message", "Failed");
								}
							}

						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", workerCode);
							jsonobj.put("message", GigUtil.getRootException(ex));
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", workerCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllWorkersByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerResponse> maplst = new ArrayList<WorkerResponse>();

			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Worker> workerlst = workerRepository
					.getAllWorkers(pageableRequest);
			if (workerlst != null && workerlst.size() > 0) {
				for(Worker worker : workerlst){

					List<Object> wasList = workerRepository.findWorkerApprovalStatusByWorkerCode(worker.getWorkerCode());
					if (wasList != null && wasList.size() > 0) {
						
						WorkerResponse workerInDb = new WorkerResponse();
						workerInDb.setWorker(worker);
						List<WorkerApprovalStatusResponse> waslst = new ArrayList<WorkerApprovalStatusResponse>();
						for (int i = 0; i < wasList.size(); i++) {
							Object[] arr = (Object[]) wasList.get(i);
							if (arr.length >= 2) {
								WorkerApprovalStatus was = (WorkerApprovalStatus) arr[0];
							WorkerApprovalStatusResponse wasr = new WorkerApprovalStatusResponse();
							wasr.setIsApproved(was.getIsApproved());
							wasr.setWorkApprovalStatusId(was.getId());
						    wasr.setOrganizationCode(was.getOrganization_Code());
						    wasr.setOrganizationName((String) arr[1]);

						    waslst.add(wasr);
							
						}
						workerInDb.setWorkerApprovalStatusResponseList(waslst);
						maplst.add(workerInDb);
					}
				}
				if(maplst.size() > 0){
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());
			}
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in getAllWorkers.");
			res = derr.toString();
		}
		logger.info("Output is" + res);
		return res;
	}

	@Override
	public String getOrganizationByWorkerCode(String workerCode, int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (workerCode != null && workerCode.trim().length() > 0) {
				List<Object> workerlst = workerRepository
						.getOrganizationByWorkerCode(workerCode,
								pageableRequest);
				if (workerlst != null && workerlst.size() > 0) {
					JSONArray jarr = new JSONArray();
					int cnt = 0;
					for (int i = 0; i < workerlst.size(); i++) {
						Object arr[] = (Object[]) workerlst.get(i);
						if (arr.length >= 3) {
							cnt++;
							JSONObject jSONObject = new JSONObject();
							jSONObject.put("organizationCode",
									arr[0].toString());
							jSONObject.put("organizationName",
									arr[1].toString());
                                                            if(arr[2]!=null)
                                                        {
                                                           jSONObject.put("color",
									arr[2].toString()); 
                                                        }else
                                                        {
                                                          jSONObject.put("color",
									""); 
                                                        }
							jarr.add(jSONObject);
						}
					}
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Success");
					jsonobj.put("organizationCount", cnt);
					jsonobj.put("data", jarr);

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Code should not be blank.");
			}
			res = jsonobj.toString();
		} 
                catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				WorkerSpecificationsBuilder builder = new WorkerSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<Worker> spec = builder.build();
				if (spec != null) {
					List<Worker> workerlst = workerRepository.findAll(spec);
					if (workerlst != null && workerlst.size() > 0) {
						for (Worker worker : workerlst) {
							if (worker.getIsDeleted() != null
									&& worker.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(worker);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew
										.put("worker", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
	}
        @Override
        public String getworkerprofileByworkerCode(String workerCode)
        {    String res = "";
           try{
              JSONObject jsonobj = new JSONObject();
              Worker worker=workerRepository.getWorkerProfileTabsByworkerCode(workerCode);
              if(worker!=null && workerCode!=null && workerCode.length()>0 && worker.getId()>0)
              {
                  WorkerProfileReq response=new WorkerProfileReq();
                   response.setName(worker.getName());
                   response.setEmail(worker.getEmail());
                    response.setHome_phone(worker.getHome_phone());
                     response.setWork_phone(worker.getWork_phone());
                     response.setHomecountryCode(worker.getHomecountryCode());
                     response.setWorkcountryCode(worker.getWorkcountryCode());
                    response.setWorkerLogo(worker.getWorkerLogo());
                     
                   jsonobj.put("responsecode", 200);
	           jsonobj.put("timestamp", new Date());
	           jsonobj.put("message", "OK");
                      ObjectMapper mapperObj = new ObjectMapper();
	              String Detail = mapperObj.writeValueAsString(response);
                      jsonobj.put("data", new JSONObject(Detail) );
                    
                   
              }
              else
              {
                  jsonobj.put("responsecode", 404);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", "Data not found");
              }
               res =jsonobj.toString();
           }
           catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
           catch(Exception ex)
           {
               GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
              ex.printStackTrace();
           }
          
            return res;
        }
        @Override
        public String putworkerprofileByworkerCode(WorkerProfileReq req,String workerCode)
        {
               String res ="";
                try{
                     JSONObject jsonobj = new JSONObject();
                     
                    
             
                
                   Worker worker= workerRepository.getWorkerProfileTabsByworkerCode(workerCode);
                    if(worker!=null && worker.getId()>0)
                    {
                        
                        worker.setName(req.getName());
                        worker.setEmail(req.getEmail());
                        worker.setHome_phone(req.getHome_phone().trim());
                        worker.setWork_phone(req.getWork_phone().trim());
                        worker.setHomecountryCode(req.getHomecountryCode());
                        worker.setWorkcountryCode(req.getWorkcountryCode());
                        worker.setWorkerLogo(req.getWorkerLogo());
                      Worker wrk= workerRepository.save(worker);
                       if(wrk!=null && wrk.getId()>0)
                       {
                           kafkaService.sendWorkerForUpdate(wrk);
                           Users users=userRepository.findByUserCode(worker.getWorkerCode());
       
                if(users!=null && users.getId()>0)
                {
                  users.setName(req.getName());
                  users.setEmail(req.getEmail());  
                   
                    Users user= userRepository.save(users);
                     if(user!=null && user.getId()>0)
                     {
                     kafkaService.sendUpdateUser(user);
                     }
                }
                         jsonobj.put("responsecode", 200);
	                 jsonobj.put("timestamp", new Date());
	                 jsonobj.put("message", "Worker Profile Updated Successfully.");
                         ObjectMapper mapperObj = new ObjectMapper();
	                 String Detail = mapperObj.writeValueAsString(wrk);
                         jsonobj.put("data", new JSONObject(Detail) );
                       }else
                       {
                             jsonobj.put("responsecode", 404);
	                     jsonobj.put("timestamp", new Date());
	                     jsonobj.put("message", " Record is not Updated ");
                       }
                    res=jsonobj.toString();
                       
                    }else
                    {
                       jsonobj.put("responsecode", 404);
	               jsonobj.put("timestamp", new Date());
	               jsonobj.put("message", " Record Not Found");
                    }
                res =jsonobj.toString();
                } 
                catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
                return res;
        }
        @Override
        public String updateworkerhomelocationByworkerCode(WorkerHomelocationReq req,String workerCode)
        {
            String res ="";
            
            try{
            JSONObject jsonobj = new JSONObject();
             Worker worker= workerRepository.getWorkerProfileTabsByworkerCode(workerCode);
             if(worker!=null && worker.getId()>0)
             {
                 String oldlat=worker.getLatitude();
                 String oldlong=worker.getLongitude();
               worker.setAddress1(req.getAddress1());
               worker.setAddress2(req.getAddress2());
               worker.setZipcode(req.getZipcode());
               worker.setState(req.getState());
               worker.setCountry(req.getCountry());
               worker.setCity(req.getCity());
               worker.setLatitude(req.getLatitude());
               worker.setLongitude(req.getLongitude());
               worker.setDistance(req.getDistance());
               Worker wrkr= workerRepository.save(worker);
                if(wrkr!=null && wrkr.getId()>0 )
                {
                    if(oldlat==null || oldlong==null || !oldlat.equalsIgnoreCase(req.getLatitude()) || !oldlong.equalsIgnoreCase(req.getLongitude()))
                    {
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician,workerCode , GigflexConstants.TimeZone);
                            String timezone = null;
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getId() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                            startAssignJobToWorkerDynamicDistanceWorkerAddressThread( wrkr,new Date(), timezone);
                           
                    }
                    kafkaService.sendWorkerForUpdate(wrkr);
                         jsonobj.put("responsecode", 200);
	                 jsonobj.put("timestamp", new Date());
	                 jsonobj.put("message", "Home Location Updated Successfully.");
                        ObjectMapper mapperObj = new ObjectMapper();
	                String Detail = mapperObj.writeValueAsString(wrkr);
                         jsonobj.put("data", new JSONObject(Detail) );
                }else
                {
                             jsonobj.put("responsecode", 404);
	                     jsonobj.put("timestamp", new Date());
	                     jsonobj.put("message", " Record is not Updated ");
                }
                 res=jsonobj.toString();
                 
             }else
             {
                  jsonobj.put("responsecode", 404);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", " Record Does Not Exist..!!");
             }
            res=jsonobj.toString();
            }
            catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
            catch(Exception ex)
            {
                  GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			
                ex.printStackTrace();
                res = derr.toString();
            }
             return res;
        }
        @Override
     public String getworkerHomelocationByworkerCode(String workerCode)
      {     String res="";
           try{
      
                JSONObject jsonobj = new JSONObject();
                Worker worker= workerRepository.getWorkerProfileTabsByworkerCode(workerCode);
            if(worker!=null && worker.getId()>0)
            {
                 WorkerHomelocationReq req=new WorkerHomelocationReq();
                  req.setAddress1(worker.getAddress1());
                  req.setAddress2(worker.getAddress2());
                  req.setZipcode(worker.getZipcode());
                  req.setState(worker.getState());
                  req.setCountry(worker.getCountry());
                  req.setCity(worker.getCity());
                  req.setLatitude(worker.getLatitude());
                  req.setLongitude(worker.getLongitude());
                  req.setDistance(worker.getDistance());
                    jsonobj.put("responsecode", 200);
	            jsonobj.put("timestamp", new Date());
	            jsonobj.put("message", "OK");
                    ObjectMapper mapperObj = new ObjectMapper();
	            String Detail = mapperObj.writeValueAsString(req);
                    jsonobj.put("data", new JSONObject(Detail) );
                  
            }
            else
            {
                  jsonobj.put("responsecode", 404);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", " Record Does not exist..!!");
            }
                res =jsonobj.toString();
      }
      catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
      catch(Exception ex)
      {     GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
          ex.printStackTrace();
           res = derr.toString();
      }
           return res;
      }
     @Override
     public String getworkerdetailsByworkerCode( String workerCode)
     {  String res="";
         
        try{
        
                JSONObject jsonobj = new JSONObject();
                Worker worker=workerRepository.getWorkerdetailByworkerCode(workerCode);
                List<SkillMaster> skilmaster=skillmaster.getWorkerSkillByworkercode(worker.getWorkerCode());
               // List<WorkerCertifications> workercertification= 
             List<CertificationsMaster>  certificationmaster=   certfktmaster.getCertificationmasterByWorkerCode(workerCode);
                if(worker!=null && worker.getId()>0)          
                {  
                      WorkerDetailsRes workerdetail=new WorkerDetailsRes();
                      workerdetail.setSkilmaster(skilmaster);
                      workerdetail.setCertificationmaster(certificationmaster);
                      workerdetail.setName(worker.getName());
                      workerdetail.setWorkerCode(worker.getWorkerCode());
                      workerdetail.setExpMonth(worker.getExpMonth());
                      workerdetail.setExpYear(worker.getExpYear());
                      
                     jsonobj.put("responsecode", 200);
	             jsonobj.put("timestamp", new Date());
                     jsonobj.put("message", "OK");
                     ObjectMapper mapperObj = new ObjectMapper();
	             String Detail = mapperObj.writeValueAsString(workerdetail);
                     jsonobj.put("data", new JSONObject(Detail) );
                     
                }else
                {
                  jsonobj.put("responsecode", 404);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", " Record Does Not Exist..!!");
                
                }
                res=jsonobj.toString();
        }
        catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
        catch(Exception ex)
        {
                GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
            ex.printStackTrace();
            res = derr.toString();
        }
       return res;
     }
     
     
     
     
     @Override
    public String getworkerdetailsByworkerCode( String workerCode,String orgCode)
    {
           String res="";
             try{
                 JSONObject jsonobj = new JSONObject();
                    List<SkillMaster> skillmaster =new ArrayList<SkillMaster>();
                 Worker worker=workerRepository.getWorkerdetailByworkerCode(workerCode);
               
                 List<String> skillcode=orgworkerskill.getSkillCodeListByworkerCode(workerCode);
                 if(skillcode!=null && skillcode.size()>0)
                 {
                 skillmaster  =orgskilldao.skillMasterByorgCodeAndskillCodeList(orgCode, skillcode);
                 }
          
                List<CertificationsMaster>  certificationmaster=   certfktmaster.getCertificationmasterByWorkerCode(workerCode);  
                 if(worker!=null && worker.getId()>0)
                 {
                       WorkerDetailsRes workerdetail=new WorkerDetailsRes();
                        workerdetail.setSkilmaster(skillmaster);
                      workerdetail.setCertificationmaster(certificationmaster);
                      workerdetail.setName(worker.getName());
                      workerdetail.setWorkerCode(worker.getWorkerCode());
                      workerdetail.setExpMonth(worker.getExpMonth());
                      workerdetail.setExpYear(worker.getExpYear());
                      
                     jsonobj.put("responsecode", 200);
	             jsonobj.put("timestamp", new Date());
                     jsonobj.put("message", "OK");
                     ObjectMapper mapperObj = new ObjectMapper();
	             String Detail = mapperObj.writeValueAsString(workerdetail);
                     jsonobj.put("data", new JSONObject(Detail) );
                     
                }else
                {
                  jsonobj.put("responsecode", 404);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", " Record Does Not Exist..!!");
                
                }
                 res=jsonobj.toString();  
             }catch(Exception ex)
             {
                 GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
            ex.printStackTrace();
            res = derr.toString();
             }
             return res;
    }
    
    
    
    
    
     @Override
    public String UpdateworkerdetailsByworkerCode( WorkerDetailsReq workerdetailreq,String workerCode)
    {                       
        String res="";
      
    try{
           JSONObject jsonobj = new JSONObject();
           Worker worker=workerRepository.getWorkerdetailByworkerCode(workerCode); 
      if(worker!=null && worker.getId()>0)
      {
             
             worker.setExpMonth(workerdetailreq.getExpMonth());
             worker.setExpYear(workerdetailreq.getExpYear());  
             Worker wrkr=workerRepository.save(worker);
            if(wrkr!=null && wrkr.getId()>0)
            {  
                kafkaService.sendWorkerForUpdate(wrkr);
          List<String>   certificationmaster=new ArrayList<String>();
          List<CertificationMasterReq>  certificationmasterlist= workerdetailreq.getCertificationmaster();
          for(CertificationMasterReq certicode:certificationmasterlist)
          { 
              certificationmaster.add(certicode.getCertificationCode());
               WorkerCertifications workercerti= wrkrcertfkt.getWorkerCertificationsCheckForSave(workerCode, certicode.getCertificationCode());
                  if(workercerti==null)
                     {
                        WorkerCertifications wc=new WorkerCertifications();
                        wc.setWorkerCode(workerCode);
                        wc.setCertificationCode(certicode.getCertificationCode());
                        WorkerCertifications wcc= wrkrcertfkt.save(wc);
                    }
                    
                 
         }
          List< WorkerCertifications> workercerti=null;
          if(certificationmaster!=null && certificationmaster.size()>0){
           workercerti=wrkrcertfkt.getworkercertificationsfordelete(workerCode, certificationmaster);
              
          }
          else
          {
              workercerti=wrkrcertfkt.getAllworkercertificationsfordelete(workerCode);
          }
         
            if(workercerti!=null && workercerti.size()>0)       
             {              wrkrcertfkt.deleteAll(workercerti);
         
             }  
        List<String>   skillCodes=new ArrayList<String>();
      List<SkillMasterReq>skillCodeList=workerdetailreq.getSkilmaster();
      for(SkillMasterReq skillCode:skillCodeList)
      {
          skillCodes.add(skillCode.getSkillCode());
          OrganizationWorkerSkill orgwrskill=    orgworkerskill.getCheckForOrganizationWorkerSkillByworkerCodeAndSkillCode(workerCode, skillCode.getSkillCode());
          if(orgwrskill==null)
          {
              OrganizationWorkerSkill orgwrkrskill=new OrganizationWorkerSkill();
              orgwrkrskill.setSkillCode(skillCode.getSkillCode());
              orgwrkrskill.setWorkerCode(workerCode);
              orgworkerskill.save(orgwrkrskill);
          }
      }
           List<OrganizationWorkerSkill>orgskill=null;
         if(skillCodes!=null && skillCodes.size()>0)  
         {
           orgskill=  orgworkerskill.getorgworkerskillforDelete(workerCode,skillCodes);
         }else
         {
          orgskill=  orgworkerskill.getfordeleteorgwrkrskillByworkerCode(workerCode);
         }
         if(orgskill!=null && orgskill.size()>0)
         {
              orgworkerskill.deleteAll(orgskill);
         }
                 
                     jsonobj.put("responsecode", 200);
	             jsonobj.put("timestamp", new Date());
                     jsonobj.put("message", "Worker Detail has been Updated.");
            }else
      {
                  jsonobj.put("responsecode", 400);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", " Failed");
      }
     
      }else
      {
                  jsonobj.put("responsecode", 404);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", " Record Does Not Exist..!!");
      }
      res=jsonobj.toString();
     
   }
    catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
    catch(Exception ex)
   {
        
                GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred."); 
                ex.printStackTrace();
            res = derr.toString();

   }
        return res;
    }
    public String getSkillsByOrgCodeAndworkerCode(String workerCode,String orgCode)
    {   String res="";
        try{
            JSONObject jsonobj=new JSONObject();
         List<String> skillcode=orgworkerskill.getSkillCodeListByworkerCode(workerCode);
         if(skillcode!=null && skillcode.size()>0)
         {
          List<SkillMaster> skillmaster  =orgskilldao.skillMasterByorgCodeAndskillCodeList(orgCode, skillcode);
              if(skillmaster!=null && skillmaster.size()>0)
              {
                     jsonobj.put("responsecode", 200);
	             jsonobj.put("timestamp", new Date());
                     jsonobj.put("message", "OK");
                     ObjectMapper mapperObj = new ObjectMapper();
	             String Detail = mapperObj.writeValueAsString(skillmaster);
                     jsonobj.put("data", new JSONArray(Detail) );  
              }else
              {
                    jsonobj.put("responsecode", 404);
	            jsonobj.put("timestamp", new Date());
	            jsonobj.put("message", " Record Does Not Exist..!!");
              }
             
         }else
         {
                  jsonobj.put("responsecode", 404);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", " Record Does Not Exist..!!");
         }
         res= jsonobj.toString();
        }
        catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
        catch(Exception ex)
        {
              GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred."); 
                ex.printStackTrace();
            res = derr.toString();

        }
       
        return res;
    }
     public String getWorkerProfileProfessionalTabforMobileByworkerCode ( String workerCode)
     {
       String res="";
        try
        {
            JSONObject jsonobj = new JSONObject();
            WorkerProfileForMobileRes wpfmRes=new WorkerProfileForMobileRes();
            Worker worker=workerRepository.getWorkerdetailByworkerCode(workerCode); 
            List<SkillMaster> skilmaster=skillmaster.getWorkerSkillByworkercode(worker.getWorkerCode());
         
            List<CertificationsMaster>  certificationmaster=   certfktmaster.getCertificationmasterByWorkerCode(workerCode);
            
            
            List<CertificationsMasterRes> certificationmasterResList = new ArrayList<CertificationsMasterRes>(); 
            
            for(CertificationsMaster cm :certificationmaster)
            {
                CertificationsMasterRes cmRes = new CertificationsMasterRes();
                cmRes.setCertificationCode(cm.getCertificationCode());
                cmRes.setCertificationName(cm.getCertificationName());
                cmRes.setCertificationUrl(cm.getCertificationUrl());
                cmRes.setId(cm.getId());
                cmRes.setIsAssigned(cm.getIsAssigned());
                cmRes.setOrganizationCode(cm.getOrganizationCode());
                
                Organization org = orgRepository.findByOrganizationCode(cm.getOrganizationCode());
                
                if(org !=null )
                {
                    cmRes.setOrganizationName(org.getOrganizationName()); 
                }
                cmRes.setSkillCode(cm.getSkillCode());
                
                SkillMaster skillMaster = skillMasterDao.getSkillMasterBySkillCode(cm.getSkillCode());
                if(skillMaster != null)
                {
                     cmRes.setSkillName(skillMaster.getSkillName()); 
                }
                certificationmasterResList.add(cmRes);
            }
            
            
            
            if(worker!=null && worker.getId()>0)
            {
                wpfmRes.setWorkerLogo(worker.getWorkerLogo());
                wpfmRes.setSkilmaster(skilmaster);
                wpfmRes.setCertificationmasterResList(certificationmasterResList);
                List <OrganizationWiseApproval> organizationWiseApprovalList=new ArrayList<OrganizationWiseApproval>();
                wpfmRes.setEmploymentTypeCode(worker.getEmploymentTypeCode());
               if(worker.getEmploymentTypeCode()!=null)
               {
                   EmploymentType et=employmentTypeRepository.getEmploymentTypeByCode(worker.getEmploymentTypeCode());
                   if(et!=null && et.getId()>0)
                   {
                       wpfmRes.setEmploymentTypeName(et.getEmploymentTypeName());
                   }
               }
               List<WorkerApprovalStatus> waslst=workerRepository.getAllWorkerApprovalStatusByWorkerCode(worker.getWorkerCode());
               if(waslst!=null && waslst.size()>0)
               {
                   for(WorkerApprovalStatus was:waslst)
                   {
                       OrganizationWiseApproval owa=new OrganizationWiseApproval();
                       owa.setOrganizationCode(was.getOrganization_Code());
                       owa.setIsApproved(was.getIsApproved());
                       organizationWiseApprovalList.add(owa);
                   }
               }
               wpfmRes.setOrganizationWiseApprovalList(organizationWiseApprovalList);
                jsonobj.put("responsecode", 200);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "OK");
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(wpfmRes);
                jsonobj.put("data", new JSONObject(Detail));  
            }else
            {
              jsonobj.put("responsecode", 404);
	      jsonobj.put("timestamp", new Date());
	      jsonobj.put("message", "Record Not Found");
            }
            res=jsonobj.toString();
        }catch(Exception ex)
        {
            GigflexResponse derr = new GigflexResponse(500, new Date(),"Exception is occurred."); 
                ex.printStackTrace();
                res = derr.toString();
        }
        return res;
     }
     public String getWorkerProfileforMobileByworkerCode(String workerCode)
     {
          String res="";
         try{
             JSONObject jsonobj = new JSONObject();
             UpdateWrkrProfileforMobileByworkerCode wpptfmRes=new UpdateWrkrProfileforMobileByworkerCode();
             Worker worker=workerRepository.getWorkerdetailByworkerCode(workerCode); 
             if(worker!=null && worker.getId()>0)
             {
                   String dtFormat=GigflexConstants.YYYY_MM_DD;

                 // String  dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.DATEFORMAT);
//                  if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
//                            {
//                                dtFormat=dateformat.trim();
//                            }  
                 DateFormat dateFormat = new SimpleDateFormat(dtFormat); 
                 String strDate="";
                 if(worker.getDob()!=null){
                  strDate = dateFormat.format(worker.getDob());  
                 
                   }
               wpptfmRes.setName(worker.getName());
               wpptfmRes.setEmail(worker.getEmail());
               wpptfmRes.setLanguage(worker.getLanguage());
                wpptfmRes.setDob(strDate);
               wpptfmRes.setMobileNo(worker.getWork_phone());
               wpptfmRes.setEmergencyNo(worker.getHome_phone());
               wpptfmRes.setAddress(worker.getAddress1());
               wpptfmRes.setCity(worker.getCity());
               wpptfmRes.setPostCode(worker.getZipcode());
               wpptfmRes.setCountry(worker.getCountry());
               wpptfmRes.setWorkerLogo(worker.getWorkerLogo());
               wpptfmRes.setLatitude(worker.getLatitude());
               wpptfmRes.setLongitude(worker.getLongitude());
               wpptfmRes.setDesignation(worker.getDesignation());
               wpptfmRes.setHomeCountryCode(worker.getHomecountryCode());
               wpptfmRes.setWorkerCountryCode(worker.getWorkcountryCode());
               jsonobj.put("responsecode", 200);
	       jsonobj.put("timestamp", new Date());
               jsonobj.put("message", "OK");
               ObjectMapper mapperObj = new ObjectMapper();
	       String Detail = mapperObj.writeValueAsString(wpptfmRes);
               jsonobj.put("data", new JSONObject(Detail));  
               }else
               {
               jsonobj.put("responsecode", 404);
	       jsonobj.put("timestamp", new Date());
	       jsonobj.put("message", "Record Not Found");
               }
               res=jsonobj.toString();
               }catch(Exception ex)
               {
               GigflexResponse derr = new GigflexResponse(500, new Date(),"Exception is occurred."); 
               ex.printStackTrace();
               res = derr.toString();        
               }
         return res;
       
     }
     
     @Override
     public String getWorkerProfilePersonalTabforMobileByworkerCode(String workerCode)
     {
        String res="";
         try{
             JSONObject jsonobj = new JSONObject();
             WorkerProfileProfessionalTabForMobileRes wpptfmRes=new WorkerProfileProfessionalTabForMobileRes();
             Worker worker=workerRepository.getWorkerdetailByworkerCode(workerCode); 
             if(worker!=null && worker.getId()>0)
             {
                 List <OrganizationWiseApproval> organizationWiseApprovalList=new ArrayList<OrganizationWiseApproval>();
                   String dtFormat=GigflexConstants.YYYY_MM_DD;

                 // String  dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeRepository, GigflexConstants.Organizations, driver.getOrganizationCode(), GigflexConstants.DATEFORMAT);
//                  if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
//                            {
//                                dtFormat=dateformat.trim();
//                            }  
                 DateFormat dateFormat = new SimpleDateFormat(dtFormat); 
                 String strDate="";
                 if(worker.getDob()!=null){
                  strDate = dateFormat.format(worker.getDob());  
                 
                   }
               wpptfmRes.setName(worker.getName());
               wpptfmRes.setEmail(worker.getEmail());
               wpptfmRes.setLanguage(worker.getLanguage());
                wpptfmRes.setDob(strDate);
               wpptfmRes.setMobileNo(worker.getWork_phone());
               wpptfmRes.setEmergencyNo(worker.getHome_phone());
               wpptfmRes.setAddress(worker.getAddress1());
               wpptfmRes.setCity(worker.getCity());
               wpptfmRes.setPostCode(worker.getZipcode());
               wpptfmRes.setCountry(worker.getCountry());
               wpptfmRes.setWorkerLogo(worker.getWorkerLogo());
               wpptfmRes.setLatitude(worker.getLatitude());
               wpptfmRes.setLongitude(worker.getLongitude());
               wpptfmRes.setDesignation(worker.getDesignation());
               wpptfmRes.setHomeCountryCode(worker.getHomecountryCode());
               wpptfmRes.setWorkerCountryCode(worker.getWorkcountryCode());
               wpptfmRes.setEmploymentTypeCode(worker.getEmploymentTypeCode());
               wpptfmRes.setQualification(worker.getQualification());
               wpptfmRes.setExpYear(worker.getExpYear());
               wpptfmRes.setExpMonth(worker.getExpMonth());
               wpptfmRes.setExpDays(worker.getExpDays());
               
               if(worker.getEmploymentTypeCode()!=null)
               {
                   EmploymentType et=employmentTypeRepository.getEmploymentTypeByCode(worker.getEmploymentTypeCode());
                   if(et!=null && et.getId()>0)
                   {
                       wpptfmRes.setEmploymentTypeName(et.getEmploymentTypeName());
                   }
               }
               List<WorkerApprovalStatus> waslst=workerRepository.getAllWorkerApprovalStatusByWorkerCode(worker.getWorkerCode());
               if(waslst!=null && waslst.size()>0)
               {
                   for(WorkerApprovalStatus was:waslst)
                   {
                       OrganizationWiseApproval owa=new OrganizationWiseApproval();
                       owa.setOrganizationCode(was.getOrganization_Code());
                       owa.setIsApproved(was.getIsApproved());
                       organizationWiseApprovalList.add(owa);
                   }
               }
               wpptfmRes.setOrganizationWiseApprovalList(organizationWiseApprovalList);
               jsonobj.put("responsecode", 200);
	       jsonobj.put("timestamp", new Date());
               jsonobj.put("message", "OK");
               ObjectMapper mapperObj = new ObjectMapper();
	       String Detail = mapperObj.writeValueAsString(wpptfmRes);
               jsonobj.put("data", new JSONObject(Detail));  
               }else
               {
               jsonobj.put("responsecode", 404);
	       jsonobj.put("timestamp", new Date());
	       jsonobj.put("message", "Record Not Found");
               }
               res=jsonobj.toString();
               }catch(Exception ex)
               {
               GigflexResponse derr = new GigflexResponse(500, new Date(),"Exception is occurred."); 
               ex.printStackTrace();
               res = derr.toString();        
               }
         return res;
     }
        @Override
     public String updateWorkerProfileProfessionalTabforMobileByworkerCode(WorkerProfileProfessionalTabForMobileRes req, String workerCode)
     {
        String res="";
        try{
            JSONObject jsonobj = new JSONObject();
            Worker worker=workerRepository.getWorkerdetailByworkerCode(workerCode); 
            if(worker!=null && worker.getId()>0)
            {
                
                
                 Worker wrkr=workerRepository.getUniqueWorkerByWorkerCodeAndemail(workerCode,worker.getEmail());
                 if(wrkr==null)
                 {
                  worker.setEmail(req.getEmail());
                 }else
                 {
                    jsonobj.put("responsecode", 404);
	            jsonobj.put("timestamp", new Date());
	            jsonobj.put("message", "Email already exist");
                   return jsonobj.toString();
                 }
                Users users=userRepository.findByUserCode(worker.getWorkerCode());
       
                if(users!=null && users.getId()>0)
                {
                  users.setName(req.getName());
                  users.setEmail(req.getEmail());  
                   if(req.getPassword()!=null && req.getPassword().trim().length()>0)
                   {
                  users.setPassword(bCryptPasswordEncoder.encode(req.getPassword().trim()));
                   }
                    Users user= userRepository.save(users);
                     if(user!=null && user.getId()>0)
                     {
                     kafkaService.sendUpdateUser(user);
                     }
                }
          
                 worker.setName(req.getName());
                 
               
                worker.setLanguage(req.getLanguage());
                  String dtFormat=GigflexConstants.YYYY_MM_DD;
            if(GigflexDateUtil.isDate(req.getDob(),dtFormat))
                  {
                   Date date1=new SimpleDateFormat(dtFormat).parse(req.getDob());  
                   worker.setDob(date1);
                  }
            String oldlat=worker.getLatitude();
            String oldlong=worker.getLongitude();
                worker.setWorkerLogo(req.getWorkerLogo());
                worker.setWork_phone(req.getMobileNo());
                worker.setHome_phone(req.getEmergencyNo());
                worker.setAddress1(req.getAddress());
                worker.setCity(req.getCity());
                worker.setZipcode(req.getPostCode());
                worker.setCountry(req.getCountry());
                worker.setLatitude(req.getLatitude());
                worker.setLongitude(req.getLongitude());
                worker.setDesignation(req.getDesignation());
                worker.setHomecountryCode(req.getHomeCountryCode());
                worker.setWorkcountryCode(req.getWorkerCountryCode());
                worker.setQualification(req.getQualification()); 
                worker.setExpYear(req.getExpYear()); 
                worker.setExpMonth(req.getExpMonth()); 
                worker.setExpDays(req.getExpDays()); 
                if(req.getEmploymentTypeCode()!=null && req.getEmploymentTypeCode().trim().length()>0)
                {
                    worker.setEmploymentTypeCode(req.getEmploymentTypeCode());
                }
                try
                {
                if(req.getOrganizationWiseApprovalList()!=null && req.getOrganizationWiseApprovalList().size()>0)
                {
                  for(OrganizationWiseApproval owa:req.getOrganizationWiseApprovalList())
                  {
                      if(owa!=null && owa.getOrganizationCode()!=null && owa.getOrganizationCode().trim().length()>0 && owa.getIsApproved()!=null)
                      {
                        WorkerApprovalStatus was=  workerApprovalStatusRepository.getWorkerApprovalStatusByWorkerCodeOrgCode(workerCode,owa.getOrganizationCode().trim());
                        if(was!=null && was.getId()>0)
                        {
                            was.setIsApproved(owa.getIsApproved());
                            was.setApprovedDate(new Date());
                            workerApprovalStatusRepository.save(was);
                        }
                      }
                  }
                }
                    
                }
                catch(Exception ee)
                {
                    ee.printStackTrace();
                }
              Worker w=workerRepository.save(worker);
              if(w!=null && w.getId()>0)
              {  
                  if(oldlat==null || oldlong==null || !oldlat.equalsIgnoreCase(req.getLatitude()) || !oldlong.equalsIgnoreCase(req.getLongitude()))
                    {
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician,workerCode , GigflexConstants.TimeZone);
                            String timezone = null;
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getId() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                            startAssignJobToWorkerDynamicDistanceWorkerAddressThread( wrkr,new Date(), timezone);
                  
                    }
                  kafkaService.sendWorkerForUpdate(w);
                 jsonobj.put("responsecode", 200);
	         jsonobj.put("timestamp", new Date());
                 jsonobj.put("message", "OK");
              
              }else
              {
                jsonobj.put("responsecode", 404);
	        jsonobj.put("timestamp", new Date());
	        jsonobj.put("message", "Record not Updated");
              }
            }else
            {
               jsonobj.put("responsecode", 404);
	       jsonobj.put("timestamp", new Date());
	       jsonobj.put("message", "Record not Found");
            }
            res=jsonobj.toString();
          }catch(Exception ex)
          {
            GigflexResponse derr = new GigflexResponse(500, new Date(),"Exception is occurred."); 
               ex.printStackTrace();
               res = derr.toString();
          }
        return res;
     }
     
        @Override
     public String UpdateworkerProfilePersonelTabByworkerCode(WorkerProfileForMobileReq req, String workerCode)
     {

          String res="";
      
    try{
           JSONObject jsonobj = new JSONObject();
           Worker worker=workerRepository.getWorkerdetailByworkerCode(workerCode); 
      if(worker!=null && worker.getId()>0)
      {
           if(req.getWorkerLogo()!=null && req.getWorkerLogo().trim().length()>0)
                {
             worker.setWorkerLogo(req.getWorkerLogo().trim());
                }
            if(req.getEmploymentTypeCode()!=null && req.getEmploymentTypeCode().trim().length()>0)
                {
                    worker.setEmploymentTypeCode(req.getEmploymentTypeCode());
                }
                try
                {
                if(req.getOrganizationWiseApprovalList()!=null && req.getOrganizationWiseApprovalList().size()>0)
                {
                  for(OrganizationWiseApproval owa:req.getOrganizationWiseApprovalList())
                  {
                      if(owa!=null && owa.getOrganizationCode()!=null && owa.getOrganizationCode().trim().length()>0 && owa.getIsApproved()!=null)
                      {
                        WorkerApprovalStatus was=  workerApprovalStatusRepository.getWorkerApprovalStatusByWorkerCodeOrgCode(workerCode,owa.getOrganizationCode().trim());
                        if(was!=null && was.getId()>0)
                        {
                            was.setIsApproved(owa.getIsApproved());
                            was.setApprovedDate(new Date());
                            workerApprovalStatusRepository.save(was);
                        }
                      }
                  }
                }
                    
                }
                catch(Exception ee)
                {
                    ee.printStackTrace();
                }
             Worker wrkr=workerRepository.save(worker);
            if(wrkr!=null && wrkr.getId()>0)
            {  
                kafkaService.sendWorkerForUpdate(wrkr);
          List<String>   certificationmaster=new ArrayList<String>();
          List<CertificationMasterReq>  certificationmasterlist= req.getCertificationmaster();
          for(CertificationMasterReq certicode:certificationmasterlist)
          { 
             if(certicode.getCertificationCode()!=null && certicode.getCertificationCode().trim().length()>0)
             {
              certificationmaster.add(certicode.getCertificationCode());
               WorkerCertifications workercerti= wrkrcertfkt.getWorkerCertificationsCheckForSave(workerCode, certicode.getCertificationCode());
                  if(workercerti==null)
                     {
                        WorkerCertifications wc=new WorkerCertifications();
                        wc.setWorkerCode(workerCode);
                        wc.setCertificationCode(certicode.getCertificationCode());
                        WorkerCertifications wcc= wrkrcertfkt.save(wc);
                    }
                 
             }
                 
         }
          List< WorkerCertifications> workercerti=null;
          if(certificationmaster!=null && certificationmaster.size()>0){
           workercerti=wrkrcertfkt.getworkercertificationsfordelete(workerCode, certificationmaster);
              
          }
          else
          {
              workercerti=wrkrcertfkt.getAllworkercertificationsfordelete(workerCode);
          }
         
            if(workercerti!=null && workercerti.size()>0)       
             {              wrkrcertfkt.deleteAll(workercerti);
         
             }  
        List<String>   skillCodes=new ArrayList<String>();
      List<SkillMasterReq>skillCodeList=req.getSkilmaster();
      for(SkillMasterReq skillCode:skillCodeList)
      {
          if(skillCode.getSkillCode()!=null && skillCode.getSkillCode().trim().length()>0)
          {
          skillCodes.add(skillCode.getSkillCode());
          OrganizationWorkerSkill orgwrskill=    orgworkerskill.getCheckForOrganizationWorkerSkillByworkerCodeAndSkillCode(workerCode, skillCode.getSkillCode());
          if(orgwrskill==null)
          {
              OrganizationWorkerSkill orgwrkrskill=new OrganizationWorkerSkill();
              orgwrkrskill.setSkillCode(skillCode.getSkillCode());
              orgwrkrskill.setWorkerCode(workerCode);
              orgworkerskill.save(orgwrkrskill);
          }
          }
      }
           List<OrganizationWorkerSkill>orgskill=null;
         if(skillCodes!=null && skillCodes.size()>0)  
         {
           orgskill=  orgworkerskill.getorgworkerskillforDelete(workerCode,skillCodes);
         }else
         {
          orgskill=  orgworkerskill.getfordeleteorgwrkrskillByworkerCode(workerCode);
         }
         if(orgskill!=null && orgskill.size()>0)
         {
              orgworkerskill.deleteAll(orgskill);
         }
                 
                     jsonobj.put("responsecode", 200);
	             jsonobj.put("timestamp", new Date());
                     jsonobj.put("message", "Worker Detail has been Updated.");
            }else
      {
                  jsonobj.put("responsecode", 400);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", " Failed");
      }
     
      }else
      {
                  jsonobj.put("responsecode", 404);
	          jsonobj.put("timestamp", new Date());
	          jsonobj.put("message", " Record Does Not Exist..!!");
      }
      res=jsonobj.toString();
     
   }
    catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
    catch(Exception ex)
   {
        
                GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred."); 
                ex.printStackTrace();
            res = derr.toString();

   }
        return res;
     }
//    public String updateworkerProfileForMobileByworkerCode(UpdateWrkrProfileforMobileByworkerCode req,String workerCode)
//    {
//         String res="";
//         try{ 
//           JSONObject jsonobj = new JSONObject();
//           Worker worker=workerRepository.getWorkerdetailByworkerCode(workerCode); 
//           if(worker!=null && worker.getId()>0)
//           {  
//                Worker wrkr=workerRepository.getUniqueWorkerByWorkerCodeAndemail(workerCode,worker.getEmail());
//                 if(wrkr==null)
//                 {
//                  worker.setEmail(req.getEmail());
//                 }else
//                 {
//                    jsonobj.put("responsecode", 404);
//	            jsonobj.put("timestamp", new Date());
//	            jsonobj.put("message", "Email already exist");
//                   return jsonobj.toString();
//                 }
//                Users users=userRepository.findByUserCode(worker.getWorkerCode());
//       
//                if(users!=null && users.getId()>0)
//                {
//                  users.setName(req.getName());
//                  users.setEmail(req.getEmail());  
//                  
//                     userRepository.save(users);
//                }
//               
//            worker.setName(req.getName());
//            worker.setDesignation(req.getDesignation());
//         
//            worker.setLanguage(req.getLanguage());
//            String dtFormat=GigflexConstants.YYYY_MM_DD;
//            if(GigflexDateUtil.isDate(dtFormat, req.getDob()))
//                  {
//                   Date date1=new SimpleDateFormat(dtFormat).parse(req.getDob());  
//                   worker.setDob(date1);
//                  }
//          
//                worker.setWorkerLogo(req.getWorkerLogo());
//                worker.setWork_phone(req.getMobileNo());
//                worker.setHome_phone(req.getEmergencyNo());
//                worker.setAddress1(req.getAddress());
//                worker.setCity(req.getCity());
//                worker.setZipcode(req.getPostCode());
//                worker.setCountry(req.getCountry());
//                worker.setLatitude(req.getLatitude());
//                worker.setLongitude(req.getLongitude());
//                Worker w=workerRepository.save(worker);
//              if(w!=null && w.getId()>0)
//              {
//                 jsonobj.put("responsecode", 200);
//	         jsonobj.put("timestamp", new Date());
//                 jsonobj.put("message", "OK");
//              
//              }else
//              {
//                jsonobj.put("responsecode", 404);
//	        jsonobj.put("timestamp", new Date());
//	        jsonobj.put("message", "Record not Updated");
//              }
//        res=jsonobj.toString();
//           }else
//           {
//                jsonobj.put("responsecode", 404);
//	        jsonobj.put("timestamp", new Date());
//	        jsonobj.put("message", "Record not found");
//              
//           }
//         res=jsonobj.toString();
//           }catch(Exception ex)
//           {
//               GigflexResponse derr = new GigflexResponse(500, new Date(),"Exception is occurred."); 
//                ex.printStackTrace();
//               res = derr.toString();
//           }
//         return res;
//    }
     
      public  void startAssignJobToWorkerDynamicDistanceWorkerAddressThread(Worker wkr,Date startDate,String timezone){
        Thread t = new Thread(new AssignJobToWorkerDynamicDistanceWorkerAddressThread(wkr,jobsAssignToWorkerRepository,startDate,timezone, googleKey));
        t.start();
    }
}
