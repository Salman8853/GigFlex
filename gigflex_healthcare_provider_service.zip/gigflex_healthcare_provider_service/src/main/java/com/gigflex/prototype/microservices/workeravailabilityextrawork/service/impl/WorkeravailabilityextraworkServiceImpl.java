/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workeravailabilityextrawork.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workeravailabilityextrawork.dtob.Workeravailabilityextrawork;
import com.gigflex.prototype.microservices.workeravailabilityextrawork.dtob.WorkeravailabilityextraworkRequest;
import com.gigflex.prototype.microservices.workeravailabilityextrawork.repository.WorkeravailabilityextraworkRepository;
import com.gigflex.prototype.microservices.workeravailabilityextrawork.service.WorkeravailabilityextraworkService;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class WorkeravailabilityextraworkServiceImpl implements WorkeravailabilityextraworkService {
   @Autowired
   WorkeravailabilityextraworkRepository waewr;
    @Override
    public String getWorkeravailabilityextrawork()
    {
      String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         List<Workeravailabilityextrawork> wlst=waewr.getAllExtraWorkerAvailability();
                         if(wlst!=null && wlst.size()>0)
                         {
                                jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlst);
				jsonobj.put("data", new JSONArray(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    }
      @Override
    public String getWorkeravailabilityextraworkByPage(int page, int limit) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        Pageable pageableRequest = PageRequest.of(page, limit);
                         List<Workeravailabilityextrawork> wlst=waewr.getAllExtraWorkerWorkerAvailability(pageableRequest);
                         if(wlst!=null && wlst.size()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlst);
				jsonobj.put("data", new JSONArray(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    
    }
   @Override
    public String getWorkeravailabilityextraworkByWorkerCode(String workerCode) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        Workeravailabilityextrawork wlst=waewr.getExtraWorkerAvailability(workerCode);
                         if(wlst!=null && wlst.getId()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlst);
				jsonobj.put("data", new JSONObject(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    
    }
 @Override
    public String saveWorkeravailabilityextrawork(WorkeravailabilityextraworkRequest workerprsfReq, String ip) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         Workeravailabilityextrawork wlst=new Workeravailabilityextrawork();
                         Workeravailabilityextrawork wlstres=waewr.getExtraWorkerAvailability(workerprsfReq.getWorkerCode());
                         if(wlstres!=null && wlstres.getId()>0)
                         {
                             wlst=wlstres;
                         }
                         
                         wlst.setDays(workerprsfReq.getDays());
                        wlst.setIpAddress(ip);
                         wlst.setWorkerCode(workerprsfReq.getWorkerCode());
                         Workeravailabilityextrawork  wlstRes= waewr.save(wlst);
                         if(wlstRes!=null && wlstRes.getId()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Extra Worker Availability has been added.");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlstRes);
				jsonobj.put("data", new JSONObject(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    }
    @Override
public String updatesavegetWorkeravailabilityextrawork(WorkeravailabilityextraworkRequest extraworkerReq,String workerCode, String ip)
{
  String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         Workeravailabilityextrawork wlst=waewr.getExtraWorkerAvailability(workerCode);
                         if(wlst!=null && wlst.getId()>0)
                         {
                             
                         wlst.setDays(extraworkerReq.getDays());
                      
                         Workeravailabilityextrawork  wlstRes= waewr.save(wlst);
                         if(wlstRes!=null && wlstRes.getId()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Extra Worker Availability has been updated.");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlstRes);
				jsonobj.put("data", new JSONObject(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Updation has been failed.");
				jsonobj.put("timestamp", new Date());
                         }
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    
    
    }
 public String deletegetWorkeravailabilityextrawork(String workerCode)
 {
       String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         Workeravailabilityextrawork wlst=waewr.getExtraWorkerAvailability(workerCode);
                         if(wlst!=null && wlst.getId()>0)
                         {
                             
                            wlst.setIsDeleted(Boolean.TRUE);
                             Workeravailabilityextrawork wlstres= waewr.save(wlst);
                            if(wlstres!=null && wlstres.getId()>0)
                            {
                                jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Extra Worker Availability has been deleted.");
				jsonobj.put("timestamp", new Date());
                            }
                            else
                            {
                                jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Failed.");
				jsonobj.put("timestamp", new Date());
                            }
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    
    
    }
 }

    

