package com.gigflex.prototype.microservices.workercertifications.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;

public interface WorkerCertificationsRepository extends JpaRepository<WorkerCertifications,Long>,JpaSpecificationExecutor<WorkerCertifications>{
	
//	public WorkerCertifications getByCertificationsCode(String certificationCode);
//	public WorkerCertifications getByWorkerCode(String workerCode);
	@Query("SELECT wc,w.name,c,o.organizationName FROM WorkerCertifications wc, Worker w, CertificationsMaster c,Organization o  WHERE wc.workerCode = w.workerCode AND wc.certificationCode = c.certificationCode AND wc.isDeleted != TRUE  AND c.isDeleted != TRUE AND c.organizationCode = o.organizationCode")
	public List<Object> getAllWorkerCertificationName();

	@Query("SELECT wc,w.name,c,o.organizationName FROM WorkerCertifications wc, Worker w, CertificationsMaster c,Organization o  WHERE wc.workerCode = w.workerCode AND wc.certificationCode = c.certificationCode AND wc.isDeleted != TRUE  AND c.isDeleted != TRUE AND c.organizationCode = o.organizationCode")
	public List<Object> getAllWorkerCertificationName(Pageable pageableRequest);
        
        @Query("SELECT wc,w.name,c,o.organizationName FROM WorkerCertifications wc, Worker w, CertificationsMaster c,Organization o  WHERE wc.workerCode = w.workerCode AND wc.certificationCode = c.certificationCode AND wc.isDeleted != TRUE  AND c.isDeleted != TRUE AND c.organizationCode = o.organizationCode AND wc.workerCode = :workerCode ")
	public List<Object> getWorkerCertificationsByWorkerCode(@Param("workerCode") String workerCode);

	@Query("SELECT wc,w.name,c,o.organizationName FROM WorkerCertifications wc, Worker w, CertificationsMaster c,Organization o  WHERE wc.workerCode = w.workerCode AND wc.certificationCode = c.certificationCode AND wc.isDeleted != TRUE  AND c.isDeleted != TRUE AND c.organizationCode = o.organizationCode AND wc.workerCode = :workerCode ")
	public List<Object> getWorkerCertificationsByWorkerCode(@Param("workerCode") String workerCode,Pageable pageableRequest);

	@Query("SELECT os FROM WorkerCertifications os WHERE os.isDeleted != TRUE")
	public List<WorkerCertifications> getAllWorkerCertifications();
	
	@Query("SELECT os FROM WorkerCertifications os WHERE os.isDeleted != TRUE")
	public List<WorkerCertifications> getAllWorkerCertifications(Pageable pageableRequest);


	@Query("SELECT os FROM WorkerCertifications os WHERE os.isDeleted != TRUE AND os.id = :id")
	public WorkerCertifications getWorkerCertificationsById(@Param("id") Long id);
	
	@Query("SELECT a FROM WorkerCertifications a WHERE a.isDeleted != TRUE AND a.workerCode = :workerCode AND a.certificationCode =:certificationCode")
	public WorkerCertifications getWorkerCertificationsCheckForSave(@Param("workerCode") String workerCode,@Param("certificationCode") String certificationCode);
	
	@Query("SELECT a FROM WorkerCertifications a WHERE a.isDeleted != TRUE AND a.id != :id AND a.workerCode = :workerCode AND a.certificationCode =:certificationCode")
	public WorkerCertifications getWorkerCertificationsCheckForUpdate(@Param("id") Long id,@Param("workerCode") String workerCode,@Param("certificationCode") String certificationCode);
        @Query("Select wrkrcertfkt  from  WorkerCertifications wrkrcertfkt  where wrkrcertfkt.workerCode=:workerCode")
        public List<WorkerCertifications> getworkerertificationsByWorkerCode(@Param("workerCode") String workerCode);
       @Query(" Select wrkrcertfkt  from WorkerCertifications wrkrcertfkt where wrkrcertfkt.isDeleted != TRUE AND wrkrcertfkt.workerCode=:workerCode AND wrkrcertfkt.certificationCode NOT IN(:certificationcodeList)")
       public List<WorkerCertifications>getworkercertificationsfordelete(@Param("workerCode") String workerCode,@Param("certificationcodeList") List<String> certificationcodeList);
       @Query("Select wrkrcertfkt  from WorkerCertifications wrkrcertfkt  where wrkrcertfkt.isDeleted != TRUE AND wrkrcertfkt.workerCode=:workerCode")
       public List<WorkerCertifications>getAllworkercertificationsfordelete(@Param("workerCode")String workerCode);

}
