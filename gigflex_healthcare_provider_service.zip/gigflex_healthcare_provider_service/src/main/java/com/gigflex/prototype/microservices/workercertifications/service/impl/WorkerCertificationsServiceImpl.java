package com.gigflex.prototype.microservices.workercertifications.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.certificationsmaster.repository.CertificationsMasterRepository;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertificationsRequest;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertificationsResponse;
import com.gigflex.prototype.microservices.workercertifications.repository.WorkerCertificationsRepository;
import com.gigflex.prototype.microservices.workercertifications.search.WorkerCertificationsSpecificationsBuilder;
import com.gigflex.prototype.microservices.workercertifications.service.WorkerCertificationsService;

@Service
public class WorkerCertificationsServiceImpl implements WorkerCertificationsService{

	@Autowired
	private WorkerCertificationsRepository workerCertificationsRepository;
	

	
	@Autowired
	private CertificationsMasterRepository certiMastDao;
	
	@Autowired
	private WorkerRepository workerDao;
	
	@Override
	public String findAllWorkerCertifications() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerCertifications> workerCertilst = workerCertificationsRepository.getAllWorkerCertifications();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (workerCertilst != null && workerCertilst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerCertilst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String findWorkerCertificationsById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerCertifications workerCertilst = workerCertificationsRepository.getWorkerCertificationsById(id);
			if ( workerCertilst != null && workerCertilst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerCertilst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveWorkerCertifications(
			WorkerCertificationsRequest workerCertiReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerCertiReq != null) {
				if ((workerCertiReq.getCertificationCode() != null && workerCertiReq
						.getCertificationCode().trim().length() > 0)
						&& (workerCertiReq.getWorkerCode() != null && workerCertiReq
								.getWorkerCode().trim().length() > 0)) {

					CertificationsMaster cm = certiMastDao
							.getCertificationsMasterByCertificationCode(workerCertiReq
									.getCertificationCode());
					if (cm != null && cm.getId() > 0) {

						Worker worker = workerDao
								.findByWorkerCode(workerCertiReq
										.getWorkerCode());
						if (worker != null && worker.getId() > 0) {

							WorkerCertifications wc = workerCertificationsRepository
									.getWorkerCertificationsCheckForSave(
											workerCertiReq.getWorkerCode(),
											workerCertiReq
													.getCertificationCode());
							if (wc != null && wc.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());

								jsonobj.put("message", "Record already exist.");
							} else {

								WorkerCertifications workerCertilst = new WorkerCertifications();
								workerCertilst
										.setCertificationCode(workerCertiReq
												.getCertificationCode());
								workerCertilst.setWorkerCode(workerCertiReq
										.getWorkerCode());
								workerCertilst.setIpAddress(ip);

								WorkerCertifications workerCertiRes = workerCertificationsRepository
										.save(workerCertilst);

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());

								if (workerCertiRes != null
										&& workerCertiRes.getId() > 0) {

//									kafkaService
//											.sendWorkerCertifications(workerCertiRes);

									jsonobj.put("message",
											"WorkerCertifications has been added successfully.");
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(workerCertiRes);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("message", "Failed");
								}
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Worker Code not found");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Certification Code not found");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Certification Code and Worker Code should not be blank");
				}
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateWorkerCertificationsById(Long id,
			WorkerCertificationsRequest workerCertiReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (workerCertiReq != null) {
				if ((workerCertiReq.getCertificationCode() != null && workerCertiReq
						.getCertificationCode().trim().length() > 0)
						&& (workerCertiReq.getWorkerCode() != null && workerCertiReq
								.getWorkerCode().trim().length() > 0)) {

					WorkerCertifications workerCertiInDb = workerCertificationsRepository
							.getWorkerCertificationsById(id);
					if (workerCertiInDb != null && workerCertiInDb.getId() > 0) {

						CertificationsMaster cm = certiMastDao
								.getCertificationsMasterByCertificationCode(workerCertiReq
										.getCertificationCode());
						if (cm != null && cm.getId() > 0) {

							Worker worker = workerDao
									.findByWorkerCode(workerCertiReq
											.getWorkerCode());
							if (worker != null && worker.getId() > 0) {

								WorkerCertifications wc = workerCertificationsRepository
										.getWorkerCertificationsCheckForUpdate(
												id, workerCertiReq
														.getWorkerCode(),
												workerCertiReq
														.getCertificationCode());
								if (wc != null && wc.getId() > 0) {
									jsonobj.put("responsecode", 409);
									jsonobj.put("timestamp", new Date());

									jsonobj.put("message",
											"Record already exist.");
								} else {

									WorkerCertifications workerCerti = workerCertiInDb;
									workerCerti
											.setCertificationCode(workerCertiReq
													.getCertificationCode());
									workerCerti.setWorkerCode(workerCertiReq
											.getWorkerCode());
									workerCerti.setIpAddress(ip);

									WorkerCertifications workerCertiRes = workerCertificationsRepository
											.save(workerCerti);
									if (workerCertiRes != null
											&& workerCertiRes.getId() > 0) {
										jsonobj.put("responsecode", 200);
										jsonobj.put("message",
												"WorkerCertifications updation has been done");
										jsonobj.put("timestamp", new Date());
										ObjectMapper mapperObj = new ObjectMapper();
										String Detail = mapperObj
												.writeValueAsString(workerCertiRes);
										jsonobj.put("data", new JSONObject(
												Detail));

//										kafkaService
//												.sendWorkerCertificationsUpdate(workerCertiRes);

									} else {
										jsonobj.put("responsecode", 400);
										jsonobj.put("message",
												"WorkerCertifications updation has been failed.");
										jsonobj.put("timestamp", new Date());
									}
								}
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Worker Code not found");
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message",
									"Certification Code not found");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"WorkerCertifications ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message",
							"Certification Code and Worker Code should not be blank");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteWorkerCertificationsById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<WorkerCertifications> workerCerti = workerCertificationsRepository.findById(id);
			if (workerCerti.isPresent() && workerCerti.get() != null) {
				workerCertificationsRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message",
						" WorkerCertifications has been deleted.");
				jsonobj.put("timestamp", new Date());
				
//				kafkaService.sendWorkerCertificationsDelete(workerCerti.get());
				
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteWorkerCertificationsById(Long id) {
		String res = "";
		try {
		JSONObject jsonobj = new JSONObject();
		WorkerCertifications wclst = workerCertificationsRepository.getWorkerCertificationsById(id);
		
		if (wclst != null && wclst.getId() > 0) {
			wclst.setIsDeleted(true);
			WorkerCertifications wcRes = workerCertificationsRepository.save(wclst);
		if (wcRes != null && wcRes.getId()>0) {
		jsonobj.put("responsecode", 200);
		jsonobj.put("timestamp", new Date());

		jsonobj.put("message", "WorkerCertifications deleted successfully.");

//		kafkaService.sendWorkerCertificationsUpdate(wcRes);
		} else {
		jsonobj.put("responsecode", 400);
		jsonobj.put("timestamp", new Date());
		jsonobj.put("message", "Failed");
		}

		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("timestamp", new Date());
		jsonobj.put("message", "Record Not Found");
		}
		res = jsonobj.toString();
		} catch (Exception ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(),
		"Exception occurred.");
		res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllWorkerCertificationsWithNames() {
		String res = "";
		try {
		JSONObject jsonobj = new JSONObject();

		List<Object> objlst= workerCertificationsRepository.getAllWorkerCertificationName();
		List<WorkerCertificationsResponse> maplst=new ArrayList<WorkerCertificationsResponse>();
		if(objlst!=null && objlst.size()>0)
		{
		for (int i = 0; i < objlst.size(); i++) {
		Object[] arr = (Object[]) objlst.get(i);
		if (arr.length >= 4) {
			WorkerCertificationsResponse wcr = new WorkerCertificationsResponse();
			
			WorkerCertifications wc = (WorkerCertifications) arr[0];
		
			wcr.setId(wc.getId());
			wcr.setCertificationCode(wc.getCertificationCode());
			wcr.setWorkerCode(wc.getWorkerCode());
			
			
			wcr.setName((String) arr[1]);
                        CertificationsMaster cm=(CertificationsMaster) arr[2];
                        if(cm!=null)
                        {
                          wcr.setCertificationName(cm.getCertificationName()); 
                          wcr.setOrganizationCode(cm.getOrganizationCode());
                        }
                        
			wcr.setOrganizationName((String) arr[3]);
			maplst.add(wcr);	

		}
		}
		if (maplst.size() > 0) {
		ObjectMapper mapperObj = new ObjectMapper();
		String Detail = mapperObj.writeValueAsString(maplst);
		jsonobj.put("responsecode", 200);
		jsonobj.put("message", "Success");
		jsonobj.put("timestamp", new Date());
		jsonobj.put("data", new JSONArray(Detail));
		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("message", "Record Not Found");
		jsonobj.put("timestamp", new Date());
		       }
		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("message", "Record Not Found");
		jsonobj.put("timestamp", new Date());
		}

		 res = jsonobj.toString();
		} 
		catch (JSONException ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
		res = derr.toString();
		ex.printStackTrace();
		} catch (Exception ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
		res = derr.toString();
		ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteById(List<Long> idList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (Long id : idList) {
				if(id != null && id >0){
				JSONObject jsonobj = new JSONObject();

				WorkerCertifications wclst = workerCertificationsRepository.getWorkerCertificationsById(id);
					
					if (wclst != null && wclst.getId() > 0) {
						
						wclst.setIsDeleted(true);
						WorkerCertifications wcRes = workerCertificationsRepository.save(wclst);
						if (wcRes != null && wcRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message", "WorkerCertifications deleted successfully.");
//							kafkaService.sendWorkerCertificationsUpdate(wcRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("Id", id);
						jsonobj.put("message", "Record Not Found");
					}
				
				jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllWorkerCertificationsByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
	        Pageable pageableRequest = PageRequest.of(page, limit);
	        List<WorkerCertifications> wclst = workerCertificationsRepository.getAllWorkerCertifications(pageableRequest);
	        jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (wclst != null && wclst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wclst);
				jsonobj.put("data", new JSONArray(Detail));
			}
			 else
	            {
	                jsonobj.put("responsecode", 200);
	            jsonobj.put("message", "Record Not Found");
	            jsonobj.put("timestamp", new Date());
	            }
			res = jsonobj.toString();
		} catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
	    return res;
	}

	@Override
	public String geAllWorkerCertificationsWithNamesByPage(int page, int limit) {
		String res = "";
		try {
		JSONObject jsonobj = new JSONObject();
                if(limit>0){
		Pageable pageableRequest = PageRequest.of(page, limit);
		List<Object> objlst= workerCertificationsRepository.getAllWorkerCertificationName(pageableRequest);
		List<WorkerCertificationsResponse> maplst=new ArrayList<WorkerCertificationsResponse>();
		if(objlst!=null && objlst.size()>0)
		{
                    int count=0;
                    List<Object> objlstcnt= workerCertificationsRepository.getAllWorkerCertificationName();
                    if(objlstcnt!=null && objlstcnt.size()>0 )
                    {
                        count=objlstcnt.size();
                    }
		for (int i = 0; i < objlst.size(); i++) {
		Object[] arr = (Object[]) objlst.get(i);
		if (arr.length >= 4) {
			WorkerCertificationsResponse wcr = new WorkerCertificationsResponse();
			
			WorkerCertifications wc = (WorkerCertifications) arr[0];
		
			wcr.setId(wc.getId());
			wcr.setCertificationCode(wc.getCertificationCode());
			wcr.setWorkerCode(wc.getWorkerCode());
			
			wcr.setName((String) arr[1]);
                        CertificationsMaster cm=(CertificationsMaster) arr[2];
                        if(cm!=null)
                        {
                          wcr.setCertificationName(cm.getCertificationName()); 
                          wcr.setOrganizationCode(cm.getOrganizationCode());
                        }
			wcr.setOrganizationName((String) arr[3]);
			maplst.add(wcr);	

		}
		}
		if (maplst.size() > 0) {
		ObjectMapper mapperObj = new ObjectMapper();
		String Detail = mapperObj.writeValueAsString(maplst);
		jsonobj.put("responsecode", 200);
		jsonobj.put("message", "Success");
                jsonobj.put("count", count);
		jsonobj.put("timestamp", new Date());
		jsonobj.put("data", new JSONArray(Detail));
		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("message", "Record Not Found");
		jsonobj.put("timestamp", new Date());
		       }
		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("message", "Record Not Found");
		jsonobj.put("timestamp", new Date());
		}
                } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
		 res = jsonobj.toString();
		} 
		catch (JSONException ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
		res = derr.toString();
		ex.printStackTrace();
		} catch (Exception ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
		res = derr.toString();
		ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
            if(search != null && search.trim().length() > 0){
			JSONObject jsonobj = new JSONObject();
			
			WorkerCertificationsSpecificationsBuilder builder = new WorkerCertificationsSpecificationsBuilder();
		        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
		        java.util.regex.Matcher matcher = pattern.matcher(search + ",");
		        while (matcher.find()) {
		            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
		        }
		         
		        Specification<WorkerCertifications> spec = builder.build();
                        if(spec!=null){
		        List<WorkerCertifications> wclst = workerCertificationsRepository.findAll(spec);
			if(wclst != null && wclst.size() > 0){
			for(WorkerCertifications wc : wclst){
				if(wc.getIsDeleted() != null && wc.getIsDeleted() != true){

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wc);
					JSONObject jsonobjNew = new JSONObject();
					jsonobjNew.put("activities", new JSONObject(Detail));
					jarr.add(jsonobjNew);

			} 
				
			} 
			if (jarr.size() > 0) {
				
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			jsonobj.put("data", jarr);
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}
			
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}}
                        else{
                          jsonobj.put("responsecode", 400);
			  jsonobj.put("message", "Record Not Found!");
			  jsonobj.put("timestamp", new Date());  
                        }
			res = jsonobj.toString();
		
            }else{
            	GigflexResponse derr = new GigflexResponse(400, new Date(),
    					"Input data is not valid.");
    			res = derr.toString();

            }
			
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

    @Override
    public String getWorkerCertificationsByWorkerCodeByPage(String workerCode, int page, int limit) {
        
		String res = "";
		try {
		JSONObject jsonobj = new JSONObject();
                if(limit>0){
		Pageable pageableRequest = PageRequest.of(page, limit);
		List<Object> objlst= workerCertificationsRepository.getWorkerCertificationsByWorkerCode(workerCode,pageableRequest);
		List<WorkerCertificationsResponse> maplst=new ArrayList<WorkerCertificationsResponse>();
		if(objlst!=null && objlst.size()>0)
		{
                    int count=0;
                    List<Object> objlstcnt= workerCertificationsRepository.getWorkerCertificationsByWorkerCode(workerCode);
                    if(objlstcnt!=null && objlstcnt.size()>0 )
                    {
                        count=objlstcnt.size();
                    }
		for (int i = 0; i < objlst.size(); i++) {
		Object[] arr = (Object[]) objlst.get(i);
		if (arr.length >= 4) {
			WorkerCertificationsResponse wcr = new WorkerCertificationsResponse();
			
			WorkerCertifications wc = (WorkerCertifications) arr[0];
		
			wcr.setId(wc.getId());
			wcr.setCertificationCode(wc.getCertificationCode());
			wcr.setWorkerCode(wc.getWorkerCode());
			
			wcr.setName((String) arr[1]);
                        CertificationsMaster cm=(CertificationsMaster) arr[2];
                        if(cm!=null)
                        {
                          wcr.setCertificationName(cm.getCertificationName()); 
                          wcr.setOrganizationCode(cm.getOrganizationCode());
                        }
			wcr.setOrganizationName((String) arr[3]);
			maplst.add(wcr);	

		}
		}
		if (maplst.size() > 0) {
		ObjectMapper mapperObj = new ObjectMapper();
		String Detail = mapperObj.writeValueAsString(maplst);
		jsonobj.put("responsecode", 200);
		jsonobj.put("message", "Success");
                jsonobj.put("count", count);
		jsonobj.put("timestamp", new Date());
		jsonobj.put("data", new JSONArray(Detail));
		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("message", "Record Not Found");
		jsonobj.put("timestamp", new Date());
		       }
		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("message", "Record Not Found");
		jsonobj.put("timestamp", new Date());
		}
                } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
		 res = jsonobj.toString();
		} 
		catch (JSONException ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
		res = derr.toString();
		ex.printStackTrace();
		} catch (Exception ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
		res = derr.toString();
		ex.printStackTrace();
		}
		return res;
	
    }

    @Override
    public String getWorkerCertificationsByWorkerCode(String workerCode) {
       
		String res = "";
		try {
		JSONObject jsonobj = new JSONObject();
                
		List<Object> objlst= workerCertificationsRepository.getWorkerCertificationsByWorkerCode(workerCode);
		List<WorkerCertificationsResponse> maplst=new ArrayList<WorkerCertificationsResponse>();
		if(objlst!=null && objlst.size()>0)
		{
		for (int i = 0; i < objlst.size(); i++) {
		Object[] arr = (Object[]) objlst.get(i);
		if (arr.length >= 4) {
			WorkerCertificationsResponse wcr = new WorkerCertificationsResponse();
			
			WorkerCertifications wc = (WorkerCertifications) arr[0];
		
			wcr.setId(wc.getId());
			wcr.setCertificationCode(wc.getCertificationCode());
			wcr.setWorkerCode(wc.getWorkerCode());
			wcr.setName((String) arr[1]);
                        CertificationsMaster cm=(CertificationsMaster) arr[2];
                        if(cm!=null)
                        {
                          wcr.setCertificationName(cm.getCertificationName()); 
                          wcr.setOrganizationCode(cm.getOrganizationCode());
                        }
			wcr.setOrganizationName((String) arr[3]);
			maplst.add(wcr);	

		}
		}
		if (maplst.size() > 0) {
		ObjectMapper mapperObj = new ObjectMapper();
		String Detail = mapperObj.writeValueAsString(maplst);
		jsonobj.put("responsecode", 200);
		jsonobj.put("message", "Success");
                jsonobj.put("timestamp", new Date());
		jsonobj.put("data", new JSONArray(Detail));
		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("message", "Record Not Found");
		jsonobj.put("timestamp", new Date());
		       }
		} else {
		jsonobj.put("responsecode", 404);
		jsonobj.put("message", "Record Not Found");
		jsonobj.put("timestamp", new Date());
		}
                
		 res = jsonobj.toString();
		} 
		catch (JSONException ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
		res = derr.toString();
		ex.printStackTrace();
		} catch (Exception ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
		res = derr.toString();
		ex.printStackTrace();
		}
		return res;
	
    }


}
