/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerhoursofoperation.dtob;

/**
 *
 * @author m.salman
 */
public class WorkerHoursofOperationResponse {
      private Long id;
      private String workerhoursOfOperationCode;
      private String workerCode;
      private String workername;
      private String fromTime;
      private String toTime; 
      private Integer dayCode;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWorkerhoursOfOperationCode() {
        return workerhoursOfOperationCode;
    }

    public void setWorkerhoursOfOperationCode(String workerhoursOfOperationCode) {
        this.workerhoursOfOperationCode = workerhoursOfOperationCode;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getWorkername() {
        return workername;
    }

    public void setWorkername(String workername) {
        this.workername = workername;
    }
  
    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public Integer getDayCode() {
        return dayCode;
    }

    public void setDayCode(Integer dayCode) {
        this.dayCode = dayCode;
    }
      
      
}
