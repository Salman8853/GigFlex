/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerhoursofoperation.service;

import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursOfOperationRequest;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface WorkerHoursofOperationService {
//  public String findHoursOfOperationByWorkerCode(String workerCode);
  public String saveWorkerHoursofOperation(WorkerHoursOfOperationRequest workerhoursOfOperationReq, String ip);
  
 public String getworkerHoursofOperationByworkerCodeAnddayCode(String workerCode, Integer dayCode);
 
  public String getworkerHoursOfOperationByworkerCode(String workerCode);
  
  public String getAllworkerHoursofOperation();
  
  public String updateworkerHoursOfOperationByhourofOperationCode(String hoursOfOperationCode, WorkerHoursOfOperationRequest workerhoursOfOperationReq,String ip);

    public String cancelWorkerHoursOfOperationByHoursOfOperationCode(String hoursOfOperationCode);

    public String cancelMultipleWorkerHoursOfOperationByHoursOfOperationCode(List<String> hoursOfOperationCodeList);
}
