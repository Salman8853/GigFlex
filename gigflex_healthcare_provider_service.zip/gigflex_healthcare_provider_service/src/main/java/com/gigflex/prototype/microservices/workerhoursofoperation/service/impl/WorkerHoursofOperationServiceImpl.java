/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerhoursofoperation.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursOfOperation;
import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursOfOperationRequest;
import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursofOperationResponse;
import com.gigflex.prototype.microservices.workerhoursofoperation.repository.WorkerHoursofOperationDao;
import com.gigflex.prototype.microservices.workerhoursofoperation.service.WorkerHoursofOperationService;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
public class WorkerHoursofOperationServiceImpl implements WorkerHoursofOperationService{
    @Autowired
    WorkerHoursofOperationDao workerHoursofOperationDao;
    
    @Autowired
    WorkerRepository workerRepository;
    
     private static final Logger LOG = LoggerFactory.getLogger(WorkerHoursofOperationServiceImpl.class);
    @Override
    public String saveWorkerHoursofOperation(WorkerHoursOfOperationRequest Req, String ip)
    {
         String res="";
         try{
            JSONObject jsonobj = new JSONObject();
              if(!GigflexDateUtil.isDate(Req.getFromTime().trim(), GigflexConstants.HH_MM_SS))
                     {
                         GigflexResponse derr = new GigflexResponse(400, new Date(),"Plz send From time in correct format("+GigflexConstants.HH_MM_SS+") ");
	                  return derr.toString();
                               }
               if(!GigflexDateUtil.isDate(Req.getToTime().trim(), GigflexConstants.HH_MM_SS))
               {
                           GigflexResponse derr = new GigflexResponse(400, new Date(),"Plz send To time in correct format("+GigflexConstants.HH_MM_SS+") ");
                           return derr.toString();
               }
                   
            if(Req.getFromTime().trim().length() > 0)
             {
                 String strFromTime = Req.getFromTime();
                                   
                    Date fromTime = GigflexDateUtil.convertStringToDate(strFromTime, GigflexConstants.HH_MM_SS); 
                       if(fromTime == null)
                       {
                           GigflexResponse derr = new GigflexResponse(400, new Date(),"Plz send from time in correct format("+GigflexConstants.HH_MM_SS+") ");
			    return derr.toString();
                        }
             }
              if(Req.getToTime().trim().length() > 0)
               {
                  String strToTime = Req.getToTime();
                                   
                       Date toTime = GigflexDateUtil.convertStringToDate(strToTime, GigflexConstants.HH_MM_SS); 
                      if(toTime == null)
                      {
                              GigflexResponse derr = new GigflexResponse(400, new Date(),"Plz send to time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                       }
              }
              
         WorkerHoursOfOperation wrkrofoperation =workerHoursofOperationDao.getHoursByWorkerCodeAndDayCode(Req.getWorkerCode(), Req.getDayCode());
          if(!(wrkrofoperation!=null &&wrkrofoperation.getId()>0))
          {
              WorkerHoursOfOperation hoursOfOperation = new WorkerHoursOfOperation();

                    hoursOfOperation.setIpAddress(ip);                            
                    hoursOfOperation.setWorkerCode(Req.getWorkerCode());
                    hoursOfOperation.setDayCode(Req.getDayCode());
                    hoursOfOperation.setFromTime(Req.getFromTime());
                    hoursOfOperation.setToTime(Req.getToTime());  
              WorkerHoursOfOperation  wkrhop=  workerHoursofOperationDao.save(hoursOfOperation);
              if(wkrhop!=null && wkrhop.getId()>0)
              {
               jsonobj.put("responsecode", 200);
               jsonobj.put("timestamp", new Date());
               jsonobj.put("message","WorkerHours Of Operation has been added successfully.");
               ObjectMapper mapperObj = new ObjectMapper();
               String Detail = mapperObj.writeValueAsString(wkrhop);
               jsonobj.put("data", new JSONObject(Detail));
              }else
              {
                jsonobj.put("responsecode", 400);
                jsonobj.put("timestamp", new Date());                                
                jsonobj.put("message", "Failed");
              }
         res=jsonobj.toString();
          }else
          {
             jsonobj.put("responsecode", 409);
             jsonobj.put("timestamp", new Date());
             jsonobj.put("message", "Driver Code with Day Code already exist.");
          }
        res=jsonobj.toString();
       }catch(JSONException | JsonProcessingException ex)
       {
         GigflexResponse derr = new GigflexResponse(500, new Date(),"JSON parsing exception occurred.");
		res = derr.toString();
                ex.printStackTrace();
                LOG.info(ex.toString());
                return res;
       }catch(Exception ex)
       {
       GigflexResponse derr = new GigflexResponse(500, new Date(),"exception occurred.");
		res = derr.toString();
                ex.printStackTrace();
                LOG.info(ex.toString());
                return res;
       }
       return res;  
    }
    @Override
    public String getworkerHoursofOperationByworkerCodeAnddayCode(String workerCode, Integer dayCode)
    {
      String res="";
       try
       {
          JSONObject jsonobj = new JSONObject();  
         WorkerHoursOfOperation  wkrhop = workerHoursofOperationDao.getHoursByWorkerCodeAndDayCode(workerCode, dayCode);
         if(wkrhop!=null && wkrhop.getId()>0)
         { Worker worker= workerRepository.findByWorkerCode(wkrhop.getWorkerCode());
             WorkerHoursofOperationResponse wkrhopRes=new WorkerHoursofOperationResponse();
               wkrhopRes.setId(wkrhop.getId());
               wkrhopRes.setDayCode(wkrhop.getDayCode());
               wkrhopRes.setWorkerCode(wkrhop.getWorkerCode());
               wkrhopRes.setWorkername(worker.getName());
               wkrhopRes.setWorkerhoursOfOperationCode(wkrhop.getWorkerhoursOfOperationCode());
               wkrhopRes.setFromTime(wkrhop.getFromTime());
               wkrhopRes.setToTime(wkrhop.getToTime());
               jsonobj.put("responsecode", 200);
               jsonobj.put("timestamp", new Date());
               jsonobj.put("message","ok");
               ObjectMapper mapperObj = new ObjectMapper();
               String Detail = mapperObj.writeValueAsString(wkrhopRes);
               jsonobj.put("data", new JSONObject(Detail));
         }else
         {
         jsonobj.put("responsecode", 400);
         jsonobj.put("timestamp", new Date());                                
         jsonobj.put("message", "Record Not Found");
         }
        res= jsonobj.toString();
       }catch(JSONException | JsonProcessingException ex)
       {   GigflexResponse derr = new GigflexResponse(500, new Date()," JSON parsing exception occurred.");
		res = derr.toString();
                ex.printStackTrace();
                LOG.info(ex.toString());
                return res;
       }catch(Exception ex)
       {
        GigflexResponse derr = new GigflexResponse(500, new Date(),"exception occurred.");
		res = derr.toString();
                ex.printStackTrace();
                LOG.info(ex.toString());
                return res;
       }
       return res;
    }
    @Override
    public String getworkerHoursOfOperationByworkerCode(String workerCode)
    {
      String res="";
       try
       { 
          JSONObject jsonobj = new JSONObject();  
          List<WorkerHoursofOperationResponse>whopRes=new ArrayList<>();
         List<WorkerHoursOfOperation>  wkrhoplist = workerHoursofOperationDao.getHoursByWorkerCode(workerCode);
         if(wkrhoplist!=null && wkrhoplist.size()>0)
         {    for(WorkerHoursOfOperation wkrhop:wkrhoplist)
             { Worker worker= workerRepository.findByWorkerCode(wkrhop.getWorkerCode());
               WorkerHoursofOperationResponse wkrhopRes=new WorkerHoursofOperationResponse();
               wkrhopRes.setId(wkrhop.getId());
               wkrhopRes.setDayCode(wkrhop.getDayCode());
               wkrhopRes.setWorkerCode(wkrhop.getWorkerCode());
               wkrhopRes.setWorkername(worker.getName());
               wkrhopRes.setWorkerhoursOfOperationCode(wkrhop.getWorkerhoursOfOperationCode());
               wkrhopRes.setFromTime(wkrhop.getFromTime());
               wkrhopRes.setToTime(wkrhop.getToTime());
               whopRes.add(wkrhopRes);
             }
          
               jsonobj.put("responsecode", 200);
               jsonobj.put("timestamp", new Date());
               jsonobj.put("message","ok");
               ObjectMapper mapperObj = new ObjectMapper();
               String Detail = mapperObj.writeValueAsString(whopRes);
               jsonobj.put("data", new JSONArray(Detail));
         }else
         {
         jsonobj.put("responsecode", 400);
         jsonobj.put("timestamp", new Date());                                
         jsonobj.put("message", "Record Not Found");
         }
        res= jsonobj.toString();
       }catch(JSONException | JsonProcessingException ex)
       {   GigflexResponse derr = new GigflexResponse(500, new Date()," JSON parsing exception occurred.");
		res = derr.toString();
                ex.printStackTrace();
                LOG.info(ex.toString());
                return res;
       }catch(Exception ex)
       {
        GigflexResponse derr = new GigflexResponse(500, new Date(),"exception occurred.");
		res = derr.toString();
                ex.printStackTrace();
                LOG.info(ex.toString());
                return res;
       }
       return res;
    }
      public String getAllworkerHoursofOperation()
      {
          String res="";
          try{
              JSONObject jsonobj=new JSONObject();
              List<WorkerHoursofOperationResponse>whopResList=new ArrayList<>();
              List<WorkerHoursOfOperation> whopList=    workerHoursofOperationDao.findAll();
              if(whopList!=null && whopList.size()>0)
              {
               for(WorkerHoursOfOperation wkrhop:whopList)
               {  
                     Worker worker= workerRepository.findByWorkerCode(wkrhop.getWorkerCode());
                     WorkerHoursofOperationResponse wkrhopRes=new WorkerHoursofOperationResponse();
                     wkrhopRes.setId(wkrhop.getId());
                     wkrhopRes.setDayCode(wkrhop.getDayCode());
                     wkrhopRes.setWorkerCode(wkrhop.getWorkerCode());
                     wkrhopRes.setWorkername(worker.getName());
                     wkrhopRes.setWorkerhoursOfOperationCode(wkrhop.getWorkerhoursOfOperationCode());
                     wkrhopRes.setFromTime(wkrhop.getFromTime());
                     wkrhopRes.setToTime(wkrhop.getToTime());
                     whopResList.add(wkrhopRes);
     
               }
               if(whopResList!=null && whopResList.size()>0)
               {
                 jsonobj.put("responsecode", 200);
                 jsonobj.put("timestamp", new Date());
                 jsonobj.put("message","ok");
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(whopResList);
                jsonobj.put("data", new JSONArray(Detail));
               }else
               {
               jsonobj.put("responsecode", 400);
               jsonobj.put("timestamp", new Date());                                
               jsonobj.put("message", "List not Found");
               }
             res=jsonobj.toString();
              }else
              {
               jsonobj.put("responsecode", 400);
               jsonobj.put("timestamp", new Date());                                
               jsonobj.put("message", "List not Found");
              }
            res=jsonobj.toString();
             }catch(JSONException |JsonProcessingException ex)
             {
                GigflexResponse derr = new GigflexResponse(500, new Date()," JSON parsing exception occurred.");
		res = derr.toString();
                ex.printStackTrace();
                LOG.info(ex.toString());
                return res;
             }catch(Exception ex)
             {
                GigflexResponse derr = new GigflexResponse(500, new Date(),"exception occurred.");
		res = derr.toString();
                ex.printStackTrace();
                LOG.info(ex.toString());
                return res;
             }
        return res;         
      }
      
    @Override
      public String updateworkerHoursOfOperationByhourofOperationCode(String hoursOfOperationCode, WorkerHoursOfOperationRequest Req,String ip)
      {
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        	if (Req.getWorkerCode()!=null && Req.getWorkerCode().trim().length() > 0
                                && Req.getFromTime()!= null &&  Req.getFromTime().trim().length() > 0 
                                && Req.getToTime()!= null && Req.getToTime().trim().length() >0  
                                &&Req.getDayCode() != null && Req.getDayCode()>0 &&  Req.getDayCode() < 8
                               ) {

                                if(!GigflexDateUtil.isDate(Req.getFromTime().trim(), GigflexConstants.HH_MM_SS))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send From time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                               }
                               
                               if(!GigflexDateUtil.isDate(Req.getToTime().trim(), GigflexConstants.HH_MM_SS))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send To time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                               }
                                                                
                                    
                                if(Req.getFromTime().trim().length() > 0)
                                {
                                      String strFromTime = Req.getFromTime();

                                      Date fromTime = GigflexDateUtil.convertStringToDate(strFromTime, GigflexConstants.HH_MM_SS); 
                                      if(fromTime == null)
                                      {
                                           GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                   "Plz send from time in correct format("+GigflexConstants.HH_MM_SS+") ");
                                                   return derr.toString();
                                      }
                                }
                            
                                    if(Req.getToTime().trim().length() > 0)
                                   {
                                       String strToTime = Req.getToTime();

                                       Date toTime = GigflexDateUtil.convertStringToDate(strToTime, GigflexConstants.HH_MM_SS); 
                                       if(toTime == null)
                                       {
                                            GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                    "Plz send to time in correct format("+GigflexConstants.HH_MM_SS+") ");
                                                    return derr.toString();
                                       }
                                   }
                                    
                                     WorkerHoursOfOperation whop = workerHoursofOperationDao.getworkerHoursofOperationByHoursOfOperationCode(hoursOfOperationCode);
                                
                                     if( whop != null && whop.getId() > 0)
                                     {
									
                                                whop.setIpAddress(ip);                            
                                                whop.setWorkerCode(Req.getWorkerCode());
                                                whop.setDayCode(Req.getDayCode());
                                                whop.setFromTime(Req.getFromTime());
                                                whop.setToTime(Req.getToTime());  

						WorkerHoursOfOperation whoursOfOperationRes = workerHoursofOperationDao.save(whop);
						if (whoursOfOperationRes != null && whoursOfOperationRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message","Hours Of Operation updation has been done");
							jsonobj.put("timestamp", new Date());
							
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message","Hours Of Operation updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					res= jsonobj.toString();
                                }
                                else {
                                   jsonobj.put("responsecode", 409);
                                   jsonobj.put("timestamp", new Date());
                                   jsonobj.put("message", "Record Not Found.");
				}
                                  res= jsonobj.toString();   
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Worker Code , From Time , To Time & Day Code should not be blank");

				}
			
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.info(ex.toString()); 
		}
		return res;
      }

    @Override
    public String cancelWorkerHoursOfOperationByHoursOfOperationCode(String hoursOfOperationCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerHoursOfOperation hoursOfOperationInDb = workerHoursofOperationDao.getworkerHoursofOperationByHoursOfOperationCode(hoursOfOperationCode);
			if (hoursOfOperationInDb != null && hoursOfOperationInDb.getId() > 0) {

                                hoursOfOperationInDb.setIsDeleted(true);                                
                                WorkerHoursOfOperation hoursOfOperationRes = workerHoursofOperationDao.save(hoursOfOperationInDb);
                                if (hoursOfOperationRes != null && hoursOfOperationRes.getId() > 0) {
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message",
                                                        "Hours Of Operation cancelled successfully.");
                                        // kafkaService.
                                } else {
                                        jsonobj.put("responsecode", 400);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Failed");
                                }
                        }

			else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
                    GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
                    res = derr.toString();
                    ex.printStackTrace();
                 LOG.error("Error in cancelWorkerHoursOfOperationByHoursOfOperationCode>>>>>>", ex);
                }catch(org.springframework.orm.jpa.JpaSystemException ex)
                {
                    GigflexResponse derr = new GigflexResponse(401, new Date(), GigUtil.getRootException(ex));
                    res = derr.toString();
                    ex.printStackTrace();
		} catch (Exception ex) {
		 ex.printStackTrace();
                  LOG.error("Error in cancelWorkerHoursOfOperationByHoursOfOperationCode>>>>>>", ex);	
                    GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String cancelMultipleWorkerHoursOfOperationByHoursOfOperationCode(List<String> hoursOfOperationCodeList) {
        
        String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String hoursOfOperationCode : hoursOfOperationCodeList) {
				if (hoursOfOperationCode != null && hoursOfOperationCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					hoursOfOperationCode = hoursOfOperationCode.trim();

					WorkerHoursOfOperation hoursOfOperationInDb = workerHoursofOperationDao.getworkerHoursofOperationByHoursOfOperationCode(hoursOfOperationCode);

					if (hoursOfOperationInDb != null && hoursOfOperationInDb.getId() > 0) {
						
						try{
							hoursOfOperationInDb.setIsDeleted(true);                                                        
							WorkerHoursOfOperation hoursOfOperationRes = workerHoursofOperationDao.save(hoursOfOperationInDb);
							if (hoursOfOperationRes != null && hoursOfOperationRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", hoursOfOperationCode);
								jsonobj.put("message",
										"Hours Of Operation cancelled successfully.");
								// kafkaService.sendUseronUpdate(usersDataRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", hoursOfOperationCode);
								jsonobj.put("message", "Failed");
							}
						}catch(org.springframework.orm.jpa.JpaSystemException ex){
							jsonobj.put("responsecode", 500);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", hoursOfOperationCode);
							jsonobj.put("message",  GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", hoursOfOperationCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple cancel failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.info(ex.toString()); 
		}
		return res;
    }
}
