/**
 * 
 */
package com.gigflex.prototype.microservices.workeroffdays.dtob;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;


/**
 * @author ajit.p
 *
 */

@Entity
@Table(name = "worker_offdays")
public class WorkerOffdays extends CommonAttributes implements Serializable {
	    
	private static final long serialVersionUID = 1L;
	
		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id")
	    private Long id;

		@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
		@GenericGenerator(name = "uuid", strategy = "uuid2")
		@Column(name = "off_days_code", unique = true)
	    private String offDaysCode;
	    
	    @Column(name = "worker_code")
	    private String workerCode;
	   
	    @Column(name = "fromdate", columnDefinition="DATETIME")
	    private Date fromDate;
	    
	    @Column(name = "todate", columnDefinition="DATETIME")
	    private Date toDate;
            
                    
        @Column(name = "days_code")
	    private String daysCode;
        
        @PrePersist
    	private void assignUUID() {
    		if (this.getOffDaysCode() == null || this.getOffDaysCode().length() == 0) {
    			this.setOffDaysCode(UUID.randomUUID().toString());
    		}
    	}

    public String getDaysCode() {
        return daysCode;
    }

    public void setDaysCode(String daysCode) {
        this.daysCode = daysCode;
    }
	    
            
	    @Column(name = "isrecurring")
	    private Boolean isRecurring;

		public WorkerOffdays(Long id) {
			super();
			this.id = id;
		}

		public WorkerOffdays() {
			super();
		}

		public WorkerOffdays(Long id, String offDaysCode, String workerCode, Date fromDate, Date toDate,
				Boolean isRecurring, String daysCode) {
			super();
			this.id = id;
			this.offDaysCode = offDaysCode;
			this.workerCode = workerCode;
			this.fromDate = fromDate;
			this.toDate = toDate;
			this.isRecurring = isRecurring;
                        this.daysCode = daysCode;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getOffDaysCode() {
			return offDaysCode;
		}

		public void setOffDaysCode(String offDaysCode) {
			this.offDaysCode = offDaysCode;
		}

		public String getWorkerCode() {
			return workerCode;
		}

		public void setWorkerCode(String workerCode) {
			this.workerCode = workerCode;
		}

		public Date getFromDate() {
			return fromDate;
		}

		public void setFromDate(Date fromDate) {
			this.fromDate = fromDate;
		}

		public Date getToDate() {
			return toDate;
		}

		public void setToDate(Date toDate) {
			this.toDate = toDate;
		}

    public Boolean getIsRecurring() {
        return isRecurring;
    }

    public void setIsRecurring(Boolean isRecurring) {
        this.isRecurring = isRecurring;
    }

		

		public static long getSerialversionuid() {
			return serialVersionUID;
		}

		@Override
		public String toString() {
			return "WorkerOffdays [id=" + id + ", offDaysCode=" + offDaysCode + ", workerCode=" + workerCode
					+ ", fromDate=" + fromDate + ", toDate=" + toDate + ", isRecurring=" + isRecurring + "]";
		}

	    
	  
}