package com.gigflex.prototype.microservices.workeroffdays.dtob;

public class WorkerOffdaysRequest {

	 private String workerCode;
	 
	 private String fromDate;
	 
	 private String toDate;
	 
	 private Boolean isRecurring;
	 
	 private String daysCode;

	public String getDaysCode() {
		return daysCode;
	}

	public void setDaysCode(String daysCode) {
		this.daysCode = daysCode;
	}

	public Boolean getIsRecurring() {
		return isRecurring;
	}

	public void setIsRecurring(Boolean isRecurring) {
		this.isRecurring = isRecurring;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}




	 
	 

}
