package com.gigflex.prototype.microservices.workeroffdays.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMaster;
import com.gigflex.prototype.microservices.daysmaster.repository.DaysMasterDao;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.workeroffdays.dtob.WorkerOffdays;
import com.gigflex.prototype.microservices.workeroffdays.dtob.WorkerOffdaysRequest;
import com.gigflex.prototype.microservices.workeroffdays.repository.WorkerOffdaysRepository;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workeroffdays.service.WorkerOffdaysService;
import com.gigflex.prototype.microservices.workeroffdays.search.WorkerOffdaysSpecificationsBuilder;
import com.gigflex.prototype.microservices.workinglocation.repository.WorkingLocationRepository;

@Service
public class WorkerOffdaysServiceImpl implements WorkerOffdaysService {
	@Autowired
	WorkerOffdaysRepository workerOffdaysRepository;
	
	@Autowired
	private WorkerRepository workerDao;
	
	@Autowired
	private DaysMasterDao daysMasterDao;
	
	@Autowired
	private WorkingLocationRepository wrkingLocDao;

	@Override
	public String getAllWorkerOffDays() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerOffdays> workerdata = workerOffdaysRepository.getAllWorkerOffDays();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (workerdata != null && workerdata.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerdata);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkerOffdaysById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerOffdays workerdaysData = workerOffdaysRepository
					.getWorkerOffDaysById(id);
			if (workerdaysData != null && workerdaysData.getId()>0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerdaysData);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public void updateWorkerOffdays(WorkerOffdays worker) {
		WorkerOffdays workerOffdaysInDb = workerOffdaysRepository.getOne(worker
				.getId());
		if (workerOffdaysInDb != null) {
			workerOffdaysInDb.setId(worker.getId());
			workerOffdaysRepository.save(workerOffdaysInDb);

		}

	}

	@Override
	public String updateWorkerOffdays(Long id,
			WorkerOffdaysRequest workerOffdaysrqst, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && workerOffdaysrqst != null) {
				if (workerOffdaysrqst.getDaysCode() != null
						&& workerOffdaysrqst.getDaysCode().trim().length() > 0
						&& workerOffdaysrqst.getWorkerCode() != null
						&& workerOffdaysrqst.getWorkerCode().trim().length() > 0) {

					WorkerOffdays offDayslst = workerOffdaysRepository
							.getWorkerOffDaysById(id);
					if (offDayslst != null && offDayslst.getId() > 0) {

						Date frmDt = null;
						Date toDt = null;

						try {
							frmDt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
									.parse(workerOffdaysrqst.getFromDate()
											.trim());
							toDt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
									.parse(workerOffdaysrqst.getToDate().trim());
							if (frmDt == null || toDt == null) {
								GigflexResponse derr = new GigflexResponse(400,
										new Date(),
										"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
								return derr.toString();
							}
						} catch (Exception ex) {
							ex.printStackTrace();
							GigflexResponse derr = new GigflexResponse(400,
									new Date(),
									"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
							return derr.toString();
						}

						DaysMaster dm = daysMasterDao
								.getDaysMasterByDaysCode(workerOffdaysrqst
										.getDaysCode());
						if (dm != null && dm.getId() > 0) {

							Worker worker = workerDao
									.findByWorkerCode(workerOffdaysrqst
											.getWorkerCode());
							if (worker != null && worker.getId() > 0) {

								WorkerOffdays wod = workerOffdaysRepository
										.getWorkerOffDaysCheckForUpdate(
												id,
												workerOffdaysrqst.getDaysCode(),
												workerOffdaysrqst
														.getWorkerCode());
								if (wod != null && wod.getId() > 0) {
									jsonobj.put("responsecode", 409);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message",
											"Record already exist.");
								} else {

									WorkerOffdays wo = offDayslst;
//									wo.setFromDate(workerOffdaysrqst
//											.getFromDate());
//									wo.setToDate(workerOffdaysrqst.getToDate());
									wo.setIsRecurring(workerOffdaysrqst
											.getIsRecurring());
									wo.setDaysCode(workerOffdaysrqst
											.getDaysCode());
									wo.setWorkerCode(workerOffdaysrqst
											.getWorkerCode());
									wo.setIpAddress(ip);
									WorkerOffdays woRes = workerOffdaysRepository
											.save(wo);
									if (woRes != null && woRes.getId() > 0) {
										jsonobj.put("responsecode", 200);
										jsonobj.put("message",
												"Worker Off days updation has been done");
										jsonobj.put("timestamp", new Date());
										ObjectMapper mapperObj = new ObjectMapper();
										String Detail = mapperObj
												.writeValueAsString(woRes);
										jsonobj.put("data", new JSONObject(
												Detail));
									} else {
										jsonobj.put("responsecode", 400);
										jsonobj.put("message",
												"Worker Off days updation has been failed.");
										jsonobj.put("timestamp", new Date());
									}
								}
							} else {
								jsonobj.put("message", "Worker Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
						} else {
							jsonobj.put("message", "Days Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getByOffDaysCode(String offDaysCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerOffdays offdayslst = workerOffdaysRepository
					.getWorkerOffDaysByOffDaysCode(offDaysCode);
			if (offdayslst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(offdayslst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveWorkerOffdays(WorkerOffdaysRequest workerOffdaysrqst,
			String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerOffdaysrqst != null) {
				if (workerOffdaysrqst.getDaysCode() != null
						&& workerOffdaysrqst.getDaysCode().trim().length() > 0
						&& workerOffdaysrqst.getWorkerCode() != null
						&& workerOffdaysrqst.getWorkerCode().trim().length() > 0) {

					Date frmDt = null;
					Date toDt = null;

					try {
						frmDt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(workerOffdaysrqst.getFromDate().trim());
						toDt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(workerOffdaysrqst.getToDate().trim());
						if (frmDt == null || toDt == null) {
							GigflexResponse derr = new GigflexResponse(400,
									new Date(),
									"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
							return derr.toString();
						}
					} catch (Exception ex) {
						ex.printStackTrace();
						GigflexResponse derr = new GigflexResponse(400,
								new Date(),
								"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
						return derr.toString();
					}

					DaysMaster dm = daysMasterDao
							.getDaysMasterByDaysCode(workerOffdaysrqst
									.getDaysCode());
					if (dm != null && dm.getId() > 0) {

						Worker worker = workerDao
								.findByWorkerCode(workerOffdaysrqst
										.getWorkerCode());
						if (worker != null && worker.getId() > 0) {
							
//							WorkerPreferredLocation wpl = workerOffdaysRepository.getByWorkerAndOrgCode
//							
//							String locationCode = workerOffdaysRepository.getLocationCodeByWorkerAndOrgCode(workerOffdaysrqst.getWorkerCode())
//							
//							WorkingLocation wl = wrkingLocDao
//									.findByWorkingLocationCode(locationCode);
//							if (wl != null && wl.getId() > 0) {
//
//								frmDt = GigflexDateUtil
//										.convertStringDateToGMT(workerOffdaysrqst
//												.getFromDate().trim(), wl
//												.getTimeZone(),
//												"yyyy-MM-dd HH:mm:ss");
//								toDt = GigflexDateUtil
//										.convertStringDateToGMT(workerOffdaysrqst.getToDate()
//												.trim(), wl
//												.getTimeZone(),
//												"yyyy-MM-dd HH:mm:ss");

							WorkerOffdays wod = workerOffdaysRepository
									.getWorkerOffDaysCheckForSave(
											workerOffdaysrqst.getDaysCode(),
											workerOffdaysrqst.getWorkerCode());
							if (wod != null && wod.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {

								WorkerOffdays workerOffDays = new WorkerOffdays();
								workerOffDays.setDaysCode(workerOffdaysrqst
										.getDaysCode());
//								workerOffDays.setFromDate(workerOffdaysrqst
//										.getFromDate());
//								workerOffDays.setToDate(workerOffdaysrqst
//										.getToDate());
								workerOffDays.setIsRecurring(workerOffdaysrqst
										.getIsRecurring());
								workerOffDays.setWorkerCode(workerOffdaysrqst
										.getWorkerCode());
								workerOffDays.setIpAddress(ip);

								WorkerOffdays offdaysRes = workerOffdaysRepository
										.save(workerOffDays);

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());

								if (offdaysRes != null
										&& offdaysRes.getId() > 0) {
									jsonobj.put("message",
											"Worker Off Days has been added successfully.");
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(offdaysRes);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("message", "Failed");
								}
							}
						} else {
							jsonobj.put("message", "Worker Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("message", "Days Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");

				}
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteWorkerOffdaysById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<WorkerOffdays> workerData = workerOffdaysRepository
					.findById(id);
			if (workerData.isPresent() && workerData.get() != null) {
				workerOffdaysRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker Off Days has been deleted.");
				jsonobj.put("timestamp", new Date());
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;

	}

	@Override
	public String deleteByOffDaysCode(String offDaysCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Integer deleteByWorkerCode = workerOffdaysRepository
					.deleteByOffDaysCode(offDaysCode);
			if (deleteByWorkerCode != 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker Off Days has been deleted.");
				jsonobj.put("timestamp", new Date());
				res = jsonobj.toString();
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}
	
	@Override
	public String softDeleteByOffDaysCode(String offDaysCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerOffdays offdayslst = workerOffdaysRepository
					.getWorkerOffDaysByOffDaysCode(offDaysCode);
			if (offdayslst != null && offdayslst.getId() > 0) {
				offdayslst.setIsDeleted(true);
				WorkerOffdays offdaysDataRes = workerOffdaysRepository.save(offdayslst);
				if (offdaysDataRes != null && offdaysDataRes.getId()>0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "WorkerOffDays deleted successfully.");
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}
				
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public WorkerOffdays saveWorkerOffdays(WorkerOffdays workerOffdays) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String softMultipleDeleteByOffDaysCode(List<String> offDaysCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String offDaysCode : offDaysCodeList) {
				if(offDaysCode != null && offDaysCode.trim().length()>0){
				JSONObject jsonobj = new JSONObject();

				offDaysCode = offDaysCode.trim();

				WorkerOffdays offdayslst = workerOffdaysRepository
						.getWorkerOffDaysByOffDaysCode(offDaysCode);
					
					if (offdayslst != null && offdayslst.getId() > 0) {
						
						offdayslst.setIsDeleted(true);
						WorkerOffdays offdaysDataRes = workerOffdaysRepository.save(offdayslst);
						if (offdaysDataRes != null && offdaysDataRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", offDaysCode);
							jsonobj.put("message", "WorkerOffDays deleted successfully.");
//							kafkaService.sendUseronUpdate(usersDataRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", offDaysCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", offDaysCode);
						jsonobj.put("message", "Record Not Found");
					}
				jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllWorkerOffDaysByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
	        Pageable pageableRequest = PageRequest.of(page, limit);
	        List<WorkerOffdays> offdayslst  = workerOffdaysRepository.getAllWorkerOffDays(pageableRequest);
	        jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (offdayslst != null && offdayslst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(offdayslst);
				jsonobj.put("data", new JSONArray(Detail));
			}
			 else
	            {
	                jsonobj.put("responsecode", 200);
	            jsonobj.put("message", "Record Not Found");
	            jsonobj.put("timestamp", new Date());
	            }
			res = jsonobj.toString();
		} catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
	    return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
            if(search != null && search.trim().length() > 0){
			JSONObject jsonobj = new JSONObject();
			
			WorkerOffdaysSpecificationsBuilder builder = new WorkerOffdaysSpecificationsBuilder();
		        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
		        java.util.regex.Matcher matcher = pattern.matcher(search + ",");
		        while (matcher.find()) {
		            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
		        }
		         
		        Specification<WorkerOffdays> spec = builder.build();
                        if(spec!=null){
		        List<WorkerOffdays> offdayslst  = workerOffdaysRepository.findAll(spec);
			if(offdayslst != null && offdayslst.size() > 0){
			for(WorkerOffdays workerOff : offdayslst){
				if(workerOff.getIsDeleted() != null && workerOff.getIsDeleted() != true){

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(workerOff);
					JSONObject jsonobjNew = new JSONObject();
					jsonobjNew.put("WorkerOffdays", new JSONObject(Detail));
					jarr.add(jsonobjNew);

			} 
				
			} 
			if (jarr.size() > 0) {
				
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			jsonobj.put("data", jarr);
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}
			
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}}
                        else{
                           jsonobj.put("responsecode", 400);
			   jsonobj.put("message", "Record Not Found!");
			   jsonobj.put("timestamp", new Date()); 
                        }
			res = jsonobj.toString();
		
            }else{
            	GigflexResponse derr = new GigflexResponse(400, new Date(),
    					"Input data is not valid.");
    			res = derr.toString();

            }
			
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}



}
