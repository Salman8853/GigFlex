package com.gigflex.prototype.microservices.workerpreferredlocation.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "worker_preferred_location")
public class WorkerPreferredLocation extends CommonAttributes implements Serializable{
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id")
	    private Long id;
	    
	    @Column(name = "worker_code", nullable = false)
	    private String workerCode;
	    
	    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
		@GenericGenerator(name = "uuid", strategy = "uuid2")
		@Column(name = "worker_preferred_location_code", unique = true)
	    private String workerPreferredLocationCode;
	    
	    @Column(name = "worker_organization_code")
	    private String workerOrganizationCode;
	    
	    @Column(name = "location")
		private String location;
	    
		@Column(name = "lat")
		private String lat;
		
		@Column(name = "lang")
		private String lang;
		
		@Column(name = "isactive")
		private Boolean isactive;
		

        @PrePersist
    	private void assignUUID() {
    		if (this.getWorkerPreferredLocationCode() == null || this.getWorkerPreferredLocationCode().length() == 0) {
    			this.setWorkerPreferredLocationCode(UUID.randomUUID().toString());
    		}
    	}
		
		public WorkerPreferredLocation(){}

		public WorkerPreferredLocation(Long id, String workerCode,
				String location, String lat, String lang, Boolean isactive) {
			super();
			this.id = id;
			this.workerCode = workerCode;
			this.location = location;
			this.lat = lat;
			this.lang = lang;
			this.isactive = isactive;
		}
		
		

		public String getWorkerPreferredLocationCode() {
			return workerPreferredLocationCode;
		}

		public void setWorkerPreferredLocationCode(String workerPreferredLocationCode) {
			this.workerPreferredLocationCode = workerPreferredLocationCode;
		}
		
		

		public String getWorkerOrganizationCode() {
			return workerOrganizationCode;
		}

		public void setWorkerOrganizationCode(String workerOrganizationCode) {
			this.workerOrganizationCode = workerOrganizationCode;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getWorkerCode() {
			return workerCode;
		}

		public void setWorkerCode(String workerCode) {
			this.workerCode = workerCode;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public String getLat() {
			return lat;
		}

		public void setLat(String lat) {
			this.lat = lat;
		}

		public String getLang() {
			return lang;
		}

		public void setLang(String lang) {
			this.lang = lang;
		}

		public Boolean getIsactive() {
			return isactive;
		}

		public void setIsactive(Boolean isactive) {
			this.isactive = isactive;
		}

		@Override
		public String toString() {
			return "WorkerPreferredLocation [workerCode=" + workerCode
					+ ", location=" + location + ", lat=" + lat + ", lang="
					+ lang + "]";
		}
		
		
	 
	 
	

}
