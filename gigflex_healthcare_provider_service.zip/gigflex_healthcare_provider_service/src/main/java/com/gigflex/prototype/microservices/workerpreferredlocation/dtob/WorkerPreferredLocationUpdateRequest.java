package com.gigflex.prototype.microservices.workerpreferredlocation.dtob;


public class WorkerPreferredLocationUpdateRequest {


	    private String workerCode;

		private String location;

		private String lat;

		private String lang;

		private Boolean isactive;
		
	    private String workerOrganizationCode;

		public String getWorkerCode() {
			return workerCode;
		}

		public void setWorkerCode(String workerCode) {
			this.workerCode = workerCode;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public String getLat() {
			return lat;
		}

		public void setLat(String lat) {
			this.lat = lat;
		}

		public String getLang() {
			return lang;
		}

		public void setLang(String lang) {
			this.lang = lang;
		}

		public Boolean getIsactive() {
			return isactive;
		}

		public void setIsactive(Boolean isactive) {
			this.isactive = isactive;
		}

		public String getWorkerOrganizationCode() {
			return workerOrganizationCode;
		}

		public void setWorkerOrganizationCode(String workerOrganizationCode) {
			this.workerOrganizationCode = workerOrganizationCode;
		}
		
		

}
