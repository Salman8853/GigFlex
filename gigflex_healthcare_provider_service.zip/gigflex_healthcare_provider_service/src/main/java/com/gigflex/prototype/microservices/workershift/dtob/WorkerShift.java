package com.gigflex.prototype.microservices.workershift.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;
@Entity
@Table(name = "worker_shift")
public class WorkerShift extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "shift_code", nullable = false)
	private String shiftCode;
	
	@Column(name = "shift_name", nullable = false)
	private String shiftName;

	@Column(name = "worker_name", nullable = false)
	private String workerName;
	
	@Column(name = "worker_code", nullable = false)
	private String workerCode;
	
	@Column(name = "organization_code", nullable = false)
	private String organizationCode;

	public WorkerShift() {
		super();
	}

	public WorkerShift(Long id) {
		super();
		this.id = id;
	}

	public WorkerShift(Long id, String shiftCode, String shiftName, String workerName, String workerCode,
			String organizationCode) {
		super();
		this.id = id;
		this.shiftCode = shiftCode;
		this.shiftName = shiftName;
		this.workerName = workerName;
		this.workerCode = workerCode;
		this.organizationCode = organizationCode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getShiftCode() {
		return shiftCode;
	}

	public void setShiftCode(String shiftCode) {
		this.shiftCode = shiftCode;
	}

	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public String getWorkerName() {
		return workerName;
	}

	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "WorkerShift [id=" + id + ", shiftCode=" + shiftCode + ", shiftName=" + shiftName + ", workerName="
				+ workerName + ", workerCode=" + workerCode + ", organizationCode=" + organizationCode + "]";
	}
	
	

}
