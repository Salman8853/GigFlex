/**
 * 
 */
package com.gigflex.prototype.microservices.workershift.dtob;

/**
 * @author ajit.p
 *
 */
public class WorkerShiftRequest {

	private String shiftCode;

	private String shiftName;

	private String workerName;

	private String workerCode;
	
	private String organizationCode;

	public WorkerShiftRequest() {
		super();
	}

	public WorkerShiftRequest(String shiftCode, String shiftName, String workerName, String workerCode,
			String organizationCode) {
		super();
		this.shiftCode = shiftCode;
		this.shiftName = shiftName;
		this.workerName = workerName;
		this.workerCode = workerCode;
		this.organizationCode = organizationCode;
	}

	public String getShiftCode() {
		return shiftCode;
	}

	public void setShiftCode(String shiftCode) {
		this.shiftCode = shiftCode;
	}

	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public String getWorkerName() {
		return workerName;
	}

	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	@Override
	public String toString() {
		return "WorkerShiftRequest [shiftCode=" + shiftCode + ", shiftName=" + shiftName + ", workerName=" + workerName
				+ ", workerCode=" + workerCode + ", organizationCode=" + organizationCode + "]";
	}

	
	
}
