/**
 *
 */
package com.gigflex.prototype.microservices.workershift.service.impl;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workershift.dtob.WorkerShift;
import com.gigflex.prototype.microservices.workershift.dtob.WorkerShiftRequest;
import com.gigflex.prototype.microservices.workershift.repository.WorkerShiftRepository;
import com.gigflex.prototype.microservices.workershift.search.WorkerShiftSpecificationsBuilder;
import com.gigflex.prototype.microservices.workershift.service.WorkerShiftService;

/**
 * @author ajit.p
 */
@Service
public class WorkerShiftServiceImpl implements WorkerShiftService {

    @Autowired
    WorkerShiftRepository workerShiftRepo;

    @Override
    public String saveWorkerShift(WorkerShiftRequest workerShiftReq, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            if (workerShiftReq != null) {
                if ((workerShiftReq.getOrganizationCode()) != null
                        && workerShiftReq.getOrganizationCode().trim().length() > 0
                        && (workerShiftReq.getWorkerCode()) != null
                        && workerShiftReq.getWorkerCode().trim().length() > 0) {

                    WorkerShift workerShiftToBeSaved = new WorkerShift();
                    WorkerShift workerShift = null;
                    WorkerShift workerShiftInDb = workerShiftRepo.getShiftWorkerByOrganizationCode(
                            workerShiftReq.getWorkerCode(), workerShiftReq.getOrganizationCode());

                    if (workerShiftInDb != null && workerShiftInDb.getShiftCode() != null) {
                        if (!(workerShiftReq.getShiftCode().equals(workerShiftInDb.getShiftCode()))) {

                            workerShiftToBeSaved.setShiftCode(workerShiftInDb.getShiftCode());
                            workerShiftToBeSaved.setWorkerName(workerShiftInDb.getWorkerName());
                            workerShiftToBeSaved.setOrganizationCode(workerShiftInDb.getOrganizationCode());
                            workerShiftToBeSaved.setShiftName(workerShiftInDb.getShiftName());
                            workerShiftToBeSaved.setWorkerCode(workerShiftInDb.getWorkerCode());

                            workerShiftToBeSaved.setIpAddress(ip);

                            jsonobj.put("responsecode", 200);
                            jsonobj.put("timestamp", new Date());

                            workerShift = workerShiftRepo.save(workerShiftToBeSaved);
                            if (workerShift != null && workerShift.getId() > 0) {
                                // kafkaService.sendOrganizationSkill(depWorkerRes);
                                jsonobj.put("message", "Worker Code added successfully.");
                                ObjectMapper mapperObj = new ObjectMapper();
                                String Detail = mapperObj.writeValueAsString(workerShift);
                                jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                jsonobj.put("message", "Failed");
                                jsonobj.put("responsecode", 400);
                                jsonobj.put("timestamp", new Date());
                            }

                        } else {
                            jsonobj.put("message", " worker shift is already present.");
                            jsonobj.put("responsecode", 409);
                            jsonobj.put("timestamp", new Date());

                        }
                    } else {
                        jsonobj.put("message", " No shift found for this Organization code.");
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("timestamp", new Date());

                    }
                    res = jsonobj.toString();
                } else {
                    GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data should not be blank.");
                    res = derr.toString();
                }

            } else {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker Shift must not be blank.");
                res = derr.toString();

            }

        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;

    }

    @Override
    public String updateWorkerShift(Long id, WorkerShiftRequest workerShiftReq, String ip) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            if (id != 0 && workerShiftReq != null) {
                if ((workerShiftReq.getOrganizationCode() != null
                        && workerShiftReq.getOrganizationCode().trim().length() > 0)) {

                    WorkerShift workerShiftInDb = workerShiftRepo.getShiftWorkerByOrganizationCode(
                            workerShiftReq.getWorkerCode(), workerShiftReq.getOrganizationCode());
                    WorkerShift workerShiftToBeSaved = new WorkerShift();
                    WorkerShift workerShift = null;

                    if (workerShiftInDb != null && workerShiftInDb.getShiftCode() != null) {
                        if (!(workerShiftReq.getShiftCode().equals(workerShiftInDb.getShiftCode()))) {

                            workerShiftToBeSaved.setShiftCode(workerShiftInDb.getShiftCode());
                            workerShiftToBeSaved.setWorkerName(workerShiftInDb.getWorkerName());
                            workerShiftToBeSaved.setOrganizationCode(workerShiftInDb.getOrganizationCode());
                            workerShiftToBeSaved.setShiftName(workerShiftInDb.getShiftName());
                            workerShiftToBeSaved.setWorkerCode(workerShiftInDb.getWorkerCode());

                            workerShiftToBeSaved.setIpAddress(ip);

                            jsonobj.put("responsecode", 200);
                            jsonobj.put("timestamp", new Date());

                            workerShift = workerShiftRepo.save(workerShiftToBeSaved);
                            if (workerShift != null && workerShift.getId() > 0) {
                                jsonobj.put("responsecode", 200);
                                jsonobj.put("message", "Worker updated successfully.");
                                jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
                                String Detail = mapperObj.writeValueAsString(workerShift);
                                jsonobj.put("data", new JSONObject(Detail));

                                // kafkaService.sendUpdateOrganizationSkill(depWorkerRes);
                            } else {
                                jsonobj.put("responsecode", 400);
                                jsonobj.put("message", "Worker updation has been failed.");
                                jsonobj.put("timestamp", new Date());
                            }

                        } else {
                            jsonobj.put("message", " start time must be before endtime.");

                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(workerShift);
                            jsonobj.put("data", new JSONObject(Detail));
                        }
                    } else {
                        jsonobj.put("message", " No shift found for this Organization code.");

                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(workerShift);
                        jsonobj.put("data", new JSONObject(Detail));
                    }
                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("message", "Ogranization Code must be Entered.");
                    jsonobj.put("timestamp", new Date());
                }

            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Input data is not valid.");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;

    }

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
            if(search != null && search.trim().length() > 0){
			JSONObject jsonobj = new JSONObject();
			
			WorkerShiftSpecificationsBuilder builder = new WorkerShiftSpecificationsBuilder();
		        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
		        java.util.regex.Matcher matcher = pattern.matcher(search + ",");
		        while (matcher.find()) {
		            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
		        }
		         
		        Specification<WorkerShift> spec = builder.build();
                        if(spec!=null){
			List<WorkerShift> workerShiftlst = workerShiftRepo.findAll(spec);
			if(workerShiftlst != null && workerShiftlst.size() > 0){
			for(WorkerShift workerShift : workerShiftlst){
				if(workerShift.getIsDeleted() != null && workerShift.getIsDeleted() != true){

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(workerShift);
					JSONObject jsonobjNew = new JSONObject();
					jsonobjNew.put("workerShift", new JSONObject(Detail));
					jarr.add(jsonobjNew);

			} 
				
			} 
			if (jarr.size() > 0) {
				
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			jsonobj.put("data", jarr);
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}
			
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}}
                        else{
                           jsonobj.put("responsecode", 400);
			   jsonobj.put("message", "Record Not Found!");
			   jsonobj.put("timestamp", new Date()); 
                        }
			res = jsonobj.toString();
		
            }else{
            	GigflexResponse derr = new GigflexResponse(400, new Date(),
    					"Input data is not valid.");
    			res = derr.toString();

            }
			
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}
}
