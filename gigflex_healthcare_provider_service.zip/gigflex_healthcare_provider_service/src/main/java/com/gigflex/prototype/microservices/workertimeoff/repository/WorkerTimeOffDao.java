/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.workertimeoff.repository;

import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOff;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface WorkerTimeOffDao extends JpaRepository<WorkerTimeOff,Long>,JpaSpecificationExecutor<WorkerTimeOff>{
    
    @Query("SELECT wt FROM WorkerTimeOff wt WHERE wt.isDeleted != TRUE")
    public List<WorkerTimeOff> getAllWorkerTimeOff();

    @Query("SELECT wt FROM WorkerTimeOff wt WHERE wt.isDeleted != TRUE AND wt.workerCode = :workercode")
    public List<WorkerTimeOff> getTimeOffByWorkerCode(@Param("workercode") String workercode);

    @Query("SELECT wt FROM WorkerTimeOff wt WHERE wt.isDeleted != TRUE AND wt.organizationCode = :organizationcode")
    public List<WorkerTimeOff> getTimeOffByOrganizationCode(@Param("organizationcode") String organizationcode);
    
    
    @Query("SELECT wt FROM WorkerTimeOff wt WHERE wt.isDeleted != TRUE AND wt.timeoffCode = :timeoffcode")
    public WorkerTimeOff getTimeOffByTimeOffCode(@Param("timeoffcode") String timeoffcode);

    @Query("SELECT wt FROM WorkerTimeOff wt WHERE wt.isDeleted != TRUE AND wt.workerCode = :workercode AND ( ((:fromDate >= wt.fromDate   AND :fromDate <= wt.toDate )  OR (:toDate >= wt.fromDate AND :toDate <= wt.toDate)) OR (:fromDate < wt.fromDate AND :toDate > wt.toDate ))")
    public List<WorkerTimeOff> getTimeOffByWorkerCodeAndBetweenDate(@Param("workercode") String workercode,@Param("fromDate") Date fromDate,@Param("toDate") Date toDate);
    
    @Query("SELECT wt FROM WorkerTimeOff wt WHERE wt.isDeleted != TRUE AND wt.workerCode = :workercode AND ( ((:fromDate >= wt.fromDateTime   AND :fromDate <= wt.toDateTime )  OR (:toDate >= wt.fromDateTime AND :toDate <= wt.toDateTime)) OR (:fromDate < wt.fromDateTime AND :toDate > wt.toDateTime ))")
    public List<WorkerTimeOff> getTimeOffByWorkerCodeAndBetweenDateTimeStamp(@Param("workercode") String workercode,@Param("fromDate") Date fromDate,@Param("toDate") Date toDate);

    @Query("SELECT jasw FROM Jobs j, JobsDuration jd, JobsAssignToWorker jasw WHERE j.isDeleted != TRUE AND jd.isDeleted != TRUE AND jasw.isDeleted != TRUE AND jasw.jobsDurationCode=jd.jobsDurationCode AND jasw.jobsCode=j.jobsCode AND jasw.workerCode= :workercode AND (jasw.status = :jobStatusAccepted OR jasw.status = :jobStatusAssigned) AND j.organizationCode = :organizationCode AND (( :fromDateTime <=jd.startTime AND :toDateTime >= jd.endTime ) OR  (:fromDateTime >jd.startTime AND :toDateTime < jd.endTime) OR  ( :toDateTime >jd.startTime AND :fromDateTime <jd.endTime ) OR  (:toDateTime > jd.startTime AND :toDateTime < jd.endTime ) )")  
    public List<JobsAssignToWorker> getJobAssignedWorkerByWorkerCodeOrganizationCodeAndBetweenDates(@Param("workercode") String workercode,@Param("fromDateTime") Date fromDateTime,@Param("toDateTime") Date toDateTime,@Param("jobStatusAccepted") String jobStatusAccepted,@Param("jobStatusAssigned") String jobStatusAssigned,@Param("organizationCode") String organizationCode);

    @Query("SELECT user FROM Users user , WorkerApprovalStatus was WHERE user.isDeleted != TRUE AND was.isDeleted != TRUE AND user.userCode = was.workerCode AND user.isAdmin = TRUE AND was.organization_Code = :organizationCode ")
    public Users getAdminByOrganizationCode(@Param("organizationCode") String organizationCode);
}
