/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerunavailability.service;

import com.gigflex.prototype.microservices.workerunavailability.dtob.WorkerUnavailabilityRequest;

/**
 *
 * @author nirbhay.p
 */
public interface WorkerUnavailabilityService {
    public String getAllWorkerUnavailability();
    public String getAllWorkerUnavailabilityByPage(int page, int limit);
    public String getWorkerUnavailabilityByWorkerCode(String workerCode);
    public String getWorkerUnavailabilityByWorkerUnavailabilityCode(String workerUnavailabilityCode);
    public String saveWorkerUnavailability(WorkerUnavailabilityRequest workerprsfReq, String ip);
    public String updateWorkerUnavailability(WorkerUnavailabilityRequest workerprsfReq,String workerUnavailabilityCode, String ip);
    public String deleteWorkerUnavailability(String workerUnavailabilityCode);
}
