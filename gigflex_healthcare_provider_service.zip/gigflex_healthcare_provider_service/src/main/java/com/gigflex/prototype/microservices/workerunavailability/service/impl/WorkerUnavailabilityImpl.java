/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerunavailability.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.util.GigflexDateFormatConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workertimeoff.service.impl.WorkerTimeOffServiceImpl;
import com.gigflex.prototype.microservices.workerunavailability.dtob.WorkerUnavailability;
import com.gigflex.prototype.microservices.workerunavailability.dtob.WorkerUnavailabilityRequest;
import com.gigflex.prototype.microservices.workerunavailability.dtob.WorkerUnavailabilityResponse;
import com.gigflex.prototype.microservices.workerunavailability.repository.WorkerUnavailabilityRepository;
import com.gigflex.prototype.microservices.workerunavailability.service.WorkerUnavailabilityService;
import com.gigflex.prototype.microservices.workpreferedshift.dtob.WorkerPreferdShift;
import java.util.ArrayList;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

/**
 *
 * @author nirbhay.p
 */
@Service
public class WorkerUnavailabilityImpl implements WorkerUnavailabilityService{

    @Autowired
    WorkerUnavailabilityRepository workerUnavailabilityRepository;
    
    @Override
    public String getAllWorkerUnavailability() {
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         List<WorkerUnavailability> wlstres=workerUnavailabilityRepository.getAllWorkerUnavailability();
                         List<WorkerUnavailabilityResponse> wlst=new ArrayList<WorkerUnavailabilityResponse>();
                         for(WorkerUnavailability fu:wlstres)
                         {
                             WorkerUnavailabilityResponse fures=new WorkerUnavailabilityResponse();
                             fures.setFromTime(fu.getFromTime());
                             fures.setId(fu.getId());
                             fures.setRequestOption(fu.getRequestOption());
                             fures.setRequestType(fu.getRequestType());
                             fures.setToTime(fu.getFromTime());
                             fures.setUnavailabilityDate(GigflexDateUtil.convertDateToString(fu.getUnavailabilityDate(),  GigflexDateFormatConstants.YYYY_MM_DD));
                             fures.setWorkerCode(fu.getWorkerCode());
                             fures.setWorkerUnavailabilityCode(fu.getWorkerUnavailabilityCode());
                             wlst.add(fures);
                               
                         }
                         if(wlst!=null && wlst.size()>0)
                         {
                             
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlst);
				jsonobj.put("data", new JSONArray(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    }

    @Override
    public String getAllWorkerUnavailabilityByPage(int page, int limit) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        Pageable pageableRequest = PageRequest.of(page, limit);
                         List<WorkerUnavailability> wlstres=workerUnavailabilityRepository.getAllWorkerUnavailability(pageableRequest);
                         List<WorkerUnavailabilityResponse> wlst=new ArrayList<WorkerUnavailabilityResponse>();
                         for(WorkerUnavailability fu:wlstres)
                         {
                             WorkerUnavailabilityResponse fures=new WorkerUnavailabilityResponse();
                             fures.setFromTime(fu.getFromTime());
                             fures.setId(fu.getId());
                             fures.setRequestOption(fu.getRequestOption());
                             fures.setRequestType(fu.getRequestType());
                             fures.setToTime(fu.getFromTime());
                             fures.setUnavailabilityDate(GigflexDateUtil.convertDateToString(fu.getUnavailabilityDate(),  GigflexDateFormatConstants.YYYY_MM_DD));
                             fures.setWorkerCode(fu.getWorkerCode());
                             fures.setWorkerUnavailabilityCode(fu.getWorkerUnavailabilityCode());
                             wlst.add(fures);
                               
                         }
                         if(wlst!=null && wlst.size()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlst);
				jsonobj.put("data", new JSONArray(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    
    }

    @Override
    public String getWorkerUnavailabilityByWorkerCode(String workerCode) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         List<WorkerUnavailability> wlstres=workerUnavailabilityRepository.getWorkerUnavailabilityByWorkerCode(workerCode);
                         List<WorkerUnavailabilityResponse> wlst=new ArrayList<WorkerUnavailabilityResponse>();
                         for(WorkerUnavailability fu:wlstres)
                         {
                             WorkerUnavailabilityResponse fures=new WorkerUnavailabilityResponse();
                             fures.setFromTime(fu.getFromTime());
                             fures.setId(fu.getId());
                             fures.setRequestOption(fu.getRequestOption());
                             fures.setRequestType(fu.getRequestType());
                             fures.setToTime(fu.getFromTime());
                             fures.setUnavailabilityDate(GigflexDateUtil.convertDateToString(fu.getUnavailabilityDate(),  GigflexDateFormatConstants.YYYY_MM_DD));
                             fures.setWorkerCode(fu.getWorkerCode());
                             fures.setWorkerUnavailabilityCode(fu.getWorkerUnavailabilityCode());
                             wlst.add(fures);
                               
                         }
                         if(wlst!=null && wlst.size()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlst);
				jsonobj.put("data", new JSONArray(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    
    }

    @Override
     public String saveWorkerUnavailability(WorkerUnavailabilityRequest workerprsfReq, String ip) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         WorkerUnavailability wlst=new WorkerUnavailability();
                         wlst.setIpAddress(ip);
                         wlst.setRequestOption(workerprsfReq.getRequestOption());
                         wlst.setRequestType(workerprsfReq.getRequestType());
                         if(!GigflexDateUtil.isDate(workerprsfReq.getUnavailabilityDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send From date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                         Date fromdate = null;
                            try {
                                fromdate = GigflexDateUtil.convertStringToDate(workerprsfReq.getUnavailabilityDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD);
                                if(fromdate==null)
                                {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString(); 
                                }
                            } catch (Exception ex) {
                                java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                                
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString();
                            }
                         wlst.setUnavailabilityDate(fromdate);
                         wlst.setFromTime(workerprsfReq.getFromTime().trim());
                         wlst.setToTime(workerprsfReq.getToTime().trim());
                         wlst.setWorkerCode(workerprsfReq.getWorkerCode());
                         WorkerUnavailability  wlstRes= workerUnavailabilityRepository.save(wlst);
                         if(wlstRes!=null && wlstRes.getId()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker Unavailability has been added.");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlstRes);
				jsonobj.put("data", new JSONObject(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    }

    @Override
    public String updateWorkerUnavailability(WorkerUnavailabilityRequest workerprsfReq,String workerUnavailabilityCode, String ip){
        
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         WorkerUnavailability wlst=workerUnavailabilityRepository.getWorkerUnavailabilityByCode(workerUnavailabilityCode);
                         if(wlst!=null && wlst.getId()>0)
                         {
                         wlst.setIpAddress(ip);
                         wlst.setRequestOption(workerprsfReq.getRequestOption());
                         wlst.setRequestType(workerprsfReq.getRequestType());
                         if(!GigflexDateUtil.isDate(workerprsfReq.getUnavailabilityDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send From date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                         Date fromdate = null;
                            try {
                                fromdate = GigflexDateUtil.convertStringToDate(workerprsfReq.getUnavailabilityDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD);
                                if(fromdate==null)
                                {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString(); 
                                }
                            } catch (Exception ex) {
                                java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                                
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString();
                            }
                         wlst.setUnavailabilityDate(fromdate);
                         wlst.setFromTime(workerprsfReq.getFromTime().trim());
                         wlst.setToTime(workerprsfReq.getToTime().trim());
                         wlst.setWorkerCode(workerprsfReq.getWorkerCode());
                         WorkerUnavailability  wlstRes= workerUnavailabilityRepository.save(wlst);
                         if(wlstRes!=null && wlstRes.getId()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker Unavailability has been updated.");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlstRes);
				jsonobj.put("data", new JSONObject(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Updation has been failed.");
				jsonobj.put("timestamp", new Date());
                         }
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    
    
    }

    @Override
    public String deleteWorkerUnavailability(String workerUnavailabilityCode){
        
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         WorkerUnavailability wlst=workerUnavailabilityRepository.getWorkerUnavailabilityByCode(workerUnavailabilityCode);
                         if(wlst!=null && wlst.getId()>0)
                         {
                             
                             wlst.setIsDeleted(Boolean.TRUE);
                             WorkerUnavailability wlstres= workerUnavailabilityRepository.save(wlst);
                            if(wlstres!=null && wlstres.getId()>0)
                            {
                                jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker Unavailability has been deleted.");
				jsonobj.put("timestamp", new Date());
                            }
                            else
                            {
                                jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Failed.");
				jsonobj.put("timestamp", new Date());
                            }
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    
    
    }

    @Override
    public String getWorkerUnavailabilityByWorkerUnavailabilityCode(String workerUnavailabilityCode) {
        
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         WorkerUnavailability fu=workerUnavailabilityRepository.getWorkerUnavailabilityByCode(workerUnavailabilityCode);
                         if(fu!=null && fu.getId()>0)
                         {
                             WorkerUnavailabilityResponse fures=new WorkerUnavailabilityResponse();
                             fures.setFromTime(fu.getFromTime());
                             fures.setId(fu.getId());
                             fures.setRequestOption(fu.getRequestOption());
                             fures.setRequestType(fu.getRequestType());
                             fures.setToTime(fu.getFromTime());
                             fures.setUnavailabilityDate(GigflexDateUtil.convertDateToString(fu.getUnavailabilityDate(),  GigflexDateFormatConstants.YYYY_MM_DD));
                             fures.setWorkerCode(fu.getWorkerCode());
                             fures.setWorkerUnavailabilityCode(fu.getWorkerUnavailabilityCode());
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(fures);
				jsonobj.put("data", new JSONObject(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    
    
    }
    
}
