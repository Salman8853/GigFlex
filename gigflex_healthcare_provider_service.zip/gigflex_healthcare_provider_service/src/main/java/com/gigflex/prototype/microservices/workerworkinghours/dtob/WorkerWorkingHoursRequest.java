package com.gigflex.prototype.microservices.workerworkinghours.dtob;

import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class WorkerWorkingHoursRequest {

	private String workerCode;
	
	private String workerPreferredLocationCode;

	private String fromDate;

	private String toDate;

	private String daysCode;
	


	public String getWorkerPreferredLocationCode() {
		return workerPreferredLocationCode;
	}

	public void setWorkerPreferredLocationCode(String workerPreferredLocationCode) {
		this.workerPreferredLocationCode = workerPreferredLocationCode;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getDaysCode() {
		return daysCode;
	}

	public void setDaysCode(String daysCode) {
		this.daysCode = daysCode;
	}

}
