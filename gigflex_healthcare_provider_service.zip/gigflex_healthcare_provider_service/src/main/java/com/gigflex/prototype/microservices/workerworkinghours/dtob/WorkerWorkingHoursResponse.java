package com.gigflex.prototype.microservices.workerworkinghours.dtob;

import java.util.Date;


public class WorkerWorkingHoursResponse {

	private Long id;

	private String workerWorkingHoursCode;

	private String workerCode;
	private String name;

	private String workerPreferredLocationCode;
	private String location;

	private String daysCode;
	private String daysName;

	private Date fromDate;

	private Date toDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWorkerWorkingHoursCode() {
		return workerWorkingHoursCode;
	}

	public void setWorkerWorkingHoursCode(String workerWorkingHoursCode) {
		this.workerWorkingHoursCode = workerWorkingHoursCode;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWorkerPreferredLocationCode() {
		return workerPreferredLocationCode;
	}

	public void setWorkerPreferredLocationCode(String workerPreferredLocationCode) {
		this.workerPreferredLocationCode = workerPreferredLocationCode;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDaysCode() {
		return daysCode;
	}

	public void setDaysCode(String daysCode) {
		this.daysCode = daysCode;
	}

	public String getDaysName() {
		return daysName;
	}

	public void setDaysName(String daysName) {
		this.daysName = daysName;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
	

}
