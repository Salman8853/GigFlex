package com.gigflex.prototype.microservices.workerworkinghours.service;

import java.util.List;

import com.gigflex.prototype.microservices.workerworkinghours.dtob.WorkerWorkingHours;
import com.gigflex.prototype.microservices.workerworkinghours.dtob.WorkerWorkingHoursRequest;

/**
 * 
 * @author ajit.p
 *
 */
public interface WorkerWorkingHoursService {
	public String search(String search);
	public String getAllWorkerWorkingHours();
	public String getAllWorkerWorkingHoursByWorkerPreferredLocationCode(String workerPreferredLocationCode);
	public String getAllWorkerWorkingHoursByWorkerPreferredLocationCodeByPage(String workerPreferredLocationCode,int page, int limit);
	public String getAllWorkerWorkingHoursByPage(int page, int limit);
	public String getWorkerWorkingHoursById(Long id);
	public String saveWorkerWorkingHours(WorkerWorkingHoursRequest workinghrsRqst,String ip);
	public WorkerWorkingHours saveWorkerWorkingHours(WorkerWorkingHours workerWorkingHours);
	public void updateWorkerWorkingHours(WorkerWorkingHours workerWorkingHours); 
    public String updateWorkerWorkingHours(Long id,WorkerWorkingHoursRequest workinghrsRqst,String ip);
    public String getByWorkerWorkingHoursCode(String workerWorkingHoursCode);
    public String deleteWorkerWorkingHoursById(Long id);
    public String deleteByWorkerWorkingHoursCode(String workerWorkingHoursCode);
    public String softDeleteByWorkerWorkingHoursCode(String workerWorkingHoursCode);
    public String softMultipleDeleteByWorkerWorkingHoursCode(List<String> workerWorkingHoursCodeList);
    public String getAllWorkerWorkingHoursWithName();

	public String getAllWorkerWorkingHoursWithNamesByPage(int page, int limit);
	public String getAllWorkerWorkingHoursByWorkerCode(String workerCode);
	public String getAllWorkerWorkingHoursByWorkerCode(String workerCode,int page, int limit);

    
}
