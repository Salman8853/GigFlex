package com.gigflex.prototype.microservices.workinglocation.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocationRequest;
import com.gigflex.prototype.microservices.workinglocation.service.WorkingLocationService;



/**
 * 
 * @author ajit.p
 *
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class WorkingLocationController {

	@Autowired
	WorkingLocationService workingLocationService;
	
	@GetMapping("/workingLocation/{search}")
	public String search(@PathVariable("search") String search) {
		return workingLocationService.search(search);
	}


	@GetMapping("/allWorkingLocation")
	public String getAllWorkingLocationss() {
		return workingLocationService.getAllWorkingLocations();
		
	}
	
	@GetMapping(path="/getAllWorkingLocationByPage")
    public String getAllWorkingLocationByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String wl = workingLocationService.getAllWorkingLocationsByPage(page, limit);
      
        return wl;
       
    }

	@GetMapping("/workingLocationById/{id}")
	public String getWorkingLocationById(@PathVariable Long id) {
		return workingLocationService.getWorkingLocationsById(id);
		
	}
	
	@GetMapping("/workingLocationByOrgCode/{organizationCode}")
	public String workingLocationByOrgCode(@PathVariable String organizationCode) {
		return workingLocationService.getWorkingLocationsByOrgCode(organizationCode);
		
	}


	@PostMapping("/saveWorkingLocation")
	public String createWorkingLocation(@RequestBody WorkingLocationRequest workingLocation, HttpServletRequest request) {
		if(workingLocation!=null)
        {
			String ip = request.getRemoteAddr();
            return  workingLocationService.saveWorkingLocations(workingLocation, ip);
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
            return derr.toString();
        }
		
			
	}

	@DeleteMapping("/deleteWorkingLocation/{id}")
	public String deleteWorkingLocation(@PathVariable Long id) {
		return workingLocationService.deleteWorkingLoccationsById(id);
		
        }
	
	@DeleteMapping("/deleteWorkingLocationByWorkingLocationCode/{workingLocationCode}")
	public String deleteWorkingLocationByWorkingLocationCode(@PathVariable String workingLocationCode) {
		return workingLocationService.deleteWorkingLoccationsByWorkingLocationCode(workingLocationCode);
		
        }
	
	@DeleteMapping("/softDeleteWorkingLocationByWorkingLocationCode/{workingLocationCode}")
	public String softDeleteWorkingLocationByWorkingLocationCode(@PathVariable String workingLocationCode) {
		return workingLocationService.softDeleteWorkingLoccationsByWorkingLocationCode(workingLocationCode);
		
        }
	
	@DeleteMapping("/softMultipleDeleteByWorkingLocationCode/{workingLocationCodeList}")
	public String softMultipleDeleteByOrganizationCode(@PathVariable List<String> workingLocationCodeList) {
		if(workingLocationCodeList != null && workingLocationCodeList.size()>0){
			return workingLocationService.softMultipleDeleteByWorkingLocationCode(workingLocationCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
		
	}

	/**
	 * 
	 * @param id
	 * @param workingLocation
	 * @param errors
	 * @return
	 */
	@PutMapping("/updateWorkingLocation/{id}")
	public String updateWorkingLocation(@PathVariable Long id, @RequestBody WorkingLocationRequest workingLocation,
			HttpServletRequest request) {
		
		if (id == null) {
			return "Working Location with Id : (" + id + ") Not found.";
		} else {

			String ip = request.getRemoteAddr();
        return  workingLocationService.updateWorkingLocations(workingLocation, id, ip);

		}
		
            
           
            
//            Object response = null;
//		if (errors.hasErrors()) {
//			response = errors.getAllErrors();
//			return ResponseEntity.badRequest().body(response);
//		}
//		Optional<WorkingLocation> workingLoc = workingLocationService.getWorkingLocationsById(id);
//		if (workingLoc == null) {
//			response = "Working Location with Id : (" + id + ") Not found.";
//		} else {
//			workingLocation = workingLocationService.saveWorkingLocations(workingLocation);
//
//			id = workingLocationService.saveWorkingLocations(workingLocation).getId();
//			response = "Working Location with Id : (" + id + ") is Updated.";
//		}
//		return ResponseEntity.ok(response);
	}
}