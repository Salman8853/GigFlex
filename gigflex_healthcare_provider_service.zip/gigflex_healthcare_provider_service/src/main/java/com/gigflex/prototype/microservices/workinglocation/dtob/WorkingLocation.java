/**
 * 
 */
package com.gigflex.prototype.microservices.workinglocation.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

/**
 * @author ajit.p
 *
 */

@Entity
@Table(name = "working_location ")
public class WorkingLocation extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "organization_code")
	private String organizationCode;
	@Column(name = "location")
	private String location;
	@Column(name = "lat")
	private String lat;
	@Column(name = "lang")
	private String lang;
	@Column(name = "isactive")
	private Boolean isactive;

	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "working_location_code", unique = true)
	private String workingLocationCode;

	@Column(name = "timezone")
	private String timeZone;

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	@PrePersist
	private void assignUUID() {
		if (this.getWorkingLocationCode() == null
				|| this.getWorkingLocationCode().length() == 0) {
			this.setWorkingLocationCode(UUID.randomUUID().toString());
		}
	}

	public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

	public WorkingLocation() {
		super();
	}

	public WorkingLocation(Long id) {
		super();
		this.id = id;
	}

	public WorkingLocation(Long id, String organizationCode, String location,
			String lat, String lang, Boolean isactive,
			String workingLocationCode, String timeZone) {
		super();
		this.id = id;
		this.organizationCode = organizationCode;
		this.location = location;
		this.lat = lat;
		this.lang = lang;
		this.isactive = isactive;
		this.workingLocationCode = workingLocationCode;
		this.timeZone = timeZone;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public Boolean isIsactive() {
		return isactive;
	}

	public void setIsactive(Boolean isactive) {
		this.isactive = isactive;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "WorkingLocation [id=" + id + ", organizationCode="
				+ organizationCode + ", location=" + location + ", lat=" + lat
				+ ", lang=" + lang + ", isactive=" + isactive + "]";
	}

}
