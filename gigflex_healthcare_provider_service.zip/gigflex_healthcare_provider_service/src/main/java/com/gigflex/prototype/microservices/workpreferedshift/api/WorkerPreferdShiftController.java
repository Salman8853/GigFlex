/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workpreferedshift.api;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOffModel;
import com.gigflex.prototype.microservices.workpreferedshift.dtob.WorkerPreferdShiftRequest;
import com.gigflex.prototype.microservices.workpreferedshift.service.WorkerPreferdShiftService;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirbhay.p
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class WorkerPreferdShiftController {
    
    @Autowired
    WorkerPreferdShiftService workerPreferdShiftService;
    
    @GetMapping("/getAllWorkerPreferdShift")
    public String getAllWorkerPreferdShift(){
            return workerPreferdShiftService.getWorkerPreferdShift();
    }
    
    @GetMapping(path="/getAllWorkerPreferdShiftByPage")
    public String getAllWorkerPreferdShiftByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        return workerPreferdShiftService.getWorkerPreferdShiftByPage(page, limit);
      
    }
    
    @GetMapping("/getWorkerPreferdShiftByWorkerCode/{workercode}")
    public String getWorkerPreferdShiftByWorkerCode(@PathVariable("workercode") String workercode){
        if(workercode!=null && workercode.trim().length()>0)
        {
        return workerPreferdShiftService.getWorkerPreferdShiftByWorkerCode(workercode.trim());
        }
        else
        {
                     GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker code should not be blank.");
               return derr.toString();
            
        }
    }
    
    
    @GetMapping("/getWorkerPreferdShiftByWorkerCodeForCalendar/{workercode}/{start}/{end}")
    public String getWorkerPreferdShiftByWorkerCodeForCalendar(@PathVariable("workercode") String workercode,
            @PathVariable("start") String start,@PathVariable("end") String end){
        if(workercode!=null && workercode.trim().length()>0 && start!=null && start.trim().length()>0 && end!=null && end.trim().length()>0)
        {
        return workerPreferdShiftService.getWorkerPreferdShiftByWorkerCodeForCalendar(workercode.trim(),start.trim(),end.trim());
        }
        else
        {
                     GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker code, start date, End date should not be blank.");
               return derr.toString();
            
        }
    }
    
//    @GetMapping("/getWorkerPreferdShiftByWorkerCodeFilterByDate/{workercode}/{startDT}/{endDT}")
//    public String getWorkerPreferdShiftByWorkerCodeFilterByDate(@PathVariable("workercode") String workercode,@PathVariable("startDT") String startDT
//    ,@PathVariable("endDT") String endDT){
//        if(workercode!=null && workercode.trim().length()>0 && endDT!=null && endDT.trim().length()>0 && startDT!=null && startDT.trim().length()>0)
//        {
//        return workerPreferdShiftService.getWorkerPreferdShiftByWorkerCodeFilterByDate(workercode.trim(),startDT,endDT);
//        }
//        else
//        {
//                     GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker code, Start date, End date should not be blank.");
//               return derr.toString();
//            
//        }
//    }
    
    
     @GetMapping("/getWorkerPreferdShiftByworkerPreferdShiftCode/{workerPreferdShiftCode}")
    public String getWorkerPreferdShiftByworkerPreferdShiftCode(@PathVariable("workerPreferdShiftCode") String workerPreferdShiftCode){
        if(workerPreferdShiftCode!=null && workerPreferdShiftCode.trim().length()>0)
        {
        return workerPreferdShiftService.getWorkerPreferdShiftByworkerPreferdShiftCode(workerPreferdShiftCode.trim());
        }
        else
        {
                     GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker Preferd Shift Codeshould not be blank.");
               return derr.toString();
            
        }
    }
    
    
     @PostMapping("/saveWorkerPreferdShift")
    public String saveWorkerPreferdShift(@RequestBody WorkerPreferdShiftRequest workerprsfReq,HttpServletRequest request){
              
       if( workerprsfReq!=null && workerprsfReq.getShiftdate()!=null && workerprsfReq.getShiftdate().trim().length()>0
                && workerprsfReq.getFromTime()!=null && workerprsfReq.getFromTime().trim().length()>0
               && workerprsfReq.getToTime() !=null && workerprsfReq.getToTime().trim().length()>0 ) 
        {
          String ip = request.getRemoteAddr();
          return workerPreferdShiftService.saveWorkerPreferdShift(workerprsfReq,ip);
        }
        else
        {
                   GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker code, SiftDate, To and From should not be blank.");
               return derr.toString();
        }

    }
    
    @GetMapping("/repeatWorkerPreferdShift/{workercode}/{type}")
    public String repeatWorkerPreferdShift(@PathVariable("workercode") String workercode,@PathVariable("type") String type,HttpServletRequest request){
              
        if(workercode!=null && workercode.trim().length()>0 && type!=null && type.trim().length()>0) 
        {
          String ip = request.getRemoteAddr();
          return workerPreferdShiftService.repeatWorkerPreferdShift(workercode,type,ip);
        }
        else
        {
                   GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker code and Type should not be blank.");
               return derr.toString();
        }

    }
    
    @PutMapping("/updateWorkerPreferdShift/{workerPreferdShiftCode}")
    public String updateWorkerPreferdShift(@PathVariable("workerPreferdShiftCode") String workerPreferdShiftCode, @RequestBody WorkerPreferdShiftRequest workerprsfReq,HttpServletRequest request) {

                 
        if(workerPreferdShiftCode!=null && workerPreferdShiftCode.trim().length()>0 && workerprsfReq!=null && workerprsfReq.getShiftdate()!=null && workerprsfReq.getShiftdate().trim().length()>0
                && workerprsfReq.getFromTime()!=null && workerprsfReq.getFromTime().trim().length()>0
               && workerprsfReq.getToTime() !=null && workerprsfReq.getToTime().trim().length()>0 ) 
        {
          String ip = request.getRemoteAddr();
          return workerPreferdShiftService.updatesaveWorkerPreferdShift(workerprsfReq,workerPreferdShiftCode,ip);
        }
        else
        {
                   GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker Preferd Shift Code,Worker code, SiftDate, To and From should not be blank.");
               return derr.toString();
        }

    }
    
    @DeleteMapping("/deleteWorkerPreferdShift/{workerPreferdShiftCode}")
    public String deleteWorkerPreferdShift(@PathVariable String workerPreferdShiftCode){
        
        if(workerPreferdShiftCode != null && workerPreferdShiftCode.trim().length() > 0 )
        {
            return workerPreferdShiftService.deleteWorkerPreferdShift(workerPreferdShiftCode.trim());
        }
        else
        {
               GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker Preferd Shift Code should not be blank.");
               return derr.toString(); 
        }
        
        
    }
    
    
    
}
