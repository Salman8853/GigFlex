/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workpreferedshift.dtob;

import javax.persistence.Column;

/**
 *
 * @author nirbhay.p
 */
public class WorkerPreferdShiftRequest {
    private String shiftdate;
     
  
    private String workerCode;

    private String fromTime;
            
    private String toTime; 
    
    private String offHoursFromTime;
    
    private String offHoursToTime; 
  
    public String getShiftdate() {
        return shiftdate;
    }

    public void setShiftdate(String shiftdate) {
        this.shiftdate = shiftdate;
    }
    
   

  

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public String getOffHoursFromTime() {
        return offHoursFromTime;
    }

    public void setOffHoursFromTime(String offHoursFromTime) {
        this.offHoursFromTime = offHoursFromTime;
    }

    public String getOffHoursToTime() {
        return offHoursToTime;
    }

    public void setOffHoursToTime(String offHoursToTime) {
        this.offHoursToTime = offHoursToTime;
    }
    
    
}
