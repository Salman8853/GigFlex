/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workpreferedshift.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workpreferedshift.dtob.WorkerPreferdShift;
import com.gigflex.prototype.microservices.workpreferedshift.repository.WorkerPreferdShiftRepository;
import com.gigflex.prototype.microservices.workpreferedshift.dtob.WorkerPreferdShiftRequest;
import com.gigflex.prototype.microservices.workpreferedshift.dtob.WorkerPreferdShiftRes;
import org.springframework.stereotype.Service;
import com.gigflex.prototype.microservices.workpreferedshift.service.WorkerPreferdShiftService;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

/**
 *
 * @author nirbhay.p
 */
@Service
public class WorkerPreferdShiftServiceImpl implements WorkerPreferdShiftService {

    @Autowired
    WorkerPreferdShiftRepository workerPreferdShiftRepository;

    @Override
    public String getWorkerPreferdShift() {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            
            
            List<WorkerPreferdShift> wlstdata = workerPreferdShiftRepository.getAllWorkerPreferdShift();
            List<WorkerPreferdShiftRes> wlst =new ArrayList<WorkerPreferdShiftRes>();
            for(WorkerPreferdShift wp:wlstdata)
            {
                String dt="";
                WorkerPreferdShiftRes wps=new WorkerPreferdShiftRes();
                if(wp.getShiftdate()!=null)
                {
                   
                   dt=GigflexDateUtil.convertDateToString(wp.getShiftdate(), GigflexConstants.YYYY_MM_DD);
                }
                wps.setFromTime(wp.getFromTime());
                wps.setId(wp.getId());
                wps.setOffHoursFromTime(wp.getOffHoursFromTime());
                wps.setOffHoursToTime(wp.getOffHoursToTime());
                wps.setShiftdate(dt);
                wps.setToTime(wp.getToTime());
                wps.setWorkerCode(wp.getWorkerCode());
                wps.setWorkerPreferdShiftCode(wp.getWorkerPreferdShiftCode());
                wlst.add(wps);
            }
            if (wlst != null && wlst.size() > 0) {
                jsonobj.put("responsecode", 200);
                jsonobj.put("message", "Success");
                jsonobj.put("timestamp", new Date());
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(wlst);
                jsonobj.put("data", new JSONArray(Detail));
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Record Not Found.");
                jsonobj.put("timestamp", new Date());
            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String getWorkerPreferdShiftByPage(int page, int limit) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Pageable pageableRequest = PageRequest.of(page, limit);
            List<WorkerPreferdShift> wlstdata = workerPreferdShiftRepository.getAllWorkerPreferdShift(pageableRequest);
            List<WorkerPreferdShiftRes> wlst =new ArrayList<WorkerPreferdShiftRes>();
            for(WorkerPreferdShift wp:wlstdata)
            {
                String dt="";
                WorkerPreferdShiftRes wps=new WorkerPreferdShiftRes();
                if(wp.getShiftdate()!=null)
                {
                   
                   dt=GigflexDateUtil.convertDateToString(wp.getShiftdate(), GigflexConstants.YYYY_MM_DD);
                }
                wps.setFromTime(wp.getFromTime());
                wps.setId(wp.getId());
                wps.setOffHoursFromTime(wp.getOffHoursFromTime());
                wps.setOffHoursToTime(wp.getOffHoursToTime());
                wps.setShiftdate(dt);
                wps.setToTime(wp.getToTime());
                wps.setWorkerCode(wp.getWorkerCode());
                wps.setWorkerPreferdShiftCode(wp.getWorkerPreferdShiftCode());
                wlst.add(wps);
            }
            if (wlst != null && wlst.size() > 0) {
                jsonobj.put("responsecode", 200);
                jsonobj.put("message", "Success");
                jsonobj.put("timestamp", new Date());
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(wlst);
                jsonobj.put("data", new JSONArray(Detail));
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Record Not Found.");
                jsonobj.put("timestamp", new Date());
            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception occurred.");
            res = derr.toString();
        }
        return res;

    }

    @Override
    public String getWorkerPreferdShiftByWorkerCode(String workerCode) {

        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         List<WorkerPreferdShift> wlstdata=workerPreferdShiftRepository.getWorkerPreferdShift(workerCode);
                         List<WorkerPreferdShiftRes> wlst =new ArrayList<WorkerPreferdShiftRes>();
            for(WorkerPreferdShift wp:wlstdata)
            {
                String dt="";
                WorkerPreferdShiftRes wps=new WorkerPreferdShiftRes();
                if(wp.getShiftdate()!=null)
                {
                   
                   dt=GigflexDateUtil.convertDateToString(wp.getShiftdate(), GigflexConstants.YYYY_MM_DD);
                }
                wps.setFromTime(wp.getFromTime());
                wps.setId(wp.getId());
                wps.setOffHoursFromTime(wp.getOffHoursFromTime());
                wps.setOffHoursToTime(wp.getOffHoursToTime());
                wps.setShiftdate(dt);
                wps.setToTime(wp.getToTime());
                wps.setWorkerCode(wp.getWorkerCode());
                wps.setWorkerPreferdShiftCode(wp.getWorkerPreferdShiftCode());
                wlst.add(wps);
            }
                         if(wlst!=null && wlst.size()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlst);
				jsonobj.put("data", new JSONArray(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
        return res;

    }

    
    @Override
    public String repeatWorkerPreferdShift(String workercode, String type, String ip) {
       
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            boolean status = true;

             if (type.equalsIgnoreCase("curruntweek")) {
                Date d = new Date();
                SimpleDateFormat df = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD);
                Date date = df.parse(df.format(d));
                Calendar cal = Calendar.getInstance();
                // cal.setTime(date);
                int curruntday = cal.get(Calendar.DAY_OF_WEEK);
//                                  System.out.println(curruntday);
                if (curruntday == 1) {
                    curruntday = 7;
                } else {
                    curruntday--;
                }
                int i = 0;
                for (; curruntday <= 7; curruntday++) {
                    try {
                        cal.setTime(date);
                        cal.add(Calendar.DATE, i++);
                        Date dd = cal.getTime();
                        Calendar c = Calendar.getInstance();
                        c.setTime(dd);
                        c.add(Calendar.DATE, -7);
                        Date olddate = c.getTime();
                        WorkerPreferdShift wlst = new WorkerPreferdShift();
                        WorkerPreferdShift wlstres = workerPreferdShiftRepository.getworkerPreferdShiftByworkerCode(workercode, dd);
                        if (wlstres != null && wlstres.getId() > 0) {
                            wlst = wlstres;
                        }
                        WorkerPreferdShift wlstresold = workerPreferdShiftRepository.getworkerPreferdShiftByworkerCode(workercode, olddate);
                        if (wlstresold != null && wlstresold.getId() > 0) {
                            wlst.setIpAddress(ip);
                            wlst.setShiftdate(dd);
                            wlst.setFromTime(wlstresold.getFromTime());
                            wlst.setToTime(wlstresold.getToTime());
                            wlst.setWorkerCode(workercode);
                            wlst.setOffHoursFromTime(wlstresold.getOffHoursFromTime());
                            wlst.setOffHoursToTime(wlstresold.getOffHoursToTime());
                            WorkerPreferdShift wrkr = workerPreferdShiftRepository.save(wlst);
                        } 
                        
                    } catch (Exception e) {
                        e.printStackTrace();
                        status = false;
                    }

                }

            } else if (type.equalsIgnoreCase("nextweek")) {
                Date d = new Date();
                SimpleDateFormat df = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD);
                Date date = df.parse(df.format(d));
                Calendar cal = Calendar.getInstance();
                // cal.setTime(date);
                int curruntday = cal.get(Calendar.DAY_OF_WEEK);
//                                  System.out.println(curruntday);
                if (curruntday == 1) {
                    curruntday = 7;
                } else {
                    curruntday--;
                }
                int i = 0;
                for (; curruntday <= 14; curruntday++) {
                    try {
                        cal.setTime(date);
                        cal.add(Calendar.DATE, i++);
                        Date dd = cal.getTime();
                        Calendar c = Calendar.getInstance();
                        c.setTime(dd);
                        c.add(Calendar.DATE, -7);
                        Date olddate = c.getTime();
                        WorkerPreferdShift wlst = new WorkerPreferdShift();
                        WorkerPreferdShift wlstres = workerPreferdShiftRepository.getworkerPreferdShiftByworkerCode(workercode, dd);
                        if (wlstres != null && wlstres.getId() > 0) {
                            wlst = wlstres;
                        }
                        WorkerPreferdShift wlstresold = workerPreferdShiftRepository.getworkerPreferdShiftByworkerCode(workercode, olddate);
                        if (wlstresold != null && wlstresold.getId() > 0) {
                            wlst.setIpAddress(ip);
                            wlst.setShiftdate(dd);
                            wlst.setFromTime(wlstresold.getFromTime());
                            wlst.setToTime(wlstresold.getToTime());
                            wlst.setWorkerCode(workercode);
                            wlst.setOffHoursFromTime(wlstresold.getOffHoursFromTime());
                            wlst.setOffHoursToTime(wlstresold.getOffHoursToTime());
                            WorkerPreferdShift wrkr = workerPreferdShiftRepository.save(wlst);
                        } 

                        
                    } catch (Exception e) {
                        e.printStackTrace();
                        status = false;
                    }
                }
            } else if (type.equalsIgnoreCase("entiremonth")) {
                Date d = new Date();
                SimpleDateFormat df = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD);
                Date date = df.parse(df.format(d));
                Calendar c = Calendar.getInstance();
                c.setTime(date);
                int m = c.getActualMaximum(Calendar.DAY_OF_MONTH);
                int curruntday = c.get(Calendar.DAY_OF_MONTH);
                int i = 0;
                for (; curruntday <= m; curruntday++) {
                    try {
                        c.setTime(date);
                        c.add(Calendar.DATE, i++);
                        Date dd = c.getTime();
                        Calendar cc = Calendar.getInstance();
                        cc.setTime(dd);
                        cc.add(Calendar.DATE, -7);
                        Date olddate = cc.getTime();
                        WorkerPreferdShift wlst = new WorkerPreferdShift();
                        WorkerPreferdShift wlstres = workerPreferdShiftRepository.getworkerPreferdShiftByworkerCode(workercode, dd);
                        if (wlstres != null && wlstres.getId() > 0) {
                            wlst = wlstres;
                        }
                        WorkerPreferdShift wlstresold = workerPreferdShiftRepository.getworkerPreferdShiftByworkerCode(workercode, olddate);
                        if (wlstresold != null && wlstresold.getId() > 0) {
                            wlst.setIpAddress(ip);
                            wlst.setShiftdate(dd);
                            wlst.setFromTime(wlstresold.getFromTime());
                            wlst.setToTime(wlstresold.getToTime());
                            wlst.setWorkerCode(workercode);
                            wlst.setOffHoursFromTime(wlstresold.getOffHoursFromTime());
                            wlst.setOffHoursToTime(wlstresold.getOffHoursToTime());
                            WorkerPreferdShift wrkr = workerPreferdShiftRepository.save(wlst);
                        } 

                        
                    } catch (Exception e) {
                        e.printStackTrace();
                        status = false;
                    }
                }
////                                
            }
//                           
//                        
            
                if (status) {
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("message", "Worker Preferd Shift has been repeated.");
                    jsonobj.put("timestamp", new Date());
                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("message", "Failed.");
                    jsonobj.put("timestamp", new Date());
                }
                res = jsonobj.toString();
           
        } catch (JSONException | ParseException ex) {
            ex.printStackTrace();
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception x) {
            x.printStackTrace();
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception occurred.");
            res = derr.toString();
        }
        return res;
    
    }

    
    @Override
    public String saveWorkerPreferdShift(WorkerPreferdShiftRequest workerprsfReq, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            boolean status = true;

                    Date date = null;
                    String shiftdate = workerprsfReq.getShiftdate();
                    try
                    {
                    SimpleDateFormat formatter = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD);
                    date = formatter.parse(shiftdate);
                    if(date==null)
                    {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Send date in proper format. Date format should be "+GigflexConstants.YYYY_MM_DD);
                        jsonobj.put("timestamp", new Date());
                        return jsonobj.toString();
                    }
                    }
                    catch(Exception ee)
                    {
                        ee.printStackTrace();
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Exception is occurred in date parsing. Date format should be "+GigflexConstants.YYYY_MM_DD);
                        jsonobj.put("timestamp", new Date());
                        return jsonobj.toString();
                    }
                    WorkerPreferdShift wlstres = workerPreferdShiftRepository.getworkerPreferdShiftByworkerCode(workerprsfReq.getWorkerCode(), date);
                    if (wlstres != null && wlstres.getId() > 0) {
                        WorkerPreferdShift wlst = wlstres;
                        wlst.setIpAddress(ip);
                        wlst.setShiftdate(date);
                        wlst.setFromTime(workerprsfReq.getFromTime().trim());
                        wlst.setToTime(workerprsfReq.getToTime().trim());
                        wlst.setWorkerCode(workerprsfReq.getWorkerCode());
                        wlst.setOffHoursFromTime(workerprsfReq.getOffHoursFromTime());
                        wlst.setOffHoursToTime(workerprsfReq.getOffHoursToTime());
                        WorkerPreferdShift wlstRes = workerPreferdShiftRepository.save(wlst);
                        if (wlstRes != null && wlstRes.getId() > 0) {
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("message", "Worker Preferd Shift has been Updated.");
                            jsonobj.put("timestamp", new Date());
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(wlstRes);
                            jsonobj.put("data", new JSONObject(Detail));
                        } else {

                            jsonobj.put("responsecode", 400);
                            jsonobj.put("message", "Record Not Updated.");
                            jsonobj.put("timestamp", new Date());
                        }

                    } else {
                        WorkerPreferdShift wrkrprdshift = new WorkerPreferdShift();

                        wrkrprdshift.setIpAddress(ip);
                        wrkrprdshift.setShiftdate(date);
                        wrkrprdshift.setFromTime(workerprsfReq.getFromTime().trim());
                        wrkrprdshift.setToTime(workerprsfReq.getToTime().trim());
                        wrkrprdshift.setWorkerCode(workerprsfReq.getWorkerCode());
                        wrkrprdshift.setOffHoursFromTime(workerprsfReq.getOffHoursFromTime());
                        wrkrprdshift.setOffHoursToTime(workerprsfReq.getOffHoursToTime());
                        WorkerPreferdShift wlstRes = workerPreferdShiftRepository.save(wrkrprdshift);
                        if (wlstRes != null && wlstRes.getId() > 0) {
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("message", "Worker Preferd Shift has been added.");
                            jsonobj.put("timestamp", new Date());
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(wlstRes);
                            jsonobj.put("data", new JSONObject(Detail));
                        } else {

                            jsonobj.put("responsecode", 400);
                            jsonobj.put("message", "Failed.");
                            jsonobj.put("timestamp", new Date());
                        }

                    }
                
                res = jsonobj.toString();

            

        } catch (JSONException | JsonProcessingException  ex) {
            ex.printStackTrace();
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception x) {
            x.printStackTrace();
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String updatesaveWorkerPreferdShift(WorkerPreferdShiftRequest workerprsfReq, String workerPreferdShiftCode, String ip) {

        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         WorkerPreferdShift wlst=workerPreferdShiftRepository.getWorkerPreferdShiftByWorkerPreferdShiftCode(workerPreferdShiftCode);
                         if(wlst!=null && wlst.getId()>0)
                         {
                         Date date = null;
                    String shiftdate = workerprsfReq.getShiftdate();
                    try
                    {
                    SimpleDateFormat formatter = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD);
                    date = formatter.parse(shiftdate);
                    if(date==null)
                    {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Send date in proper format. Date format should be "+GigflexConstants.YYYY_MM_DD);
                        jsonobj.put("timestamp", new Date());
                        return jsonobj.toString();
                    }
                    }
                    catch(Exception ee)
                    {
                        ee.printStackTrace();
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Exception is occurred in date parsing. Date format should be "+GigflexConstants.YYYY_MM_DD);
                        jsonobj.put("timestamp", new Date());
                        return jsonobj.toString();
                    }
                         WorkerPreferdShift wlstres = workerPreferdShiftRepository.getworkerPreferdShiftByworkerCodeAndDateAndNotCode(workerprsfReq.getWorkerCode(), date,workerPreferdShiftCode);   
                         if(wlstres!=null && wlstres.getId()>0)
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record alre");
				jsonobj.put("timestamp", new Date());
                         }
                         else
                         {
                         wlst.setShiftdate(date);
                         wlst.setFromTime(workerprsfReq.getFromTime().trim());
                         wlst.setToTime(workerprsfReq.getToTime().trim());
                         wlst.setOffHoursFromTime(workerprsfReq.getOffHoursFromTime());
                         wlst.setOffHoursToTime(workerprsfReq.getOffHoursToTime());
                         WorkerPreferdShift  wlstRes= workerPreferdShiftRepository.save(wlst);
                         if(wlstRes!=null && wlstRes.getId()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker Preferd Shift has been updated.");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlstRes);
				jsonobj.put("data", new JSONObject(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Updation has been failed.");
				jsonobj.put("timestamp", new Date());
                         }
                         }
                                                  
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
        return res;

    }

    @Override
    public String deleteWorkerPreferdShift(String workerPreferdShiftCode) {

        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         WorkerPreferdShift wlst=workerPreferdShiftRepository.getWorkerPreferdShiftByWorkerPreferdShiftCode(workerPreferdShiftCode);
                         if(wlst!=null && wlst.getId()>0)
                         {
                             
                             wlst.setIsDeleted(Boolean.TRUE);
                             WorkerPreferdShift wlstres= workerPreferdShiftRepository.save(wlst);
                            if(wlstres!=null && wlstres.getId()>0)
                            {
                                jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker Preferd Shift has been deleted.");
				jsonobj.put("timestamp", new Date());
                            }
                            else
                            {
                                jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Failed.");
				jsonobj.put("timestamp", new Date());
                            }
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException  ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
        return res;

    }

    @Override
    public String getWorkerPreferdShiftByworkerPreferdShiftCode(String workerPreferdShiftCode) {
       
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         WorkerPreferdShift wp=workerPreferdShiftRepository.getWorkerPreferdShiftByWorkerPreferdShiftCode(workerPreferdShiftCode);
                         WorkerPreferdShiftRes wps=null;
            if(wp!=null && wp.getId()>0)
            {
                String dt="";
                wps=new WorkerPreferdShiftRes();
                if(wp.getShiftdate()!=null)
                {
                   
                   dt=GigflexDateUtil.convertDateToString(wp.getShiftdate(), GigflexConstants.YYYY_MM_DD);
                }
                wps.setFromTime(wp.getFromTime());
                wps.setId(wp.getId());
                wps.setOffHoursFromTime(wp.getOffHoursFromTime());
                wps.setOffHoursToTime(wp.getOffHoursToTime());
                wps.setShiftdate(dt);
                wps.setToTime(wp.getToTime());
                wps.setWorkerCode(wp.getWorkerCode());
                wps.setWorkerPreferdShiftCode(wp.getWorkerPreferdShiftCode());
                
            }
                         if(wps!=null && wps.getId()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wps);
				jsonobj.put("data", new JSONObject(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
        return res;
    }

    @Override
    public String getWorkerPreferdShiftByWorkerCodeForCalendar(String workerCode, String start, String end) {
        
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
                    Date sDt = null;
                    Date eDt = null;
                    try
                    {
                    SimpleDateFormat formatter = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD);
                    sDt = formatter.parse(start);
                    eDt = formatter.parse(end);
                    if(sDt==null || eDt==null)
                    {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Send date in proper format. Date format should be "+GigflexConstants.YYYY_MM_DD);
                        jsonobj.put("timestamp", new Date());
                        return jsonobj.toString();
                    }
                    }
                    catch(Exception ee)
                    {
                        ee.printStackTrace();
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Exception is occurred in date parsing. Date format should be "+GigflexConstants.YYYY_MM_DD);
                        jsonobj.put("timestamp", new Date());
                        return jsonobj.toString();
                    }
                    List<WorkerPreferdShift> wlstdata=workerPreferdShiftRepository.getWorkerPreferdShiftByWorkerCodeForCalendar(workerCode,sDt,eDt);
                         List<WorkerPreferdShiftRes> wlst =new ArrayList<WorkerPreferdShiftRes>();
            for(WorkerPreferdShift wp:wlstdata)
            {
                String dt="";
                WorkerPreferdShiftRes wps=new WorkerPreferdShiftRes();
                if(wp.getShiftdate()!=null)
                {
                   
                   dt=GigflexDateUtil.convertDateToString(wp.getShiftdate(), GigflexConstants.YYYY_MM_DD);
                }
                wps.setFromTime(wp.getFromTime());
                wps.setId(wp.getId());
                wps.setOffHoursFromTime(wp.getOffHoursFromTime());
                wps.setOffHoursToTime(wp.getOffHoursToTime());
                wps.setShiftdate(dt);
                wps.setToTime(wp.getToTime());
                wps.setWorkerCode(wp.getWorkerCode());
                wps.setWorkerPreferdShiftCode(wp.getWorkerPreferdShiftCode());
                wlst.add(wps);
            }
                         if(wlst!=null && wlst.size()>0)
                         {
                            jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlst);
				jsonobj.put("data", new JSONArray(Detail)); 
                         }
                         else
                         {
                             jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
                         }
                        res = jsonobj.toString();
                res = jsonobj.toString();

            

        } catch (JSONException | JsonProcessingException  ex) {
            ex.printStackTrace();
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception x) {
            x.printStackTrace();
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception occurred.");
            res = derr.toString();
        }
        return res;
    
    }

    
}
