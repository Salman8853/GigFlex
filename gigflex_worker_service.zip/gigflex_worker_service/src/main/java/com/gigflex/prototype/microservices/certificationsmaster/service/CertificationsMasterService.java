package com.gigflex.prototype.microservices.certificationsmaster.service;

import java.util.List;

import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMasterRequest;

public interface CertificationsMasterService {
	public String search(String search);
	public String getCertificationsMasterByPage(int page, int limit);

	public String updateCertificationsMasterById(Long id, CertificationsMasterRequest cermasterreq,String ip);
	public String findAllCertificationsMaster();
	public String findCertificationsMasterById(Long id);
	public String saveCertificationsMaster(CertificationsMasterRequest cermasterreq,String ip);
	public String deleteCertificationsMasterById(Long id);
	public String getCertificationsMasterByCertificationCode(String certificationCode);
	public String deleteByCertificationCode(String certificationCode);
//	public String getCertificationsMasterByWorkerCode(String workerCode);
//	public String getCertificationsMasterByWorkerCodeAssigned(String workerCode);
	public String getCertificationsMasterByOrganizationCode(String organization_Code);
	
//	public String getCertificationsMasterByWorkerCode(String workerCode,int page, int limit);
	public String getCertificationsMasterByOrganizationCode(String organization_Code,int page, int limit);
	
	public String softDeleteByCertificationCode(String certificationCode);
    public String softMultipleDeleteByCertificationCode(List<String> certificationCodeList);

}
