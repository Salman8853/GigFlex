package com.gigflex.prototype.microservices.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import com.gigflex.prototype.microservices.shift.dtob.Shift;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.worker.approvalstatus.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocation;

@Service
public class KafkaService {
	
	@Autowired
	private KafkaTemplate<String, Shift> kafkaShiftTemplate;

	@Autowired
	private KafkaTemplate<String, Organization> kafkaOrganizationTemplate;

	@Autowired
	private KafkaTemplate<String, Worker> kafkaWorkerTemplate;
	
	@Autowired
	private KafkaTemplate<String, Users> kafkaUsersTemplate;
	
	@Autowired
	private KafkaTemplate<String, WorkerApprovalStatus> kafkaWorkerApprovalStatusTemplate;

	@Autowired
	private KafkaTemplate<String, CertificationsMaster> kafkaCertificationsMasterTemplate;

	@Autowired
	private KafkaTemplate<String, WorkerCertifications> kafkaWorkerCertificationsTemplate;
	
	@Autowired
	private KafkaTemplate<String, WorkerPreferredLocation> kafkaWorkerPreferredLocationTemplate;
	
	@Autowired
	private KafkaTemplate<String, SkillMaster> kafkaSkillMasterTemplate;

	@Autowired
	private KafkaTemplate<String, OrganizationSkill> kafkaOrganizationSkillTemplate;
	
	@Autowired
	private KafkaTemplate<String, OrganizationWorkerSkill> kafkaOrganizationWorkerSkillTemplate;
	
	
	
	String kafkaTopicSkillMaster = "AddSkillMasterFromWorker";

	String kafkaTopicSkillMasterAtUpdation = "UpdateSkillMasterFromWorker";
	

	String kafkaTopicOrganizationSkill = "AddOrganizationSkillFromWorker";

	String kafkaTopicOrganizationSkillAtUpdation = "UpdateOrganizationSkillFromWorker";
	
	
	String kafkaTopicOrganizationWorkerSkill = "AddOrganizationWorkerSkillFromWorker";

	String kafkaTopicOrganizationWorkerSkillAtUpdation = "UpdateOrganizationWorkerSkillFromWorker";
	

	String kafkaTopicUsersAtUpdation = "UpdateUserFromWorker";
	
	String kafkaTopicWorkApprovalStatusAtUpdation = "UpdateWorkerApprovalStatusFromWorker";

	String kafkaTopicOrganizationAtDeletion = "DeleteOrganizationFromWorker";
	String kafkaTopicOrganizationAtUpdation = "UpdateOrganizationFromWorker";
	String kafkaTopicWorkerAtUpdation = "UpdateWorkerFromWorker";
	String kafkaTopicWorkerAtDeletion = "DeletionWorkerFromWorker";
	String kafkaTopicWorkerAtAdd = "AddWorkerFromWorker";

	String kafkaTopicCertificationsMaster = "NewCertificationsMaster";
	String kafkaTopicCertificationsMasterAtDeletion = "DeleteCertificationsMaster";
	String kafkaTopicCertificationsMasterAtUpdation = "UpdateCertificationsMaster";

	String kafkaTopicWorkerCertifications = "NewWorkerCertifications";
	String kafkaTopicWorkerCertificationsAtDeletion = "DeleteWorkerCertifications";
	String kafkaTopicWorkerCertificationsAtUpdation = "UpdateWorkerCertifications";
	
	String kafkaTopicWorkerPreferredLocation = "NewWorkerPreferredLocation";
	String kafkaTopicWorkerPreferredLocationAtDeletion = "DeleteWorkerPreferredLocation";
	String kafkaTopicWorkerPreferredLocationAtUpdation = "UpdateWorkerPreferredLocation";
	
	String kafkaTopicShift = "NewShift";
	String kafkaTopicShiftAtUpdation = "UpdateShiftFromOrganization";
	
	public void sendOrganizationWorkerSkill(OrganizationWorkerSkill message) {

		kafkaOrganizationWorkerSkillTemplate.send(kafkaTopicOrganizationWorkerSkill, message);
	}

	
	
	public void sendUpdateOrganizationWorkerSkill(OrganizationWorkerSkill message) {

		kafkaOrganizationWorkerSkillTemplate.send(kafkaTopicOrganizationWorkerSkillAtUpdation,
				message);
	}
	
	public void sendOrganizationSkill(OrganizationSkill message) {

		kafkaOrganizationSkillTemplate.send(kafkaTopicOrganizationSkill, message);
	}

	

	public void sendUpdateOrganizationSkill(OrganizationSkill message) {

		kafkaOrganizationSkillTemplate.send(kafkaTopicOrganizationSkillAtUpdation,
				message);
	}
	
	public void sendSkillMaster(SkillMaster message) {

		kafkaSkillMasterTemplate.send(kafkaTopicSkillMaster, message);
	}

	
	public void sendUpdateSkillMaster(SkillMaster message) {

		kafkaSkillMasterTemplate.send(kafkaTopicSkillMasterAtUpdation,
				message);
	}
	
	
	
	public void sendShift(Shift message) {

		kafkaShiftTemplate.send(kafkaTopicShift, message);
	}

	public void sendUpdateShift(Shift message) {

		kafkaShiftTemplate.send(kafkaTopicShiftAtUpdation,
				message);
	}
	
	public void sendUpdateWAS(WorkerApprovalStatus message) {

		kafkaWorkerApprovalStatusTemplate.send(
				kafkaTopicWorkApprovalStatusAtUpdation, message);
	}
	public void sendUpdateUser(Users message) {

		kafkaUsersTemplate.send(kafkaTopicUsersAtUpdation,
				message);
	}
	
	
	public void sendDeleteOrganization(Organization message) {

		kafkaOrganizationTemplate.send(kafkaTopicOrganizationAtDeletion,
				message);
	}

	public void sendUpdateOrganization(Organization message) {

		kafkaOrganizationTemplate.send(kafkaTopicOrganizationAtUpdation,
				message);
	}

	public void sendAddWorker(Worker message) {

		kafkaWorkerTemplate.send(kafkaTopicWorkerAtAdd, message);
	}

	public void sendUpdateWorker(Worker message) {

		kafkaWorkerTemplate.send(kafkaTopicWorkerAtUpdation, message);
	}

	public void sendDeleteWorker(Worker message) {

		kafkaWorkerTemplate.send(kafkaTopicWorkerAtDeletion, message);
	}
	

	public void sendCertificationsMaster(CertificationsMaster message) {
		kafkaCertificationsMasterTemplate.send(kafkaTopicCertificationsMaster, message);
	}

	public void sendCertificationsMasterUpdate(CertificationsMaster message) {
		kafkaCertificationsMasterTemplate.send(kafkaTopicCertificationsMasterAtUpdation,
				message);
	}
	
	public void sendCertificationsMasterDelete(CertificationsMaster message){
		kafkaCertificationsMasterTemplate.send(kafkaTopicCertificationsMasterAtDeletion, message);
	}
	
	
	public void sendWorkerCertifications(WorkerCertifications message) {
		kafkaWorkerCertificationsTemplate.send(kafkaTopicWorkerCertifications, message);
	}

	public void sendWorkerCertificationsUpdate(WorkerCertifications message) {
		kafkaWorkerCertificationsTemplate.send(kafkaTopicWorkerCertificationsAtUpdation,
				message);
	}
	
	public void sendWorkerCertificationsDelete(WorkerCertifications message){
		kafkaWorkerCertificationsTemplate.send(kafkaTopicWorkerCertificationsAtDeletion, message);
	}
	
	
	public void sendWorkerPreferredLocation(WorkerPreferredLocation message) {
		kafkaWorkerPreferredLocationTemplate.send(kafkaTopicWorkerPreferredLocation, message);
	}

	public void sendWorkerPreferredLocationUpdate(WorkerPreferredLocation message) {
		kafkaWorkerPreferredLocationTemplate.send(kafkaTopicWorkerPreferredLocationAtUpdation,
				message);
	}
	
	public void sendWorkerPreferredLocationDelete(WorkerPreferredLocation message){
		kafkaWorkerPreferredLocationTemplate.send(kafkaTopicWorkerPreferredLocationAtDeletion, message);
	}
     
}
