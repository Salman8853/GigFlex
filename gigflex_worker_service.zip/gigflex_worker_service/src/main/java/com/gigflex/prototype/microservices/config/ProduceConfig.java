package com.gigflex.prototype.microservices.config;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import com.gigflex.prototype.microservices.shift.dtob.Shift;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.worker.approvalstatus.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocation;

@Configuration
public class ProduceConfig {

    //@Value("${kafka.bootstrap-servers}")
    //private String bootstrapServers;

    @Bean
    public Map<String, Object> producerConfigs() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        return props;
    }
    
    @Bean
    public ProducerFactory<String, OrganizationWorkerSkill> producerFactoryOrganizationWorkerSkill() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, OrganizationWorkerSkill> kafkaTemplateOrganizationWorkerSkill() {
        return new KafkaTemplate<>(producerFactoryOrganizationWorkerSkill());
    }
    
    
    @Bean
    public ProducerFactory<String, SkillMaster> producerFactorySkillMaster() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, SkillMaster> kafkaTemplateSkillMaster() {
        return new KafkaTemplate<>(producerFactorySkillMaster());
    }
    
    @Bean
    public ProducerFactory<String, OrganizationSkill> producerFactoryOrganizationSkill() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, OrganizationSkill> kafkaTemplateOrganizationSkill() {
        return new KafkaTemplate<>(producerFactoryOrganizationSkill());
    }
    
    @Bean
    public ProducerFactory<String, Shift> producerFactoryShift() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Shift> kafkaTemplateShift() {
        return new KafkaTemplate<>(producerFactoryShift());
    }
    
    @Bean
    public ProducerFactory<String, WorkerApprovalStatus> producerFactoryWAS() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, WorkerApprovalStatus> kafkaTemplateWAS() {
        return new KafkaTemplate<>(producerFactoryWAS());
    }
    @Bean
    public ProducerFactory<String, Users> producerFactoryUser() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Users> kafkaTemplateUser() {
        return new KafkaTemplate<>(producerFactoryUser());
    }

    @Bean
    public ProducerFactory<String, Organization> producerFactoryOrg() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Organization> kafkaTemplateOrg() {
        return new KafkaTemplate<>(producerFactoryOrg());
    }
    
     @Bean
    public ProducerFactory<String, Worker> producerFactoryWorker() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Worker> kafkaTemplateWorker() {
        return new KafkaTemplate<>(producerFactoryWorker());
    }
    
    @Bean
    public ProducerFactory<String, CertificationsMaster> producerFactoryCertificationsMaster() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, CertificationsMaster> kafkaTemplateCertificationsMaster() {
        return new KafkaTemplate<>(producerFactoryCertificationsMaster());
    }
    
    @Bean
    public ProducerFactory<String, WorkerCertifications> producerFactoryWorkerCertifications() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, WorkerCertifications> kafkaTemplateWorkerCertifications() {
        return new KafkaTemplate<>(producerFactoryWorkerCertifications());
    }
    
    @Bean
    public ProducerFactory<String, WorkerPreferredLocation> producerFactoryWorkerPreferredLocation() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, WorkerPreferredLocation> kafkaTemplateWorkerPreferredLocation() {
        return new KafkaTemplate<>(producerFactoryWorkerPreferredLocation());
    }
    
    @Bean
    public ProduceConfig sender() {
        return new ProduceConfig();
    }
}
