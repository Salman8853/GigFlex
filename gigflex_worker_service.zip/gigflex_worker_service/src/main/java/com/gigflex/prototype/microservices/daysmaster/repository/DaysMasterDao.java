package com.gigflex.prototype.microservices.daysmaster.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMaster;
import com.gigflex.prototype.microservices.shift.dtob.ShiftWithDays;
import com.gigflex.prototype.microservices.worker.dtob.WorkerOffdays;
import com.gigflex.prototype.microservices.worker.dtob.WorkerWorkingHours;

@Repository
public interface DaysMasterDao extends JpaRepository<DaysMaster,Integer>,JpaSpecificationExecutor<DaysMaster> {
	
	@Query("SELECT dm FROM DaysMaster dm WHERE dm.isDeleted != TRUE AND dm.daysCode = :daysCode")
	public DaysMaster getDaysMasterByDaysCode(@Param("daysCode") String daysCode);
	
//	@Query("SELECT wwh FROM WorkerWorkingHours wwh WHERE wwh.isDeleted != TRUE AND wwh.daysCode = :daysCode")
//	public List<WorkerWorkingHours> getWorkerWorkingHrsByDaysCode(@Param("daysCode") String daysCode);
//	
//	@Query("SELECT wof FROM WorkerOffdays wof WHERE wof.isDeleted != TRUE AND wof.daysCode = :daysCode")
//	public List<WorkerOffdays> getWorkerOffdaysByDaysCode(@Param("daysCode") String daysCode);
	
	@Query("SELECT swd FROM ShiftWithDays swd WHERE swd.isDeleted != TRUE AND swd.daysCode = :daysCode")
	public List<ShiftWithDays> getShiftWithDaysByDaysCode(@Param("daysCode") String daysCode);
	
	@Transactional
	public Integer deleteDaysMasterByDaysCode(String daysCode);
	
	@Query("SELECT dm FROM DaysMaster dm WHERE dm.isDeleted != TRUE")
    public List<DaysMaster> getAllDaysMaster();
	
	@Query("SELECT dm FROM DaysMaster dm WHERE dm.isDeleted != TRUE")
    public List<DaysMaster> getAllDaysMaster(Pageable pageableRequest);
	
	@Query("SELECT dm FROM DaysMaster dm WHERE dm.isDeleted != TRUE AND dm.id = :id")
	public DaysMaster getDaysMasterById(@Param("id") Integer id);


}
