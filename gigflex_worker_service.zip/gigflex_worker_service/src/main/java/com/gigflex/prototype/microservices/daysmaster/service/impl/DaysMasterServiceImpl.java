package com.gigflex.prototype.microservices.daysmaster.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMaster;
import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMasterRequest;
import com.gigflex.prototype.microservices.daysmaster.repository.DaysMasterDao;
import com.gigflex.prototype.microservices.daysmaster.search.DaysMasterSpecificationsBuilder;
import com.gigflex.prototype.microservices.daysmaster.service.DaysMasterService;
import com.gigflex.prototype.microservices.shift.dtob.ShiftWithDays;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.WorkerOffdays;
import com.gigflex.prototype.microservices.worker.dtob.WorkerWorkingHours;
import com.gigflex.prototype.microservices.worker.service.impl.WorkerServiceImpl;

@Service
public class DaysMasterServiceImpl implements DaysMasterService {
	 private static final Logger LOG = LoggerFactory.getLogger(DaysMasterServiceImpl.class);


	@Autowired
	private DaysMasterDao daysMasterRep;

	@Override
	public String findAllDaysMaster() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<DaysMaster> dayslst = daysMasterRep.getAllDaysMaster();

			if (dayslst != null && dayslst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(dayslst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String findDaysMasterById(Integer id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DaysMaster dayslst = daysMasterRep.getDaysMasterById(id);

			if (dayslst != null && dayslst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(dayslst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveDaysMaster(DaysMasterRequest daysMasterReq,String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (daysMasterReq != null) {
				if (daysMasterReq.getDaysName() != null
						&& daysMasterReq.getDaysName().trim().length() > 0) {

					DaysMaster days = new DaysMaster();

					days.setDaysName(daysMasterReq.getDaysName());
                    days.setIpAddress(ip);
					DaysMaster daysRes = daysMasterRep.save(days);

					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					if (daysRes != null && daysRes.getId() > 0) {
						jsonobj.put("message",
								"Days Master has been added successfully.");
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(daysRes);
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("message", "Failed");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Days name should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String deleteDaysMasterById(Integer id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<DaysMaster> daysData = daysMasterRep.findById(id);
			if (daysData.isPresent() && daysData.get() != null) {
				daysMasterRep.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", " DaysMaster has been deleted.");
				jsonobj.put("timestamp", new Date());
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String updateDaysMasterById(Integer id,
			DaysMasterRequest daysMasterReq,String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && daysMasterReq != null) {
				if (daysMasterReq.getDaysName() != null
						&& daysMasterReq.getDaysName().trim().length() > 0) {

					DaysMaster daysMasterInDb = daysMasterRep
							.getDaysMasterById(id);
					if (daysMasterInDb != null && daysMasterInDb.getId() > 0) {

						DaysMaster days = daysMasterInDb;
						days.setDaysName(daysMasterReq.getDaysName());
	                    days.setIpAddress(ip);

						DaysMaster daysRes = daysMasterRep.save(days);
						if (daysRes != null && daysRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"Days Master updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(daysRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Days Master updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Days Master ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Days name should not be blank");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String findByDaysCode(String daysCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DaysMaster dayslst = daysMasterRep
					.getDaysMasterByDaysCode(daysCode);
			if (dayslst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(dayslst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteDaysMasterByDaysCode(String daysCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Integer deleteByDaysCode = daysMasterRep
					.deleteDaysMasterByDaysCode(daysCode);

			if (deleteByDaysCode != 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Days Master has been deleted.");
				jsonobj.put("timestamp", new Date());
				res = jsonobj.toString();
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteDaysMasterByDaysCode(String daysCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DaysMaster dayslst = daysMasterRep
					.getDaysMasterByDaysCode(daysCode);
			if (dayslst != null && dayslst.getId() > 0) {


					dayslst.setIsDeleted(true);
					DaysMaster daysRes = daysMasterRep.save(dayslst);
					if (daysRes != null && daysRes.getId() > 0) {
						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message",
								"Days Master deleted successfully.");
						// kafkaService.
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}
				}

			else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        LOG.error("Error in softDeleteByDaysCode>>>>>>", ex);
                }catch(org.springframework.orm.jpa.JpaSystemException ex)
                {
                    GigflexResponse derr = new GigflexResponse(401, new Date(), GigUtil.getRootException(ex));
            res = derr.toString();
            ex.printStackTrace();
		} catch (Exception ex) {
		 ex.printStackTrace();
        LOG.error("Error in softDeleteByDaysCode>>>>>>", ex);	
                    GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByDaysCode(List<String> daysCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String daysCode : daysCodeList) {
				if (daysCode != null && daysCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					daysCode = daysCode.trim();

					DaysMaster dayslst = daysMasterRep
							.getDaysMasterByDaysCode(daysCode);

					if (dayslst != null && dayslst.getId() > 0) {
						
						try{
							dayslst.setIsDeleted(true);
							DaysMaster daysRes = daysMasterRep.save(dayslst);
							if (daysRes != null && daysRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", daysCode);
								jsonobj.put("message",
										"Days Master deleted successfully.");
								// kafkaService.sendUseronUpdate(usersDataRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", daysCode);
								jsonobj.put("message", "Failed");
							}
						}catch(org.springframework.orm.jpa.JpaSystemException ex){
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", daysCode);
							jsonobj.put("message",  GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", daysCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllDaysMasterByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<DaysMaster> dayslst = daysMasterRep
					.getAllDaysMaster(pageableRequest);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (dayslst != null && dayslst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(dayslst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				DaysMasterSpecificationsBuilder builder = new DaysMasterSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<DaysMaster> spec = builder.build();
				if (spec != null) {
					List<DaysMaster> dayslst = daysMasterRep.findAll(spec);
					if (dayslst != null && dayslst.size() > 0) {
						for (DaysMaster days : dayslst) {
							if (days.getIsDeleted() != null
									&& days.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(days);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("Days", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}

				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
