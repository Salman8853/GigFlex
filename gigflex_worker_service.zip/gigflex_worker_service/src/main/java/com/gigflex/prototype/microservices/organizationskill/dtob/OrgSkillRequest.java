package com.gigflex.prototype.microservices.organizationskill.dtob;

public class OrgSkillRequest {

	private String organizationCode;
	private String skillCode;

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getSkillCode() {
		return skillCode;
	}

	public void setSkillCode(String skillCode) {
		this.skillCode = skillCode;
	}

}
