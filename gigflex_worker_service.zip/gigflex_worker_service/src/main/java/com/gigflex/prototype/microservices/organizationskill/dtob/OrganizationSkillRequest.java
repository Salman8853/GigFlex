package com.gigflex.prototype.microservices.organizationskill.dtob;

import java.util.List;

public class OrganizationSkillRequest {

	private List<String> skillCode;

	private String organizationCode;

	

	public List<String> getSkillCode() {
		return skillCode;
	}

	public void setSkillCode(List<String> skillCode) {
		this.skillCode = skillCode;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

}
