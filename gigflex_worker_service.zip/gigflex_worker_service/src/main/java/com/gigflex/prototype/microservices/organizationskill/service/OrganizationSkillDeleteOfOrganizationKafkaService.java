package com.gigflex.prototype.microservices.organizationskill.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationskill.repository.OrganizationSkillDao;


@Service
public class OrganizationSkillDeleteOfOrganizationKafkaService {
	
	@Autowired
	private OrganizationSkillDao orgSkillDao;
	
    private static final Logger LOG = LoggerFactory.getLogger(OrganizationSkillDeleteOfOrganizationKafkaService.class);


	@KafkaListener(topics = "DeleteOrganizationSkill")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			OrganizationSkill os = objectMapper.readValue(message, OrganizationSkill.class);
			
			LOG.info("received message='{}'", os.getOrganizationCode());
			LOG.info("received message='{}'", os.getSkillCode());
			
			OrganizationSkill orgSkillRes =orgSkillDao.getByOrgCodeAndSkillCode(os.getOrganizationCode(), os.getSkillCode());
                        if(orgSkillRes!=null && orgSkillRes.getId()>0)
                        {
                        	orgSkillDao.deleteById(orgSkillRes.getId());
                        }
			
		} catch (JsonParseException e) {
			LOG.error("In OrganizationSkillDeleteOfOrganizationKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In OrganizationSkillDeleteOfOrganizationKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In OrganizationSkillDeleteOfOrganizationKafkaService >>>>", e);
		}catch (Exception e) {
			LOG.error("In OrganizationSkillDeleteOfOrganizationKafkaService >>>>", e);
		}
    }

}
