package com.gigflex.prototype.microservices.organizationworkerskill.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;

@Repository
public interface OrgWorkerSkillDao extends JpaRepository<OrganizationWorkerSkill,Long> ,JpaSpecificationExecutor<OrganizationWorkerSkill>{
	
//	@Query("SELECT a,b.skillName,c.organizationName,d.name FROM OrganizationWorkerSkill a , Organization c , SkillMaster b , Worker d WHERE a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.workerCode=d.workerCode")
//	public List<Object> getAllOrgWorkerSkill();
	
	@Query("SELECT ows FROM OrganizationWorkerSkill ows  WHERE ows.isDeleted != TRUE AND ows.organizationCode = :organizationCode AND ows.skillCode = :skillCode AND ows.workerCode = :workerCode")

	public OrganizationWorkerSkill getByOrgCodeAndWorkerCodeAndSkillCode(@Param("organizationCode") String organizationCode, @Param("skillCode") String skillCode, @Param("workerCode") String workerCode);
	
	
	@Query("SELECT a,b.skillName,c.organizationName,d.name FROM OrganizationWorkerSkill a , Organization c , SkillMaster b , Worker d WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.workerCode=d.workerCode")
	public List<Object> getAllOrgWorkerSkillWithNames();
	
	@Query("SELECT os FROM OrganizationWorkerSkill os WHERE os.isDeleted != TRUE")
	public List<OrganizationWorkerSkill> getAllOrganizationWorkerSkill();
	
	@Query("SELECT os FROM OrganizationWorkerSkill os WHERE os.isDeleted != TRUE")
	public List<OrganizationWorkerSkill> getAllOrganizationWorkerSkill(Pageable pageableRequest);
	
	@Query("SELECT a,b.skillName,c.organizationName,d.name FROM OrganizationWorkerSkill a , Organization c , SkillMaster b , Worker d WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.workerCode=d.workerCode")
	public List<Object> getAllOrgWorkerSkillWithNames(Pageable pageableRequest);

	@Query("SELECT os FROM OrganizationWorkerSkill os WHERE os.isDeleted != TRUE AND os.id = :id")
	public OrganizationWorkerSkill getOrganizationWorkerSkillById(@Param("id") Long id);
	
	@Query("SELECT a FROM SkillMaster a, Organization org, OrganizationWorkerSkill ows WHERE org.isDeleted != TRUE AND org.organizationCode = ows.organizationCode AND ows.skillCode = a.skillCode AND org.organizationCode = :organizationCode")
	public List<SkillMaster> getSkillsByOrganizationCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT a FROM SkillMaster a, Organization org, OrganizationWorkerSkill ows WHERE org.isDeleted != TRUE AND org.organizationCode = ows.organizationCode AND ows.skillCode = a.skillCode AND org.organizationCode = :organizationCode")
	public List<SkillMaster> getSkillsByOrganizationCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
        @Query("SELECT a,b.skillName,c.organizationName,d.name FROM OrganizationWorkerSkill a , Organization c , SkillMaster b , Worker d WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.workerCode=d.workerCode AND a.organizationCode = :organizationCode")
	public List<Object> getOrgWorkerSkillsByOrganizationCode(@Param("organizationCode") String organizationCode);
	
        @Query("SELECT a,b.skillName,c.organizationName,d.name FROM OrganizationWorkerSkill a , Organization c , SkillMaster b , Worker d WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.workerCode=d.workerCode AND a.organizationCode = :organizationCode")
	public List<Object> getOrgWorkerSkillsByOrganizationCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
        @Query("SELECT a,b.skillName,c.organizationName,d.name FROM OrganizationWorkerSkill a , Organization c , SkillMaster b , Worker d WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.workerCode=d.workerCode AND a.workerCode = :workerCode")
	public List<Object> getOrgWorkerSkillsByWorkerCode(@Param("workerCode") String workerCode);
	
        @Query("SELECT a,b.skillName,c.organizationName,d.name FROM OrganizationWorkerSkill a , Organization c , SkillMaster b , Worker d WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.workerCode=d.workerCode AND a.workerCode = :workerCode")
	public List<Object> getOrgWorkerSkillsByWorkerCode(@Param("workerCode") String workerCode,Pageable pageableRequest);
	
        @Query("SELECT a,b.skillName,c.organizationName,d.name FROM OrganizationWorkerSkill a , Organization c , SkillMaster b , Worker d WHERE a.isDeleted != TRUE AND a.isAssigned = TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.workerCode=d.workerCode AND a.workerCode = :workerCode")
	public List<Object> getOrgWorkerSkillsByWorkerCodeAssigned(@Param("workerCode") String workerCode);
	
	@Query("SELECT a FROM SkillMaster a, Worker b, OrganizationWorkerSkill ows WHERE b.isDeleted != TRUE AND b.workerCode = ows.workerCode AND ows.skillCode = a.skillCode AND b.workerCode = :workerCode")
	public List<SkillMaster> getSkillsByWorkerCode(@Param("workerCode") String workerCode);
	
	@Query("SELECT a FROM SkillMaster a, Worker b, OrganizationWorkerSkill ows WHERE b.isDeleted != TRUE  AND ows.isAssigned = TRUE AND b.workerCode = ows.workerCode AND ows.skillCode = a.skillCode AND b.workerCode = :workerCode")
	public List<SkillMaster> getSkillsByWorkerCodeAssigned(@Param("workerCode") String workerCode);
	
	@Query("SELECT a FROM SkillMaster a, Worker b, OrganizationWorkerSkill ows WHERE b.isDeleted != TRUE AND b.workerCode = ows.workerCode AND ows.skillCode = a.skillCode AND b.workerCode = :workerCode")
	public List<SkillMaster> getSkillsByWorkerCode(@Param("workerCode") String workerCode,Pageable pageableRequest);
	
	
	@Query("SELECT a FROM OrganizationWorkerSkill a WHERE a.isDeleted != TRUE AND a.skillCode = :skillCode AND a.organizationCode =:organizationCode AND a.workerCode =:workerCode")
	public OrganizationWorkerSkill getOrgWorkSkillCheckForSave(@Param("skillCode") String skillCode,@Param("organizationCode") String organizationCode,@Param("workerCode") String workerCode);
	
	@Query("SELECT a FROM OrganizationWorkerSkill a WHERE a.isDeleted != TRUE AND a.id != :id AND a.skillCode = :skillCode AND a.organizationCode =:organizationCode AND a.workerCode =:workerCode")
	public OrganizationWorkerSkill getOrgWorkSkillCheckForUpdate(@Param("id") Long id,@Param("skillCode") String skillCode,@Param("organizationCode") String organizationCode,@Param("workerCode") String workerCode);

	


}
