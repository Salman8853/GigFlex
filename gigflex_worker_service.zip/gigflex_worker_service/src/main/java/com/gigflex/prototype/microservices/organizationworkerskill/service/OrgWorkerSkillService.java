package com.gigflex.prototype.microservices.organizationworkerskill.service;

import java.util.List;

import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrgWorkerSkillRequest;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkillRequest;



public interface OrgWorkerSkillService {
	public String search(String search);
	public String updateOrgWorkerSkillById(Long id,OrganizationWorkerSkillRequest orgWorkerSkillReq,String ip);
    public String getAllOrgWorkerSkill();
	public String findAllOrgWorkerSkill();
	public String findOrgWorkerSkillById(Long id);
	public String saveOrgWorkerSkill(OrganizationWorkerSkillRequest orgWorkerSkillReq,String ip);
	public String deleteOrgWorkerSkillById(Long id);
	public String softDeleteOrgWorkerSkillById(Long id);
	
	public String getOrgWorkerSkill(int page, int limit);
	public String getOrgWorkerSkillWithNamesByPage(int page, int limit);
	
	public String getSkillsByOrgCode(String organizationCode);
	public String getSkillsByOrgCodeByPage(String organizationCode,int page, int limit);

	public String getSkillsByWorkerCode(String workerCode);
	public String getSkillsByWorkerCodeAssigned(String workerCode);
	public String getSkillsByWorkerCodeByPage(String workerCode,int page, int limit);

	public String softMultipleDeleteById(List<Long> idList);


}
