/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

/**
 *
 * @author abhishek
 */

public class ApprovalChangeAssignScheduleToWorkerInputRequest  {
    
   
    private String changeAssignScheduletoWorkerCode;
    
    private Boolean isApproved;

    public String getChangeAssignScheduletoWorkerCode() {
        return changeAssignScheduletoWorkerCode;
    }

    public void setChangeAssignScheduletoWorkerCode(String changeAssignScheduletoWorkerCode) {
        this.changeAssignScheduletoWorkerCode = changeAssignScheduletoWorkerCode;
    }
    
    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }
    
  

}
