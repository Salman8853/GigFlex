/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author abhishek
 */
@Entity
@Table(name = "assign_schedule_to_worker")
public class AssignScheduleToWorker extends CommonAttributes implements Serializable {
     private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "assign_schedule_to_worker_code", unique = true)
    private String assignScheduletoWorkerCode;
    
    @Column(name = "schedule_request_code")
    private String scheduleRequestCode;
     
    @Column(name = "schedule_request_assignment_code")
    private String scheduleRequestAssignmentCode;
    
    @Column(name = "worker_code")
    private String workerCode;
    
    @Column(name = "status")
    private String status;
    
    
    @PrePersist
    private void assignUUID() {
        if(this.getAssignScheduletoWorkerCode()==null || this.getAssignScheduletoWorkerCode().length()==0)
        {
            this.setAssignScheduletoWorkerCode(UUID.randomUUID().toString());
        }
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAssignScheduletoWorkerCode() {
        return assignScheduletoWorkerCode;
    }

    public void setAssignScheduletoWorkerCode(String assignScheduletoWorkerCode) {
        this.assignScheduletoWorkerCode = assignScheduletoWorkerCode;
    }

    public String getScheduleRequestCode() {
        return scheduleRequestCode;
    }

    public void setScheduleRequestCode(String scheduleRequestCode) {
        this.scheduleRequestCode = scheduleRequestCode;
    }

    public String getScheduleRequestAssignmentCode() {
        return scheduleRequestAssignmentCode;
    }

    public void setScheduleRequestAssignmentCode(String scheduleRequestAssignmentCode) {
        this.scheduleRequestAssignmentCode = scheduleRequestAssignmentCode;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
