/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

/**
 *
 * @author nirbhay.p
 */
public class ScheduleRequestresponse {
    private WorkerScheduleRequest workerScheduleRequest;
    private WorkerScheduleRequestAssignment workerScheduleRequestAssignment;

    public WorkerScheduleRequest getWorkerScheduleRequest() {
        return workerScheduleRequest;
    }

    public void setWorkerScheduleRequest(WorkerScheduleRequest workerScheduleRequest) {
        this.workerScheduleRequest = workerScheduleRequest;
    }

    public WorkerScheduleRequestAssignment getWorkerScheduleRequestAssignment() {
        return workerScheduleRequestAssignment;
    }

    public void setWorkerScheduleRequestAssignment(WorkerScheduleRequestAssignment workerScheduleRequestAssignment) {
        this.workerScheduleRequestAssignment = workerScheduleRequestAssignment;
    }
    
    
}
