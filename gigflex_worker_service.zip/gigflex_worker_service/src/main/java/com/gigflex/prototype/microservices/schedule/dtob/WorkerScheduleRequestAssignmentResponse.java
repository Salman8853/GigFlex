package com.gigflex.prototype.microservices.schedule.dtob;

import java.util.List;

public class WorkerScheduleRequestAssignmentResponse {
	
	
	public WorkerScheduleRequest workerScheduleRequest;
	
	public List<WorkerScheduleRequestAssignmentWithName> workerScheduleRequestAssignmentWithNameList;

	public WorkerScheduleRequest getWorkerScheduleRequest() {
		return workerScheduleRequest;
	}

	public void setWorkerScheduleRequest(WorkerScheduleRequest workerScheduleRequest) {
		this.workerScheduleRequest = workerScheduleRequest;
	}

	public List<WorkerScheduleRequestAssignmentWithName> getWorkerScheduleRequestAssignmentWithNameList() {
		return workerScheduleRequestAssignmentWithNameList;
	}

	public void setWorkerScheduleRequestAssignmentWithNameList(
			List<WorkerScheduleRequestAssignmentWithName> workerScheduleRequestAssignmentWithNameList) {
		this.workerScheduleRequestAssignmentWithNameList = workerScheduleRequestAssignmentWithNameList;
	}

	
	
	
//	public WorkerScheduleRequest workerScheduleRequest;
//	
//	public List<WorkerScheduleRequestAssignment> workerScheduleRequestAssignment;
//	
//	public WorkerScheduleRequest getWorkerScheduleRequest() {
//		return workerScheduleRequest;
//	}
//	public void setWorkerScheduleRequest(WorkerScheduleRequest workerScheduleRequest) {
//		this.workerScheduleRequest = workerScheduleRequest;
//	}
//	public List<WorkerScheduleRequestAssignment> getWorkerScheduleRequestAssignment() {
//		return workerScheduleRequestAssignment;
//	}
//	public void setWorkerScheduleRequestAssignment(
//			List<WorkerScheduleRequestAssignment> workerScheduleRequestAssignment) {
//		this.workerScheduleRequestAssignment = workerScheduleRequestAssignment;
//	}
	
	
	

}
