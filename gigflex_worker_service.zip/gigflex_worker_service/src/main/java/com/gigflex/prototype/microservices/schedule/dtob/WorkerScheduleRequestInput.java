package com.gigflex.prototype.microservices.schedule.dtob;

import java.util.Date;
import java.util.List;



/**
 * 
 * @author nirbhay.p
 *
 */

public class WorkerScheduleRequestInput {

    private String organizationCode;
    
    private String start ;
    
    private String end ;
    
    private String jobName;
    
    private String workingLocationCode;

    
    private List<WorkerScheduleRequestAssignmentInputList> assignmentList;
    
    public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

    public List<WorkerScheduleRequestAssignmentInputList> getAssignmentList() {
        return assignmentList;
    }

    public void setAssignmentList(List<WorkerScheduleRequestAssignmentInputList> assignmentList) {
        this.assignmentList = assignmentList;
    }
    
    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }
    

    public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public void setEnd(String end) {
        this.end = end;
    }

    
    

}