/**
 * 
 */
package com.gigflex.prototype.microservices.schedule.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.schedule.dtob.ChangeAssignScheduleToWorker;
import com.gigflex.prototype.microservices.schedule.repository.ChangeAssignScheduleRequestToWorkerRepository;
import com.gigflex.prototype.microservices.schedule.service.ChangeAssignScheduleRequestToWorkerService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.schedule.dtob.ChangeAssignScheduleToWorkerResponse;
import java.util.ArrayList;

/**
 * @author ajit.p
 *
 */
@Service
public class ChangeAssignScheduleRequestToWorkerServiceImpl implements ChangeAssignScheduleRequestToWorkerService {

	@Autowired
	ChangeAssignScheduleRequestToWorkerRepository changeAssignScheduleRequestToWorkerRepository;

	@Override
	public String getTradeWorkerListByOrganizationCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        List<ChangeAssignScheduleToWorkerResponse> caslst=new ArrayList<ChangeAssignScheduleToWorkerResponse>();
			if (organizationCode != null && organizationCode.trim().length() > 0) {
				List<Object> tradeWorkerListByWorkerCode  = changeAssignScheduleRequestToWorkerRepository
						.getTradeWorkerListByOrganizationCode(organizationCode);

				if (tradeWorkerListByWorkerCode != null && tradeWorkerListByWorkerCode.size() > 0) {
					for (int i = 0; i < tradeWorkerListByWorkerCode.size(); i++) {

						Object[] arr = (Object[]) tradeWorkerListByWorkerCode.get(i);
						if (arr.length >= 3) {
                                                    ChangeAssignScheduleToWorkerResponse cas=new ChangeAssignScheduleToWorkerResponse();
                                                    ChangeAssignScheduleToWorker cast = (ChangeAssignScheduleToWorker) arr[0];
                                                        if(cast!=null)
                                                        {
                                                            cas.setChangeAssignScheduleToWorker(cast);
                                                            cas.setChangedByWorkerName((String) arr[1]); 
                                                            cas.setChangeToWorkerName((String) arr[2]);
							caslst.add(cas);
                                                        }
						}
					}
					if (caslst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(caslst);	
                                            jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}

				}else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getTradeWorkerListByWorkerCode(String changeByWorkerCode) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			//JSONArray jsonArray = new JSONArray();
                        List<ChangeAssignScheduleToWorkerResponse> caslst=new ArrayList<ChangeAssignScheduleToWorkerResponse>();
			
			if (changeByWorkerCode != null && changeByWorkerCode.trim().length() > 0) {
				List<Object> tradeWorkerListByWorkerCode = changeAssignScheduleRequestToWorkerRepository
						.getTradeWorkerListByWorkerCodeEmployee(changeByWorkerCode);

				if (tradeWorkerListByWorkerCode != null && tradeWorkerListByWorkerCode.size() > 0) {
					for (int i = 0; i < tradeWorkerListByWorkerCode.size(); i++) {

						Object[] arr = (Object[]) tradeWorkerListByWorkerCode.get(i);
						if (arr.length >= 3) {
                                                    ChangeAssignScheduleToWorkerResponse cas=new ChangeAssignScheduleToWorkerResponse();
                                                    ChangeAssignScheduleToWorker cast = (ChangeAssignScheduleToWorker) arr[0];
                                                        if(cast!=null)
                                                        {
                                                            cas.setChangeAssignScheduleToWorker(cast);
                                                            cas.setChangedByWorkerName((String) arr[1]); 
                                                            cas.setChangeToWorkerName((String) arr[2]);
							caslst.add(cas);
                                                        }
						}
					}
					if (caslst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(caslst);	
                                            jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}

				}else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			}else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
