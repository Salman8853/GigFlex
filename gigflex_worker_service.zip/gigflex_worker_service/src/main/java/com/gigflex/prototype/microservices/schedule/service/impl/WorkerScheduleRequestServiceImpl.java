/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.certificationsmaster.repository.CertificationsMasterRepository;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationskill.repository.OrganizationSkillDao;
import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.AvailableWorkerBasedOnScheduleFilterRes;
import com.gigflex.prototype.microservices.schedule.dtob.ScheduleCalendarRequest;
import com.gigflex.prototype.microservices.schedule.dtob.ScheduleRequestresponse;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequest;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignment;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignmentInputList;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignmentResponse;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignmentWithName;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestInput;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleStatus;
import com.gigflex.prototype.microservices.schedule.repository.AssignScheduleRequestToWorkerRepository;
import com.gigflex.prototype.microservices.schedule.repository.WorkerScheduleRequestAssignmentRepository;
import com.gigflex.prototype.microservices.schedule.repository.WorkerScheduleRequestRepository;
import com.gigflex.prototype.microservices.schedule.service.WorkerScheduleRequestService;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateFormatConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.workinglocation.repository.WorkingLocationRepository;

/**
 *
 * @author nirbhay.p
 */
@Service
public class WorkerScheduleRequestServiceImpl implements WorkerScheduleRequestService {

	@Autowired
	WorkerScheduleRequestRepository workerScheduleRequestRepository;

	@Autowired
	WorkerScheduleRequestAssignmentRepository workerScheduleRequestAssignmentRepository;

	@Autowired
	AssignScheduleRequestToWorkerRepository assignScheduleRequestToWorkerRepository;

	@Autowired
	OrganizationRepository organizationRepository;
	@Autowired
	OrganizationSkillDao organizationSkillDao;
	@Autowired
	CertificationsMasterRepository certificationsMasterRepository;
        @Autowired
    TimeZoneRepository timeZoneDao;
        @Autowired
	WorkingLocationRepository workLocRep;

	@Override
	public String saveWorkerScheduleRequest(WorkerScheduleRequestInput schReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (schReq != null && schReq.getOrganizationCode() != null
					&& schReq.getOrganizationCode().trim().length() > 0 && schReq.getStart() != null
					&& schReq.getEnd() != null && schReq.getAssignmentList() != null
					&& schReq.getAssignmentList().size() > 0 && schReq.getJobName() != null
					&& schReq.getJobName().trim().length() > 0 && schReq.getWorkingLocationCode() != null && schReq.getWorkingLocationCode().trim().length() > 0) {
				WorkerScheduleRequest wsr = new WorkerScheduleRequest();
				Organization org = organizationRepository.findByOrganizationCode(schReq.getOrganizationCode().trim());
				if (org != null && org.getId() > 0) {
					WorkingLocation wl = workLocRep.findByWorkingLocationCode(schReq.getWorkingLocationCode().trim());
					if (wl != null && wl.getId() > 0) {
                                Date sdt = null;//new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(schReq.getStart().trim());
				Date edt = null;//new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse( schReq.getEnd().trim());
				TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
				sdt = GigflexDateUtil
						.convertStringDateToGMT(schReq.getStart().trim(), timezone,
								"yyyy-MM-dd HH:mm:ss");
				edt = GigflexDateUtil
						.convertStringDateToGMT(schReq.getEnd().trim(), timezone,
                                                        				"yyyy-MM-dd HH:mm:ss");
                    }
                    
                    if(sdt==null || edt==null)
                    {
                        jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Exception is occurred in date parsing.");
					return jsonobj.toString();
                    }
                                wsr.setEndDT(edt);
                                wsr.setIpAddress(ip);
                                wsr.setIsProcessed(Boolean.FALSE);
                                wsr.setIsPublished(Boolean.FALSE);
                                wsr.setOrganizationCode(schReq.getOrganizationCode().trim());
                                wsr.setJobName(schReq.getJobName().trim());
                                wsr.setWorkingLocationCode(schReq.getWorkingLocationCode().trim());
                                wsr.setStartDT(sdt);
                                WorkerScheduleRequest wsrResponse = workerScheduleRequestRepository.save(wsr);
                                JSONArray jarr = new JSONArray();
					String assignres = "";
					if (wsrResponse != null && wsrResponse.getId() > 0) {
						int i = 0;
						for (WorkerScheduleRequestAssignmentInputList ass : schReq.getAssignmentList()) {
							i++;
							if (ass != null && ass.getSkillCode() != null && ass.getSkillCode().trim().length() > 0
									&& ass.getExpDays() != null && ass.getExpDays() >= 0
									&& ass.getRequestedStaff() != null
									&& ass.getRequestedStaff() > 0) {

								boolean skillst = false;
								boolean certist = true;
								if (ass.getSkillCode() != null && ass.getSkillCode().trim().length() > 0) {
									ass.setSkillCode(ass.getSkillCode().trim());
									OrganizationSkill oskill = organizationSkillDao.getByOrgCodeAndSkillCode(
											schReq.getOrganizationCode().trim(), ass.getSkillCode());
									if (!(oskill != null && oskill.getId() > 0)) {
										skillst = false;
									} else {
										skillst = true;
									}
								}
								if (skillst) {

									if (ass.getCertificationCode() != null
											&& ass.getCertificationCode().trim().length() > 0) {
										ass.setCertificationCode(ass.getCertificationCode().trim());
										CertificationsMaster serti = certificationsMasterRepository
												.getCertificationsMasterByCertificationCode(ass.getCertificationCode());
										if (!(serti != null && serti.getId() > 0)) {
											certist = false;
										}
									}
									if (certist) {
										WorkerScheduleRequestAssignment wsrAss = new WorkerScheduleRequestAssignment();
										wsrAss.setCertificationCode(ass.getCertificationCode());
										wsrAss.setCostPerHours(ass.getCostPerHours());
										wsrAss.setIpAddress(ip);
										wsrAss.setRequestedStaff(ass.getRequestedStaff());
										wsrAss.setExpDays(ass.getExpDays());
										wsrAss.setLocationCode(ass.getLocationCode());
										wsrAss.setRequiredHours(ass.getRequiredHours());
										wsrAss.setScheduleRequestCode(wsrResponse.getScheduleRequestCode());
										wsrAss.setSkillCode(ass.getSkillCode());
										WorkerScheduleRequestAssignment wsrAssRes = workerScheduleRequestAssignmentRepository
												.save(wsrAss);
										if (wsrAssRes != null && wsrAssRes.getId() > 0) {
											ObjectMapper mapperObj = new ObjectMapper();
											String Detail = mapperObj.writeValueAsString(wsrAssRes);
											jarr.add(new JSONObject(Detail));
										}
									} else {
										assignres += " " + i + ". Given Certifications does not exist.";
									}
								} else {
									assignres += " " + i + ". Given Skill does not exist for this Organization.";
								}
							} else {
								assignres += " " + i
										+ ".Skill, Experience and Requested Staff should not be blank.";
							}
						}
						if(jarr.size()==0)
                                                {
                                                jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
                                                workerScheduleRequestRepository.deleteById(wsrResponse.getId());
                                                jsonobj.put("message", "Worker Schedule Request has been not added due to ("+ assignres +").");
                                                }
                                                else
                                                {
                                                jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						if (assignres.length() > 0) {
							jsonobj.put("message",
									"Worker Schedule Request has been added without some Schedule Assignment due to ("
											+ assignres + ")");
						} else {
							jsonobj.put("message", "Worker Schedule Request has been added successfully.");
						}
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsrResponse);
						JSONObject jobj = new JSONObject(Detail);
						jobj.put("assignmentList", jarr);
						jsonobj.put("data", jobj);
                                                }
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Worker Schedule Request has been not added.");
					}
					}else{
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Working Location Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Given organization does not exist.");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid input data.");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String addWorkerScheduleRequestAssignment(String scheduleCode, WorkerScheduleRequestAssignmentInputList ass,
			String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerScheduleRequest wsrResponse = workerScheduleRequestRepository.getByScheduleRequestCode(scheduleCode);
			if (wsrResponse != null && wsrResponse.getId() > 0) {
				if (ass != null && ass.getSkillCode() != null && ass.getSkillCode().trim().length() > 0
						&& ass.getExpDays() != null && ass.getExpDays() >= 0 
						 && ass.getRequestedStaff() != null
						&& ass.getRequestedStaff() > 0) {

					boolean skillst = false;
					boolean certist = true;
					if (ass.getSkillCode() != null && ass.getSkillCode().trim().length() > 0) {
						ass.setSkillCode(ass.getSkillCode().trim());
						OrganizationSkill oskill = organizationSkillDao
								.getByOrgCodeAndSkillCode(wsrResponse.getOrganizationCode().trim(), ass.getSkillCode());
						if (!(oskill != null && oskill.getId() > 0)) {
							skillst = false;
						} else {
							skillst = true;
						}
					}
					if (skillst) {

						if (ass.getCertificationCode() != null && ass.getCertificationCode().trim().length() > 0) {
							ass.setCertificationCode(ass.getCertificationCode().trim());
							CertificationsMaster serti = certificationsMasterRepository
									.getCertificationsMasterByCertificationCode(ass.getCertificationCode());
							if (!(serti != null && serti.getId() > 0)) {
								certist = false;
							}
						}
						if (certist) {
							WorkerScheduleRequestAssignment wsrAss = new WorkerScheduleRequestAssignment();
							wsrAss.setCertificationCode(ass.getCertificationCode());
							wsrAss.setCostPerHours(ass.getCostPerHours());
							wsrAss.setIpAddress(ip);
							wsrAss.setRequestedStaff(ass.getRequestedStaff());
							wsrAss.setExpDays(ass.getExpDays());
							wsrAss.setLocationCode(ass.getLocationCode());
							wsrAss.setRequiredHours(ass.getRequiredHours());
							wsrAss.setScheduleRequestCode(wsrResponse.getScheduleRequestCode());
							wsrAss.setSkillCode(ass.getSkillCode());
							WorkerScheduleRequestAssignment wsrAssRes = workerScheduleRequestAssignmentRepository
									.save(wsrAss);
							if (wsrAssRes != null && wsrAssRes.getId() > 0) {

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message",
										"Worker Schedule Request Assignment has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj.writeValueAsString(wsrAssRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message",
										"Worker Schedule Request Assignment has not been added successfully.");
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Given Certifications does not exist.");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Given Skill does not exist for this Organization.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Skill, Experience and Requested Staff should not be blank.");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Schedule Code does not exist.");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestByScheduleRequestCode(String scheduleRequestCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(scheduleRequestCode);
				WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
				List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
				WorkerScheduleRequest workerScheduleRequest = null;
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
							WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
							wsan.setWorkerScheduleRequestAssignment(ws);
							
							if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
								String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
							wsan.setSkillName(skillName);
							}
							if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
								String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
								wsan.setLocation(location);
							}
							if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

							CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
							if(cm != null && cm.getId() > 0){
							wsan.setCertificationName(cm.getCertificationName());
							}
							}
							workerScheduleRequest = (WorkerScheduleRequest) arr[0];
							wsan.setJobName(workerScheduleRequest.getJobName());
//						    wsan.setLocation((String) arr[2]);
							

							wsrlst.add(wsan);

						}

					}

					if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
						
						Date frmDt = null;
						Date toDt = null;
						
						WorkingLocation wl = workLocRep
								.findByWorkingLocationCode(workerScheduleRequest
										.getWorkingLocationCode().trim());

						if (wl != null && wl.getId() > 0
								&& wl.getTimeZone() != null
								&& wl.getTimeZone().trim().length() > 0) {
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
							Date fromDate = workerScheduleRequest.getStartDT();
							frmDt = GigflexDateUtil.getGMTtoLocationDate(
									fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
							Date toDate = workerScheduleRequest.getEndDT();
							toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
									timezone, "yyyy-MM-dd HH:mm:ss");
                    }
							workerScheduleRequest.setStartDT(frmDt);
							workerScheduleRequest.setEndDT(toDt);
						}
						
						wsr.setWorkerScheduleRequest(workerScheduleRequest);
						wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsr);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id != null && id > 0) {
				List<Object> objlst = workerScheduleRequestRepository.getWorkerScheduleRequestById(id);
				WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
				List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
				WorkerScheduleRequest workerScheduleRequest = null;
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
							WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
							wsan.setWorkerScheduleRequestAssignment(ws);
							
							if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
								String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
							wsan.setSkillName(skillName);
							}
							if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
								String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
								wsan.setLocation(location);
							}
							if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

							CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
							if(cm != null && cm.getId() > 0){
							wsan.setCertificationName(cm.getCertificationName());
							}
							}
							workerScheduleRequest = (WorkerScheduleRequest) arr[0];
							wsan.setJobName(workerScheduleRequest.getJobName());

							wsrlst.add(wsan);

						}
					}

					if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
						
						Date frmDt = null;
						Date toDt = null;
						
						WorkingLocation wl = workLocRep
								.findByWorkingLocationCode(workerScheduleRequest
										.getWorkingLocationCode().trim());

						if (wl != null && wl.getId() > 0
								&& wl.getTimeZone() != null
								&& wl.getTimeZone().trim().length() > 0) {
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
							Date fromDate = workerScheduleRequest.getStartDT();
							frmDt = GigflexDateUtil.getGMTtoLocationDate(
									fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
							Date toDate = workerScheduleRequest.getEndDT();
							toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
									timezone, "yyyy-MM-dd HH:mm:ss");
                    }
							workerScheduleRequest.setStartDT(frmDt);
							workerScheduleRequest.setEndDT(toDt);
						}
						
						wsr.setWorkerScheduleRequest(workerScheduleRequest);
						wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsr);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String getWorkerScheduleRequestByOrganizationCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null && organizationCode.trim().length() > 0) {
				List<WorkerScheduleRequest> wsList = workerScheduleRequestRepository.getListByOrganizationCode(organizationCode);
				if(wsList != null && wsList.size() > 0){
				List<WorkerScheduleRequestAssignmentResponse> wsrlist = new ArrayList<WorkerScheduleRequestAssignmentResponse>();

				for(WorkerScheduleRequest workerScheduleRequest : wsList){
					List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
					WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
					List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
//					WorkerScheduleRequest workerScheduleRequest = null;
					wsr.setWorkerScheduleRequest(workerScheduleRequest);
					
					if (objlst != null && objlst.size() > 0) {
						for (int i = 0; i < objlst.size(); i++) {
							Object[] arr = (Object[]) objlst.get(i);
							if (arr.length >= 2) {
								WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
								WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
								wsan.setWorkerScheduleRequestAssignment(ws);
								
								if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
									String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
								wsan.setSkillName(skillName);
								}
								if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
									String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
									wsan.setLocation(location);
								}
								if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

								CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
								if(cm != null && cm.getId() > 0){
								wsan.setCertificationName(cm.getCertificationName());
								}
								}
								workerScheduleRequest = (WorkerScheduleRequest) arr[0];
								wsan.setJobName(workerScheduleRequest.getJobName());
								wsrlst.add(wsan);

							}

						}

						if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
							
							Date frmDt = null;
							Date toDt = null;
							
							WorkingLocation wl = workLocRep
									.findByWorkingLocationCode(workerScheduleRequest
											.getWorkingLocationCode().trim());

							if (wl != null && wl.getId() > 0
									&& wl.getTimeZone() != null
									&& wl.getTimeZone().trim().length() > 0) {
								TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
								Date fromDate = workerScheduleRequest.getStartDT();
								frmDt = GigflexDateUtil.getGMTtoLocationDate(
										fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
								Date toDate = workerScheduleRequest.getEndDT();
								toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
										timezone, "yyyy-MM-dd HH:mm:ss");
                    }
								workerScheduleRequest.setStartDT(frmDt);
								workerScheduleRequest.setEndDT(toDt);
							}
							
							wsr.setWorkerScheduleRequest(workerScheduleRequest);
							wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
							
						} 
					} 
					if(wsr != null && wsr.getWorkerScheduleRequest() != null){
						wsrlist.add(wsr);
					}
				}
				
				if (wsrlist != null && wsrlist.size() > 0) {
					
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wsrlist);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String publishedWorkerScheduleRequest(Boolean pub, String scheduleCode, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
//			WorkerScheduleRequest wsr = new WorkerScheduleRequest();
			WorkerScheduleRequest wsrResponse = workerScheduleRequestRepository.getByScheduleRequestCode(scheduleCode);
		
			if (wsrResponse != null && wsrResponse.getId() > 0) {
				
				Date frmDt = null;
				Date toDt = null;
				
				WorkingLocation wl = workLocRep
						.findByWorkingLocationCode(wsrResponse
								.getWorkingLocationCode().trim());

				if (wl != null && wl.getId() > 0
						&& wl.getTimeZone() != null
						&& wl.getTimeZone().trim().length() > 0) {
					TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
					Date fromDate = wsrResponse.getStartDT();
					frmDt = GigflexDateUtil.getGMTtoLocationDate(
							fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
					Date toDate = wsrResponse.getEndDT();
					toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
							timezone, "yyyy-MM-dd HH:mm:ss");
                    }
					wsrResponse.setStartDT(frmDt);
					wsrResponse.setEndDT(toDt);
				}
				
				wsrResponse.setIsPublished(pub);
				wsrResponse.setIpAddress(ip);
				WorkerScheduleRequest wsrRes = workerScheduleRequestRepository.save(wsrResponse);
				if (wsrRes != null && wsrRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Worker Schedule has been published");
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wsrRes);
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed.");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Schedule Code does not exist.");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getScheduleCalendar(ScheduleCalendarRequest calreq) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = workerScheduleRequestRepository.getScheduleCalendar(calreq.getOrganizationCode(),
					calreq.getStartDate(), calreq.getEndDate());
			if (objlst != null && objlst.size() > 0) {
				List<ScheduleRequestresponse> arrresss = new ArrayList<ScheduleRequestresponse>();
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					ScheduleRequestresponse resss = new ScheduleRequestresponse();
					resss.setWorkerScheduleRequest((WorkerScheduleRequest) arr[0]);
					resss.setWorkerScheduleRequestAssignment((WorkerScheduleRequestAssignment) arr[1]);
					arrresss.add(resss);
				}
				if (arrresss != null && arrresss.size() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Worker Schedule has been published");
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(arrresss);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record does not exist.");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record does not exist.");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestByScheduleRequestCode(String scheduleRequestCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(scheduleRequestCode,
						pageableRequest);
				WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
				List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
				WorkerScheduleRequest workerScheduleRequest = null;
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
							WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
							wsan.setWorkerScheduleRequestAssignment(ws);
							
							if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
								String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
							wsan.setSkillName(skillName);
							}
							if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
								String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
								wsan.setLocation(location);
							}
							if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

							CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
							if(cm != null && cm.getId() > 0){
							wsan.setCertificationName(cm.getCertificationName());
							}
							}
							workerScheduleRequest = (WorkerScheduleRequest) arr[0];
							wsan.setJobName(workerScheduleRequest.getJobName());

							wsrlst.add(wsan);

						}

					}

					if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
						
						Date frmDt = null;
						Date toDt = null;
						
						WorkingLocation wl = workLocRep
								.findByWorkingLocationCode(workerScheduleRequest
										.getWorkingLocationCode().trim());

						if (wl != null && wl.getId() > 0
								&& wl.getTimeZone() != null
								&& wl.getTimeZone().trim().length() > 0) {
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
							Date fromDate = workerScheduleRequest.getStartDT();
							frmDt = GigflexDateUtil.getGMTtoLocationDate(
									fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
							Date toDate = workerScheduleRequest.getEndDT();
							toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
									timezone, "yyyy-MM-dd HH:mm:ss");
                    }
							workerScheduleRequest.setStartDT(frmDt);
							workerScheduleRequest.setEndDT(toDt);
						}
						
						wsr.setWorkerScheduleRequest(workerScheduleRequest);
						wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsr);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestById(Long id, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (id != null && id > 0) {
				List<Object> objlst = workerScheduleRequestRepository.getWorkerScheduleRequestById(id, pageableRequest);
				WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
				List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
				WorkerScheduleRequest workerScheduleRequest = null;
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
							WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
							wsan.setWorkerScheduleRequestAssignment(ws);
							
							if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
								String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
							wsan.setSkillName(skillName);
							}
							if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
								String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
								wsan.setLocation(location);
							}
							if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

							CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
							if(cm != null && cm.getId() > 0){
							wsan.setCertificationName(cm.getCertificationName());
							}
							}
							workerScheduleRequest = (WorkerScheduleRequest) arr[0];
							wsan.setJobName(workerScheduleRequest.getJobName());

							wsrlst.add(wsan);

						}

					}

					if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
						
						Date frmDt = null;
						Date toDt = null;
						
						WorkingLocation wl = workLocRep
								.findByWorkingLocationCode(workerScheduleRequest
										.getWorkingLocationCode().trim());

						if (wl != null && wl.getId() > 0
								&& wl.getTimeZone() != null
								&& wl.getTimeZone().trim().length() > 0) {
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
							Date fromDate = workerScheduleRequest.getStartDT();
							frmDt = GigflexDateUtil.getGMTtoLocationDate(
									fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
							Date toDate = workerScheduleRequest.getEndDT();
							toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
									timezone, "yyyy-MM-dd HH:mm:ss");
                    }
							workerScheduleRequest.setStartDT(frmDt);
							workerScheduleRequest.setEndDT(toDt);
						}
						
						wsr.setWorkerScheduleRequest(workerScheduleRequest);
						wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wsr);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerScheduleRequestByOrganizationCode(String organizationCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			if (organizationCode != null && organizationCode.trim().length() > 0) {
				List<WorkerScheduleRequest> wsList = workerScheduleRequestRepository.getListByOrganizationCodeByPage(organizationCode,pageableRequest);
				if(wsList != null && wsList.size() > 0){
				List<WorkerScheduleRequestAssignmentResponse> wsrlist = new ArrayList<WorkerScheduleRequestAssignmentResponse>();

				for(WorkerScheduleRequest workerScheduleRequest : wsList){
					List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(workerScheduleRequest.getScheduleRequestCode());
					WorkerScheduleRequestAssignmentResponse wsr = new WorkerScheduleRequestAssignmentResponse();
					List<WorkerScheduleRequestAssignmentWithName> wsrlst = new ArrayList<WorkerScheduleRequestAssignmentWithName>();
//					WorkerScheduleRequest workerScheduleRequest = null;
					wsr.setWorkerScheduleRequest(workerScheduleRequest);
					
					if (objlst != null && objlst.size() > 0) {
						for (int i = 0; i < objlst.size(); i++) {
							Object[] arr = (Object[]) objlst.get(i);
							if (arr.length >= 2) {
								WorkerScheduleRequestAssignmentWithName wsan = new WorkerScheduleRequestAssignmentWithName();
								WorkerScheduleRequestAssignment ws = (WorkerScheduleRequestAssignment) arr[1];
								wsan.setWorkerScheduleRequestAssignment(ws);
								
								if(ws.getSkillCode() != null && ws.getSkillCode().length() > 0){
									String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
								wsan.setSkillName(skillName);
								}
								if(ws.getLocationCode() != null && ws.getLocationCode().length() > 0){
									String location = workerScheduleRequestRepository.getLocationByCode(ws.getLocationCode());
									wsan.setLocation(location);
								}
								if(ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0){

								CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
								if(cm != null && cm.getId() > 0){
								wsan.setCertificationName(cm.getCertificationName());
								}
								}
								workerScheduleRequest = (WorkerScheduleRequest) arr[0];
								wsan.setJobName(workerScheduleRequest.getJobName());
								wsrlst.add(wsan);

							}

						}

						if (workerScheduleRequest != null && workerScheduleRequest.getId() > 0) {
							
							Date frmDt = null;
							Date toDt = null;
							
							WorkingLocation wl = workLocRep
									.findByWorkingLocationCode(workerScheduleRequest
											.getWorkingLocationCode().trim());

							if (wl != null && wl.getId() > 0
									&& wl.getTimeZone() != null
									&& wl.getTimeZone().trim().length() > 0) {
								TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
								Date fromDate = workerScheduleRequest.getStartDT();
								frmDt = GigflexDateUtil.getGMTtoLocationDate(
										fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
								Date toDate = workerScheduleRequest.getEndDT();
								toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
										timezone, "yyyy-MM-dd HH:mm:ss");
                    }
								workerScheduleRequest.setStartDT(frmDt);
								workerScheduleRequest.setEndDT(toDt);
							}
							
							wsr.setWorkerScheduleRequest(workerScheduleRequest);
							wsr.setWorkerScheduleRequestAssignmentWithNameList(wsrlst);
							
						} 
					} 
					if(wsr != null && wsr.getWorkerScheduleRequest() != null){
						wsrlist.add(wsr);
					}
				}
				
				if (wsrlist != null && wsrlist.size() > 0) {
					
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wsrlist);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getTargetAchieved(String scheduleRequestCode) {
		String res = "";
		String status = null;
		double targetInPercent = 0.0;
		try {
			JSONObject jsonobj = new JSONObject();
			AssignScheduleToWorker assignScheduleToWorker = assignScheduleRequestToWorkerRepository
					.getWorkerScheduleRequestCode(scheduleRequestCode);
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {
					status = GigflexConstants.assignedScheduleAcceptedStatus;
					Long requestedStaffCount = workerScheduleRequestRepository
							.getRequestedStaffCount(scheduleRequestCode);
					Long scheduleAcceptedStatusCount = workerScheduleRequestRepository
							.getScheduleAcceptedStatusCount(scheduleRequestCode, status);
					if (requestedStaffCount > 0) {
						if (scheduleAcceptedStatusCount > 0) {
							targetInPercent = (scheduleAcceptedStatusCount * 100) / requestedStaffCount;

							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Target Achieved is :" + targetInPercent + " %");
							jsonobj.put("achievedTarget", targetInPercent);
						} else {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Target Achieved is :" + targetInPercent + " %");
							jsonobj.put("achievedTarget", targetInPercent);
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Staff Count Not Found.");
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found.");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
			res = derr.toString();
		}
		return res;

	}

	@Override
	public String getAvailableWorkerBasedOnScheduleFilterByScheduleRequestCode(String scheduleRequestCode) {
		String res = "";
		try {

			JSONObject jsonobj = new JSONObject();
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				List<Object> objlst = workerScheduleRequestRepository.findByScheduleRequestCode(scheduleRequestCode);
				WorkerScheduleRequest wsr = null;

				if (objlst != null && objlst.size() > 0) {
					List<AvailableWorkerBasedOnScheduleFilterRes> asslst = new ArrayList<AvailableWorkerBasedOnScheduleFilterRes>();
					for (int i = 0; i < objlst.size(); i++) {

						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							AvailableWorkerBasedOnScheduleFilterRes aeb = new AvailableWorkerBasedOnScheduleFilterRes();
							wsr = (WorkerScheduleRequest) arr[0];
							WorkerScheduleRequestAssignment wsra = (WorkerScheduleRequestAssignment) arr[1];
							if (wsr != null && wsr.getId() > 0 && wsr.getStartDT() != null && wsr.getEndDT() != null
									&& wsra != null && wsra.getId() > 0) {

								List<String> busyWorkerLst = new ArrayList<String>();
								List<Object> busyObj = assignScheduleRequestToWorkerRepository
										.getBusyWorkerLisInOtherScheduletInStartEnd(wsr.getStartDT(), wsr.getEndDT(),wsra.getScheduleRequestAssignmentCode());
								if (busyObj != null && busyObj.size() > 0) {
									for (Object objectWr : busyObj) {
										if (objectWr != null && objectWr.toString().length() > 0) {
											busyWorkerLst.add((String) objectWr);
										}
									}
								}
								boolean stNot = true;
								Long experienceInDays = 0L;
								String skillcode = null;
								String certificatecode = null;
								String orgCode = wsr.getOrganizationCode();

								List<String> newWorkerLst = new ArrayList<String>();
								List<Worker> wrlstRes = null;
								experienceInDays = wsra.getExpDays();
								skillcode = wsra.getSkillCode();
								certificatecode = wsra.getCertificationCode();
								if (skillcode != null && skillcode.trim().length() > 0) {
									if (busyWorkerLst != null && busyWorkerLst.size() > 0) {
										List<Worker> wrlst = workerScheduleRequestRepository
												.getSameSkillAvailableWorkerListByOrganizationCode(experienceInDays,
														skillcode, orgCode, busyWorkerLst);
										wrlstRes = wrlst;
										for (Worker wr : wrlst) {
											newWorkerLst.add(wr.getWorkerCode());
										}
										stNot = false;
									} else {
										List<Worker> wrlst = workerScheduleRequestRepository
												.getSameSkillAvailableWorkerListByOrganizationCodewithIN(
														experienceInDays, skillcode, orgCode);
										wrlstRes = wrlst;
										for (Worker wr : wrlst) {
											newWorkerLst.add(wr.getWorkerCode());
										}
										stNot = false;
									}
								}
								if (certificatecode != null && certificatecode.trim().length() > 0) {
									if (stNot == false && wrlstRes != null && wrlstRes.size() > 0) {
										List<Worker> wrlst = assignScheduleRequestToWorkerRepository
												.getSameCertificateAvailableWorkerListWithIN(certificatecode, orgCode,
														newWorkerLst);
										wrlstRes = wrlst;
										newWorkerLst = new ArrayList<String>();
										for (Worker wr : wrlst) {
											newWorkerLst.add(wr.getWorkerCode());
										}
									} else {
										if (stNot) {
											List<Worker> wrlst = assignScheduleRequestToWorkerRepository
													.getSameCertificateAvailableWorkerListWithNotIN(certificatecode,
															wsr.getOrganizationCode(), busyWorkerLst);
											wrlstRes = wrlst;
											newWorkerLst = new ArrayList<String>();
											for (Worker wr : wrlst) {
												newWorkerLst.add(wr.getWorkerCode());
											}
											stNot = false;
										}
									}

								}

								// if (exp_year != null && exp_month != null && exp_days != null && (exp_year >
								// 0 || exp_month > 0 || exp_days > 0)) {
								// if (stNot == false && wrlstRes != null && wrlstRes.size() > 0) {
								// List<Worker> wrlst
								// =assignScheduleRequestToWorkerRepository.getSameExperienceAvailableWorkerListWithIN(exp_year,
								// exp_month, exp_days, wsr.getOrganizationCode(),newWorkerLst);
								// wrlstRes = wrlst;
								// newWorkerLst = new ArrayList<String>();
								// for (Worker wr : wrlst) {
								// newWorkerLst.add(wr.getWorkerCode());
								// }
								// } else {
								// if (stNot) {
								// List<Worker> wrlst
								// =assignScheduleRequestToWorkerRepository.getSameExperienceAvailableWorkerListWithNotIN(exp_year,
								// exp_month, exp_days, wsr.getOrganizationCode(),busyWorkerLst);
								// wrlstRes = wrlst;
								// newWorkerLst = new ArrayList<String>();
								// for (Worker wr : wrlst) {
								// newWorkerLst.add(wr.getWorkerCode());
								// }
								// stNot = false;
								// }
								// }
								//
								// }
								// List<Worker> wrlst =
								// assignScheduleRequestToWorkerRepository.getSmaeSkillAvailableWorkerList(assignScheduletoWorkerCode,busyWorkerLst);
								List<WorkerScheduleStatus> wrlstResWithstatus =new ArrayList<WorkerScheduleStatus>();
                                                                if (wrlstRes != null && wrlstRes.size() > 0) {
									
                                                                        aeb.setScheduleRequestAssignmentCode(wsra.getScheduleRequestAssignmentCode());
                                                                        for(Worker wr:wrlstRes)
                                                                        {
                                                                            WorkerScheduleStatus wss=new WorkerScheduleStatus();
                                                                            wss.setWorker(wr);
                                                                            AssignScheduleToWorker astw=assignScheduleRequestToWorkerRepository.getAssignedScheduledToWorkerByWorkerScheduleRequestAssignment(scheduleRequestCode, wsra.getScheduleRequestAssignmentCode(), wr.getWorkerCode());
                                                                            if(astw!=null && astw.getId()>0 && astw.getStatus()!=null && astw.getStatus().trim().length()>0)
                                                                            {
                                                                               wss.setAssignWorkerStatus(astw.getStatus());
                                                                            }
                                                                            wrlstResWithstatus.add(wss);
                                                                        }
									aeb.setWorkerCount(wrlstRes.size());
									aeb.setWorkerListWithStatus(wrlstResWithstatus);
									asslst.add(aeb);

								} else {
									aeb.setScheduleRequestAssignmentCode(wsra.getScheduleRequestAssignmentCode());
									aeb.setWorkerCount(wrlstRes.size());
									aeb.setWorkerListWithStatus(wrlstResWithstatus);
									asslst.add(aeb);

								}

							}

						}

					}
					if (asslst != null && asslst.size() > 0) {
						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Same skill available worker list");
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(asslst);
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record Not Found");
					}
					res = jsonobj.toString();

				} else {
					GigflexResponse derr = new GigflexResponse(500, new Date(), "Record not found.");
					res = derr.toString();
				}

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid.");
				res = derr.toString();
			}

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getPercentageOfScheduleFulfilment(String scheduleRequestCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				AssignScheduleToWorker assignScheduleToWorker = assignScheduleRequestToWorkerRepository
						.getWorkerScheduleRequestCode(scheduleRequestCode);
				if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {

					List<WorkerScheduleRequestAssignment> wsra = workerScheduleRequestRepository
							.getScheduleAssgnByScheduleRequestCode(scheduleRequestCode);

					Double scheduleFulfillment = 0.0;
					for (WorkerScheduleRequestAssignment wsra1 : wsra) {

						Integer staff = wsra1.getRequestedStaff();

						Long reqStaff = workerScheduleRequestRepository
								.getCountOfRequestedStaff(wsra1.getScheduleRequestAssignmentCode());
						if (staff > 0) {
							if (reqStaff > 0) {

								scheduleFulfillment = (double) ((reqStaff * 100) / staff);

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Schedule Fullfilled :" + scheduleFulfillment + " %");
								jsonobj.put("scheduleFulfillment", scheduleFulfillment);

							} else {
								jsonobj.put("responsecode", 404);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Schedule Fullfilled :" + scheduleFulfillment + " %");
								jsonobj.put("scheduleFulfillment", scheduleFulfillment);
							}

						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Staff Not Found.");

						}
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found.");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWeeklyReportByDates(String scheduleRequestAssignmentCode, String status, String strtDate, String enDate) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (scheduleRequestAssignmentCode != null && scheduleRequestAssignmentCode.trim().length() > 0 && status != null && status.trim().length() > 0 ) {
				WorkerScheduleRequestAssignment assignScheduleToWorker = assignScheduleRequestToWorkerRepository
						.getWorkerScheduleRequestAssignmentCode(scheduleRequestAssignmentCode);
				if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {
					if (status.equalsIgnoreCase(GigflexConstants.assignedScheduleAcceptedStatus)) {
						Date startDate = null;
						Date endDate = null;
						try {
							startDate = GigflexDateUtil.convertStringToDate(strtDate,GigflexDateFormatConstants.DD_MM_YYYY_HH_MM_SS);
							endDate = GigflexDateUtil.convertStringToDate(enDate,GigflexDateFormatConstants.DD_MM_YYYY_HH_MM_SS);
						} catch (Exception ex) {
							ex.printStackTrace();
							GigflexResponse derr = new GigflexResponse(400,
									new Date(),
									"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
							return derr.toString();
						}
						WorkingLocation wl = null;
						if(assignScheduleToWorker.getLocationCode() != null && assignScheduleToWorker.getLocationCode().trim().length()>0){
						
						 wl = workLocRep
								.findByWorkingLocationCode(assignScheduleToWorker
										.getLocationCode().trim());
						}
						if (wl != null && wl.getId() > 0) {

                                                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
							startDate = GigflexDateUtil
									.convertStringDateToGMT(strtDate.trim(), timezone,
											"yyyy-MM-dd HH:mm:ss");
							endDate = GigflexDateUtil
									.convertStringDateToGMT(enDate.trim(), timezone,
											"yyyy-MM-dd HH:mm:ss");
                    }

					Double scheduleFulfillmentWeekly = 0.0;

					Long reqStaffWeekly = workerScheduleRequestRepository
							.getScheduleAcceptedForDateRange(scheduleRequestAssignmentCode, status, startDate, endDate);

					Long staffWeekly = workerScheduleRequestRepository.getTotalStaffByDateRange(startDate, endDate);
							if (staffWeekly > 0) {
								if (reqStaffWeekly > 0) {

									scheduleFulfillmentWeekly = (double) ((reqStaffWeekly * 100) / staffWeekly);
									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message",
											"Schedule Fullfilled :"
													+ scheduleFulfillmentWeekly
													+ " %");
									jsonobj.put("scheduleFulfillment",
											scheduleFulfillmentWeekly);

								} else {
									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message",
											"Schedule Fullfilled :"
													+ scheduleFulfillmentWeekly
													+ " %");
									jsonobj.put("scheduleFulfillment",
											scheduleFulfillmentWeekly);
								}

							} else {
								jsonobj.put("responsecode", 404);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record Not Found.");

							}
						} else {
							jsonobj.put("message",
									"Working Location Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Status Not Matched.");

					}

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found.");

				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

//	@Override
//	public String getWorkerScheduleRequestByScheduleRequestCode(
//			String scheduleRequestCode) {
//		String res = "";
//        try {
//            JSONObject jsonobj = new JSONObject();
//            WorkerScheduleRequest wsrReslst = workerScheduleRequestRepository.getByScheduleRequestCode(scheduleRequestCode);
//            if ( wsrReslst!= null ) {
//                ObjectMapper mapperObj = new ObjectMapper();
//                String Detail = mapperObj.writeValueAsString(wsrReslst);
//                jsonobj.put("responsecode", 200);
//                jsonobj.put("timestamp", new Date());
//                jsonobj.put("message", "Success");
//                jsonobj.put("data", new JSONObject(Detail));
//                
//            }
//            else
//            {
//            jsonobj.put("responsecode", 404);
//            jsonobj.put("timestamp", new Date());
//            jsonobj.put("message", "Record Not Found");
//            }
//            res = jsonobj.toString();
//        } catch (JSONException | JsonProcessingException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
//	}

//	@Override
//	public String getWorkerScheduleRequestById(Long id) {
//		String res = "";
//        try {
//            JSONObject jsonobj = new JSONObject();
//            WorkerScheduleRequest wsrReslst = workerScheduleRequestRepository.getWorkerScheduleRequestById(id);
//            if ( wsrReslst!= null ) {
//                ObjectMapper mapperObj = new ObjectMapper();
//                String Detail = mapperObj.writeValueAsString(wsrReslst);
//                jsonobj.put("responsecode", 200);
//                jsonobj.put("timestamp", new Date());
//                jsonobj.put("message", "Success");
//                jsonobj.put("data", new JSONObject(Detail));
//                
//            }
//            else
//            {
//            jsonobj.put("responsecode", 404);
//            jsonobj.put("timestamp", new Date());
//            jsonobj.put("message", "Record Not Found");
//            }
//            res = jsonobj.toString();
//        } catch (JSONException | JsonProcessingException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
//	}

//	@Override
//	public String getWorkerScheduleRequestByOrganizationCode(
//			String organizationCode) {
//		String res = "";
//        try {
//            JSONObject jsonobj = new JSONObject();
//            WorkerScheduleRequest wsrReslst = workerScheduleRequestRepository.getWorkerScheduleRequestByOrgCode(organizationCode);
//            if ( wsrReslst!= null ) {
//                ObjectMapper mapperObj = new ObjectMapper();
//                String Detail = mapperObj.writeValueAsString(wsrReslst);
//                jsonobj.put("responsecode", 200);
//                jsonobj.put("timestamp", new Date());
//                jsonobj.put("message", "Success");
//                jsonobj.put("data", new JSONObject(Detail));
//                
//            }
//            else
//            {
//            jsonobj.put("responsecode", 404);
//            jsonobj.put("timestamp", new Date());
//            jsonobj.put("message", "Record Not Found");
//            }
//            res = jsonobj.toString();
//        } catch (JSONException | JsonProcessingException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
//	}

}
