package com.gigflex.prototype.microservices.shift.dtob;

import java.util.Date;

/**
 * 
 * @author ajit.p
 *
 */
public class ShiftRequest {
	
	private String organizationCode;
	
	private String workingLocationCode;

	private String shiftName;
	
	private Date startTime;
	
	private Date endTime;

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	

	public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	
}
