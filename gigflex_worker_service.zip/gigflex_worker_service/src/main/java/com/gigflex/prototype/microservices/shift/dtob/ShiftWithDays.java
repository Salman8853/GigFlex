/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.shift.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author nirbhay.p
 */
@Entity
@Table(name = "shift_days")
public class ShiftWithDays extends CommonAttributes implements Serializable {
    private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
    
        @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "shift_days_code")
	private String shiftDaysCode;
        
        @Column(name = "day_code", nullable = false)
	private String daysCode;
        
        @Column(name = "shift_code", nullable = false)
	private String shiftCode;

        @PrePersist
    private void assignUUID() {
        if(this.getShiftDaysCode()==null || this.getShiftDaysCode().length()==0)
        {
            this.setShiftDaysCode(UUID.randomUUID().toString());
        }
    }
        
    public String getShiftDaysCode() {
        return shiftDaysCode;
    }

    public void setShiftDaysCode(String shiftDaysCode) {
        this.shiftDaysCode = shiftDaysCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDaysCode() {
        return daysCode;
    }

    public void setDaysCode(String daysCode) {
        this.daysCode = daysCode;
    }

    public String getShiftCode() {
        return shiftCode;
    }

    public void setShiftCode(String shiftCode) {
        this.shiftCode = shiftCode;
    }
        
        
}
