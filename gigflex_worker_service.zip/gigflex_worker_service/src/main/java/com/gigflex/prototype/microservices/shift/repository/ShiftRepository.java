/**
 * 
 */
package com.gigflex.prototype.microservices.shift.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gigflex.prototype.microservices.shift.dtob.Shift;

/**
 * @author ajit.p
 *
 */
@Repository
public interface ShiftRepository extends JpaRepository<Shift, Long> {

	
	@Query("SELECT s FROM Shift s WHERE s.isDeleted != TRUE AND s.shiftName = :shiftName AND s.organizationCode = :organizationCode AND s.workingLocationCode = :workingLocationCode AND s.id != :id")
    public Shift findShiftByOrganizationCodeWithId(@Param("shiftName") String shiftName,@Param("organizationCode") String organizationCode,@Param("workingLocationCode") String workingLocationCode,@Param("id") Long id);
	
	
	@Query("SELECT s FROM Shift s WHERE s.id=:id AND s.isDeleted != TRUE")
	public Shift getShiftById(@Param("id") Long id);
	
//	@Query("SELECT s FROM Shift s WHERE s.isDeleted != TRUE AND s.organizationCode = :organizationCode")
//    public List<Shift> getShiftByOrganizationCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT s FROM Shift s WHERE s.isDeleted != TRUE AND s.shiftName = :shiftName AND s.organizationCode = :organizationCode AND s.workingLocationCode = :workingLocationCode")
    public Shift findShiftByOrganizationCode(@Param("shiftName") String shiftName,@Param("organizationCode") String organizationCode,@Param("workingLocationCode") String workingLocationCode);
	
//	@Query("SELECT s FROM Shift s,Organization b,DaysMaster c,WorkingLocation d WHERE s.isDeleted != TRUE AND s.shiftName = :shiftName AND b.organizationCode = :organizationCode AND c.daysCode = :daysCode AND d.workingLocationCode = :workingLocationCode")
//    public Shift findShiftByOrganizationCode(@Param("shiftName") String shiftName,@Param("organizationCode") String organizationCode,@Param("daysCode") String daysCode,@Param("workingLocationCode") String workingLocationCode);
	
//	@Query("SELECT s FROM Shift s,Organization b, DaysMaster c, WorkingLocation d WHERE s.isDeleted != TRUE AND s.organizationCode=b.organizationCode AND s.daysCode=c.daysCode AND s.workingLocationCode=d.workingLocationCode AND s.shiftName = :shiftName AND s.organizationCode = :organizationCode AND s.daysCode = :daysCode AND s.workingLocationCode = :workingLocationCode")
//    public Shift findShiftByOrganizationCode(@Param("shiftName") String shiftName,@Param("organizationCode") String organizationCode,@Param("daysCode") String daysCode,@Param("workingLocationCode") String workingLocationCode);
	
	
//	@Query("SELECT a,b.organizationName,c.daysName,d.location FROM Shift a , Organization b , DaysMaster c , WorkingLocation d WHERE a.isDeleted != TRUE AND a.organizationCode=b.organizationCode AND a.daysCode=c.daysCode AND a.workingLocationCode=d.workingLocationCode")
//	public List<Object> getAllOrgWorkerShiftWithNames();
	
//	@Query("SELECT a,b.organizationName,c.daysName,d.location FROM Shift a , Organization b , DaysMaster c , WorkingLocation d WHERE a.isDeleted != TRUE AND a.organizationCode=b.organizationCode AND a.daysCode=c.daysCode AND a.workingLocationCode=d.workingLocationCode AND a.organizationCode = :organizationCode")
//	public List<Object> getAllOrgWorkerShiftWithNames(@Param("organizationCode") String organizationCode);


//	@Query("SELECT s.shiftName FROM Shift s WHERE  s.organizationCode = :organizationCode")
//    public Shift findShiftByOrganizationCode(@Param("organizationCode") String organizationCode);

    
}