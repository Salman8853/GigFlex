package com.gigflex.prototype.microservices.shift.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.shift.dtob.Shift;
import com.gigflex.prototype.microservices.shift.repository.ShiftRepository;

@Service
public class KafkaShiftService {
	
	@Autowired
	private ShiftRepository shiftDao;
	
	 private static final Logger LOG = LoggerFactory.getLogger(KafkaShiftService.class);

		@KafkaListener(topics = "AddShiftFromOrganization")
	    public void listen(@Payload String message) {
			ObjectMapper objectMapper = new ObjectMapper();
			LOG.info("received message='{}'", message);
			try {
				Shift shift = objectMapper.readValue(message, Shift.class);
				
				Shift shiftRes =  new Shift();//shiftDao.findShiftByOrganizationCode(shift.getShiftName(),shift.getOrganizationCode(),shift.getWorkingLocationCode());

			
					shiftRes.setOrganizationCode(shift.getOrganizationCode());
					shiftRes.setShiftName(shift.getShiftName());
					shiftRes.setStartTime(shift.getStartTime());
					shiftRes.setEndTime(shift.getEndTime());
					shiftRes.setIpAddress(shift.getIpAddress());
					shiftRes.setWorkingLocationCode(shift.getWorkingLocationCode());
					shiftRes.setIsDeleted(shift.getIsDeleted());
				
				shiftDao.save(shiftRes);
				
			} catch (JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}

}
