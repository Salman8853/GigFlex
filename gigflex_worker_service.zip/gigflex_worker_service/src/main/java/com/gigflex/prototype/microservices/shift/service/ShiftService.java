/**
 * 
 */
package com.gigflex.prototype.microservices.shift.service;

import com.gigflex.prototype.microservices.shift.dtob.ShiftRequest;

/**
 * @author ajit.p
 *
 */
public interface ShiftService {
	public String createShift(ShiftRequest shiftRequest, String ip);

	public String updateShiftById(String shiftCode, ShiftRequest shiftRequest , String ip);
	
    public String getAllOrgWorkerShift();

}
