package com.gigflex.prototype.microservices.shift.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.shift.dtob.Shift;
import com.gigflex.prototype.microservices.shift.repository.ShiftRepository;

@Service
public class UpdateShiftFromOrganizationKafkaService {

	@Autowired
	private ShiftRepository shiftDao;

	private static final Logger LOG = LoggerFactory
			.getLogger(UpdateShiftFromOrganizationKafkaService.class);

	@KafkaListener(topics = "UpdateShiftFromOrganization")
	public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			Shift shift = objectMapper.readValue(message,
					Shift.class);

			LOG.info("received message='{}'", shift.getOrganizationCode());
			LOG.info("received message='{}'", shift.getShiftCode());
			LOG.info("received message='{}'", shift.getShiftName());
			LOG.info("received message='{}'", shift.getWorkingLocationCode());
			LOG.info("received message='{}'", shift.getIsActive());
			LOG.info("received message='{}'", shift.getEndTime());
			LOG.info("received message='{}'", shift.getStartTime());

			Shift shiftRes = shiftDao.findShiftByOrganizationCode(shift.getShiftName(),shift.getOrganizationCode(),shift.getWorkingLocationCode());

			if (shiftRes != null && shiftRes.getId() > 0) {
				shiftRes.setOrganizationCode(shift.getOrganizationCode());
				shiftRes.setShiftName(shift.getShiftName());
				shiftRes.setStartTime(shift.getStartTime());
				shiftRes.setEndTime(shift.getEndTime());
				shiftRes.setIpAddress(shift.getIpAddress());
				shiftRes.setWorkingLocationCode(shift.getWorkingLocationCode());
				shiftRes.setIsDeleted(shift.getIsDeleted());
				shiftDao.save(shiftRes);

			}

		} catch (JsonParseException e) {
			LOG.error(
					"In UpdateShiftFromOrganizationKafkaService >>>>",
					e);
		} catch (JsonMappingException e) {
			LOG.error(
					"In UpdateShiftFromOrganizationKafkaService >>>>",
					e);
		} catch (IOException e) {
			LOG.error(
					"In UpdateShiftFromOrganizationKafkaService >>>>",
					e);
		} catch (Exception e) {
			LOG.error(
					"In UpdateShiftFromOrganizationKafkaService >>>>",
					e);
		}
	}

}
