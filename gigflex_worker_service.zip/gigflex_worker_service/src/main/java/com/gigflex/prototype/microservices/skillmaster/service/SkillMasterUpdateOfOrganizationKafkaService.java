package com.gigflex.prototype.microservices.skillmaster.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.skillmaster.repository.SkillMasterDao;

@Service
public class SkillMasterUpdateOfOrganizationKafkaService {

	@Autowired
	private SkillMasterDao skillMasterDao;

	private static final Logger LOG = LoggerFactory
			.getLogger(SkillMasterUpdateOfOrganizationKafkaService.class);

	@KafkaListener(topics = "UpdateSkillMaster")
	public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			SkillMaster sm = objectMapper.readValue(message, SkillMaster.class);

			LOG.info("received message='{}'", sm.getSkillName());
			LOG.info("received message='{}'", sm.getSkillCode());

			SkillMaster skillRes = skillMasterDao.getSkillMasterBySkillCode(sm
					.getSkillCode());
			if (skillRes != null && skillRes.getId() > 0) {
				skillRes.setSkillName(sm.getSkillName());
				skillRes.setIndustryCode(sm.getIndustryCode());
				skillRes.setIsDeleted(sm.getIsDeleted());
				skillMasterDao.save(skillRes);
			}

		} catch (JsonParseException e) {
			LOG.error("In SkillMasterUpdateOfOrganizationKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In SkillMasterUpdateOfOrganizationKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In SkillMasterUpdateOfOrganizationKafkaService >>>>", e);
		} catch (Exception e) {
			LOG.error("In SkillMasterUpdateOfOrganizationKafkaService >>>>", e);
		}
	}

}
