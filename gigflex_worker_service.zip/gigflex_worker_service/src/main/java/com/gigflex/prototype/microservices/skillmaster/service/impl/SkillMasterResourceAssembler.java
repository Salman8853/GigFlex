//package com.gigflex.prototype.microservices.skillmaster.service.impl;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.hateoas.EntityLinks;
//import org.springframework.hateoas.Link;
//import org.springframework.hateoas.Resource;
//import org.springframework.hateoas.ResourceAssembler;
//
//import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
//
//public class SkillMasterResourceAssembler implements ResourceAssembler<SkillMaster, Resource<SkillMaster>> {
//
//
//    @Autowired
//private EntityLinks entityLinks;
//	
//	@Override
//	public Resource<SkillMaster> toResource(SkillMaster skill) {
//		Link self = entityLinks.linkFor(SkillMaster.class).slash(skill.getId()).withSelfRel();
//        Link rel = entityLinks.linkFor(SkillMaster.class).slash(skill.getId()).withRel("skill_master");
//       return new Resource<>(skill, self, rel);	}
//
//}
