package com.gigflex.prototype.microservices.timezone.service;

import java.util.List;

import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetailMultiRequest;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetailRequest;

public interface TimeZoneDetailService {
	
	public String getAllTimeZoneDetail();
	public String getAllTimeZoneDetail(int page, int limit);
	public String createNewTimeZone(TimeZoneDetailMultiRequest timeZonereq,String ip);
	
	public String updateTimeZoneDetailById(Long id,TimeZoneDetailRequest timeZonereq,String ip);
	public String getTimeZoneDetailById(Long id);

	
	public String getTimeZoneDetailByTimeZoneCode(String timeZoneCode);
	public String softDeleteTimeZoneDetailByTimeZoneCode(String timeZoneCode);
	
	public String softMultipleDeleteByTimeZoneCode(List<String> timeZoneCode);
	
	public String search(String search);




}
