/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.users.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.users.repository.UserRepository;

/**
 *
 * @author nirbhay.p
 */
@Service
public class KafkaUserUpdateFromOrganization {
   
        
        @Autowired
        UserRepository userRepository;
	
    private static final Logger LOG = LoggerFactory.getLogger(KafkaUserUpdateFromOrganization.class);

    @KafkaListener(topics = "UpdateUserFromOrganization")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			Users user = objectMapper.readValue(message, Users.class);
                        Users userres=userRepository.findByUserCode(user.getUserCode());
			if(userres!=null && userres.getId()>0)
                        {
                            userres.setEmail(user.getEmail());
                            userres.setEmailLinkExpiredAt(user.getEmailLinkExpiredAt());
                            userres.setIpAddress(user.getIpAddress());
                            userres.setIsActive(user.getIsActive());
                            userres.setIsAdmin(user.getIsAdmin());
                            userres.setIsOwner(user.getIsOwner());
                            userres.setIsVerified(user.getIsVerified());
                            userres.setName(user.getName());
                            userres.setUserCode(user.getUserCode());
                            userres.setUserName(user.getUserName());
                            userres.setPassword(user.getPassword());
                            userres.setIsDeleted(user.getIsDeleted());
                            userRepository.save(userres);
                        }
			
		} catch (JsonParseException e) {
			LOG.error("In KafkaUserUpdateFromOrganization >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaUserUpdateFromOrganization >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaUserUpdateFromOrganization >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaUserUpdateFromOrganization >>>>", e);
		}
    }
}
