/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.users.service;
import com.gigflex.prototype.microservices.users.dtob.Users;
/**
 *
 * @author nirbhay.p
 */
public interface UserService {
    public Users saveInUsers(Users usr);
}
