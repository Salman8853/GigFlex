/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

/**
 *
 * @author abhishek
 */
public class GigflexConstants {
    public static final String assignedScheduleStatus = "pending";
    public static final String assignedScheduleAcceptedStatus = "fulfilled";
    public static final String assignedScheduleRejectedStatus = "reschedule";

    public static final String assignedScheduleChangedStatus = "changed";
}
