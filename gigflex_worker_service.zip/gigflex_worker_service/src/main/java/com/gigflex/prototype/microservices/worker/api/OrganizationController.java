package com.gigflex.prototype.microservices.worker.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.service.OrganizationService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/workerservice/")
public class OrganizationController {

	@Autowired
	private OrganizationService orgService;
	
	@GetMapping("/organizations/{search}")
	public String search(@PathVariable("search") String search) {
		return orgService.search(search);
	}

	@GetMapping("/getAllOrganizations")
	public String getAllOrganization() {
		return orgService.getAllOrganization();
	}
	
	@GetMapping(path="/getOrganizationByPage")
    public String getOrganizationByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String org = orgService.getAllOrganizationByPage(page, limit);
      
        return org;
       
    }

	@GetMapping("/getOrganization/{id}")
	public String getOrgById(@PathVariable long id) {
		return orgService.getOrgById(id);
	}

	@GetMapping("/getOrganizationByOrgCode/{organizationCode}")
	public String getOrganizationByOrgCode(@PathVariable String organizationCode) {
		return orgService.findOrganizationByOrgCode(organizationCode);
	}

	// @PostMapping("/organization")
	// public String saveAllOrganization(@Valid @RequestBody OrganizationRequest
	// organizationrqst, HttpServletRequest request){
	// String ip=request.getRemoteAddr();
	// return orgService.saveOrganization(organizationrqst, ip);
	//
	// }

	@DeleteMapping("/deleteOrganization/{id}")
	public String deleteOrgById(@PathVariable("id") Long id) {
		return orgService.deleteOrgById(id);
	}

	@DeleteMapping("/deleteOrganizationByOrgCode/{organizationCode}")
	public String deleteOrganizationByOrgCode(
			@PathVariable String organizationCode) {
		return orgService.deleteByOrgCode(organizationCode);
	}
	
	@DeleteMapping("/softDeleteOrganizationByOrgCode/{organizationCode}")
	public String softDeleteOrganizationByOrgCode(
			@PathVariable String organizationCode) {
		return orgService.softDeleteByOrgCode(organizationCode);
	}
	
	@DeleteMapping("/softMultipleDeleteByOrgCode/{organizationCodeList}")
	public String softMultipleDeleteByOrgCode(@PathVariable List<String> organizationCodeList) {
		if(organizationCodeList != null && organizationCodeList.size()>0){
			return orgService.softMultipleDeleteByOrgCode(organizationCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
		
	}

	@PutMapping("/updateOrganization/{id}")
	public String updateOrganization(@PathVariable Long id,
			@RequestBody Organization organization,
			HttpServletRequest httpRequest) {
		if (organization != null) {
			organization.setIpAddress(httpRequest.getRemoteAddr());
			return orgService.updateOrganization(organization, id);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}
}
