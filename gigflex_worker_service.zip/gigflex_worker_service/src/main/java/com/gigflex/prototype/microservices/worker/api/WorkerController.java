package com.gigflex.prototype.microservices.worker.api;


import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.approvalstatus.service.WorkerApprovalStatusService;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.dtob.WorkerLogoRequest;
import com.gigflex.prototype.microservices.worker.dtob.WorkerRequest;
import com.gigflex.prototype.microservices.worker.service.WorkerService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/workerservice/")
public class WorkerController {

	@Autowired
	WorkerService workerService;
	@Autowired
	WorkerApprovalStatusService approvalStatusService;
	
	@GetMapping("/workers/{search}")
	public String search(@PathVariable("search") String search) {
		return workerService.search(search);
	}

	@GetMapping("/getAllWorkers")
	public String getAllWorkers() {
		return workerService.getAllWorkers();
	}

	
	@GetMapping(path="/getAllWorkersByPage")
    public String getAllWorkersByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String worker = workerService.getAllWorkersByPage(page, limit);
      
        return worker;
       
    }

	@GetMapping("/getWorker/{id}")
	public String getWorkerById(@PathVariable long id) {
		return workerService.getWorkerById(id);
	}

	@GetMapping("/getWorkerAndOrganizationFromWAS/{organizationCode}")
	public String getWorkerAndOrganizationFromWAS(
			@PathVariable String organizationCode) {
		return approvalStatusService.getWorkerAndOrganization(organizationCode);
	}

	@GetMapping("/getOrganizationByWorkerCode/{workerCode}")
	public String getOrganizationByWorkerCode(@PathVariable String workerCode) {
		return workerService.getOrganizationByWorkerCode(workerCode);
	}
	
	@GetMapping("/getOrganizationByWorkerCodeByPage/{workerCode}")
	public String getOrganizationByWorkerCodeByPage(@PathVariable String workerCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String org = workerService.getOrganizationByWorkerCode(workerCode,page, limit);
      
        return org;
       
	}

	@GetMapping("/getPendingWorkerForApproval/{organizationCode}")
	public String getPendingWorkerForApproval(
			@PathVariable String organizationCode) {
		return approvalStatusService
				.getPendingWorkerForApproval(organizationCode);
	}

	@GetMapping("/getWorkerByWorkerCode/{workerCode}")
	public String getWorkerByWorkerCode(@PathVariable String workerCode) {
		return workerService.findWorkerByWorkerCode(workerCode);
	}

	@GetMapping("/getWorkerApprovalStatusByWorkerCode/{workerCode}")
	public String getWorkerApprovalStatusByWorkerCode(
			@PathVariable String workerCode) {
		return approvalStatusService
				.getWorkerApprovalStatusByWorkerCode(workerCode);
	}
	
	@GetMapping("/getAllWorkerApprovalStatus")
	public String getAllWorkerApprovalStatus() {
		return approvalStatusService.getAllWorkerApprovalStatus();
	}

	@PostMapping("/saveNewWorker")
	public String saveWorker(@RequestBody WorkerRequest workerReq,
			HttpServletRequest httpRequest) {
		if (workerReq != null) {
			 String ip=httpRequest.getRemoteAddr();
			 return workerService.saveWorker(workerReq, ip);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}
	}

	@DeleteMapping("/deleteWorker/{id}")
	public String deleteWorkerById(@PathVariable long id) {
		return workerService.deleteWorkerById(id);
	}

	@DeleteMapping("/deleteWorkerByWorkerCode/{workerCode}")
	public String deleteWorkerByWorkerCode(@PathVariable String workerCode) {
		return workerService.deleteByWorkerCode(workerCode);
	}

	@DeleteMapping("/softDeleteWorkerByWorkerCode/{workerCode}")
	public String softDeleteWorkerByWorkerCode(@PathVariable String workerCode) {
		return workerService.softDeleteByWorkerCode(workerCode);
	}

	@DeleteMapping("/softMultipleDeleteByWorkerCode/{workerCodeList}")
	public String softMultipleDeleteByWorkerCode(
			@PathVariable List<String> workerCodeList) {
		if (workerCodeList != null && workerCodeList.size() > 0) {
			return workerService.softMultipleDeleteByWorkerCode(workerCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

	@PutMapping("/updateWorker/{id}")
	public String updateWorker(@PathVariable Long id,
			@RequestBody WorkerRequest workerReq, HttpServletRequest httpRequest) {
		if (workerReq != null) {
			 String ip=httpRequest.getRemoteAddr();
			return workerService.updateWorker(id, workerReq, ip);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

	@PutMapping("/updateWorkerLogoByWorkerCode/{workerCode}")
	public String updateWorkerLogoByWorkerCode(@PathVariable String workerCode,
			@RequestBody WorkerLogoRequest workerLogoReq,
			HttpServletRequest httpRequest) {
		if (workerLogoReq != null) {
			String ip = httpRequest.getRemoteAddr();
			return workerService.updateWorkerLogoByWorkerCode(workerLogoReq,
					workerCode, ip);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}
}