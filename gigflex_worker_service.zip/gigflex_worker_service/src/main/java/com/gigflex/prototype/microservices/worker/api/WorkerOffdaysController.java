package com.gigflex.prototype.microservices.worker.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.WorkerOffdaysRequest;
import com.gigflex.prototype.microservices.worker.service.WorkerOffdaysService;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/workerservice/")
@ControllerAdvice
public class WorkerOffdaysController {
	@Autowired
	WorkerOffdaysService workerOffdaysService;

	@GetMapping("/getAllWorkerOffDays")
	public String getAllWorkerOffDays() {
		return workerOffdaysService.getAllWorkerOffDays();
	}
	
	@GetMapping("/workerOffDays/{search}")
	public String search(@PathVariable("search") String search) {
		return workerOffdaysService.search(search);
	}

	
	@GetMapping(path="/getAllWorkerOffDaysByPage")
    public String getAllWorkerOffDaysByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String wrkrOffDays = workerOffdaysService.getAllWorkerOffDaysByPage(page, limit);
      
        return wrkrOffDays;
       
    }

	@GetMapping("/getWorkerOffDays/{id}")
	public String getWorkerOffDaysById(@PathVariable Long id) {
		return workerOffdaysService.getWorkerOffdaysById(id);
	}

	@GetMapping("/getWorkerOffDaysByOffDaysCode/{offDaysCode}")
	public String getWorkerOffDaysByOffDaysCode(@PathVariable String offDaysCode) {
		return workerOffdaysService.getByOffDaysCode(offDaysCode);
	}

	@PostMapping("/saveWorkerOffDays")
	public String saveWorkerOffDays(
			 @RequestBody WorkerOffdaysRequest workeroffdaysReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return workerOffdaysService.saveWorkerOffdays(workeroffdaysReq, ip);

	}

	@PutMapping("/updateWorkerOffdays/{id}")
	public String updateWorkerOffdays(@PathVariable Long id,
			 @RequestBody WorkerOffdaysRequest workerOffdaysrqst,
			HttpServletRequest httpRequest) {

		if (workerOffdaysrqst != null) {
			String ip = httpRequest.getRemoteAddr();
			return workerOffdaysService.updateWorkerOffdays(id, workerOffdaysrqst,ip);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

		// Object response = null;
		// if (errors.hasErrors()) {
		// response = errors.getAllErrors();
		// return ResponseEntity.badRequest().body(response);
		// }
		// WorkerOffdays org = workerOffdaysService.getWorkerOffdaysById(id);
		// if (org == null) {
		// response = "WorkerOffdays with Id : (" + id + ") Not found.";
		// } else {
		// org = workerOffdaysService.saveWorkerOffdays(workerOffdays);
		//
		// id = workerOffdaysService.saveWorkerOffdays(workerOffdays).getId();
		// response = "WorkerOffdays with Id : (" + id + ") is Updated.";
		// }
		// return ResponseEntity.ok(response);
	}

	@DeleteMapping("/deleteWorkerOffDays/{id}")
	public String deleteWorkerOffDaysById(@PathVariable Long id) {
		return workerOffdaysService.deleteWorkerOffdaysById(id);
	}

	@DeleteMapping("/deleteWorkerOffDaysByOffDaysCode/{offDaysCode}")
	public String deleteWorkerOffDaysByOffDaysCode(
			@PathVariable String offDaysCode) {
		return workerOffdaysService.deleteByOffDaysCode(offDaysCode);
	}
	
	@DeleteMapping("/softDeleteWorkerOffDaysByOffDaysCode/{offDaysCode}")
	public String softDeleteWorkerOffDaysByOffDaysCode(
			@PathVariable String offDaysCode) {
		return workerOffdaysService.softDeleteByOffDaysCode(offDaysCode);
	}
	
	@DeleteMapping("/softMultipleDeleteByOffDaysCode/{offDaysCodeList}")
	public String softMultipleDeleteByOffDaysCode(@PathVariable List<String> offDaysCodeList) {
		if(offDaysCodeList != null && offDaysCodeList.size()>0){
			return workerOffdaysService.softMultipleDeleteByOffDaysCode(offDaysCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
		
	}

}
