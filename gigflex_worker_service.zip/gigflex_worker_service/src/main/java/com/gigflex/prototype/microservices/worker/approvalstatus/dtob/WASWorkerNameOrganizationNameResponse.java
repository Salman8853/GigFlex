package com.gigflex.prototype.microservices.worker.approvalstatus.dtob;

import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.Worker;

public class WASWorkerNameOrganizationNameResponse {
	
	    private String workerCode ;

	    private String organization_Code ;

	    private String approvedStatus ;
	    
	    private String organizationName;
	    
	    private String name;

		public String getWorkerCode() {
			return workerCode;
		}

		public void setWorkerCode(String workerCode) {
			this.workerCode = workerCode;
		}

		public String getOrganization_Code() {
			return organization_Code;
		}

		public void setOrganization_Code(String organization_Code) {
			this.organization_Code = organization_Code;
		}

		public String getApprovedStatus() {
			return approvedStatus;
		}

		public void setApprovedStatus(String approvedStatus) {
			this.approvedStatus = approvedStatus;
		}

		public String getOrganizationName() {
			return organizationName;
		}

		public void setOrganizationName(String organizationName) {
			this.organizationName = organizationName;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
    
	
    
    


}
