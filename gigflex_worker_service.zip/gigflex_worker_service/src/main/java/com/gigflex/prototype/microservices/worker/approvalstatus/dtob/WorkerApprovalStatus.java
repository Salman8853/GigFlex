/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.approvalstatus.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author nirbhay.p
 */
@Entity
@Table(name = "worker_approval_status")
public class WorkerApprovalStatus extends CommonAttributes implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    
    @Column(name = "worker_code", nullable = false)
    private String workerCode ;
    
    @Column(name = "organization_code", nullable = false)
    private String organization_Code ;
    
    @Column(name = "isapproved")
    private Boolean isApproved;
     
    @Column(name = "approveddate", columnDefinition="DATETIME")
    private Date approvedDate ;
    
    @Column(name ="approved_by_code" , nullable = false)
    private String approvedByCode ;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getOrganization_Code() {
        return organization_Code;
    }

    public void setOrganization_Code(String organizationCode) {
        this.organization_Code = organizationCode;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }

    public Date getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(Date approvedDate) {
        this.approvedDate = approvedDate;
    }

    public String getApprovedByCode() {
        return approvedByCode;
    }

    public void setApprovedByCode(String approvedByCode) {
        this.approvedByCode = approvedByCode;
    }

    
    
}
