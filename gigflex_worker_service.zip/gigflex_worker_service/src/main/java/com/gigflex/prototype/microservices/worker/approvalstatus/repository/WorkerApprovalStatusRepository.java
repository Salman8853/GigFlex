/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.approvalstatus.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gigflex.prototype.microservices.worker.approvalstatus.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.worker.dtob.Worker;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
@Repository
public interface WorkerApprovalStatusRepository extends JpaRepository<WorkerApprovalStatus, Long>{
    
	@Query("SELECT was FROM WorkerApprovalStatus was WHERE was.isDeleted != TRUE AND was.organization_Code=:organizationCode")
	public List<WorkerApprovalStatus> findAllWorkerApprovalStatusByOrgCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT was FROM WorkerApprovalStatus was WHERE was.isDeleted != TRUE AND was.workerCode=:workerCode AND was.organization_Code != :organizationCode")
	public List<WorkerApprovalStatus> findAllWASByWorkerAndOrgCode(@Param("workerCode") String workerCode , @Param("organizationCode") String organizationCode);
	
	@Query("SELECT was FROM WorkerApprovalStatus was, Worker w WHERE was.isDeleted != TRUE AND was.workerCode=w.workerCode AND w.workerCode=:workerCode")
	public WorkerApprovalStatus findWorkerApprovalStatusByWorkerCode(@Param("workerCode") String workerCode);
	
	
    @Query("SELECT w FROM WorkerApprovalStatus w  WHERE w.isDeleted != TRUE AND w.organization_Code=:organization_Code AND w.workerCode=:workerCode")
    public WorkerApprovalStatus getWASByWorkercodeAndOrgcode(@Param("organization_Code") String organization_Code,@Param("workerCode") String workerCode);
    
    @Query("SELECT b FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.organization_Code=:organizationCode AND a.isApproved<>TRUE")
    public List<Worker> getPendingWorkerForApproval(@Param("organizationCode") String organizationCode);
    
    @Query("SELECT b,c FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.organization_Code=:organizationCode")
    public List<Object> getNameAndOrgName(@Param("organizationCode") String organizationCode);
    
    @Query("SELECT a,b.name,c.organizationName FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.workerCode = :workerCode")
    public List<Object> getWASByWorkerCode(@Param("workerCode") String workerCode);
    
    @Query("SELECT a,b.name,c.organizationName FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode")
    public List<Object> getAllWorkerApprovalStatus();
	
}
