package com.gigflex.prototype.microservices.worker.approvalstatus.service;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.worker.approvalstatus.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.worker.approvalstatus.repository.WorkerApprovalStatusRepository;



@Service
public class KafkaWorkerApprovalStatusUpdateFormOrgService {
	
	
	@Autowired
	WorkerApprovalStatusRepository workerApprovalStatusRepository;
    private static final Logger LOG = LoggerFactory.getLogger(KafkaWorkerApprovalStatusUpdateFormOrgService.class);

	@KafkaListener(topics = "UpdateWorkApprovalStatusFromOrganization")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			WorkerApprovalStatus was = objectMapper.readValue(message, WorkerApprovalStatus.class);
			WorkerApprovalStatus wasRes=workerApprovalStatusRepository.getWASByWorkercodeAndOrgcode(was.getOrganization_Code(), was.getWorkerCode());
                        if(wasRes!=null && wasRes.getId()>0)
                        {
                        wasRes.setApprovedByCode(was.getApprovedByCode());
                        wasRes.setApprovedDate(was.getApprovedDate());
                        wasRes.setIpAddress(was.getIpAddress());
                        wasRes.setIsApproved(was.getIsApproved());
                        wasRes.setIsDeleted(was.getIsDeleted());
                        workerApprovalStatusRepository.save(wasRes);
                        }
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	
}