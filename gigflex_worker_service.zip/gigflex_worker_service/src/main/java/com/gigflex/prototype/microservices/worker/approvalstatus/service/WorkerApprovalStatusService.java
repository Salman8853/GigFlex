/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.approvalstatus.service;

import com.gigflex.prototype.microservices.worker.approvalstatus.dtob.WorkerApprovalStatus;
import com.google.common.base.Optional;


/**
 *
 * @author nirbhay.p
 */
public interface WorkerApprovalStatusService {
    public WorkerApprovalStatus saveInWorkerApprovalStatus(WorkerApprovalStatus workerApprovalStatus);
   public String getPendingWorkerForApproval(String organizationCode);
   public String getWorkerAndOrganization(String organizationCode);
   public String getWorkerApprovalStatusByWorkerCode(String workerCode);
   public String getAllWorkerApprovalStatus();
}
