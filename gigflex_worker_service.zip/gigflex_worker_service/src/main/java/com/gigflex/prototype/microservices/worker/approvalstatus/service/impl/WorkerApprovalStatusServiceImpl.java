/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.approvalstatus.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.approvalstatus.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.worker.approvalstatus.dtob.WASWorkerNameOrganizationNameResponse;
import com.gigflex.prototype.microservices.worker.approvalstatus.dtob.WorkerOrganizationResponse;
import com.gigflex.prototype.microservices.worker.approvalstatus.repository.WorkerApprovalStatusRepository;
import com.gigflex.prototype.microservices.worker.approvalstatus.service.WorkerApprovalStatusService;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocation;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocationResponse;

/**
 *
 * @author nirbhay.p
 */
@Service
public class WorkerApprovalStatusServiceImpl implements
		WorkerApprovalStatusService {
	@Autowired
	WorkerApprovalStatusRepository approvalStatusRepository;

	@Override
	public WorkerApprovalStatus saveInWorkerApprovalStatus(
			WorkerApprovalStatus workerApprovalStatus) {
		WorkerApprovalStatus resp = approvalStatusRepository
				.save(workerApprovalStatus);
		return resp;
	}

	@Override
	public String getPendingWorkerForApproval(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {
				List<Worker> objlst = approvalStatusRepository
						.getPendingWorkerForApproval(organizationCode);
				if (objlst != null && objlst.size() > 0) {

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(objlst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("workercount", objlst.size());
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerAndOrganization(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {
				List<Object> objlst = approvalStatusRepository
						.getNameAndOrgName(organizationCode);
				List<WorkerOrganizationResponse> wolst = new ArrayList<WorkerOrganizationResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerOrganizationResponse wo = new WorkerOrganizationResponse();
							wo.setWorker((Worker) arr[0]);
							wo.setOrganization((Organization) arr[1]);
							wolst.add(wo);
						}

					}

					if (wolst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wolst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("workercount", wolst.size());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerApprovalStatusByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerCode != null && workerCode.trim().length() > 0) {
				List<Object> objlst = approvalStatusRepository
						.getWASByWorkerCode(workerCode);
				List<WASWorkerNameOrganizationNameResponse> maplst=new ArrayList<WASWorkerNameOrganizationNameResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							WASWorkerNameOrganizationNameResponse wwo = new WASWorkerNameOrganizationNameResponse();
							
							WorkerApprovalStatus was = (WorkerApprovalStatus) arr[0];

							if(was.getIsApproved())
							{
								wwo.setApprovedStatus("This worker is approved");
							}else{
								wwo.setApprovedStatus("This worker is not approved");
							}
							wwo.setOrganization_Code(was.getOrganization_Code());
							wwo.setOrganizationName((String) arr[2]);
							wwo.setWorkerCode(was.getWorkerCode());
							wwo.setName((String) arr[1]);
							

							maplst.add(wwo);
						}
					}
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("data", new JSONArray(Detail));
			}else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			}else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Code should not be blank");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllWorkerApprovalStatus() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = approvalStatusRepository
					.getAllWorkerApprovalStatus();
			List<WASWorkerNameOrganizationNameResponse> maplst=new ArrayList<WASWorkerNameOrganizationNameResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {
						WASWorkerNameOrganizationNameResponse wwo = new WASWorkerNameOrganizationNameResponse();
						
						WorkerApprovalStatus was = (WorkerApprovalStatus) arr[0];

						if(was.getIsApproved())
						{
							wwo.setApprovedStatus("This worker is approved");
						}else{
							wwo.setApprovedStatus("This worker is not approved");
						}
						wwo.setOrganization_Code(was.getOrganization_Code());
						wwo.setOrganizationName((String) arr[2]);
						wwo.setWorkerCode(was.getWorkerCode());
						wwo.setName((String) arr[1]);
						

						maplst.add(wwo);
					}
				}
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
		}else {
			jsonobj.put("responsecode", 404);
			jsonobj.put("timestamp", new Date());
			jsonobj.put("message", "Record Not Found");
		}
		res = jsonobj.toString();
	} catch (JSONException | JsonProcessingException ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(),
				"JSON parsing exception occurred.");
		res = derr.toString();
		ex.printStackTrace();
	} catch (Exception ex) {
		GigflexResponse derr = new GigflexResponse(500, new Date(),
				"Exception is occurred.");
		res = derr.toString();
		ex.printStackTrace();
	}
	return res;
			
	}
}


