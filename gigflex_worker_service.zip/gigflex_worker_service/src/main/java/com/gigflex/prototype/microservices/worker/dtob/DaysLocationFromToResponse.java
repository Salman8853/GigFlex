package com.gigflex.prototype.microservices.worker.dtob;

import java.util.List;

public class DaysLocationFromToResponse {
	
    private String location;
    private String organizationCode;
    private String organizationName;

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }
    
    
	
	private List<DaysFromToResponse> daysFromToResponse;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<DaysFromToResponse> getDaysFromToResponse() {
		return daysFromToResponse;
	}

	public void setDaysFromToResponse(List<DaysFromToResponse> daysFromToResponse) {
		this.daysFromToResponse = daysFromToResponse;
	}
	
	

}
