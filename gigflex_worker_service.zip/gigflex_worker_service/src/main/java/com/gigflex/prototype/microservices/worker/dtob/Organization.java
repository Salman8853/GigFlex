package com.gigflex.prototype.microservices.worker.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import java.util.UUID;

import javax.persistence.PrePersist;

import com.gigflex.prototype.microservices.util.CommonAttributes;



@Entity
@Table(name = "organization")
public class Organization extends CommonAttributes implements Serializable {
	
	    
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id")
	    private Long id;

	    @Column(name = "organizationname", nullable = false)
	    private String organizationName;
	    
	    @Column(name = "organization_code", nullable = false)
	    private String organizationCode;

	    @Column(name = "lat")
	    private String lat;

	    @Column(name = "lang")
	    private String lang;

	    @Column(name = "isactive")
	    private Boolean isActive;

	    @Column(name = "isverified")
	    private Boolean isVerified;
            
            @Column(name = "timezone")
             private String timezone;
	    
	  
	    
	  
		public Organization(Long id, String organizationName,
				String organizationCode, String lat, String lang,
				Boolean isActive, Boolean isVerified,String timezone) {
			super();
			this.id = id;
			this.organizationName = organizationName;
			this.organizationCode = organizationCode;
			this.lat = lat;
			this.lang = lang;
			this.isActive = isActive;
			this.isVerified = isVerified;
                        this.timezone=timezone;
		}

                public String getTimezone() {
                    return timezone;
                }

                public void setTimezone(String timezone) {
                    this.timezone = timezone;
                }
	    
		public Organization(Long id) {
			super();
			this.id = id;
		}

		public Organization() {
			super();
		}

	
		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getOrganizationName() {
			return organizationName;
		}

		public void setOrganizationName(String organizationName) {
			this.organizationName = organizationName;
		}

		public String getOrganizationCode() {
			return organizationCode;
		}

		public void setOrganizationCode(String organizationCode) {
			this.organizationCode = organizationCode;
		}

		public String getLat() {
			return lat;
		}

		public void setLat(String lat) {
			this.lat = lat;
		}

		public String getLang() {
			return lang;
		}

		public void setLang(String lang) {
			this.lang = lang;
		}

		public Boolean getIsActive() {
			return isActive;
		}

		public void setIsActive(Boolean isActive) {
			this.isActive = isActive;
		}

		public Boolean getIsVerified() {
			return isVerified;
		}

		public void setIsVerified(Boolean isVerified) {
			this.isVerified = isVerified;
		}

		@Override
		public String toString() {
			return "Organization [id=" + id + ", organizationName=" + organizationName + ", organizationCode="
					+ organizationCode + ", lat=" + lat + ", lang=" + lang + ", isActive=" + isActive + ", isVerified="
					+ isVerified + "]";
		}
	    
	    

}
