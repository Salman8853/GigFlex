package com.gigflex.prototype.microservices.worker.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;

import java.util.UUID;

import javax.persistence.PrePersist;

/**
 * 
 * @author ajit.p
 *
 */
@Entity
@Table(name = "worker")
public class Worker extends CommonAttributes implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    @Column(name = "name")
    private String name;
    @Column(name = "email")
    private String email;
    
//    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
//    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "worker_code", unique = true)
    private String workerCode;
    
    @Column(name = "department_code")
    private String departmentCode;
    
    @Column(name = "phone")
    private String phone;
    
    @Column(name = "exp_year")
    private Integer expYear;  
    @Column(name = "exp_month")
    private Integer expMonth;  
    @Column(name = "exp_days")
    private Integer expDays; 
    
    @Column(name = "qualification")
    private String qualification; 
    
    @Column(name = "external_emp_code")
    private String externalEmpCode; 
    
    @Column(name = "pre_working_hours")
    private String preWorkingHours; 
   
    @Column(name = "isactive")
    private Boolean isActive; 
    
    @Column(name = "worker_status_code")
    private String workerStatusCode;
    
    @Column(name = "worker_logo")
    private String workerLogo;
	
   @PrePersist
    private void assignUUID() {
        if(this.getWorkerCode()==null || this.getWorkerCode().length()==0)
        {
            this.setWorkerCode(UUID.randomUUID().toString());
        }
    }
    
    
    public Worker() {
		super();
	}

	
    
	public Worker(Long id, String name, String email, String workerCode,
			String departmentCode, String phone, Integer expYear, Integer expMonth,
			Integer expDays, String qualification, String externalEmpCode,
			String preWorkingHours, Boolean isActive, String workerStatusCode,
			String workerLogo) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.workerCode = workerCode;
		this.departmentCode = departmentCode;
		this.phone = phone;
		this.expYear = expYear;
		this.expMonth = expMonth;
		this.expDays = expDays;
		this.qualification = qualification;
		this.externalEmpCode = externalEmpCode;
		this.preWorkingHours = preWorkingHours;
		this.isActive = isActive;
		this.workerStatusCode = workerStatusCode;
		this.workerLogo = workerLogo;
	}


	public Worker(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Integer getExpYear() {
		return expYear;
	}

	public void setExpYear(Integer expYear) {
		this.expYear = expYear;
	}

	public Integer getExpMonth() {
		return expMonth;
	}

	public void setExpMonth(Integer expMonth) {
		this.expMonth = expMonth;
	}

	public Integer getExpDays() {
		return expDays;
	}

	public void setExpDays(Integer expDays) {
		this.expDays = expDays;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getExternalEmpCode() {
		return externalEmpCode;
	}

	public void setExternalEmpCode(String externalEmpCode) {
		this.externalEmpCode = externalEmpCode;
	}

	public String getPreWorkingHours() {
		return preWorkingHours;
	}

	public void setPreWorkingHours(String preWorkingHours) {
		this.preWorkingHours = preWorkingHours;
	}

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
	public String getWorkerStatusCode() {
		return workerStatusCode;
	}

	public void setWorkerStatusCode(String workerStatusCode) {
		this.workerStatusCode = workerStatusCode;
	}

	public String getWorkerLogo() {
		return workerLogo;
	}


	public void setWorkerLogo(String workerLogo) {
		this.workerLogo = workerLogo;
	}


	@Override
	public String toString() {
		return "Worker [id=" + id + ", name=" + name + ", email=" + email + ", workerCode=" + workerCode
				+ ", departmentCode=" + departmentCode + ", phone=" + phone + ", expYear=" + expYear + ", expMonth="
				+ expMonth + ", expDays=" + expDays + ", qualification=" + qualification + ", externalEmpCode="
				+ externalEmpCode + ", preWorkingHours=" + preWorkingHours + ", isActive=" + isActive
				+ ", workerStatusCode=" + workerStatusCode + "]";
	} 
   
	
   

}