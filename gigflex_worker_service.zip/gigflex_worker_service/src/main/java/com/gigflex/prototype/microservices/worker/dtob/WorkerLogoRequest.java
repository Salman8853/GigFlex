package com.gigflex.prototype.microservices.worker.dtob;

public class WorkerLogoRequest {
	
	 private String workerLogo;

	public String getWorkerLogo() {
		return workerLogo;
	}

	public void setWorkerLogo(String workerLogo) {
		this.workerLogo = workerLogo;
	}
	 
	 

}
