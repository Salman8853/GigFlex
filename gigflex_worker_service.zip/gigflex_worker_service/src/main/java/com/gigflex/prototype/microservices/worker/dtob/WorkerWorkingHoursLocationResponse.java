package com.gigflex.prototype.microservices.worker.dtob;

public class WorkerWorkingHoursLocationResponse {
	
	    private WorkerWorkingHours workerWorkingHours;
	    
	    private String location;

		private String daysName;
		
		

		public String getDaysName() {
			return daysName;
		}

		public void setDaysName(String daysName) {
			this.daysName = daysName;
		}

		public WorkerWorkingHours getWorkerWorkingHours() {
			return workerWorkingHours;
		}

		public void setWorkerWorkingHours(WorkerWorkingHours workerWorkingHours) {
			this.workerWorkingHours = workerWorkingHours;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}
	    
	    

}
