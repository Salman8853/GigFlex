package com.gigflex.prototype.microservices.worker.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import com.gigflex.prototype.microservices.worker.dtob.Organization;

@Repository
public interface OrganizationRepository extends JpaRepository<Organization,Long>,JpaSpecificationExecutor<Organization>{
    
	@Query("SELECT o FROM Organization o WHERE o.isDeleted != TRUE AND o.organizationCode = :organizationCode")
	public Organization findByOrganizationCode(@Param("organizationCode") String organizationCode);
    
    @Transactional
	public Integer deleteOrganizationrByOrganizationCode(String organizationCode);

    @Query("SELECT o FROM Organization o WHERE o.isDeleted != TRUE")
    public List<Organization> getAllOrganization();

    
    @Query("SELECT o FROM Organization o WHERE o.isDeleted != TRUE")
    public List<Organization> getAllOrganization(Pageable pageableRequest);

	
	@Query("SELECT o FROM Organization o WHERE o.isDeleted != TRUE AND o.id = :id")
	public Organization getOrganizationById(@Param("id") Long id);
	
	@Query("SELECT o FROM OrganizationSkill o WHERE o.isDeleted != TRUE AND o.organizationCode = :organizationCode")
	public List<OrganizationSkill> getOrgSkillByOrgCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT o FROM OrganizationWorkerSkill o WHERE o.isDeleted != TRUE AND o.organizationCode = :organizationCode")
	public List<OrganizationWorkerSkill> getOrgWorkerSkillByOrgCode(@Param("organizationCode") String organizationCode);
	
	
	
	
}
