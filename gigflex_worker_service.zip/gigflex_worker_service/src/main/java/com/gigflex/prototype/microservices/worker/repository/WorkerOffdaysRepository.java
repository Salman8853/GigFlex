package com.gigflex.prototype.microservices.worker.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.worker.dtob.WorkerOffdays;

/**
 * 
 * @author ajit.p
 *
 */
@Repository
public interface WorkerOffdaysRepository  extends JpaRepository<WorkerOffdays, Long>,JpaSpecificationExecutor<WorkerOffdays>{

	@Query("SELECT wod FROM WorkerOffdays wod WHERE wod.isDeleted != TRUE AND wod.offDaysCode = :offDaysCode")
	public WorkerOffdays getWorkerOffDaysByOffDaysCode(@Param("offDaysCode") String offDaysCode);
	
	@Transactional
	public Integer deleteByOffDaysCode(String offDaysCode);
	
	@Query("SELECT wod FROM WorkerOffdays wod WHERE wod.isDeleted != TRUE")
    public List<WorkerOffdays> getAllWorkerOffDays();

	@Query("SELECT wod FROM WorkerOffdays wod WHERE wod.isDeleted != TRUE")
    public List<WorkerOffdays> getAllWorkerOffDays(Pageable pageableRequest);

	@Query("SELECT wod FROM WorkerOffdays wod WHERE wod.isDeleted  != TRUE AND wod.id = :id")
	public WorkerOffdays getWorkerOffDaysById(@Param("id") Long id);
	
	@Query("SELECT wod FROM WorkerOffdays wod WHERE wod.isDeleted  != TRUE AND wod.daysCode = :daysCode AND wod.workerCode = :workerCode")
	public WorkerOffdays getWorkerOffDaysCheckForSave(@Param("daysCode") String daysCode,@Param("workerCode") String workerCode);
	
	@Query("SELECT wod FROM WorkerOffdays wod WHERE wod.isDeleted  != TRUE AND wod.id != :id AND wod.daysCode = :daysCode AND wod.workerCode = :workerCode")
	public WorkerOffdays getWorkerOffDaysCheckForUpdate(@Param("id") Long id,@Param("daysCode") String daysCode,@Param("workerCode") String workerCode);
	
	@Query("SELECT wpl.workerPreferredLocationCode FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted  != TRUE AND wpl.workerCode = :workerCode AND wpl.workerOrganizationCode = :workerOrganizationCode")
	public String getLocationCodeByWorkerAndOrgCode(@Param("workerCode") String workerCode,@Param("workerOrganizationCode") String workerOrganizationCode);
	
	}
