/**
 * 
 */
package com.gigflex.prototype.microservices.worker.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.worker.dtob.WorkerWorkingHours;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocation;

/**
 * @author ajit.p
 *
 */
@Repository
public interface WorkerWorkingHoursRepository extends JpaRepository<WorkerWorkingHours, Long>,JpaSpecificationExecutor<WorkerWorkingHours>{
	@Query("SELECT wwh FROM WorkerWorkingHours wwh WHERE wwh.isDeleted != TRUE AND wwh.workerWorkingHoursCode = :workerWorkingHoursCode")
	public WorkerWorkingHours getWorkerOffDaysByWorkerWorkingHoursCode(@Param("workerWorkingHoursCode") String workerWorkingHoursCode);
	
	@Transactional
	public Integer deleteByWorkerWorkingHoursCode(String workerWorkingHoursCode);
	
	@Query("SELECT wwh FROM WorkerWorkingHours wwh WHERE wwh.isDeleted != TRUE")
	public List<WorkerWorkingHours> getAllWorkerWorkingHours();

	
	@Query("SELECT wwh FROM WorkerWorkingHours wwh WHERE wwh.isDeleted != TRUE")
	public List<WorkerWorkingHours> getAllWorkerWorkingHours(Pageable pageableRequest);


	@Query("SELECT wwh FROM WorkerWorkingHours wwh WHERE wwh.isDeleted != TRUE AND wwh.id = :id")
	public WorkerWorkingHours getWorkerWorkingHoursById(@Param("id") Long id);
	

	@Query("SELECT wwh FROM WorkerWorkingHours wwh,WorkerPreferredLocation wpl WHERE wwh.isDeleted != TRUE AND wpl.workerPreferredLocationCode = wwh.workerPreferredLocationCode AND wwh.workerPreferredLocationCode = :workerPreferredLocationCode")
	public List<WorkerWorkingHours> getAllWorkerWorkingHoursByWorkerPreferredLocationCode(@Param("workerPreferredLocationCode") String workerPreferredLocationCode);
	
	@Query("SELECT wwh FROM WorkerWorkingHours wwh,WorkerPreferredLocation wpl WHERE wwh.isDeleted != TRUE AND wpl.workerPreferredLocationCode = wwh.workerPreferredLocationCode AND wwh.workerPreferredLocationCode = :workerPreferredLocationCode")
	public List<WorkerWorkingHours> getAllWorkerWorkingHoursByWorkerPreferredLocationCode(@Param("workerPreferredLocationCode") String workerPreferredLocationCode,Pageable pageableRequest);

	@Query("SELECT a,b.name,c.daysName,d.location FROM WorkerWorkingHours a,Worker b,DaysMaster c, WorkerPreferredLocation d WHERE a.isDeleted != TRUE AND a.workerCode = b.workerCode AND a.daysCode = c.daysCode AND a.workerPreferredLocationCode = d.workerPreferredLocationCode")
	public List<Object> getAllWorkerWorkingHoursWithName();
	

	@Query("SELECT a,b.name,c.daysName,d.location FROM WorkerWorkingHours a,Worker b,DaysMaster c, WorkerPreferredLocation d WHERE a.isDeleted != TRUE AND a.workerCode = b.workerCode AND a.daysCode = c.daysCode AND a.workerPreferredLocationCode = d.workerPreferredLocationCode")
	public List<Object> getAllWorkerWorkingHoursWithName(Pageable pageableRequest);
	
	@Query("SELECT a,b.location,dm.daysName FROM WorkerWorkingHours a, WorkerPreferredLocation b, DaysMaster dm, Worker w WHERE a.isDeleted != TRUE AND a.daysCode =dm.daysCode AND a.workerCode = w.workerCode AND a.workerCode = b.workerCode AND a.workerPreferredLocationCode = b.workerPreferredLocationCode AND a.workerCode = :workerCode ORDER BY b.location")
	public List<Object> getAllWorkerWorkingHoursByWorkerCode(@Param("workerCode") String workerCode);
	
	@Query("SELECT a,dm.daysName FROM WorkerWorkingHours a, DaysMaster dm, Worker w WHERE a.isDeleted != TRUE AND a.daysCode =dm.daysCode AND a.workerCode = w.workerCode AND a.workerPreferredLocationCode = :workerPreferredLocationCode AND a.workerCode = :workerCode")
	public List<Object> getAllWorkerWorkingHoursByWorkerCodeWithLocation(@Param("workerCode") String workerCode,@Param("workerPreferredLocationCode") String workerPreferredLocationCode);
	
	@Query("SELECT wwh FROM WorkerWorkingHours wwh WHERE wwh.isDeleted != TRUE AND wwh.daysCode = :daysCode AND wwh.workerCode = :workerCode AND wwh.workerPreferredLocationCode = :workerPreferredLocationCode")
	public WorkerWorkingHours getWrkrWrkngHrsByDayCodeWorkerCodeAndWorkerPreferredLocCode(@Param("daysCode") String daysCode, @Param("workerCode") String workerCode, @Param("workerPreferredLocationCode") String workerPreferredLocationCode);
	
	@Query("SELECT wwh FROM WorkerWorkingHours wwh WHERE wwh.isDeleted != TRUE AND wwh.id != :id AND wwh.daysCode = :daysCode AND wwh.workerCode = :workerCode AND wwh.workerPreferredLocationCode = :workerPreferredLocationCode")
	public WorkerWorkingHours getWrkrWrkngHrsByIdDayCodeWorkerCodeAndWorkerPreferredLocCode(@Param("id") Long id,@Param("daysCode") String daysCode, @Param("workerCode") String workerCode, @Param("workerPreferredLocationCode") String workerPreferredLocationCode);

	@Query("SELECT wl FROM WorkerPreferredLocation wl WHERE wl.isDeleted != TRUE AND wl.workerCode = :workerCode ORDER BY wl.location")
    public List<WorkerPreferredLocation> getWorkerPreferredLocationByWorkerCode(@Param("workerCode") String workerCode,Pageable pageableRequest);
	
	
}
