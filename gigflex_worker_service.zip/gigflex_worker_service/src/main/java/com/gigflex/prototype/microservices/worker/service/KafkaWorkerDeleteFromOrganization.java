/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.dtob.WorkerConsumeFromOrganization;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */
@Service
public class KafkaWorkerDeleteFromOrganization {
    private Worker worker;

	@Autowired
	WorkerRepository workerRepository;
	
    private static final Logger LOG = LoggerFactory.getLogger(KafkaWorkerDeleteFromOrganization.class);

	@KafkaListener(topics = "DeletionWorkerFromOrganization")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			WorkerConsumeFromOrganization wkr = objectMapper.readValue(message, WorkerConsumeFromOrganization.class);
			worker=workerRepository.findByWorkerCode(wkr.getWorkerCode());
                        if(worker!=null && worker.getId()>0)
                        {
                            workerRepository.deleteById(worker.getId());
                        }
			
		} catch (JsonParseException e) {
			LOG.error("In KafkaWorkerDeleteFromOrganization >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaWorkerDeleteFromOrganization >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaWorkerDeleteFromOrganization >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaWorkerDeleteFromOrganization >>>>", e);
		}
    }
}
