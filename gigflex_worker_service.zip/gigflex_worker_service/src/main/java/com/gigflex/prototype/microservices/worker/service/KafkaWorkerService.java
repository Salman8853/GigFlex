package com.gigflex.prototype.microservices.worker.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;

@Service
public class KafkaWorkerService {

	private Worker worker;

	@Autowired
	WorkerRepository workerRepository;
	private static final Logger LOG = LoggerFactory.getLogger(KafkaWorkerService.class);

	@KafkaListener(topics = "NewEmployee")
	public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			Users user = objectMapper.readValue(message, Users.class);
			LOG.info("received message='{}'", user.getName());
			LOG.info("received message='{}'", user.getUserCode());
			LOG.info("received message='{}'", user.getIsActive());
			LOG.info("received message='{}'", user.getEmail());
			worker = new Worker();
			worker.setName(user.getName());
			worker.setWorkerCode(user.getUserCode());
			worker.setIsActive(user.getIsActive());
			worker.setEmail(user.getEmail());
			workerRepository.save(worker);
			
		} catch (JsonParseException e) {
			LOG.error("In KafkaWorkerService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaWorkerService >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaWorkerService >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaWorkerService >>>>", e);
		}
	}


}