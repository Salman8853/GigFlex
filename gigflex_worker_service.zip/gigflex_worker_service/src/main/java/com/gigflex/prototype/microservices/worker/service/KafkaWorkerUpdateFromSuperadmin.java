package com.gigflex.prototype.microservices.worker.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;

@Service
public class KafkaWorkerUpdateFromSuperadmin {
	
	 private Worker worker;

		@Autowired
		WorkerRepository workerRepository;
		
		  private static final Logger LOG = LoggerFactory.getLogger(KafkaWorkerUpdateFromSuperadmin.class);
		  
		  @KafkaListener(topics = "UpdateWorkerFromSuperAdmin")
		    public void listen(@Payload String message) {
				ObjectMapper objectMapper = new ObjectMapper();
				LOG.info("received message='{}'", message);
				try {
					Worker worker = objectMapper.readValue(message, Worker.class);
					Worker workerres=workerRepository.findByWorkerCode(worker.getWorkerCode());
					if(workerres!=null && workerres.getId()>0)
	                {
	                    workerres.setDepartmentCode(worker.getDepartmentCode());
	                    workerres.setIsActive(worker.getIsActive());
	                    workerres.setName(worker.getName());
	                    workerres.setIsDeleted(worker.getIsDeleted());

	                    workerRepository.save(workerres);
	                }
				} catch (JsonParseException e) {
					LOG.error("In KafkaWorkerUpdateFromSuperadmin >>>>", e);
				} catch (JsonMappingException e) {
					LOG.error("In KafkaWorkerUpdateFromSuperadmin >>>>", e);
				} catch (IOException e) {
					LOG.error("In KafkaWorkerUpdateFromSuperadmin >>>>", e);
				}catch (Exception e) {
					LOG.error("In KafkaWorkerUpdateFromSuperadmin >>>>", e);
				}
		    }

}
