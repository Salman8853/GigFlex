package com.gigflex.prototype.microservices.worker.service;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.OrganizationConsume;


@Service
public class OrgConsumeKafkaService {
	
	
	private Organization organization;

	@Autowired
	WorkerService workerService;
	
	@Autowired
	OrganizationService orgService;
	
    private static final Logger LOG = LoggerFactory.getLogger(OrgConsumeKafkaService.class);


	@KafkaListener(topics = "NewOrganization")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			OrganizationConsume org = objectMapper.readValue(message, OrganizationConsume.class);
			LOG.info("received message='{}'", org.getOrganizationName());
			LOG.info("received message='{}'", org.getOrganizationCode());
			LOG.info("received message='{}'", org.getIsActive());
			organization = new Organization();
			organization.setOrganizationName(org.getOrganizationName());
			organization.setOrganizationCode(org.getOrganizationCode());
			organization.setIsActive(org.getIsActive());
                        organization.setLang(org.getLang()!=null ? org.getLang().toString():null);
                        organization.setLat(org.getLat()!= null ? org.getLat().toString():null);
                        organization.setIsVerified(org.getIsVerified());
                        organization.setTimezone(org.getTimezone());
			orgService.saveOrganization(organization);
			
		} catch (JsonParseException e) {
			LOG.error("In OrgConsumeKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In OrgConsumeKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In OrgConsumeKafkaService >>>>", e);
		}catch (Exception e) {
			LOG.error("In OrgConsumeKafkaService >>>>", e);
		}
    }
}