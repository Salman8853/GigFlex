package com.gigflex.prototype.microservices.worker.service;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.OrganizationConsume;
import com.gigflex.prototype.microservices.worker.dtob.OrganizationConsumeFromOrganization;
import com.gigflex.prototype.microservices.worker.repository.OrganizationRepository;


@Service
public class OrgUpdateOfOrganizationConsumeKafkaService {
	
	
	private Organization organization;

	@Autowired
	WorkerService workerService;
	
	@Autowired
	OrganizationRepository organizationRepository;
	
    private static final Logger LOG = LoggerFactory.getLogger(OrgUpdateOfOrganizationConsumeKafkaService.class);


	@KafkaListener(topics = "UpdateOrganizationFromOrganization")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			OrganizationConsumeFromOrganization org = objectMapper.readValue(message, OrganizationConsumeFromOrganization.class);
			LOG.info("received message='{}'", org.getOrganizationName());
			LOG.info("received message='{}'", org.getOrganizationCode());
			LOG.info("received message='{}'", org.getIsActive());
			Organization orgRes=organizationRepository.findByOrganizationCode(org.getOrganizationCode());
                        if(orgRes!=null && orgRes.getId()>0)
                        {
                            orgRes.setIsActive(org.getIsActive());
                            orgRes.setIsVerified(org.getIsVerified());
                            orgRes.setLat(org.getLat());
                            orgRes.setLang(org.getLang());
                            orgRes.setIsDeleted(org.getIsDeleted());
                            orgRes.setTimezone(org.getTimezone());
//                            orgRes.setLang(org.getLang()!=null ?org.getLang().toString():null);
//                            orgRes.setLat(org.getLat()!=null ? org.getLat().toString():null);
                            orgRes.setOrganizationName(org.getOrganizationName());
                            organizationRepository.save(orgRes);
                        }
			
		} catch (JsonParseException e) {
			LOG.error("In OrgUpdateOfOrganizationConsumeKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In OrgUpdateOfOrganizationConsumeKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In OrgUpdateOfOrganizationConsumeKafkaService >>>>", e);
		}catch (Exception e) {
			LOG.error("In OrgUpdateOfOrganizationConsumeKafkaService >>>>", e);
		}
    }
}