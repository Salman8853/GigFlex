package com.gigflex.prototype.microservices.worker.service;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.OrganizationConsume;
import com.gigflex.prototype.microservices.worker.repository.OrganizationRepository;


@Service
public class OrgUpdateOfRegistrationConsumeKafkaService {
	
	
	
	@Autowired
	OrganizationRepository organizationRepository;
	
    private static final Logger LOG = LoggerFactory.getLogger(OrgUpdateOfRegistrationConsumeKafkaService.class);


	@KafkaListener(topics = "UpdateOrganization")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			OrganizationConsume org = objectMapper.readValue(message, OrganizationConsume.class);
			LOG.info("received message='{}'", org.getOrganizationName());
			LOG.info("received message='{}'", org.getOrganizationCode());
			LOG.info("received message='{}'", org.getIsActive());
			Organization orgRes=organizationRepository.findByOrganizationCode(org.getOrganizationCode());
                        if(orgRes!=null && orgRes.getId()>0)
                        {
                            orgRes.setIsActive(org.getIsActive());
                            orgRes.setIsVerified(org.getIsVerified());
                            orgRes.setLat(org.getLat());
                            orgRes.setLang(org.getLang());
                            orgRes.setIsDeleted(org.getIsDeleted());
//                            orgRes.setLang(org.getLang()!=null ? org.getLang().toString():null);
//                            orgRes.setLat(org.getLat()!= null ? org.getLat().toString():null);
                            orgRes.setOrganizationName(org.getOrganizationName());
                            orgRes.setTimezone(org.getTimezone());
                            organizationRepository.save(orgRes);
                        }
			
		} catch (JsonParseException e) {
			LOG.error("In OrgUpdateOfRegistrationConsumeKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In OrgUpdateOfRegistrationConsumeKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In OrgUpdateOfRegistrationConsumeKafkaService >>>>", e);
		}catch (Exception e) {
			LOG.error("In OrgUpdateOfRegistrationConsumeKafkaService >>>>", e);
		}
    }
}