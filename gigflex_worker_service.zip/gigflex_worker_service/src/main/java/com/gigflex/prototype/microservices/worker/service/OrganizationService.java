package com.gigflex.prototype.microservices.worker.service;

import java.util.List;
import java.util.Optional;

import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.OrganizationRequest;

public interface OrganizationService {
	
//	public List<Organization> getAllOrganization();
//	public Optional<Organization> getOrgById(long id);
//	public Organization saveOrganization(Organization organization);
//	public void deleteOrgById(long id);
	public String search(String search);
	public String findOrganizationByOrgCode(String organizationCode);
	public String getAllOrganizationByPage(int page, int limit);
	public String deleteByOrgCode(String organizationCode);
	public Organization saveOrganization(Organization organization);
	public String getAllOrganization();
	public String getOrgById(Long id);
	public String saveOrganization(OrganizationRequest organizationrqst, String ip);
	public String deleteOrgById(Long id);
    public String updateOrganization(Organization organization,Long id);
    public String softDeleteByOrgCode(String organizationCode);
    public String softMultipleDeleteByOrgCode(List<String> organizationCodeList);
}
