package com.gigflex.prototype.microservices.worker.service;

import java.util.List;

import com.gigflex.prototype.microservices.worker.dtob.WorkerLogoRequest;
import com.gigflex.prototype.microservices.worker.dtob.WorkerRequest;

/**
 * @author ajit.p
 *
 */
public interface WorkerService {

	public String search(String search);

	public String getAllWorkers();

	public String getAllWorkersByPage(int page, int limit);

	public String getWorkerById(Long id);

	public String saveWorker(WorkerRequest workerReq, String ip);

	public String deleteWorkerById(Long id);

	public String updateWorker(Long id, WorkerRequest workerReq, String ip);

	public String findWorkerByWorkerCode(String workerCode);

	public String deleteByWorkerCode(String workerCode);

	public String getOrganizationByWorkerCode(String workerCode);

	public String getOrganizationByWorkerCode(String workerCode, int page,
			int limit);

	public String updateWorkerLogoByWorkerCode(WorkerLogoRequest workerLogoReq,
			String workerCode, String ip);

	public String softDeleteByWorkerCode(String workerCode);

	public String softMultipleDeleteByWorkerCode(List<String> workerCodeList);
}