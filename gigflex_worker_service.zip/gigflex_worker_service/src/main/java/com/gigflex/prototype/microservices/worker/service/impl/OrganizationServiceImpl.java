package com.gigflex.prototype.microservices.worker.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.organization.search.OrgSpecificationsBuilder;
import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
//import com.gigflex.prototype.microservices.config.KafkaWorkerService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.approvalstatus.repository.WorkerApprovalStatusRepository;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.OrganizationRequest;
import com.gigflex.prototype.microservices.worker.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.worker.service.OrganizationService;

@Service
public class OrganizationServiceImpl implements OrganizationService {
	private static final Logger LOG = LoggerFactory
			.getLogger(OrganizationServiceImpl.class);

	@Autowired
	private OrganizationRepository orgRep;

	@Autowired
	WorkerRepository workerRepository;

	@Autowired
	KafkaService kafkaService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	WorkerApprovalStatusRepository wasRepository;

	@Override
	public String getAllOrganization() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Organization> orglst = orgRep.getAllOrganization();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Succes");
			jsonobj.put("timestamp", new Date());
			if (orglst != null && orglst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(orglst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getOrgById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization orglst = orgRep.getOrganizationById(id);
			if (orglst != null && orglst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				if (orglst != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(orglst);
					jsonobj.put("data", new JSONObject(Detail));
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveOrganization(OrganizationRequest organizationrqst,
			String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization org = new Organization();
			org.setOrganizationName(organizationrqst.getOrganizationName());
			org.setIpAddress(ip);
			org.setIsActive(organizationrqst.getIsActive());
			org.setIsVerified(organizationrqst.getIsVerified());
			org.setLang(organizationrqst.getLang());
			org.setLat(organizationrqst.getLat());
			org.setOrganizationCode(organizationrqst.getOrganizationCode());
			Organization orgRes = orgRep.save(org);
			jsonobj.put("responsecode", 200);
			jsonobj.put("timestamp", new Date());
			if (orgRes != null && orgRes.getId() > 0) {
				// kafkaService.sendDepartment(deptRes);
				jsonobj.put("message",
						"Organization has been added successfully.");
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(orgRes);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("message", "Failed");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String deleteOrgById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<Organization> orglst = orgRep.findById(id);
			if (orglst.isPresent() && orglst.get() != null) {
				Organization org = orglst.get();
				orgRep.deleteById(id);
				kafkaService.sendDeleteOrganization(org);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Organization has been deleted.");
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
			}
			jsonobj.put("timestamp", new Date());
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	// @Override
	// public List<Organization> getAllOrganization() {
	// List<Organization> orgList = orgRep.findAll();
	// return orgList;
	// }
	//
	// @Override
	// public Optional<Organization> getOrgById(long id) {
	// return orgRep.findById(id);
	// }
	//
	// @Override
	// public Organization saveOrganization(Organization organization) {
	// return orgRep.save(organization);
	// }
	//
	// @Override
	// public void deleteOrgById(long id) {
	// orgRep.deleteById(id);
	//
	// }

	@Override
	public String updateOrganization(Organization organization, Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && organization != null) {
				if (organization.getOrganizationName() != null
						&& organization.getOrganizationName().length() > 0) {
					Organization orglst = orgRep.getOrganizationById(id);
					if (orglst != null && orglst.getId() > 0) {
						Organization org = orglst;

						org.setOrganizationName(organization
								.getOrganizationName());
						org.setLat(organization.getLat());
						org.setLang(organization.getLang());
						org.setIsActive(organization.getIsActive());
						org.setIpAddress(organization.getIpAddress());
						org.setIsVerified(organization.getIsVerified());

						org.setUpdatedAt(organization.getUpdatedAt());
						org.setCreatedAt(organization.getCreatedAt());
                                                org.setTimezone(organization.getTimezone());
						Organization orgRes = orgRep.save(org);
						if (orgRes != null && orgRes.getId() > 0) {
							kafkaService.sendUpdateOrganization(orgRes);
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"Organization updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(orgRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Organization updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Organization ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Organization Name can not be blank");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public Organization saveOrganization(Organization organization) {
		return orgRep.save(organization);
	}

	@Override
	public String findOrganizationByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization orglst = orgRep
					.findByOrganizationCode(organizationCode);
			if (orglst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(orglst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization org = orgRep.findByOrganizationCode(organizationCode);
			Integer deleteByOrgCode = orgRep
					.deleteOrganizationrByOrganizationCode(organizationCode);

			if (deleteByOrgCode != 0 && org != null && org.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Organization has been deleted.");
				jsonobj.put("timestamp", new Date());
				kafkaService.sendDeleteOrganization(org);
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization org = orgRep.findByOrganizationCode(organizationCode);
			if (org != null && org.getId() > 0) {
				org.setIsDeleted(true);
				Organization orgDataRes = orgRep.save(org);
				if (orgDataRes != null && orgDataRes.getId() > 0) {

					// List<WorkerApprovalStatus> wasList =
					// wasRepository.findAllWorkerApprovalStatusByOrgCode(organizationCode);
					// for(WorkerApprovalStatus wasFind : wasList){
					//
					// List<WorkerApprovalStatus> wasByWorkerList =
					// wasRepository.findAllWASByWorkerAndOrgCode(wasFind.getWorkerCode(),organizationCode);
					// if(wasByWorkerList == null || wasByWorkerList.size() ==
					// 0){
					//
					//
					//
					// Worker worker1 =
					// workerRepository.findByWorkerCode(wasFind.getWorkerCode());
					// Users user1 =
					// userRepository.findByUserCode(wasFind.getWorkerCode());
					//
					// if (worker1 != null && worker1.getId() > 0 ) {
					// worker1.setIsDeleted(true);
					// Worker wrkRes1 = workerRepository.save(worker1);
					// kafkaService.sendUpdateWorker(wrkRes1);
					// }if( user1 != null && user1.getId() > 0){
					// user1.setIsDeleted(true);
					// Users userRes1 = userRepository.save(user1);
					// kafkaService.sendUpdateUser(userRes1);
					//
					// }
					// }
					// wasFind.setIsDeleted(true);
					// WorkerApprovalStatus wasRes1 =
					// wasRepository.save(wasFind);
					// kafkaService.sendUpdateWAS(wasRes1);
					//
					// }

					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Organization deleted successfully.");
					kafkaService.sendUpdateOrganization(orgDataRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteByOrganizationCode>>>>>>", ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteByOrganizationCode>>>>>>", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByOrgCode(List<String> organizationCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String organizationCode : organizationCodeList) {
				if (organizationCode != null
						&& organizationCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					organizationCode = organizationCode.trim();

					Organization org = orgRep
							.findByOrganizationCode(organizationCode);

					if (org != null && org.getId() > 0) {
						try {
							org.setIsDeleted(true);
							Organization orgDataRes = orgRep.save(org);
							if (orgDataRes != null && orgDataRes.getId() > 0) {

								// List<WorkerApprovalStatus> wasList =
								// wasRepository.findAllWorkerApprovalStatusByOrgCode(organizationCode);
								// for(WorkerApprovalStatus wasFind : wasList){
								//
								// List<WorkerApprovalStatus> wasByWorkerList =
								// wasRepository.findAllWASByWorkerAndOrgCode(wasFind.getWorkerCode(),organizationCode);
								// if(wasByWorkerList == null ||
								// wasByWorkerList.size() == 0){
								//
								//
								//
								// Worker worker1 =
								// workerRepository.findByWorkerCode(wasFind.getWorkerCode());
								// Users user1 =
								// userRepository.findByUserCode(wasFind.getWorkerCode());
								//
								// if (worker1 != null && worker1.getId() > 0 )
								// {
								// worker1.setIsDeleted(true);
								// Worker wrkRes1 =
								// workerRepository.save(worker1);
								// kafkaService.sendUpdateWorker(wrkRes1);
								// }if( user1 != null && user1.getId() > 0){
								// user1.setIsDeleted(true);
								// Users userRes1 = userRepository.save(user1);
								// kafkaService.sendUpdateUser(userRes1);
								//
								// }
								// }
								// wasFind.setIsDeleted(true);
								// WorkerApprovalStatus wasRes1 =
								// wasRepository.save(wasFind);
								// kafkaService.sendUpdateWAS(wasRes1);
								//
								// }
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", organizationCode);
								jsonobj.put("message",
										"Organization deleted successfully.");
								kafkaService.sendUpdateOrganization(orgDataRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", organizationCode);
								jsonobj.put("message", "Failed");
							}
						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", organizationCode);
							jsonobj.put("message", GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", organizationCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllOrganizationByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Organization> org = orgRep.getAllOrganization(pageableRequest);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (org != null && org.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(org);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				OrgSpecificationsBuilder builder = new OrgSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<Organization> spec = builder.build();
				if (spec != null) {
					List<Organization> orglst = orgRep.findAll(spec);
					if (orglst != null && orglst.size() > 0) {
						for (Organization org : orglst) {
							if (org.getIsDeleted() != null
									&& org.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(org);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("organization", new JSONObject(
										Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
