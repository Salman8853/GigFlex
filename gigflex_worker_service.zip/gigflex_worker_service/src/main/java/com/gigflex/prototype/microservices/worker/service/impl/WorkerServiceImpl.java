package com.gigflex.prototype.microservices.worker.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.approvalstatus.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.worker.approvalstatus.repository.WorkerApprovalStatusRepository;
import com.gigflex.prototype.microservices.worker.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.dtob.WorkerApprovalStatusResponse;
import com.gigflex.prototype.microservices.worker.dtob.WorkerLogoRequest;
import com.gigflex.prototype.microservices.worker.dtob.WorkerOffdays;
import com.gigflex.prototype.microservices.worker.dtob.WorkerRequest;
import com.gigflex.prototype.microservices.worker.dtob.WorkerResponse;
import com.gigflex.prototype.microservices.worker.dtob.WorkerWorkingHours;
import com.gigflex.prototype.microservices.worker.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.worker.search.WorkerSpecificationsBuilder;
import com.gigflex.prototype.microservices.worker.service.WorkerOffdaysService;
import com.gigflex.prototype.microservices.worker.service.WorkerService;
import com.gigflex.prototype.microservices.worker.service.WorkerWorkingHoursService;

/**
 * 
 * @author ajit.p
 *
 */
@Service
public class WorkerServiceImpl implements WorkerService {

	private static final Logger LOG = LoggerFactory
			.getLogger(WorkerServiceImpl.class);

	@Autowired
	WorkerRepository workerRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	WorkerApprovalStatusRepository wasRepository;

	@Autowired
	OrganizationRepository orgRepository;

	@Autowired
	WorkerOffdaysService workerOffdaysservice;

	@Autowired
	WorkerWorkingHoursService workerWorkingHourService;
	@Autowired
	KafkaService kafkaService;

	private static final Logger logger = LoggerFactory.getLogger(Worker.class);

	@Override
	public String getAllWorkers() {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//
//			List<Object> objlst = workerRepository.getAllWorkersWithApprovedAndId();
//			List<WorkerResponse> maplst = new ArrayList<WorkerResponse>();
//			if (objlst != null && objlst.size() > 0) {
//				for (int i = 0; i < objlst.size(); i++) {
//					Object[] arr = (Object[]) objlst.get(i);
//					if (arr.length >= 3) {
//						WorkerResponse workerInDb = new WorkerResponse();
//
//						Worker data = (Worker) arr[0];
//
//						workerInDb.setId(data.getId());
//						workerInDb.setWorkerCode(data.getWorkerCode());
//						workerInDb.setName(data.getName());
//						workerInDb.setEmail(data.getEmail());
//						workerInDb.setDepartmentCode(data.getDepartmentCode());
//						workerInDb.setPhone(data.getPhone());
//						workerInDb.setExpYear(data.getExpYear());
//						workerInDb.setExpMonth(data.getExpMonth());
//						workerInDb.setExpDays(data.getExpDays());
//						workerInDb.setQualification(data.getQualification());
//						workerInDb.setExternalEmpCode(data.getExternalEmpCode());
//						workerInDb.setPreWorkingHours(data.getPreWorkingHours());
//						workerInDb.setIsActive(data.getIsActive());
//						workerInDb.setWorkerStatusCode(data.getWorkerStatusCode());
//						workerInDb.setWorkerLogo(data.getWorkerLogo());
//						
//						workerInDb.setWorkApprovalStatusId((Long) arr[1]);
//
//						workerInDb.setIsApproved((Boolean) arr[2]);
//
//						maplst.add(workerInDb);
//
//					}
//				}
//				if (maplst.size() > 0) {
//					ObjectMapper mapperObj = new ObjectMapper();
//					String Detail = mapperObj.writeValueAsString(maplst);
//					jsonobj.put("responsecode", 200);
//					jsonobj.put("message", "Success");
//					jsonobj.put("timestamp", new Date());
//					jsonobj.put("data", new JSONArray(Detail));
//				} else {
//					jsonobj.put("responsecode", 404);
//					jsonobj.put("message", "Record Not Found");
//					jsonobj.put("timestamp", new Date());
//				}
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Record Not Found");
//				jsonobj.put("timestamp", new Date());
//			}
//
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		}
//		return res;
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerResponse> maplst = new ArrayList<WorkerResponse>();

			List<Worker> workerlst = workerRepository.getAllWorkers();
			
			if (workerlst != null && workerlst.size() > 0) {
				for(Worker worker : workerlst){

					List<Object> wasList = workerRepository.findWorkerApprovalStatusByWorkerCode(worker.getWorkerCode());
					if (wasList != null && wasList.size() > 0) {
						
						WorkerResponse workerInDb = new WorkerResponse();
						workerInDb.setWorker(worker);
						List<WorkerApprovalStatusResponse> waslst = new ArrayList<WorkerApprovalStatusResponse>();
						for (int i = 0; i < wasList.size(); i++) {
							Object[] arr = (Object[]) wasList.get(i);
							if (arr.length >= 2) {
								WorkerApprovalStatus was = (WorkerApprovalStatus) arr[0];
							WorkerApprovalStatusResponse wasr = new WorkerApprovalStatusResponse();
							wasr.setIsApproved(was.getIsApproved());
							wasr.setWorkApprovalStatusId(was.getId());
						    wasr.setOrganizationCode(was.getOrganization_Code());
						    wasr.setOrganizationName((String) arr[1]);

						    waslst.add(wasr);
							
						}
						workerInDb.setWorkerApprovalStatusResponseList(waslst);
						maplst.add(workerInDb);
					}
				}
				if(maplst.size() > 0){
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());
			}
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in getAllWorkers.");
			res = derr.toString();
		}
		logger.info("Output is" + res);
		return res;
	}

	@Override
	public String getWorkerById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Worker workerData = workerRepository.getWorkerById(id);
			if (workerData != null && workerData.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerData);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveWorker(WorkerRequest workerReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (workerReq != null) {
				Worker workerInDb = new Worker();

				workerInDb.setName(workerReq.getName());
				workerInDb.setEmail(workerReq.getEmail());
				workerInDb.setDepartmentCode(workerReq.getDepartmentCode());
				workerInDb.setPhone(workerReq.getPhone());
				workerInDb.setExpYear(workerReq.getExpYear());
				workerInDb.setExpMonth(workerReq.getExpMonth());
				workerInDb.setExpDays(workerReq.getExpDays());
				workerInDb.setQualification(workerReq.getQualification());
				workerInDb.setExternalEmpCode(workerReq.getExternalEmpCode());
				workerInDb.setPreWorkingHours(workerReq.getPreWorkingHours());
				workerInDb.setIsActive(workerReq.getIsActive());
				workerInDb.setWorkerStatusCode(workerReq.getWorkerStatusCode());
				workerInDb.setIpAddress(ip);
				workerInDb.setWorkerLogo(workerReq.getWorkerLogo());

				Worker workerResponse = workerRepository.save(workerInDb);

				if (workerResponse != null && workerResponse.getId() > 0) {
					WorkerOffdays workOffdays = new WorkerOffdays();
					WorkerWorkingHours workWorkingHours = new WorkerWorkingHours();
					workOffdays.setWorkerCode(workerResponse.getWorkerCode());
					workerOffdaysservice.saveWorkerOffdays(workOffdays);
					workWorkingHours.setWorkerCode(workerResponse
							.getWorkerCode());
					workerWorkingHourService
							.saveWorkerWorkingHours(workWorkingHours);
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Worker has been added successfully.");
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj
							.writeValueAsString(workerResponse);
					jsonobj.put("data", new JSONObject(Detail));
					kafkaService.sendAddWorker(workerResponse);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Worker has been not added successfully.");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();

		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in Worker table.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String deleteWorkerById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<Worker> workerData = workerRepository.findById(id);
			if (workerData.isPresent() && workerData.get() != null) {
				workerRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker has been deleted.");
				kafkaService.sendDeleteWorker(workerData.get());
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
			}
			jsonobj.put("timestamp", new Date());
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in Worker table.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String updateWorker(Long id, WorkerRequest workerReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			Worker workerlst = workerRepository.getWorkerById(id);
			if (workerlst != null && workerlst.getId() > 0) {
				Worker workerInDb = workerlst;

				workerInDb.setName(workerReq.getName());
				workerInDb.setEmail(workerReq.getEmail());
				workerInDb.setDepartmentCode(workerReq.getDepartmentCode());
				workerInDb.setPhone(workerReq.getPhone());
				workerInDb.setExpYear(workerReq.getExpYear());
				workerInDb.setExpMonth(workerReq.getExpMonth());
				workerInDb.setExpDays(workerReq.getExpDays());
				workerInDb.setQualification(workerReq.getQualification());
				workerInDb.setExternalEmpCode(workerReq.getExternalEmpCode());
				workerInDb.setPreWorkingHours(workerReq.getPreWorkingHours());
				workerInDb.setIsActive(workerReq.getIsActive());
				workerInDb.setWorkerStatusCode(workerReq.getWorkerStatusCode());
				workerInDb.setIpAddress(ip);
				workerInDb.setWorkerLogo(workerReq.getWorkerLogo());

				Worker workerData = workerRepository.save(workerInDb);
				if (workerData != null) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Worker updated successfully");
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(workerData);
					jsonobj.put("data", new JSONObject(Detail));
					kafkaService.sendUpdateWorker(workerData);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Worker is not updated successfully");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker is not found for update");
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in Worker table.");
			res = derr.toString();
		}
		return res;

	}

	@Override
	public String findWorkerByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Worker workerlst = workerRepository.findByWorkerCode(workerCode);
			if (workerlst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerlst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Worker worker = workerRepository.findByWorkerCode(workerCode);
			Integer deleteByWorkerCode = workerRepository
					.deleteByWorkerCode(workerCode);
			if (deleteByWorkerCode != 0 && worker != null && worker.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker has been deleted.");
				jsonobj.put("timestamp", new Date());
				kafkaService.sendDeleteWorker(worker);
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getOrganizationByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerCode != null && workerCode.trim().length() > 0) {
				List<Object> workerlst = workerRepository
						.getOrganizationByWorkerCode(workerCode);
				if (workerlst != null && workerlst.size() > 0) {
					JSONArray jarr = new JSONArray();
					int cnt = 0;
					for (int i = 0; i < workerlst.size(); i++) {
						Object arr[] = (Object[]) workerlst.get(i);
						if (arr.length >= 2) {
							cnt++;
							JSONObject jSONObject = new JSONObject();
							jSONObject.put("organizationCode",
									arr[0].toString());
							jSONObject.put("organizationName",
									arr[1].toString());
							jarr.add(jSONObject);
						}
					}
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Success");
					jsonobj.put("organizationCount", cnt);
					jsonobj.put("data", jarr);

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Code should not be blank.");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateWorkerLogoByWorkerCode(WorkerLogoRequest workerLogoReq,
			String workerCode, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerLogoReq != null) {
				if (workerLogoReq.getWorkerLogo() != null
						&& workerLogoReq.getWorkerLogo().length() > 0) {
					Worker worker = workerRepository
							.findByWorkerCode(workerCode);
					if (worker != null) {

						worker.setWorkerLogo(workerLogoReq.getWorkerLogo());
						worker.setIpAddress(ip);

						Worker workerRes = workerRepository.save(worker);
						if (workerRes != null && workerRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"Worker Logo updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(workerRes);
							jsonobj.put("data", new JSONObject(Detail));
							// kafkaService.sendUpdateOrganization(workerRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Worker Logo updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Worker Code is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Worker Logo should not be blank");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByWorkerCode(String workerCode) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Worker worker = workerRepository.findByWorkerCode(workerCode);
			if (worker != null && worker.getId() > 0) {

				Users user = userRepository.findByUserCode(workerCode);
				if (user != null && user.getId() > 0
						&& user.getIsOwner() == true) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Owner should not be deleted");

				} else {

					worker.setIsDeleted(true);
					Worker wrkRes = workerRepository.save(worker);

					if (wrkRes != null && wrkRes.getId() > 0) {

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Worker deleted successfully.");
						kafkaService.sendUpdateWorker(wrkRes);
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteByWorkerCode>>>>>>", ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteByWorkerCode>>>>>>", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByWorkerCode(List<String> workerCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String workerCode : workerCodeList) {
				if (workerCode != null && workerCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					workerCode = workerCode.trim();

					Worker worker = workerRepository
							.findByWorkerCode(workerCode);

					if (worker != null && worker.getId() > 0) {

						try {

							Users user = userRepository
									.findByUserCode(workerCode);
							if (user != null && user.getId() > 0
									&& user.getIsOwner() == true) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", workerCode);
								jsonobj.put("message",
										"Owner should not be deleted");

							} else {
								worker.setIsDeleted(true);
								Worker wrkRes = workerRepository.save(worker);
								if (wrkRes != null && wrkRes.getId() > 0) {
									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("code", workerCode);
									jsonobj.put("message",
											"Worker deleted successfully.");
									kafkaService.sendUpdateWorker(wrkRes);
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("code", workerCode);
									jsonobj.put("message", "Failed");
								}
							}

						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", workerCode);
							jsonobj.put("message", GigUtil.getRootException(ex));
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", workerCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllWorkersByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerResponse> maplst = new ArrayList<WorkerResponse>();

			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Worker> workerlst = workerRepository
					.getAllWorkers(pageableRequest);
			if (workerlst != null && workerlst.size() > 0) {
				for(Worker worker : workerlst){

					List<Object> wasList = workerRepository.findWorkerApprovalStatusByWorkerCode(worker.getWorkerCode());
					if (wasList != null && wasList.size() > 0) {
						
						WorkerResponse workerInDb = new WorkerResponse();
						workerInDb.setWorker(worker);
						List<WorkerApprovalStatusResponse> waslst = new ArrayList<WorkerApprovalStatusResponse>();
						for (int i = 0; i < wasList.size(); i++) {
							Object[] arr = (Object[]) wasList.get(i);
							if (arr.length >= 2) {
								WorkerApprovalStatus was = (WorkerApprovalStatus) arr[0];
							WorkerApprovalStatusResponse wasr = new WorkerApprovalStatusResponse();
							wasr.setIsApproved(was.getIsApproved());
							wasr.setWorkApprovalStatusId(was.getId());
						    wasr.setOrganizationCode(was.getOrganization_Code());
						    wasr.setOrganizationName((String) arr[1]);

						    waslst.add(wasr);
							
						}
						workerInDb.setWorkerApprovalStatusResponseList(waslst);
						maplst.add(workerInDb);
					}
				}
				if(maplst.size() > 0){
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());
			}
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred in getAllWorkers.");
			res = derr.toString();
		}
		logger.info("Output is" + res);
		return res;
	}

	@Override
	public String getOrganizationByWorkerCode(String workerCode, int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (workerCode != null && workerCode.trim().length() > 0) {
				List<Object> workerlst = workerRepository
						.getOrganizationByWorkerCode(workerCode,
								pageableRequest);
				if (workerlst != null && workerlst.size() > 0) {
					JSONArray jarr = new JSONArray();
					int cnt = 0;
					for (int i = 0; i < workerlst.size(); i++) {
						Object arr[] = (Object[]) workerlst.get(i);
						if (arr.length >= 2) {
							cnt++;
							JSONObject jSONObject = new JSONObject();
							jSONObject.put("organizationCode",
									arr[0].toString());
							jSONObject.put("organizationName",
									arr[1].toString());
							jarr.add(jSONObject);
						}
					}
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Success");
					jsonobj.put("organizationCount", cnt);
					jsonobj.put("data", jarr);

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Code should not be blank.");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				WorkerSpecificationsBuilder builder = new WorkerSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<Worker> spec = builder.build();
				if (spec != null) {
					List<Worker> workerlst = workerRepository.findAll(spec);
					if (workerlst != null && workerlst.size() > 0) {
						for (Worker worker : workerlst) {
							if (worker.getIsDeleted() != null
									&& worker.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(worker);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew
										.put("worker", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
