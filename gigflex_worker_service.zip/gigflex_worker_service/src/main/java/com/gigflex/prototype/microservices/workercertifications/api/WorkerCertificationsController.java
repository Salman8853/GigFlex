package com.gigflex.prototype.microservices.workercertifications.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertificationsRequest;
import com.gigflex.prototype.microservices.workercertifications.service.WorkerCertificationsService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/workerservice/")
public class WorkerCertificationsController {
	
	@Autowired
	private WorkerCertificationsService workerCertificationsService;
	
	
	@GetMapping("/workerCertifications/{search}")
	public String search(@PathVariable("search") String search) {
		return workerCertificationsService.search(search);
	}
	
        @GetMapping("/getWorkerCertificationsByWorkerCode/{workerCode}")
	public String getWorkerCertificationsByWorkerCode(@PathVariable("workerCode") String workerCode){
	if(workerCode!=null && workerCode.trim().length()>0)	
        {
            return workerCertificationsService.getWorkerCertificationsByWorkerCode(workerCode.trim());
        }
        else
        {
             GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker code should not be blank.");
	           return derr.toString();
        }
	}
	

	@GetMapping(path="/getWorkerCertificationsByWorkerCodeByPage/{workerCode}")
    public String getWorkerCertificationsByWorkerCodeByPage(@PathVariable("workerCode") String workerCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
if(workerCode!=null && workerCode.trim().length()>0)	
        {
        return workerCertificationsService.getWorkerCertificationsByWorkerCodeByPage(workerCode.trim(),page, limit);
      }
        else
        {
             GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker code should not be blank.");
	           return derr.toString();
        }
       
    }
        
	@GetMapping("/getAllWorkerCertifications")
	public String getAllWorkerCertifications(){
		return workerCertificationsService.findAllWorkerCertifications();
	}
	

	@GetMapping(path="/getAllWorkerCertificationsByPage")
    public String getAllWorkerCertificationsByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String wc = workerCertificationsService.getAllWorkerCertificationsByPage(page, limit);
      
        return wc;
       
    }
	
	@GetMapping(path="/getAllWorkerCertificationsWithNamesByPage")
    public String getAllWorkerCertificationsWithNamesByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

		 String wc = workerCertificationsService.geAllWorkerCertificationsWithNamesByPage(page, limit);
	      
	        return wc;
       
    }
	
	@GetMapping("/getAllWorkerCertificationsWithNames")
	public String getAllWorkerCertificationsWithNames(){
		return workerCertificationsService.getAllWorkerCertificationsWithNames();
	}
	
	@GetMapping("/getWorkerCertifications/{id}")
    public String getWorkerCertificationsById(@PathVariable Long id){
  	    return workerCertificationsService.findWorkerCertificationsById(id);
    }
	
	@PostMapping("/saveWorkerCertifications")
    public String saveNewWorkerCertifications(@RequestBody WorkerCertificationsRequest workerCertiReq, HttpServletRequest request){
  	    String ip=request.getRemoteAddr();
  	   return workerCertificationsService.saveWorkerCertifications(workerCertiReq, ip);
  	
    }
	
    @DeleteMapping("/deleteWorkerCertifications/{id}")
    public String deleteWorkerCertificationsById(@PathVariable Long id){
    	return workerCertificationsService.deleteWorkerCertificationsById(id);
    }
    
    @DeleteMapping("/softDeleteWorkerCertifications/{id}")
    public String softDeleteWorkerCertificationsById(@PathVariable Long id){
    	return workerCertificationsService.softDeleteWorkerCertificationsById(id);
    }
    
    @DeleteMapping("/softMultipleDeleteWorkerCertificationsById/{idList}")
	public String softMultipleDeleteWorkerCertificationsById(@PathVariable("idList") List<Long> idList) {
		if(idList != null && idList.size()>0){
			return workerCertificationsService.softMultipleDeleteById(idList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
	}
    
    @PutMapping("/updateWorkerCertifications/{id}")
 		public String updateWorkerCertificationsById(@PathVariable Long id,@RequestBody WorkerCertificationsRequest workerCertiReq,
 				HttpServletRequest request) {
    	
    	if (id == null) {
 				return "PermissionsActivities with Id : (" + id + ") Not found.";
 			} else {
                 String ip = request.getRemoteAddr();
 				 return workerCertificationsService.updateWorkerCertificationsById(id, workerCertiReq, ip);
 				
 			}
 			
 		}

}



