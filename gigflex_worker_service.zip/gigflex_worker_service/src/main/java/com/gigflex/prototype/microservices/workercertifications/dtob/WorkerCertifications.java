package com.gigflex.prototype.microservices.workercertifications.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import javax.persistence.GenerationType;


@Entity
@Table (name="worker_certifications")
public class WorkerCertifications extends CommonAttributes implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private Long id;
	
	@Column(name = "certification_code", unique = true, nullable = false)
	private String certificationCode;
	
	@Column(name = "worker_code", unique = true, nullable = false)
	private String workerCode;

	public WorkerCertifications(){}
	
	public WorkerCertifications(Long id, String certificationCode,
			String workerCode) {
		super();
		this.id = id;
		this.certificationCode = certificationCode;
		this.workerCode = workerCode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCertificationCode() {
		return certificationCode;
	}

	public void setCertificationCode(String certificationCode) {
		this.certificationCode = certificationCode;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}
	
	
	
	

}
