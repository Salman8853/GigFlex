package com.gigflex.prototype.microservices.workercertifications.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.util.SearchCriteria;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;


public class WorkerCertificationsSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public WorkerCertificationsSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public WorkerCertificationsSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<WorkerCertifications> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<WorkerCertifications>> specs = new ArrayList<Specification<WorkerCertifications>>();
        for (SearchCriteria param : params) {
            specs.add(new WorkerCertificationsSpecification(param));
        }
 
        Specification<WorkerCertifications> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
