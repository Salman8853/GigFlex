package com.gigflex.prototype.microservices.workerpreferredlocation.dtob;

import java.util.List;

public class Location {
	
	private String location;
    
	private String lat;
	
	private String lang;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}
	
	

}
