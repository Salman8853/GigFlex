package com.gigflex.prototype.microservices.workerworkinghours.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.util.SearchCriteria;
import com.gigflex.prototype.microservices.worker.dtob.WorkerWorkingHours;



public class WorkerWorkingHoursSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public WorkerWorkingHoursSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public WorkerWorkingHoursSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<WorkerWorkingHours> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<WorkerWorkingHours>> specs = new ArrayList<Specification<WorkerWorkingHours>>();
        for (SearchCriteria param : params) {
            specs.add(new WorkerWorkingHoursSpecification(param));
        }
 
        Specification<WorkerWorkingHours> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
