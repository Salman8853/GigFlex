/**
 * 
 */
package com.gigflex.prototype.microservices.workinglocation.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;

@Repository
public interface WorkingLocationRepository extends
		JpaRepository<WorkingLocation, Long> {

	@Query("SELECT wl FROM WorkingLocation wl WHERE wl.isDeleted != TRUE AND wl.organizationCode = :organizationCode")
	public List<WorkingLocation> getWorkingLocationByOrganizationCode(
			@Param("organizationCode") String organizationCode);

	@Transactional
	public Integer deleteWorkingLocationByOrganizationCode(
			String organizationCode);

	@Query("SELECT wl FROM WorkingLocation wl WHERE wl.isDeleted != TRUE")
	public List<WorkingLocation> getAllWorkingLocation();

	@Query("SELECT wl FROM WorkingLocation wl WHERE wl.isDeleted != TRUE")
	public List<WorkingLocation> getAllWorkingLocation(Pageable pageableRequest);

	@Query("SELECT wl FROM WorkingLocation wl WHERE wl.isDeleted != TRUE AND wl.id = :id")
	public WorkingLocation getWorkingLocationById(@Param("id") Long id);

	@Query("SELECT wl FROM WorkingLocation wl WHERE wl.isDeleted != TRUE AND wl.workingLocationCode = :workingLocationCode")
	public WorkingLocation findByWorkingLocationCode(
			@Param("workingLocationCode") String workingLocationCode);

	@Query("SELECT wl FROM WorkingLocation wl WHERE wl.isDeleted != TRUE AND wl.lat = :lat AND wl.lang = :lang AND wl.organizationCode =:organizationCode")
	public WorkingLocation getWorkingLocationByLatLangAndOrgCode(
			@Param("lat") String lat, @Param("lang") String lang,
			@Param("organizationCode") String organizationCode);

	@Query("SELECT wl FROM WorkingLocation wl WHERE wl.isDeleted != TRUE AND wl.id != :id AND wl.lat = :lat AND wl.lang = :lang AND wl.organizationCode =:organizationCode")
	public WorkingLocation getWorkingLocationByIdLatLangAndOrgCode(
			@Param("id") Long id, @Param("lat") String lat,
			@Param("lang") String lang,
			@Param("organizationCode") String organizationCode);
}
