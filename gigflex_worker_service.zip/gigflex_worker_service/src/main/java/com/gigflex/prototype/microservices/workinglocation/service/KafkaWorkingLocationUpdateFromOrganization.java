/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workinglocation.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.workinglocation.repository.WorkingLocationRepository;

@Service
public class KafkaWorkingLocationUpdateFromOrganization {
	private WorkingLocation workingLocation;

	@Autowired
	WorkingLocationRepository workingLocationRepository;

	private static final Logger LOG = LoggerFactory
			.getLogger(KafkaWorkingLocationUpdateFromOrganization.class);

	@KafkaListener(topics = "UpdateWorkingLocationFromOrganization")
	public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			WorkingLocation workLoc = objectMapper.readValue(message,
					WorkingLocation.class);
			// workingLocation = workingLocationRepository
			// .getWorkingLocationByIdLatLangAndOrgCode(workLoc.getId(),
			// workLoc.getLat(), workLoc.getLang(),
			// workLoc.getOrganizationCode());
			workingLocation = workingLocationRepository
					.findByWorkingLocationCode(workLoc.getWorkingLocationCode());

			if (workingLocation != null && workingLocation.getId() > 0) {

				workingLocation.setLocation(workLoc.getLocation());
				workingLocation.setLat(workLoc.getLat());
				workingLocation.setLang(workLoc.getLang());
				workingLocation.setIsactive(workLoc.isIsactive());
				workingLocation.setOrganizationCode(workLoc
						.getOrganizationCode());
				workingLocation.setIsDeleted(workLoc.getIsDeleted());
				workingLocation.setTimeZone(workLoc.getTimeZone());

				workingLocationRepository.save(workingLocation);
			}

		} catch (JsonParseException e) {
			LOG.error("In KafkaWorkingLocationUpdateFromOrganization >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaWorkingLocationUpdateFromOrganization >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaWorkingLocationUpdateFromOrganization >>>>", e);
		} catch (Exception e) {
			LOG.error("In KafkaWorkingLocationUpdateFromOrganization >>>>", e);
		}
	}
}
